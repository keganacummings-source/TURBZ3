# TURBZ world and combat update

## World layout
- Rebuilt the global map as a large, irregular central continent with surrounding Verdant, Tide, Frost, Ashen, Void and Crypt landmasses.
- Repositioned every global region and remapped existing map-space NPCs, vendors, shrines, resource areas and other landmarks with their zones.
- Added dedicated causeways from the main continent to each surrounding landmass; nearby region joins remain narrow, naturally-winding land connections.
- Crownfall's six capital regions now sit in the southwest and its castle/courtyard geometry is enlarged in the global tile coordinate system.

## Art assets and licensing
- This update uses the existing 32×32 monster images bundled in `assets/ghosts/`; sprite rendering fits images within a square footprint while preserving aspect ratio. No new external artwork binary was downloaded or embedded in this build environment, and no existing art files were overwritten. The current 284 ghost PNGs remain 32×32 and render with aspect-ratio preservation. For the next art pass, the following relevant OpenGameArt submissions were verified as CC0: [Assorted 32x32 creatures](https://opengameart.org/content/assorted-32x32-creatures) by AndHeGames and [More assorted 32x32 creatures](https://opengameart.org/content/more-assorted-32x32-creatures) by AndHeGames. The container could not download their source binaries, so those sprites are not claimed as bundled or used in this update.
- OpenGameArt's [CC0 Resources collection](https://opengameart.org/content/cc0-resources) is an appropriate sourcing catalog for later assets. When a new asset is imported, keep a source URL and license in this document. The `assets/ghosts/` pack should be credited to its original authors if/when its exact source is confirmed; the code does not claim every bundled PNG is CC0.

## Update notes
See this document's companion `CHANGELOG_WORLD_COMBAT.md` for gameplay and combat changes.

## Additional NPC / ghost sprite references researched
- [NPC and Enemies](https://opengameart.org/content/npc-and-enemies-0) — Refo, CC0.
- [Ghost Sprite](https://opengameart.org/content/ghost-sprite) — ChiliGames, CC0.
- [CC0 Resources](https://opengameart.org/content/cc0-resources) — OpenGameArt CC0 resource catalog.

These listings were verified during the update, but binary downloads were not available from this environment. The project therefore uses the original local sprite definitions and new self-contained fallback assets; these references are not asserted to be embedded in this release. Keep the original license/author notice when importing assets from those pages later.

## Included improvements
- Added hand-authored palette sprites for the 112-resident TownNPC roster and a ghoul fallback definition.
- Verified that all 189 distinct `imageSprite` filenames used in source are present under `assets/ghosts/` (284 PNG files bundled).
- Added project-authored environment tiles for forest stands, lake shores, ruin floors/walls, and mountain switchback features.
