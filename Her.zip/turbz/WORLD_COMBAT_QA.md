> Historical note for the current peer-hosted build: references to cloud save/load below describe an earlier version. The cloud backend was removed from this release; all saves now remain local and multiplayer saves are world/player-isolated.

# TURBZ world/combat update — QA notes

## Automated checks executed

- Source structure: checked all Lua/Kyo files for balanced delimiters and Lua function/`if`/`do`/`repeat` block pairing. Then compiled all 452 `.lua` and `.kyo` files with `texlua` `loadfile` syntax checks: 0 syntax errors.
- Declarative data: 11 types, 17 effects, 390 attack definitions, 322 ghost definitions, 86 global world regions; no missing explicit move references, invalid type/effect references, empty/placeholder ghost names, or malformed world region coordinates.
- Move names and animation tags: all 390 move display names are unique; all move animation tags are handled by the battle renderer.
- Sprite sizing: 284 bundled ghost PNGs are consistently 32×32. Image-backed sprite rendering preserves aspect ratio and uses fixed level-independent footprint; battle uses a fixed standard size with deliberate boss emphasis.
- Map topology simulation mirrors region stamps, authored coastline masks, 15-tile nearby land connectors, designated coast-anchored bridges, and the scaled Crownfall schematic. Main walkable component: 432,285 tiles; remaining disconnected noise: 36 tiles in a 36-tile component, within the runtime pruning threshold of 64. Spawn (72, 935) is walkable.
- All six designated causeway endpoints found coastal land: Tide, Frost, Ashen, Void, Verdant, and Crypt.
- Save migration is now schema version 5. Local and cloud load both move older layout versions to Crownfall and retain discovered-region entries. NPC reactions and companion recruitment are included in cloud save/load fields.
- ZIP and LÖVE archives are built after validation and archive-tested.

## Testing limitation

This environment does not have a LÖVE executable or Lua interpreter. These checks are structural/data-integrity tests and a Python tile-connectivity simulation, not a real graphical runtime launch. The final package still needs a live playtest for rendering/performance and interaction timing.

## Art provenance

No new OpenGameArt binary could be retrieved by the build environment (network name resolution failed), so no external sprites are represented as bundled art. The existing 284 32×32 sprites remain in use and are named to fit their visuals. Candidate CC0 source pages are documented in `ASSET_CREDITS_AND_WORLD_UPDATE.md` for the next asset import pass.
