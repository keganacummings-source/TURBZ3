==============================================================================
CUSTOMIZABLE CHARACTER SPRITESHEET  -  32x32 FRAMES  -  PLACEMENT GUIDE
Image file : character_spritesheet.png   (2560 x 2688 px, RGBA, transparent background)
==============================================================================

1. THE BIG IDEA (read this first)
------------------------------------------------------------------------------
Every piece (a skin tone, a hat, a pair of boots...) is a 'BLOCK' of 128x128 px.
Every block has the exact same internal layout: 4 columns x 4 rows of 32x32 frames.
To build a character you draw ONE block per layer, ALL AT THE SAME FRAME, stacked in
the layer order of section 4. No offsets or alignment are needed - every layer is
already registered to the same 32x32 canvas, so frame N of the hat lines up with
frame N of the body automatically.

2. INSIDE A BLOCK (128x128)
------------------------------------------------------------------------------
Frame size: 32x32.   Block origin = (BX, BY) from the tables below.

  Frame source rectangle  =  x: BX + frame*32 ,  y: BY + direction*32 ,  w:32 , h:32

  DIRECTION (block row)         y offset in block
    0 = DOWN  (facing camera)         0
    1 = LEFT                         32
    2 = RIGHT (mirror of LEFT)       64
    3 = UP    (facing away)          96

  FRAME (block column)          x offset in block     use
    0 = idle / stand                  0              idle pose (use this when not moving)
    1 = walk step A                  32              walk cycle
    2 = idle / stand                 64              walk cycle
    3 = walk step B                  96              walk cycle

  Walk animation : play frames 0 -> 1 -> 2 -> 3 -> loop (about 6-8 FPS feels right).
  Idle           : show frame 0 of the current direction.

3. SHEET GRID (20 columns x 21 rows of 128x128 blocks)
------------------------------------------------------------------------------
  Block column c (0-19)  ->  BX = c * 128
  Block row    r (0-20)  ->  BY = r * 128

  Rows 0-6   = MALE      Rows 7-13 = FEMALE      Rows 14-20 = CHILD

  Row within a body type:
    +0  BODY       (10 skin tones)    cols 0-9   <- remaining cells are empty/transparent
    +1  HAIR       (10 styles)        cols 0-9   <- remaining cells are empty/transparent
    +2  HEAD       (20 hats/headgear) cols 0-19
    +3  CHEST      (20 tops/outfits)  cols 0-19
    +4  LEGS       (20 bottoms)       cols 0-19
    +5  FEET       (20 footwear)      cols 0-19
    +6  ACCESSORY  (20 accessories)   cols 0-19

  Quick row table (BY values):
    CATEGORY     MALE BY   FEMALE BY   CHILD BY
    BODY              0         896       1792
    HAIR            128        1024       1920
    HEAD            256        1152       2048
    CHEST           384        1280       2176
    LEGS            512        1408       2304
    FEET            640        1536       2432
    ACCESSORY       768        1664       2560

  IMPORTANT: pieces are drawn for ONE body type. A male CHEST piece is only for the
  male BODY, etc. Never mix body types (child clothes on a male body will not fit).

4. LAYER ORDER  (bottom to top)  -  draw in this order every frame
------------------------------------------------------------------------------
    z0  BODY        exactly 1 required  (pick a skin tone)
    z1  FEET        optional
    z2  LEGS        optional
    z3  CHEST       optional
    z4  HAIR        optional (see HEAD hair-rule below)
    z5  HEAD        optional (hats / helmets)
    z6  ACCESSORY   optional - you may stack several accessories

  Category rules so everything works right:
   * BODY  : the ONLY layer that carries skin colour. Clothes are skin-independent.
             The base body wears a plain grey-lilac underwear band; every LEGS piece
             covers it. With no clothes the character shows bare skin + that band.
   * HAIR  : drawn in neutral GREY on purpose. Tint it in-engine with a multiply colour
             (e.g. brown 0x6B4423, blonde 0xE6C86E, red 0xB5481F, black 0x2A2A2A, white).
   * HEAD  : hat/headgear. See 'Hair vs hat' column in the HEAD tables:
               hide    = do NOT draw the HAIR layer (helmet/hood covers all hair)
               partial = hair may poke out; draw it for long styles, or skip it - your choice
               ok      = designed to sit on top of hair, draw both
   * CHEST : tops, dresses, robes, armor. Long garments (robes, dresses, coats) already
             include the skirt/hem part below the waist.
   * LEGS  : trousers, shorts and skirts. Include the waistband/hip so no gap shows.
   * FEET  : shoes/boots/socks. Boot shafts cover the lower leg; long LEGS pieces are
             drawn over the boot top (trousers over boots).
   * ACCESSORY: Capes, backpack and quiver are 'behind-the-body' items. In the DOWN and
             side views only the parts that stick out around the body are visible; in
             the UP view they cover the back. This is already baked into the frames, so
             just draw ACCESSORY last - no special back-layer needed.
             Mustache + Beard are grey and should be tinted like HAIR.
             Beards/mustaches are drawn with adult proportions; fine on male/female
             adults, use sparingly on CHILD.

5. SPRITE SPECS
------------------------------------------------------------------------------
  Frame size ........ 32x32 px, transparent background, no padding between frames
  Anchor / pivot .... bottom-centre of the feet:  x = 16 , y = 31  (feet occupy rows 29-30)
  Approx. height .... Male 24 px (head top at y=7)   Female 24 px   Child 17 px (head top at y=14)
  Hat headroom ...... adults have 7 empty rows above the head for tall hats
  Right-facing ...... the RIGHT row is the LEFT row flipped horizontally; you may also
                      skip row 2 and flip row 1 in code if you prefer
  Suggested hitbox .. ~10 x 6 px at the feet (x 11-20, y 25-30) for adults

6. SKIN TONES (BODY row, columns 0-9)
------------------------------------------------------------------------------
    col 0  Porcelain          base #F9E1D2
    col 1  Fair               base #F3CDB0
    col 2  Light              base #E9B890
    col 3  Warm Beige         base #DDA578
    col 4  Tan                base #C68B5C
    col 5  Caramel            base #AE7447
    col 6  Brown              base #8A5632
    col 7  Dark Brown         base #6A3F24
    col 8  Orc Green          base #7FB069
    col 9  Undead Grey-Blue   base #9AA8B8

7. HAIR STYLES (HAIR row, columns 0-9)  -  grey, tint in engine
------------------------------------------------------------------------------
    col 0  Buzz Cut
    col 1  Short Messy
    col 2  Side Part
    col 3  Spiky
    col 4  Bob Cut
    col 5  Long Straight
    col 6  Ponytail
    col 7  Pigtails
    col 8  Top Bun
    col 9  Afro Curls
    (No hair layer = bald.)

8. PIECE LISTS PER CATEGORY  (same column order for Male / Female / Child)
------------------------------------------------------------------------------
[HEAD]
    col  0  Baseball Cap   hair vs hat: partial
    col  1  Beanie   hair vs hat: partial
    col  2  Straw Hat   hair vs hat: partial
    col  3  Cowboy Hat   hair vs hat: partial
    col  4  Top Hat   hair vs hat: partial
    col  5  Wizard Hat   hair vs hat: partial
    col  6  Knight Helmet   hair vs hat: hide
    col  7  Viking Helmet   hair vs hat: hide
    col  8  Gold Crown   hair vs hat: ok
    col  9  Green Hood   hair vs hat: hide
    col 10  Chef Hat   hair vs hat: partial
    col 11  Pirate Bandana   hair vs hat: partial
    col 12  Ninja Headband   hair vs hat: ok
    col 13  Santa Hat   hair vs hat: partial
    col 14  Cat Ears   hair vs hat: ok
    col 15  Bunny Ears   hair vs hat: ok
    col 16  Hard Hat   hair vs hat: partial
    col 17  Flower Crown   hair vs hat: ok
    col 18  Rice Kasa Hat   hair vs hat: partial
    col 19  Guard Cap   hair vs hat: partial

[CHEST]
    col  0  White T-Shirt
    col  1  Blue T-Shirt
    col  2  Red Tank Top
    col  3  Green Long-Sleeve
    col  4  Striped Sailor Shirt
    col  5  Grey Hoodie
    col  6  Plaid Farmer Shirt
    col  7  Brown Tunic
    col  8  Leather Vest
    col  9  Purple Robe
    col 10  Red Dress
    col 11  Steel Plate Armor
    col 12  Leather Armor
    col 13  Chainmail
    col 14  Overalls
    col 15  Lab Coat
    col 16  Black Suit
    col 17  Monk Habit
    col 18  Yellow Raincoat
    col 19  Royal Doublet

[LEGS]
    col  0  Blue Jeans
    col  1  Black Pants
    col  2  Khaki Shorts
    col  3  Red Athletic Shorts
    col  4  Brown Trousers
    col  5  Green Cargo Pants
    col  6  White Pants
    col  7  Short Red Skirt
    col  8  Long Blue Skirt
    col  9  Plaid Kilt
    col 10  Leather Pants
    col 11  Steel Greaves
    col 12  Pajama Pants
    col 13  Teal Capri Pants
    col 14  Orange Coveralls
    col 15  Grey Sweatpants
    col 16  Denim Shorts
    col 17  Checkered Pants
    col 18  Royal Trousers
    col 19  Tribal Loincloth

[FEET]
    col  0  Brown Boots
    col  1  Black Boots
    col  2  White Sneakers
    col  3  Blue Sneakers
    col  4  Leather Sandals
    col  5  Dress Shoes
    col  6  Steel Sabatons
    col  7  Work Boots
    col  8  Yellow Rain Boots
    col  9  Cloth Slippers
    col 10  Red Sneakers
    col 11  Elf Boots
    col 12  Tall Riding Boots
    col 13  Gladiator Sandals
    col 14  White Socks
    col 15  Striped Socks
    col 16  Fur Boots
    col 17  Pirate Boots
    col 18  Wizard Shoes
    col 19  Bandage Wraps

[ACCESSORY]
    col  0  Round Glasses
    col  1  Sunglasses
    col  2  Eye Patch
    col  3  Monocle
    col  4  Face Mask
    col  5  Mustache (tintable grey)   (tint with multiply colour)
    col  6  Beard (tintable grey)   (tint with multiply colour)
    col  7  Gold Earrings
    col  8  Pendant Necklace
    col  9  Red Bandana Neckerchief
    col 10  Teal Scarf
    col 11  Red Bow Tie
    col 12  Belt and Pouch
    col 13  Diagonal Sash
    col 14  Leather Gloves
    col 15  Red Wristbands
    col 16  Steel Pauldrons
    col 17  Backpack
    col 18  Quiver and Arrows
    col 19  Red Cape

9. EXACT BLOCK COORDINATES (pixel origin of each 128x128 block)
------------------------------------------------------------------------------
Format:   index  name  ->  BX, BY     (frame rect = BX+frame*32, BY+dir*32, 32, 32)

##############################################################################
# BODY TYPE: MALE
##############################################################################
[MALE BODY]
     0  Porcelain skin               -> BX=   0, BY=   0
     1  Fair skin                    -> BX= 128, BY=   0
     2  Light skin                   -> BX= 256, BY=   0
     3  Warm Beige skin              -> BX= 384, BY=   0
     4  Tan skin                     -> BX= 512, BY=   0
     5  Caramel skin                 -> BX= 640, BY=   0
     6  Brown skin                   -> BX= 768, BY=   0
     7  Dark Brown skin              -> BX= 896, BY=   0
     8  Orc Green skin               -> BX=1024, BY=   0
     9  Undead Grey-Blue skin        -> BX=1152, BY=   0

[MALE HAIR]
     0  Buzz Cut                     -> BX=   0, BY= 128
     1  Short Messy                  -> BX= 128, BY= 128
     2  Side Part                    -> BX= 256, BY= 128
     3  Spiky                        -> BX= 384, BY= 128
     4  Bob Cut                      -> BX= 512, BY= 128
     5  Long Straight                -> BX= 640, BY= 128
     6  Ponytail                     -> BX= 768, BY= 128
     7  Pigtails                     -> BX= 896, BY= 128
     8  Top Bun                      -> BX=1024, BY= 128
     9  Afro Curls                   -> BX=1152, BY= 128

[MALE HEAD]
     0  Baseball Cap                 -> BX=   0, BY= 256
     1  Beanie                       -> BX= 128, BY= 256
     2  Straw Hat                    -> BX= 256, BY= 256
     3  Cowboy Hat                   -> BX= 384, BY= 256
     4  Top Hat                      -> BX= 512, BY= 256
     5  Wizard Hat                   -> BX= 640, BY= 256
     6  Knight Helmet                -> BX= 768, BY= 256
     7  Viking Helmet                -> BX= 896, BY= 256
     8  Gold Crown                   -> BX=1024, BY= 256
     9  Green Hood                   -> BX=1152, BY= 256
    10  Chef Hat                     -> BX=1280, BY= 256
    11  Pirate Bandana               -> BX=1408, BY= 256
    12  Ninja Headband               -> BX=1536, BY= 256
    13  Santa Hat                    -> BX=1664, BY= 256
    14  Cat Ears                     -> BX=1792, BY= 256
    15  Bunny Ears                   -> BX=1920, BY= 256
    16  Hard Hat                     -> BX=2048, BY= 256
    17  Flower Crown                 -> BX=2176, BY= 256
    18  Rice Kasa Hat                -> BX=2304, BY= 256
    19  Guard Cap                    -> BX=2432, BY= 256

[MALE CHEST]
     0  White T-Shirt                -> BX=   0, BY= 384
     1  Blue T-Shirt                 -> BX= 128, BY= 384
     2  Red Tank Top                 -> BX= 256, BY= 384
     3  Green Long-Sleeve            -> BX= 384, BY= 384
     4  Striped Sailor Shirt         -> BX= 512, BY= 384
     5  Grey Hoodie                  -> BX= 640, BY= 384
     6  Plaid Farmer Shirt           -> BX= 768, BY= 384
     7  Brown Tunic                  -> BX= 896, BY= 384
     8  Leather Vest                 -> BX=1024, BY= 384
     9  Purple Robe                  -> BX=1152, BY= 384
    10  Red Dress                    -> BX=1280, BY= 384
    11  Steel Plate Armor            -> BX=1408, BY= 384
    12  Leather Armor                -> BX=1536, BY= 384
    13  Chainmail                    -> BX=1664, BY= 384
    14  Overalls                     -> BX=1792, BY= 384
    15  Lab Coat                     -> BX=1920, BY= 384
    16  Black Suit                   -> BX=2048, BY= 384
    17  Monk Habit                   -> BX=2176, BY= 384
    18  Yellow Raincoat              -> BX=2304, BY= 384
    19  Royal Doublet                -> BX=2432, BY= 384

[MALE LEGS]
     0  Blue Jeans                   -> BX=   0, BY= 512
     1  Black Pants                  -> BX= 128, BY= 512
     2  Khaki Shorts                 -> BX= 256, BY= 512
     3  Red Athletic Shorts          -> BX= 384, BY= 512
     4  Brown Trousers               -> BX= 512, BY= 512
     5  Green Cargo Pants            -> BX= 640, BY= 512
     6  White Pants                  -> BX= 768, BY= 512
     7  Short Red Skirt              -> BX= 896, BY= 512
     8  Long Blue Skirt              -> BX=1024, BY= 512
     9  Plaid Kilt                   -> BX=1152, BY= 512
    10  Leather Pants                -> BX=1280, BY= 512
    11  Steel Greaves                -> BX=1408, BY= 512
    12  Pajama Pants                 -> BX=1536, BY= 512
    13  Teal Capri Pants             -> BX=1664, BY= 512
    14  Orange Coveralls             -> BX=1792, BY= 512
    15  Grey Sweatpants              -> BX=1920, BY= 512
    16  Denim Shorts                 -> BX=2048, BY= 512
    17  Checkered Pants              -> BX=2176, BY= 512
    18  Royal Trousers               -> BX=2304, BY= 512
    19  Tribal Loincloth             -> BX=2432, BY= 512

[MALE FEET]
     0  Brown Boots                  -> BX=   0, BY= 640
     1  Black Boots                  -> BX= 128, BY= 640
     2  White Sneakers               -> BX= 256, BY= 640
     3  Blue Sneakers                -> BX= 384, BY= 640
     4  Leather Sandals              -> BX= 512, BY= 640
     5  Dress Shoes                  -> BX= 640, BY= 640
     6  Steel Sabatons               -> BX= 768, BY= 640
     7  Work Boots                   -> BX= 896, BY= 640
     8  Yellow Rain Boots            -> BX=1024, BY= 640
     9  Cloth Slippers               -> BX=1152, BY= 640
    10  Red Sneakers                 -> BX=1280, BY= 640
    11  Elf Boots                    -> BX=1408, BY= 640
    12  Tall Riding Boots            -> BX=1536, BY= 640
    13  Gladiator Sandals            -> BX=1664, BY= 640
    14  White Socks                  -> BX=1792, BY= 640
    15  Striped Socks                -> BX=1920, BY= 640
    16  Fur Boots                    -> BX=2048, BY= 640
    17  Pirate Boots                 -> BX=2176, BY= 640
    18  Wizard Shoes                 -> BX=2304, BY= 640
    19  Bandage Wraps                -> BX=2432, BY= 640

[MALE ACCESSORY]
     0  Round Glasses                -> BX=   0, BY= 768
     1  Sunglasses                   -> BX= 128, BY= 768
     2  Eye Patch                    -> BX= 256, BY= 768
     3  Monocle                      -> BX= 384, BY= 768
     4  Face Mask                    -> BX= 512, BY= 768
     5  Mustache (tintable grey)     -> BX= 640, BY= 768
     6  Beard (tintable grey)        -> BX= 768, BY= 768
     7  Gold Earrings                -> BX= 896, BY= 768
     8  Pendant Necklace             -> BX=1024, BY= 768
     9  Red Bandana Neckerchief      -> BX=1152, BY= 768
    10  Teal Scarf                   -> BX=1280, BY= 768
    11  Red Bow Tie                  -> BX=1408, BY= 768
    12  Belt and Pouch               -> BX=1536, BY= 768
    13  Diagonal Sash                -> BX=1664, BY= 768
    14  Leather Gloves               -> BX=1792, BY= 768
    15  Red Wristbands               -> BX=1920, BY= 768
    16  Steel Pauldrons              -> BX=2048, BY= 768
    17  Backpack                     -> BX=2176, BY= 768
    18  Quiver and Arrows            -> BX=2304, BY= 768
    19  Red Cape                     -> BX=2432, BY= 768

##############################################################################
# BODY TYPE: FEMALE
##############################################################################
[FEMALE BODY]
     0  Porcelain skin               -> BX=   0, BY= 896
     1  Fair skin                    -> BX= 128, BY= 896
     2  Light skin                   -> BX= 256, BY= 896
     3  Warm Beige skin              -> BX= 384, BY= 896
     4  Tan skin                     -> BX= 512, BY= 896
     5  Caramel skin                 -> BX= 640, BY= 896
     6  Brown skin                   -> BX= 768, BY= 896
     7  Dark Brown skin              -> BX= 896, BY= 896
     8  Orc Green skin               -> BX=1024, BY= 896
     9  Undead Grey-Blue skin        -> BX=1152, BY= 896

[FEMALE HAIR]
     0  Buzz Cut                     -> BX=   0, BY=1024
     1  Short Messy                  -> BX= 128, BY=1024
     2  Side Part                    -> BX= 256, BY=1024
     3  Spiky                        -> BX= 384, BY=1024
     4  Bob Cut                      -> BX= 512, BY=1024
     5  Long Straight                -> BX= 640, BY=1024
     6  Ponytail                     -> BX= 768, BY=1024
     7  Pigtails                     -> BX= 896, BY=1024
     8  Top Bun                      -> BX=1024, BY=1024
     9  Afro Curls                   -> BX=1152, BY=1024

[FEMALE HEAD]
     0  Baseball Cap                 -> BX=   0, BY=1152
     1  Beanie                       -> BX= 128, BY=1152
     2  Straw Hat                    -> BX= 256, BY=1152
     3  Cowboy Hat                   -> BX= 384, BY=1152
     4  Top Hat                      -> BX= 512, BY=1152
     5  Wizard Hat                   -> BX= 640, BY=1152
     6  Knight Helmet                -> BX= 768, BY=1152
     7  Viking Helmet                -> BX= 896, BY=1152
     8  Gold Crown                   -> BX=1024, BY=1152
     9  Green Hood                   -> BX=1152, BY=1152
    10  Chef Hat                     -> BX=1280, BY=1152
    11  Pirate Bandana               -> BX=1408, BY=1152
    12  Ninja Headband               -> BX=1536, BY=1152
    13  Santa Hat                    -> BX=1664, BY=1152
    14  Cat Ears                     -> BX=1792, BY=1152
    15  Bunny Ears                   -> BX=1920, BY=1152
    16  Hard Hat                     -> BX=2048, BY=1152
    17  Flower Crown                 -> BX=2176, BY=1152
    18  Rice Kasa Hat                -> BX=2304, BY=1152
    19  Guard Cap                    -> BX=2432, BY=1152

[FEMALE CHEST]
     0  White T-Shirt                -> BX=   0, BY=1280
     1  Blue T-Shirt                 -> BX= 128, BY=1280
     2  Red Tank Top                 -> BX= 256, BY=1280
     3  Green Long-Sleeve            -> BX= 384, BY=1280
     4  Striped Sailor Shirt         -> BX= 512, BY=1280
     5  Grey Hoodie                  -> BX= 640, BY=1280
     6  Plaid Farmer Shirt           -> BX= 768, BY=1280
     7  Brown Tunic                  -> BX= 896, BY=1280
     8  Leather Vest                 -> BX=1024, BY=1280
     9  Purple Robe                  -> BX=1152, BY=1280
    10  Red Dress                    -> BX=1280, BY=1280
    11  Steel Plate Armor            -> BX=1408, BY=1280
    12  Leather Armor                -> BX=1536, BY=1280
    13  Chainmail                    -> BX=1664, BY=1280
    14  Overalls                     -> BX=1792, BY=1280
    15  Lab Coat                     -> BX=1920, BY=1280
    16  Black Suit                   -> BX=2048, BY=1280
    17  Monk Habit                   -> BX=2176, BY=1280
    18  Yellow Raincoat              -> BX=2304, BY=1280
    19  Royal Doublet                -> BX=2432, BY=1280

[FEMALE LEGS]
     0  Blue Jeans                   -> BX=   0, BY=1408
     1  Black Pants                  -> BX= 128, BY=1408
     2  Khaki Shorts                 -> BX= 256, BY=1408
     3  Red Athletic Shorts          -> BX= 384, BY=1408
     4  Brown Trousers               -> BX= 512, BY=1408
     5  Green Cargo Pants            -> BX= 640, BY=1408
     6  White Pants                  -> BX= 768, BY=1408
     7  Short Red Skirt              -> BX= 896, BY=1408
     8  Long Blue Skirt              -> BX=1024, BY=1408
     9  Plaid Kilt                   -> BX=1152, BY=1408
    10  Leather Pants                -> BX=1280, BY=1408
    11  Steel Greaves                -> BX=1408, BY=1408
    12  Pajama Pants                 -> BX=1536, BY=1408
    13  Teal Capri Pants             -> BX=1664, BY=1408
    14  Orange Coveralls             -> BX=1792, BY=1408
    15  Grey Sweatpants              -> BX=1920, BY=1408
    16  Denim Shorts                 -> BX=2048, BY=1408
    17  Checkered Pants              -> BX=2176, BY=1408
    18  Royal Trousers               -> BX=2304, BY=1408
    19  Tribal Loincloth             -> BX=2432, BY=1408

[FEMALE FEET]
     0  Brown Boots                  -> BX=   0, BY=1536
     1  Black Boots                  -> BX= 128, BY=1536
     2  White Sneakers               -> BX= 256, BY=1536
     3  Blue Sneakers                -> BX= 384, BY=1536
     4  Leather Sandals              -> BX= 512, BY=1536
     5  Dress Shoes                  -> BX= 640, BY=1536
     6  Steel Sabatons               -> BX= 768, BY=1536
     7  Work Boots                   -> BX= 896, BY=1536
     8  Yellow Rain Boots            -> BX=1024, BY=1536
     9  Cloth Slippers               -> BX=1152, BY=1536
    10  Red Sneakers                 -> BX=1280, BY=1536
    11  Elf Boots                    -> BX=1408, BY=1536
    12  Tall Riding Boots            -> BX=1536, BY=1536
    13  Gladiator Sandals            -> BX=1664, BY=1536
    14  White Socks                  -> BX=1792, BY=1536
    15  Striped Socks                -> BX=1920, BY=1536
    16  Fur Boots                    -> BX=2048, BY=1536
    17  Pirate Boots                 -> BX=2176, BY=1536
    18  Wizard Shoes                 -> BX=2304, BY=1536
    19  Bandage Wraps                -> BX=2432, BY=1536

[FEMALE ACCESSORY]
     0  Round Glasses                -> BX=   0, BY=1664
     1  Sunglasses                   -> BX= 128, BY=1664
     2  Eye Patch                    -> BX= 256, BY=1664
     3  Monocle                      -> BX= 384, BY=1664
     4  Face Mask                    -> BX= 512, BY=1664
     5  Mustache (tintable grey)     -> BX= 640, BY=1664
     6  Beard (tintable grey)        -> BX= 768, BY=1664
     7  Gold Earrings                -> BX= 896, BY=1664
     8  Pendant Necklace             -> BX=1024, BY=1664
     9  Red Bandana Neckerchief      -> BX=1152, BY=1664
    10  Teal Scarf                   -> BX=1280, BY=1664
    11  Red Bow Tie                  -> BX=1408, BY=1664
    12  Belt and Pouch               -> BX=1536, BY=1664
    13  Diagonal Sash                -> BX=1664, BY=1664
    14  Leather Gloves               -> BX=1792, BY=1664
    15  Red Wristbands               -> BX=1920, BY=1664
    16  Steel Pauldrons              -> BX=2048, BY=1664
    17  Backpack                     -> BX=2176, BY=1664
    18  Quiver and Arrows            -> BX=2304, BY=1664
    19  Red Cape                     -> BX=2432, BY=1664

##############################################################################
# BODY TYPE: CHILD
##############################################################################
[CHILD BODY]
     0  Porcelain skin               -> BX=   0, BY=1792
     1  Fair skin                    -> BX= 128, BY=1792
     2  Light skin                   -> BX= 256, BY=1792
     3  Warm Beige skin              -> BX= 384, BY=1792
     4  Tan skin                     -> BX= 512, BY=1792
     5  Caramel skin                 -> BX= 640, BY=1792
     6  Brown skin                   -> BX= 768, BY=1792
     7  Dark Brown skin              -> BX= 896, BY=1792
     8  Orc Green skin               -> BX=1024, BY=1792
     9  Undead Grey-Blue skin        -> BX=1152, BY=1792

[CHILD HAIR]
     0  Buzz Cut                     -> BX=   0, BY=1920
     1  Short Messy                  -> BX= 128, BY=1920
     2  Side Part                    -> BX= 256, BY=1920
     3  Spiky                        -> BX= 384, BY=1920
     4  Bob Cut                      -> BX= 512, BY=1920
     5  Long Straight                -> BX= 640, BY=1920
     6  Ponytail                     -> BX= 768, BY=1920
     7  Pigtails                     -> BX= 896, BY=1920
     8  Top Bun                      -> BX=1024, BY=1920
     9  Afro Curls                   -> BX=1152, BY=1920

[CHILD HEAD]
     0  Baseball Cap                 -> BX=   0, BY=2048
     1  Beanie                       -> BX= 128, BY=2048
     2  Straw Hat                    -> BX= 256, BY=2048
     3  Cowboy Hat                   -> BX= 384, BY=2048
     4  Top Hat                      -> BX= 512, BY=2048
     5  Wizard Hat                   -> BX= 640, BY=2048
     6  Knight Helmet                -> BX= 768, BY=2048
     7  Viking Helmet                -> BX= 896, BY=2048
     8  Gold Crown                   -> BX=1024, BY=2048
     9  Green Hood                   -> BX=1152, BY=2048
    10  Chef Hat                     -> BX=1280, BY=2048
    11  Pirate Bandana               -> BX=1408, BY=2048
    12  Ninja Headband               -> BX=1536, BY=2048
    13  Santa Hat                    -> BX=1664, BY=2048
    14  Cat Ears                     -> BX=1792, BY=2048
    15  Bunny Ears                   -> BX=1920, BY=2048
    16  Hard Hat                     -> BX=2048, BY=2048
    17  Flower Crown                 -> BX=2176, BY=2048
    18  Rice Kasa Hat                -> BX=2304, BY=2048
    19  Guard Cap                    -> BX=2432, BY=2048

[CHILD CHEST]
     0  White T-Shirt                -> BX=   0, BY=2176
     1  Blue T-Shirt                 -> BX= 128, BY=2176
     2  Red Tank Top                 -> BX= 256, BY=2176
     3  Green Long-Sleeve            -> BX= 384, BY=2176
     4  Striped Sailor Shirt         -> BX= 512, BY=2176
     5  Grey Hoodie                  -> BX= 640, BY=2176
     6  Plaid Farmer Shirt           -> BX= 768, BY=2176
     7  Brown Tunic                  -> BX= 896, BY=2176
     8  Leather Vest                 -> BX=1024, BY=2176
     9  Purple Robe                  -> BX=1152, BY=2176
    10  Red Dress                    -> BX=1280, BY=2176
    11  Steel Plate Armor            -> BX=1408, BY=2176
    12  Leather Armor                -> BX=1536, BY=2176
    13  Chainmail                    -> BX=1664, BY=2176
    14  Overalls                     -> BX=1792, BY=2176
    15  Lab Coat                     -> BX=1920, BY=2176
    16  Black Suit                   -> BX=2048, BY=2176
    17  Monk Habit                   -> BX=2176, BY=2176
    18  Yellow Raincoat              -> BX=2304, BY=2176
    19  Royal Doublet                -> BX=2432, BY=2176

[CHILD LEGS]
     0  Blue Jeans                   -> BX=   0, BY=2304
     1  Black Pants                  -> BX= 128, BY=2304
     2  Khaki Shorts                 -> BX= 256, BY=2304
     3  Red Athletic Shorts          -> BX= 384, BY=2304
     4  Brown Trousers               -> BX= 512, BY=2304
     5  Green Cargo Pants            -> BX= 640, BY=2304
     6  White Pants                  -> BX= 768, BY=2304
     7  Short Red Skirt              -> BX= 896, BY=2304
     8  Long Blue Skirt              -> BX=1024, BY=2304
     9  Plaid Kilt                   -> BX=1152, BY=2304
    10  Leather Pants                -> BX=1280, BY=2304
    11  Steel Greaves                -> BX=1408, BY=2304
    12  Pajama Pants                 -> BX=1536, BY=2304
    13  Teal Capri Pants             -> BX=1664, BY=2304
    14  Orange Coveralls             -> BX=1792, BY=2304
    15  Grey Sweatpants              -> BX=1920, BY=2304
    16  Denim Shorts                 -> BX=2048, BY=2304
    17  Checkered Pants              -> BX=2176, BY=2304
    18  Royal Trousers               -> BX=2304, BY=2304
    19  Tribal Loincloth             -> BX=2432, BY=2304

[CHILD FEET]
     0  Brown Boots                  -> BX=   0, BY=2432
     1  Black Boots                  -> BX= 128, BY=2432
     2  White Sneakers               -> BX= 256, BY=2432
     3  Blue Sneakers                -> BX= 384, BY=2432
     4  Leather Sandals              -> BX= 512, BY=2432
     5  Dress Shoes                  -> BX= 640, BY=2432
     6  Steel Sabatons               -> BX= 768, BY=2432
     7  Work Boots                   -> BX= 896, BY=2432
     8  Yellow Rain Boots            -> BX=1024, BY=2432
     9  Cloth Slippers               -> BX=1152, BY=2432
    10  Red Sneakers                 -> BX=1280, BY=2432
    11  Elf Boots                    -> BX=1408, BY=2432
    12  Tall Riding Boots            -> BX=1536, BY=2432
    13  Gladiator Sandals            -> BX=1664, BY=2432
    14  White Socks                  -> BX=1792, BY=2432
    15  Striped Socks                -> BX=1920, BY=2432
    16  Fur Boots                    -> BX=2048, BY=2432
    17  Pirate Boots                 -> BX=2176, BY=2432
    18  Wizard Shoes                 -> BX=2304, BY=2432
    19  Bandage Wraps                -> BX=2432, BY=2432

[CHILD ACCESSORY]
     0  Round Glasses                -> BX=   0, BY=2560
     1  Sunglasses                   -> BX= 128, BY=2560
     2  Eye Patch                    -> BX= 256, BY=2560
     3  Monocle                      -> BX= 384, BY=2560
     4  Face Mask                    -> BX= 512, BY=2560
     5  Mustache (tintable grey)     -> BX= 640, BY=2560
     6  Beard (tintable grey)        -> BX= 768, BY=2560
     7  Gold Earrings                -> BX= 896, BY=2560
     8  Pendant Necklace             -> BX=1024, BY=2560
     9  Red Bandana Neckerchief      -> BX=1152, BY=2560
    10  Teal Scarf                   -> BX=1280, BY=2560
    11  Red Bow Tie                  -> BX=1408, BY=2560
    12  Belt and Pouch               -> BX=1536, BY=2560
    13  Diagonal Sash                -> BX=1664, BY=2560
    14  Leather Gloves               -> BX=1792, BY=2560
    15  Red Wristbands               -> BX=1920, BY=2560
    16  Steel Pauldrons              -> BX=2048, BY=2560
    17  Backpack                     -> BX=2176, BY=2560
    18  Quiver and Arrows            -> BX=2304, BY=2560
    19  Red Cape                     -> BX=2432, BY=2560

10. HOW TO COMPOSE A CHARACTER (pseudo-code)
------------------------------------------------------------------------------
    BLOCK = 128
    def frame_rect(body_type, category, index, direction, frame):
        BX = index * BLOCK
        BY = (BODY_ROW[body_type] + CATEGORY_ROW[category]) * BLOCK
        return (BX + frame*32, BY + direction*32, 32, 32)

    BODY_ROW     = {'male':0, 'female':7, 'child':14}
    CATEGORY_ROW = {'BODY':0,'HAIR':1,'HEAD':2,'CHEST':3,'LEGS':4,'FEET':5,'ACCESSORY':6}
    DIRECTION    = {'down':0,'left':1,'right':2,'up':3}
    LAYER_ORDER  = ['BODY','FEET','LEGS','CHEST','HAIR','HEAD','ACCESSORY']

    # example character: male, skin #3, jeans(0), t-shirt(1), side-part hair(2), cap(0)
    char = {'BODY':[3], 'FEET':[0], 'LEGS':[0], 'CHEST':[1], 'HAIR':[2], 'HEAD':[0], 'ACCESSORY':[]}
    for layer in LAYER_ORDER:
        for idx in char[layer]:
            draw(frame_rect('male', layer, idx, direction, frame))   # same direction+frame for all layers

    Python / Pillow example for one finished frame:
        out = Image.new('RGBA',(32,32))
        for layer in LAYER_ORDER:
            for idx in char[layer]:
                x,y,w,h = frame_rect('male',layer,idx,0,0)
                out.alpha_composite(sheet.crop((x,y,x+w,y+h)))

11. MACHINE-READABLE LIST (CSV)  -  body,category,index,name,BX,BY
------------------------------------------------------------------------------
male,BODY,0,Porcelain skin,0,0
male,BODY,1,Fair skin,128,0
male,BODY,2,Light skin,256,0
male,BODY,3,Warm Beige skin,384,0
male,BODY,4,Tan skin,512,0
male,BODY,5,Caramel skin,640,0
male,BODY,6,Brown skin,768,0
male,BODY,7,Dark Brown skin,896,0
male,BODY,8,Orc Green skin,1024,0
male,BODY,9,Undead Grey-Blue skin,1152,0
male,HAIR,0,Buzz Cut,0,128
male,HAIR,1,Short Messy,128,128
male,HAIR,2,Side Part,256,128
male,HAIR,3,Spiky,384,128
male,HAIR,4,Bob Cut,512,128
male,HAIR,5,Long Straight,640,128
male,HAIR,6,Ponytail,768,128
male,HAIR,7,Pigtails,896,128
male,HAIR,8,Top Bun,1024,128
male,HAIR,9,Afro Curls,1152,128
male,HEAD,0,Baseball Cap,0,256
male,HEAD,1,Beanie,128,256
male,HEAD,2,Straw Hat,256,256
male,HEAD,3,Cowboy Hat,384,256
male,HEAD,4,Top Hat,512,256
male,HEAD,5,Wizard Hat,640,256
male,HEAD,6,Knight Helmet,768,256
male,HEAD,7,Viking Helmet,896,256
male,HEAD,8,Gold Crown,1024,256
male,HEAD,9,Green Hood,1152,256
male,HEAD,10,Chef Hat,1280,256
male,HEAD,11,Pirate Bandana,1408,256
male,HEAD,12,Ninja Headband,1536,256
male,HEAD,13,Santa Hat,1664,256
male,HEAD,14,Cat Ears,1792,256
male,HEAD,15,Bunny Ears,1920,256
male,HEAD,16,Hard Hat,2048,256
male,HEAD,17,Flower Crown,2176,256
male,HEAD,18,Rice Kasa Hat,2304,256
male,HEAD,19,Guard Cap,2432,256
male,CHEST,0,White T-Shirt,0,384
male,CHEST,1,Blue T-Shirt,128,384
male,CHEST,2,Red Tank Top,256,384
male,CHEST,3,Green Long-Sleeve,384,384
male,CHEST,4,Striped Sailor Shirt,512,384
male,CHEST,5,Grey Hoodie,640,384
male,CHEST,6,Plaid Farmer Shirt,768,384
male,CHEST,7,Brown Tunic,896,384
male,CHEST,8,Leather Vest,1024,384
male,CHEST,9,Purple Robe,1152,384
male,CHEST,10,Red Dress,1280,384
male,CHEST,11,Steel Plate Armor,1408,384
male,CHEST,12,Leather Armor,1536,384
male,CHEST,13,Chainmail,1664,384
male,CHEST,14,Overalls,1792,384
male,CHEST,15,Lab Coat,1920,384
male,CHEST,16,Black Suit,2048,384
male,CHEST,17,Monk Habit,2176,384
male,CHEST,18,Yellow Raincoat,2304,384
male,CHEST,19,Royal Doublet,2432,384
male,LEGS,0,Blue Jeans,0,512
male,LEGS,1,Black Pants,128,512
male,LEGS,2,Khaki Shorts,256,512
male,LEGS,3,Red Athletic Shorts,384,512
male,LEGS,4,Brown Trousers,512,512
male,LEGS,5,Green Cargo Pants,640,512
male,LEGS,6,White Pants,768,512
male,LEGS,7,Short Red Skirt,896,512
male,LEGS,8,Long Blue Skirt,1024,512
male,LEGS,9,Plaid Kilt,1152,512
male,LEGS,10,Leather Pants,1280,512
male,LEGS,11,Steel Greaves,1408,512
male,LEGS,12,Pajama Pants,1536,512
male,LEGS,13,Teal Capri Pants,1664,512
male,LEGS,14,Orange Coveralls,1792,512
male,LEGS,15,Grey Sweatpants,1920,512
male,LEGS,16,Denim Shorts,2048,512
male,LEGS,17,Checkered Pants,2176,512
male,LEGS,18,Royal Trousers,2304,512
male,LEGS,19,Tribal Loincloth,2432,512
male,FEET,0,Brown Boots,0,640
male,FEET,1,Black Boots,128,640
male,FEET,2,White Sneakers,256,640
male,FEET,3,Blue Sneakers,384,640
male,FEET,4,Leather Sandals,512,640
male,FEET,5,Dress Shoes,640,640
male,FEET,6,Steel Sabatons,768,640
male,FEET,7,Work Boots,896,640
male,FEET,8,Yellow Rain Boots,1024,640
male,FEET,9,Cloth Slippers,1152,640
male,FEET,10,Red Sneakers,1280,640
male,FEET,11,Elf Boots,1408,640
male,FEET,12,Tall Riding Boots,1536,640
male,FEET,13,Gladiator Sandals,1664,640
male,FEET,14,White Socks,1792,640
male,FEET,15,Striped Socks,1920,640
male,FEET,16,Fur Boots,2048,640
male,FEET,17,Pirate Boots,2176,640
male,FEET,18,Wizard Shoes,2304,640
male,FEET,19,Bandage Wraps,2432,640
male,ACCESSORY,0,Round Glasses,0,768
male,ACCESSORY,1,Sunglasses,128,768
male,ACCESSORY,2,Eye Patch,256,768
male,ACCESSORY,3,Monocle,384,768
male,ACCESSORY,4,Face Mask,512,768
male,ACCESSORY,5,Mustache (tintable grey),640,768
male,ACCESSORY,6,Beard (tintable grey),768,768
male,ACCESSORY,7,Gold Earrings,896,768
male,ACCESSORY,8,Pendant Necklace,1024,768
male,ACCESSORY,9,Red Bandana Neckerchief,1152,768
male,ACCESSORY,10,Teal Scarf,1280,768
male,ACCESSORY,11,Red Bow Tie,1408,768
male,ACCESSORY,12,Belt and Pouch,1536,768
male,ACCESSORY,13,Diagonal Sash,1664,768
male,ACCESSORY,14,Leather Gloves,1792,768
male,ACCESSORY,15,Red Wristbands,1920,768
male,ACCESSORY,16,Steel Pauldrons,2048,768
male,ACCESSORY,17,Backpack,2176,768
male,ACCESSORY,18,Quiver and Arrows,2304,768
male,ACCESSORY,19,Red Cape,2432,768
female,BODY,0,Porcelain skin,0,896
female,BODY,1,Fair skin,128,896
female,BODY,2,Light skin,256,896
female,BODY,3,Warm Beige skin,384,896
female,BODY,4,Tan skin,512,896
female,BODY,5,Caramel skin,640,896
female,BODY,6,Brown skin,768,896
female,BODY,7,Dark Brown skin,896,896
female,BODY,8,Orc Green skin,1024,896
female,BODY,9,Undead Grey-Blue skin,1152,896
female,HAIR,0,Buzz Cut,0,1024
female,HAIR,1,Short Messy,128,1024
female,HAIR,2,Side Part,256,1024
female,HAIR,3,Spiky,384,1024
female,HAIR,4,Bob Cut,512,1024
female,HAIR,5,Long Straight,640,1024
female,HAIR,6,Ponytail,768,1024
female,HAIR,7,Pigtails,896,1024
female,HAIR,8,Top Bun,1024,1024
female,HAIR,9,Afro Curls,1152,1024
female,HEAD,0,Baseball Cap,0,1152
female,HEAD,1,Beanie,128,1152
female,HEAD,2,Straw Hat,256,1152
female,HEAD,3,Cowboy Hat,384,1152
female,HEAD,4,Top Hat,512,1152
female,HEAD,5,Wizard Hat,640,1152
female,HEAD,6,Knight Helmet,768,1152
female,HEAD,7,Viking Helmet,896,1152
female,HEAD,8,Gold Crown,1024,1152
female,HEAD,9,Green Hood,1152,1152
female,HEAD,10,Chef Hat,1280,1152
female,HEAD,11,Pirate Bandana,1408,1152
female,HEAD,12,Ninja Headband,1536,1152
female,HEAD,13,Santa Hat,1664,1152
female,HEAD,14,Cat Ears,1792,1152
female,HEAD,15,Bunny Ears,1920,1152
female,HEAD,16,Hard Hat,2048,1152
female,HEAD,17,Flower Crown,2176,1152
female,HEAD,18,Rice Kasa Hat,2304,1152
female,HEAD,19,Guard Cap,2432,1152
female,CHEST,0,White T-Shirt,0,1280
female,CHEST,1,Blue T-Shirt,128,1280
female,CHEST,2,Red Tank Top,256,1280
female,CHEST,3,Green Long-Sleeve,384,1280
female,CHEST,4,Striped Sailor Shirt,512,1280
female,CHEST,5,Grey Hoodie,640,1280
female,CHEST,6,Plaid Farmer Shirt,768,1280
female,CHEST,7,Brown Tunic,896,1280
female,CHEST,8,Leather Vest,1024,1280
female,CHEST,9,Purple Robe,1152,1280
female,CHEST,10,Red Dress,1280,1280
female,CHEST,11,Steel Plate Armor,1408,1280
female,CHEST,12,Leather Armor,1536,1280
female,CHEST,13,Chainmail,1664,1280
female,CHEST,14,Overalls,1792,1280
female,CHEST,15,Lab Coat,1920,1280
female,CHEST,16,Black Suit,2048,1280
female,CHEST,17,Monk Habit,2176,1280
female,CHEST,18,Yellow Raincoat,2304,1280
female,CHEST,19,Royal Doublet,2432,1280
female,LEGS,0,Blue Jeans,0,1408
female,LEGS,1,Black Pants,128,1408
female,LEGS,2,Khaki Shorts,256,1408
female,LEGS,3,Red Athletic Shorts,384,1408
female,LEGS,4,Brown Trousers,512,1408
female,LEGS,5,Green Cargo Pants,640,1408
female,LEGS,6,White Pants,768,1408
female,LEGS,7,Short Red Skirt,896,1408
female,LEGS,8,Long Blue Skirt,1024,1408
female,LEGS,9,Plaid Kilt,1152,1408
female,LEGS,10,Leather Pants,1280,1408
female,LEGS,11,Steel Greaves,1408,1408
female,LEGS,12,Pajama Pants,1536,1408
female,LEGS,13,Teal Capri Pants,1664,1408
female,LEGS,14,Orange Coveralls,1792,1408
female,LEGS,15,Grey Sweatpants,1920,1408
female,LEGS,16,Denim Shorts,2048,1408
female,LEGS,17,Checkered Pants,2176,1408
female,LEGS,18,Royal Trousers,2304,1408
female,LEGS,19,Tribal Loincloth,2432,1408
female,FEET,0,Brown Boots,0,1536
female,FEET,1,Black Boots,128,1536
female,FEET,2,White Sneakers,256,1536
female,FEET,3,Blue Sneakers,384,1536
female,FEET,4,Leather Sandals,512,1536
female,FEET,5,Dress Shoes,640,1536
female,FEET,6,Steel Sabatons,768,1536
female,FEET,7,Work Boots,896,1536
female,FEET,8,Yellow Rain Boots,1024,1536
female,FEET,9,Cloth Slippers,1152,1536
female,FEET,10,Red Sneakers,1280,1536
female,FEET,11,Elf Boots,1408,1536
female,FEET,12,Tall Riding Boots,1536,1536
female,FEET,13,Gladiator Sandals,1664,1536
female,FEET,14,White Socks,1792,1536
female,FEET,15,Striped Socks,1920,1536
female,FEET,16,Fur Boots,2048,1536
female,FEET,17,Pirate Boots,2176,1536
female,FEET,18,Wizard Shoes,2304,1536
female,FEET,19,Bandage Wraps,2432,1536
female,ACCESSORY,0,Round Glasses,0,1664
female,ACCESSORY,1,Sunglasses,128,1664
female,ACCESSORY,2,Eye Patch,256,1664
female,ACCESSORY,3,Monocle,384,1664
female,ACCESSORY,4,Face Mask,512,1664
female,ACCESSORY,5,Mustache (tintable grey),640,1664
female,ACCESSORY,6,Beard (tintable grey),768,1664
female,ACCESSORY,7,Gold Earrings,896,1664
female,ACCESSORY,8,Pendant Necklace,1024,1664
female,ACCESSORY,9,Red Bandana Neckerchief,1152,1664
female,ACCESSORY,10,Teal Scarf,1280,1664
female,ACCESSORY,11,Red Bow Tie,1408,1664
female,ACCESSORY,12,Belt and Pouch,1536,1664
female,ACCESSORY,13,Diagonal Sash,1664,1664
female,ACCESSORY,14,Leather Gloves,1792,1664
female,ACCESSORY,15,Red Wristbands,1920,1664
female,ACCESSORY,16,Steel Pauldrons,2048,1664
female,ACCESSORY,17,Backpack,2176,1664
female,ACCESSORY,18,Quiver and Arrows,2304,1664
female,ACCESSORY,19,Red Cape,2432,1664
child,BODY,0,Porcelain skin,0,1792
child,BODY,1,Fair skin,128,1792
child,BODY,2,Light skin,256,1792
child,BODY,3,Warm Beige skin,384,1792
child,BODY,4,Tan skin,512,1792
child,BODY,5,Caramel skin,640,1792
child,BODY,6,Brown skin,768,1792
child,BODY,7,Dark Brown skin,896,1792
child,BODY,8,Orc Green skin,1024,1792
child,BODY,9,Undead Grey-Blue skin,1152,1792
child,HAIR,0,Buzz Cut,0,1920
child,HAIR,1,Short Messy,128,1920
child,HAIR,2,Side Part,256,1920
child,HAIR,3,Spiky,384,1920
child,HAIR,4,Bob Cut,512,1920
child,HAIR,5,Long Straight,640,1920
child,HAIR,6,Ponytail,768,1920
child,HAIR,7,Pigtails,896,1920
child,HAIR,8,Top Bun,1024,1920
child,HAIR,9,Afro Curls,1152,1920
child,HEAD,0,Baseball Cap,0,2048
child,HEAD,1,Beanie,128,2048
child,HEAD,2,Straw Hat,256,2048
child,HEAD,3,Cowboy Hat,384,2048
child,HEAD,4,Top Hat,512,2048
child,HEAD,5,Wizard Hat,640,2048
child,HEAD,6,Knight Helmet,768,2048
child,HEAD,7,Viking Helmet,896,2048
child,HEAD,8,Gold Crown,1024,2048
child,HEAD,9,Green Hood,1152,2048
child,HEAD,10,Chef Hat,1280,2048
child,HEAD,11,Pirate Bandana,1408,2048
child,HEAD,12,Ninja Headband,1536,2048
child,HEAD,13,Santa Hat,1664,2048
child,HEAD,14,Cat Ears,1792,2048
child,HEAD,15,Bunny Ears,1920,2048
child,HEAD,16,Hard Hat,2048,2048
child,HEAD,17,Flower Crown,2176,2048
child,HEAD,18,Rice Kasa Hat,2304,2048
child,HEAD,19,Guard Cap,2432,2048
child,CHEST,0,White T-Shirt,0,2176
child,CHEST,1,Blue T-Shirt,128,2176
child,CHEST,2,Red Tank Top,256,2176
child,CHEST,3,Green Long-Sleeve,384,2176
child,CHEST,4,Striped Sailor Shirt,512,2176
child,CHEST,5,Grey Hoodie,640,2176
child,CHEST,6,Plaid Farmer Shirt,768,2176
child,CHEST,7,Brown Tunic,896,2176
child,CHEST,8,Leather Vest,1024,2176
child,CHEST,9,Purple Robe,1152,2176
child,CHEST,10,Red Dress,1280,2176
child,CHEST,11,Steel Plate Armor,1408,2176
child,CHEST,12,Leather Armor,1536,2176
child,CHEST,13,Chainmail,1664,2176
child,CHEST,14,Overalls,1792,2176
child,CHEST,15,Lab Coat,1920,2176
child,CHEST,16,Black Suit,2048,2176
child,CHEST,17,Monk Habit,2176,2176
child,CHEST,18,Yellow Raincoat,2304,2176
child,CHEST,19,Royal Doublet,2432,2176
child,LEGS,0,Blue Jeans,0,2304
child,LEGS,1,Black Pants,128,2304
child,LEGS,2,Khaki Shorts,256,2304
child,LEGS,3,Red Athletic Shorts,384,2304
child,LEGS,4,Brown Trousers,512,2304
child,LEGS,5,Green Cargo Pants,640,2304
child,LEGS,6,White Pants,768,2304
child,LEGS,7,Short Red Skirt,896,2304
child,LEGS,8,Long Blue Skirt,1024,2304
child,LEGS,9,Plaid Kilt,1152,2304
child,LEGS,10,Leather Pants,1280,2304
child,LEGS,11,Steel Greaves,1408,2304
child,LEGS,12,Pajama Pants,1536,2304
child,LEGS,13,Teal Capri Pants,1664,2304
child,LEGS,14,Orange Coveralls,1792,2304
child,LEGS,15,Grey Sweatpants,1920,2304
child,LEGS,16,Denim Shorts,2048,2304
child,LEGS,17,Checkered Pants,2176,2304
child,LEGS,18,Royal Trousers,2304,2304
child,LEGS,19,Tribal Loincloth,2432,2304
child,FEET,0,Brown Boots,0,2432
child,FEET,1,Black Boots,128,2432
child,FEET,2,White Sneakers,256,2432
child,FEET,3,Blue Sneakers,384,2432
child,FEET,4,Leather Sandals,512,2432
child,FEET,5,Dress Shoes,640,2432
child,FEET,6,Steel Sabatons,768,2432
child,FEET,7,Work Boots,896,2432
child,FEET,8,Yellow Rain Boots,1024,2432
child,FEET,9,Cloth Slippers,1152,2432
child,FEET,10,Red Sneakers,1280,2432
child,FEET,11,Elf Boots,1408,2432
child,FEET,12,Tall Riding Boots,1536,2432
child,FEET,13,Gladiator Sandals,1664,2432
child,FEET,14,White Socks,1792,2432
child,FEET,15,Striped Socks,1920,2432
child,FEET,16,Fur Boots,2048,2432
child,FEET,17,Pirate Boots,2176,2432
child,FEET,18,Wizard Shoes,2304,2432
child,FEET,19,Bandage Wraps,2432,2432
child,ACCESSORY,0,Round Glasses,0,2560
child,ACCESSORY,1,Sunglasses,128,2560
child,ACCESSORY,2,Eye Patch,256,2560
child,ACCESSORY,3,Monocle,384,2560
child,ACCESSORY,4,Face Mask,512,2560
child,ACCESSORY,5,Mustache (tintable grey),640,2560
child,ACCESSORY,6,Beard (tintable grey),768,2560
child,ACCESSORY,7,Gold Earrings,896,2560
child,ACCESSORY,8,Pendant Necklace,1024,2560
child,ACCESSORY,9,Red Bandana Neckerchief,1152,2560
child,ACCESSORY,10,Teal Scarf,1280,2560
child,ACCESSORY,11,Red Bow Tie,1408,2560
child,ACCESSORY,12,Belt and Pouch,1536,2560
child,ACCESSORY,13,Diagonal Sash,1664,2560
child,ACCESSORY,14,Leather Gloves,1792,2560
child,ACCESSORY,15,Red Wristbands,1920,2560
child,ACCESSORY,16,Steel Pauldrons,2048,2560
child,ACCESSORY,17,Backpack,2176,2560
child,ACCESSORY,18,Quiver and Arrows,2304,2560
child,ACCESSORY,19,Red Cape,2432,2560
