# UI / World / Catch Update

## Readability & pixel clarity
- Logical resolution raised (height 480, width follows aspect) so UI text has more room
- Fullscreen present prefers larger integer/half-step scales to fill more of the monitor while keeping nearest-neighbour sharpness
- Default window 1600x900
- Party slot rows slightly taller

## Companion speech
- Banter is rare (~every 220 steps, 35% chance) instead of constant chatter
- Speech bubble anchored above the companion sprite and clamped on-screen
- Companions congratulate you when you catch rare / notable ghosts

## After-battle flow
- Every win opens a **Battle Results** screen showing XP
- Defeated wild ghosts are **not** auto-boxed
- **C CATCH (JAR)** on the result screen: **100% catch** if the ghost was defeated (costs 1 Ghost Jar)
- Mid-battle jar throws still use level-based % (trainer vs ghost level + HP + Catching skill)

## World x5
- Map size **7875 x 5700** (5× previous)
- Regions, cities, landmarks, resources, terrain, continent masks scaled
- NPCs dispersed across Crownfall castle wards (gate, courtyard, keep, dorms, market, north, west) and multiple city hubs
- Added intact castles (Northwatch, Eastgate, Southmere), villages, and extra cities (Goldroad, Starfall, etc.)
