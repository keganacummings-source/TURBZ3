> Historical note for the current peer-hosted build: references to cloud save/load below describe an earlier version. The cloud backend was removed from this release; all saves now remain local and multiplayer saves are world/player-isolated.

# TURBZ World + Combat Update

- Reworked world regions into a broad central continent and smaller surrounding landmasses; moved the Void causeway to the southeast coast to avoid an inland-spanning bridge. Optimized ocean biome ownership lookup during world generation.
- Repositioned map objects with their source regions and added bridges so the continents belong to one traversable world.
- Added discovered-region fast travel to the atlas (T key or Travel button); undiscovered regions stay locked, and arrivals choose a safe walkable tile. Bumped the world save version to 4 so pre-layout-change local/cloud saves return to Crownfall safely.
- Enlarged the Crownfall capital and restored its spawn as the death respawn destination.
- Reduced on-screen ghost scaling so species level no longer causes sprites to become giant; large boss scale remains deliberate and bounded.
- Introduced independent 10% type rolls up to five types and saved the type list in ghost exports. Removed a universal Normal-type immunity that accidentally made all ghosts immune to Spirit attacks; capped stacked type effectiveness at 0.25×–3× (real immunities still apply).
- Rewrote 300 expanded attacks with distinctive type-themed names, effects, accuracy, cooldowns, tactical roles and multi-layer battle animations; balanced the remaining legacy moves and authored ghoul-pack actions. The 40 curated pack2 moves remain as signature tactics. Added counter, exposure, silence, ward, cleanse, rally, drain and forced-switch play.
- Refreshed the tab menu and battle display while maintaining the pixel-art visual language.
- Replaced opaque generated monster placeholder names with visual/theme-based species names while retaining internal IDs for save compatibility.

Runtime note: static source/data checks can be run from the package; a real graphical LÖVE playtest is still required on a desktop installation.

- Bumped world save schema to version 5 so saves from the previous world geometry migrate safely to Crownfall while retaining discovered atlas destinations.
- Replaced the blocky zone-union coastline with an authored central-continent mask and widened southwest cape to Crownfall; clipped the five outer land groups and Crypt isle to distinct curved island silhouettes.
- Changed long bridge anchors to find actual coastal floor before tracing each designated causeway. Reduced incidental nearby joins to 15 tiles so oceans stay meaningful.
- Corrected combat turn flow after forced swaps: a replacement defender picks its own valid action, and a party ghost forcibly swapped out does not pass its chosen move to the incoming ally.
- Included NPC relationship reactions and recruited companion IDs in cloud save/load snapshots as well as local saves.

## UI/context menu, companion, and exploration pass
- Rebuilt the NPC conversation context menu and fixed visible action selection, wrapped/scrollable dialogue, recruitment gating, and companion dismissal options.
- Rebuilt pause, quests, bank, and resource-zone layouts; added scrolling viewports to list-heavy screens and chat scrollback.
- Centered legacy fixed-width panels and corrected text-fit calculations for widescreen logical canvases; use nearest filtering and integer scaling where available.
- Added 112 talkable residents with unique local sprites/dialogue and randomized personal quests; completing a task unlocks companion recruitment. Companion perks affect XP, attack, defence, or Kyo gain.
- Added 20 named landmarks plus up to 12 seeded filler points, four lake coves, forest trail stands, ruined courtyards, and three mountain ridges with narrow switchback gaps.
- Spawn candidates for wild encounters must be outside the visible camera area; ghosts may persist off-screen for up to 120 seconds.
- Added a ghoul fallback sprite and automatic missing-sprite recovery. Audited the 284 bundled ghost PNG files against every `imageSprite` reference.
- External OpenGameArt CC0 sources were researched, but their binary assets could not be fetched in this environment and are not claimed as newly bundled. See `UI_CONTEXT_WORLD_UPDATE.md` for links and test results.
