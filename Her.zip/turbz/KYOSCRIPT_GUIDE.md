# TURBO SCRIPT GUIDE

Turbo Script is Lua with some ready-made words added. If you've modded Reassembly, the shape will look familiar:
**a word, a name in quotes, then `{ fields }`**.

```lua
-- two dashes start a comment. The game ignores it.
Attack "ember" {
  name     = "Ember Trail",
  type     = "fire",
  power    = 42,
  accuracy = 95,
  crit     = 12,
  effect   = "burn",
}
```

**3 golden rules**
1. Every field line ends with a comma `,`
2. Text goes in quotes: `"fire"`. Numbers don't: `42`
3. Lists use curly brackets: `moves = { "ember", "flare" }`

If you leave a field out, the engine uses the default value from `game/terms/`.

---

## PART 1 — TERMS (the things you make)

Each term below has its own file in `game/terms/` that lists every field and its default.

### Ghost  — `game/ghosts/<type>/<id>.kyo`
```lua
Ghost "nobi" {
  number = 0, name = "Nobi", type = "fire",
  spooky = 6, sleepy = 3, speed = 4, damage = 5, mass = 3,   -- MAX stats. Wild ones roll 62-100%
  sleepChance = 8,                                          -- note shown in the pedia
  moves  = { "ember", "flare", "cinder", "wail" },          -- up to 10, same type only (Settings.sameTypeMoves)
  sprite = "nobi",
}
```

### Attack — `game/attacks/<type>/<id>.kyo`
`name  type  power  accuracy (%)  crit (%)  effect`

### Type — `game/types/<id>.kyo`
```lua
Type "fire" {
  name = "Fire", color = "#e25a32",
  strong_against = { "ice", "void" },     -- Fire attacks do x2 to these
  weak_against   = { "water", "earth" },  -- Fire attacks do x0.5 to these
  immune_to      = {},                    -- attacks of these types do x0 to a Fire ghost
  against        = {},                    -- exact numbers that win  { light = 1.3 }
  palette = { D = "#3a140c", B = "#e25a32", L = "#ffb15e", H = "#fff1c9", F = "#ffd27a" },
}
```
The 10 base types: **normal fire water earth air electric ice void light spirit**.
The x2 / x0.5 / x0 numbers live in `game/rules/type_bonus.kyo` (STRONG, WEAK, IMMUNE).
**New type?** Make `game/types/poison.kyo`, give some ghosts `type = "poison"`, and add `poison = 20` to some region `spawns`. That's all.

### Effect — `game/effects/<id>.kyo`
An effect can do things at 4 moments:

| action | when | you get |
|---|---|---|
| `onHit = function(e)` | the attack lands | `e.user` `e.target` `e.attack` `e.damage` |
| `onTurnEnd = function(u)` | end of each turn, if `u` **has** this status | the ghost `u` |
| `onBeforeAct = function(e)` | before a ghost that **has** it attacks | set `e.skip = true` to make it lose its turn |
| `onDefend = function(e)` | a ghost that **has** it gets hit | change `e.damage` |

`countdown = true` makes the status lose 1 turn at every turn end.
```lua
Effect "burn" {
  name = "Burn", countdown = true,
  onHit     = function(e) Give(e.target, "burn", 3) end,
  onTurnEnd = function(u) Hurt(u, PercentOf(u.max, 5)) end,
}
```

### Region — `game/regions/<id>.kyo`
`name  x  y  w  h  tint  spawns  levels  pool = true`
```lua
spawns = { fire = 60, water = 30, nobi = { weight = 10, levels = { 4, 8 } } },  -- Type OR Ghost ids = how often
levels = { 2, 8 },                                                              -- level range here
```
Only what is listed spawns in that region. Roads use the map's `roadSpawns` / `roadLevels`.

### Map — `game/maps/<id>.kyo`  (pick one with `Settings { map = "..." }`)
**Way 1, regions + roads:** list `regions` (stamped in order) and `roads = { { "a", "b" } }` (dug between region centres).
**Way 2, draw it:** give `layout` (one text row per line) and a `legend` that turns each letter into a Tile:
```lua
legend = { ["#"] = "wall", ["."] = "floor", ["~"] = "pool" },
layout = {
  "##########",
  "#....~~..#",
  "##########",
},
```
Also: `start = { x, y }`, `roadName`, `roadTint`, `roadSpawns`, `scatter = { { "bone", 7 } }` (percent of floor tiles).

### Tile — `game/tiles/<id>.kyo`
`walkable  color ("zone" = region tint)  detail = { { x, y, w, h, "#colour" } }  questSpot  onDraw = function(x, y) ... end`

### Sprite — `game/sprites/...`
Each letter is one pixel, `.` is see-through.
Ghost sprites use their Type palette letters **D B L H F**. Other sprites give their own `palette`.
Animate with `frames = { {rows}, {rows} }` and `fps = 4`.

### Rarity — `game/rarities/<id>.kyo`  (the depth levels of ghost colours)

| File | Name | Tier | Odds | Look |
|---|---|---|---|---|
| awake.kyo | Awake | Common | the rest (~74%) | Base palette |
| faded.kyo | Faded | Uncommon | 1/5 | Washed stone |
| weeping.kyo | Weeping | Rare | 1/16 | Blue tears |
| sleeping.kyo | Sleeping | Shiny | 1/80 | Rainbow nap |
| eclipse.kyo | Eclipse | Epic | 1/320 | Dark crown, gold eyes |
| kyo_touched.kyo | Kyo-Touched | Mythic | 1/1400 | Gold veins, red sparks |

Every new wild ghost rolls its rarity **rarest first**, each tier with its own `1 in oneIn` chance. Whatever is left is the common one (`oneIn = 0`).
The recolour is **automatic** and works on any palette, so ghosts you make yourself get every rarity look without extra work. The steps run in this order:
`saturation` → `brightness` → `mix` + `amount` → `letters` → `rainbow` → the sprite's own `rarity` colours → `onLook`.
Extras drawn on top: `sparks` (+ `sparkStyle = "twinkle"` or `"drip"`, `sparkCount`), `crown` + `crownGem`.
Power: `statFloor` (stats roll statFloor%–100%), `bonus = { spooky = 1 }`, `damageBoost` (percent), `sky` (battle colour), `jumpSound`.
```lua
Rarity "frozen" {
  name = "Frozen", tier = "Rare", order = 7, oneIn = 50, look = "Ice glaze",
  color = "#b7e4ff", tag = "ICE",
  mix = "#b7e4ff", amount = 45, sparks = "#ffffff", sparkCount = 3,
  statFloor = 80,
}
```
**Hand-tune one sprite for one rarity:**
`Sprite "nobi" { rarity = { eclipse = { H = "#ff2020" } }, "..HH....", ... }`
**Luckier world:** `Settings { rarityLuck = 2 }` doubles every rarity chance.

### Item — `game/items/<id>.kyo`  (things in your bag that DO something)
`name  about  where ("battle" / "field" / "both")  consume  price  dropChance  order  onUse = function(e) ... end`
In `onUse(e)`: `e.user` = your ghost in battle, `e.target` = the foe, `e.ghost` = the ghost it's used on, `e.battle`. Set `e.used = false` to cancel.
Using an item in battle costs your turn (the foe still attacks).
```lua
Item "revive_tea" {
  name = "Revive Tea", about = "Heal 25% and clear burn.", where = "battle", dropChance = 5,
  onUse = function(e)
    Heal(e.user, PercentOf(e.user.max, 25))
    Take(e.user, "burn")
    e.battle.line = "TEA TIME"
  end,
}
```
Item verbs: `GiveItem(id, n)` `TakeItem(id, n)` `HasItem(id)` `ItemCount(id)` `UseItem(id, ghost)` `BagList()` `TryCatch(bonus)` `FleeBattle()` `GiveXp(ghost, amount)`. Starting bag: `Settings.startBag`.

### Enemy — `game/enemies/<id>.kyo`  (Skeletons and other NPCs)
`name  sprite  party = { "random", "kage" }  levelBonus  xpMultiplier (2 = double XP)  kyoReward  wanderChance  turnTime`
They walk around at random. Bump into one (or it bumps into you) and you fight its whole party. Regions choose which enemies appear: `enemies = { skeleton = 80 }`, `maxEnemies = 1`.

### Maps folder — `game/maps/<map>/`
Each map has its own folder: the Map file, `regions/`, `portals/`, `addons/`.
* `Portal "id" { map, x, y, to, toX, toY, sprite }` is a door to another map.
* `MapAddon "id" { map, regions, roads, layout, legend, at }` expands a map **without editing it**, and the map grows to fit. Future map updates go here.

### Spawning & TurnTime
Spawns run on timers (`Settings.spawnSeconds`, `enemySeconds`) with limits per map (`maxWilds`, `maxEnemies`) and per region (`maxGhosts`, `maxEnemies`).
Every few moments a **world turn** happens (`Settings.worldTurnSeconds`): things wander, and anything **off screen** for more than its `turnTime` turns vanishes. That frees room, so each area keeps spawning at its own rate.

### Battles, XP & names
* Both sides fight with their whole party. When a ghost faints, the next one is thrown out automatically.
* XP goes to the ghost that lands the knockout (`Rule "xp_reward"`, `Rule "xp_needed"`). Enemies give `xpMultiplier` times more.
* Health only exists during a battle, so your team is **always fully healed** when a battle ends.
* Press **R** on the result screen or the Ghostbook party tab to nickname a ghost. `GhostName(g)` gives the nickname or the species name.

### Menus & grid
`Screen "menu"` is the main menu (edit its `ITEMS` list to add buttons), and `Screen "pause"` opens with Esc. Everything stands on the tile grid, and sprites are centred on their tile automatically using their visible pixels (`DrawSpriteAt`, `DrawGhostAt`). Movement slides smoothly (`Settings.moveSpeed`, `stepTicks`).

### Player, Sound, Screen, System
* `Player "kyo" { name, sprite, bob, offsetX, offsetY }`
* `Sound "hit" { freq = 340, length = 0.05, wave = "square", volume = 0.04 }`. Waves: square sine saw triangle noise. Or use `file = "assets/sounds/x.wav"`.
* `Screen "title" { onDraw, onTick, onKey, onClick, onEnter }`. The screens are `title explore intro battle result book`, plus `global` which runs on top of all of them.
* `System "weather" { onTick, onDraw, onKey, onClick }` adds a whole new feature without editing the engine.

### Single-table files
`Settings { }`  `Colors { }`  `Words { }`  `Keys { }`. Read them anywhere: `Settings.partySize`, `Word("saved")`.

---

## PART 2 — CHANGING & ADDING (modding words)

| Word | Example | Does |
|---|---|---|
| `NewTerm` | `NewTerm "Item" { name = "", price = 0 }` | creates a **brand new word** `Item "potion" { ... }` |
| `Edit` | `Edit "Attack" "ember" { power = 60 }` | changes some fields of something that already exists |
| `Remove` | `Remove "Ghost" "nobi"` | deletes it |
| `Rule` | `Rule "damage" (function(user, target, attack) ... end)` | replaces a game formula |
| `When` | `When "battle_won" (function(e) ... end)` | runs your code when something happens |
| `Fire` | `Fire("my_event", data)` | triggers your own event |

**Events you can hook with When:**
`boot` `linked` `new_game` `world_built` `map_changed` `world_turn` `step` `enemy_spawned` `wild_vanished` `item_got` `item_used` `ghost_level_up` `ghost_named` `team_healed` `battle_fled` `wild_spawned` `ghost_made` `quest_new` `battle_start` `hit` `battle_won` `battle_lost` `level_up` `saved` `loaded` `draw_world`

**Rules you can replace** (`game/rules/`):
`damage` `unit_stats` `new_ghost` `xp_reward` `xp_needed` `catch_chance` `flee_chance` `move_score` `trainer_level` `wild_level` `ghost_look`

**Reading data:** `Get("Ghost", "nobi")`  `All("Attack")`  `Each("Charm", function(c) ... end)`  `Count("Ghost")`

**Your own saved data:** put anything in `S.vars`, e.g. `S.vars.coins = 10`. It's saved with the game.

---

## PART 3 — VERBS (things you can call)

**Drawing** (game screen is 320 x 320; text `y` is the bottom of the letters)
`Text(text, x, y, color, size)` `Box(x, y, w, h, color)` `Frame(x, y, w, h, color)` `Fill(color)` `Bar(x, y, w, value, max, color)`
`DrawSprite(id, x, y, scale, palette)` `DrawGhost(ghost, x, y, scale)` `DrawPlayer(x, y)` `DrawWorld()` `HSL(hue, sat, light)`

**Game**
`Go("screen")` `Say(text)` `Word(key, ...)` `Play("sound")` `IsKey(key, "action")` `Inside(x, y, bx, by, bw, bh)`
`Step(dx, dy)` `SpawnWild()` `NewQuest()` `ToggleAfk()` `SaveGame()` `LoadGame()`

**Ghosts**
`MakeGhost(id, level, rarity)` `Species(ghost)` `MovesOf(ghost)` `GhostList()` `GhostsOfType("fire")` `StatSum(ghost)` `Owned()` `LeadGhost()` `WildAt(x, y)`

**Battle** (`u` = a ghost in battle: `u.hp u.max u.atk u.def u.spd u.type u.level u.status u.mods`)
`Give(u, "status", turns)` `Take(u, "status")` `Has(u, "status")` `Heal(u, n)` `Hurt(u, n)` `Lower(u, "atk", n, limit)` `Raise(u, "def", n, limit)`
`TypeBonus(attackType, defendType)` `BestMove(me, foe)` `UseMove(n)` `BeginBattle()` `Strike(user, target, attack)`

**Map**
`RegionAt(x, y)` `TileAt(x, y)` `Walkable(x, y)` `MapRegions()`

**Rarity & colour**
`RarityOf(ghost)` `RollRarity()` `RarityList()` `RarityChance("weeping")` `CommonRarity()` `MakeGhost("nobi", 5, "eclipse")`
`MixColor(a, b, percent)` `Saturate(color, percent)` `Brighten(color, percent)` `SpriteSize(id)`

**Numbers & text**
`Random()` `Random(1, 6)` `Chance(25)` `Pick(list)` `PickWeighted({ a = 1, b = 3 })` `Min` `Max` `Floor` `Round` `Clamp` `Abs` `Sin` `Cos` `Sqrt` `PI`
`PercentOf(value, percent)` `Half(n)` `Upper(text)` `Cut(text, n)` `Tick()` `Blink(every)` `Copy(table)`

**The game state `S`** (read or change it from any file)
`S.screen S.px S.py S.trainer S.kyo S.kills S.need S.party S.box S.wilds S.quest S.battle S.afk S.book S.seen S.caught S.msg S.vars`

---

## PART 4 — RECIPES

**A new ghost (3 files)**
1. `game/ghosts/fire/chochin.kyo` → `Ghost "chochin" { ... sprite = "chochin" }`
2. `game/sprites/ghosts/chochin.kyo` → `Sprite "chochin" { "..HH..", ... }`
3. (optional) a new attack in `game/attacks/fire/`

**A brand new kind of thing, a shop**
```lua
-- (Item is already built in. This makes the shop.)
-- mods/my_shop/systems/shop.kyo
System "shop" {
  onKey = function(key)
    if key == "p" and S.kyo >= Get("Item", "potion").price then
      S.kyo = S.kyo - Get("Item", "potion").price
      S.vars.potions = (S.vars.potions or 0) + 1
      Say("BOUGHT A POTION")
    end
  end,
}
```

**Bigger rewards for quarry hunts:** `Settings { questReward = 10 }`

**Fire beats water instead:** `Edit "Type" "fire" { strong_against = { "water", "ice" }, weak_against = { "earth" } }`

See `mods/_example_mod` for a working mod. It adds a new term, a ghost, an attack, a sprite, edits, hooks and a System.

## Kyo leveling
Open the Ghostbook (G) -> PARTY to pick a ghost -> BAG -> **Kyo** -> ENTER  (or press K on the party tab).
Each use costs 10 KYO for +1 level, up to LV400. Change it in `game/rules/kyo_level.kyo` (or `kyoPerLevel` / `maxLevel` in settings.kyo).

## Options menu (ESC)
ESC while exploring opens OPTIONS: Resume, Controls, Ghostbook, Sound, Save, Save & Main Menu, Quit.
The controls list is `CONTROLS` in `game/screens/global.kyo`, buttons are `ITEMS` in `game/screens/pause.kyo`.

## Quests — `game/quests/<id>.kyo`
```lua
Quest "ember_hunt" {
  name  = "Ember Hunt",
  goals = {                                   -- done in order, the HUD + map flag show the next one
    { kind = "visit", biome = "ashland" },    -- or region = "cinder_yard"
    { kind = "catch", type = "fire", region = "cinder_yard", count = 2 },
  },
  rewards = {                                 -- the player PICKS ONE (Settings.rewardChoices shown)
    { kyo = 15 },
    { item = "potion", count = 3 },
    { ghost = "onibi", level = 5, rarity = "faded" },
  },
  weight = 10, minTrainer = 1, map = "", once = false,
}
```
Goal kinds (`game/goals/`): **collect** (item, count) · **visit** (region or biome) · **catch** (type, ghost, region, rarity, count) · **defeat** (count, enemy) · **boss** (boss).
**New goal kind?** Make `game/goals/reach_level.kyo`:
```lua
Goal "reach_level" {
  onText     = function(goal) return "GET A GHOST TO LV" .. goal.level end,
  onProgress = function(goal) for _, g in ipairs(Owned()) do if g.level >= goal.level then return 1 end end return 0 end,
}
```
Hooks: `onText(goal)` `onEvent(goal, name, e)` (return progress to add) `onProgress(goal, have)` (return new progress) `onFlag(goal)` (return x, y) `onFinish(goal)` `onValidate(goal)`.
Events goals can listen to: `ghost_caught` `battle_won` `enemy_defeated` `boss_defeated` `item_bought` `ghost_traded` `step` ... (any `Fire` name).
Regions have `biome = "marsh"` so quests can say "go to any marsh".

## Boss — `game/bosses/<id>.kyo`
```lua
Boss "bone_king" { name = "Bone King", map = "zomnia", x = 64, y = 26, ghost = "gaikotsu", sprite = "bone_king",
  level = 12, rarity = "eclipse", hpMultiplier = 3, minions = { { ghost = "yami", level = 10 } },
  xpMultiplier = 4, kyoReward = 40, drops = { big_potion = 2 }, once = true }
```
Bosses are drawn `Settings.bossScale` (4x) bigger and cover `bossTiles` x `bossTiles` tiles. Walk into one to fight. You can't run or catch.

## Store — `game/stores/<id>.kyo`
```lua
Store "crypt_peddler" { name = "Crypt Peddler", map = "zomnia", x = 8, y = 26, sprite = "peddler",
  stock = {
    { item = "potion",      price = 4,  chance = 80, amount = 2, max = 6 },   -- chance = % to be added on each add
    { item = "lantern_jar", price = 20, chance = 10, amount = 1, max = 1 },
  },
  startItems = 3,        -- adds when first seen
  restockTurns = 40,     -- every 40 world turns...
  itemsPerRestock = 2,   -- ...do 2 adds
  maxShelf = 6 }
```
Hooks: `onRestock(store, shelf)` `onBuy(store, entry)` (return false = no sale) `onTalk(store)` (return false = don't open).

## Trader — `game/traders/<id>.kyo`
```lua
Trader "old_digger" { name = "Old Digger", map = "zomnia", x = 14, y = 31,
  wants = { type = "normal", minLevel = 3 },   -- also ghost =, rarity =
  gives = { ghost = "raiju", level = 6 },      -- any reward: { kyo = 20 } { item = "potion", count = 2 }
  once = true }
```

## Your own kind of place (healer, quest giver...)
```lua
NewTerm "Healer" { name = "", map = "", x = 0, y = 0, sprite = "peddler" }
PlaceKinds.Healer = function(def) Say(Upper(def.name) .. " HEALS YOU") end
Healer "nun" { name = "Old Nun", map = "zomnia", x = 10, y = 24 }
```

## .ghost files (share / trade / collect)
* Every ghost you own is saved as its own file: `<save folder>/ghosts/<id>.ghost`.
* Ghostbook → BOX → click a ghost: watch it move, TO PARTY, **EXPORT** (or press X), RENAME.
* EXPORT writes `<save folder>/exports/NAME_id.ghost` and the ghost **leaves your box** (so each ghost is unique).
  Set `exportKeepsCopy = true` in settings.kyo to keep a copy instead. Options menu → GHOST FILES opens the folder.
* A friend **drags the .ghost file onto their game window** (while playing) and it joins their box.
* The file is a scrambled seed code with a checksum: edited or made-up files are refused, and the same file can't be imported twice.

## Quest givers — `game/questgivers/<id>.kyo`
```lua
QuestGiver "grave_keeper" { name = "Grave Keeper", map = "zomnia", x = 15, y = 25, sprite = "keeper",
  quests = { "keeper_lanterns", "salt_run", "bone_king" },   -- handed out in this order ("random" = any)
  order = "list", repeatable = false, greeting = "HELP ME?" }
```
"!" = they have a quest for you. Walk into them → ACCEPT (it replaces your current quest). When it's done the HUD says
**RETURN TO GRAVE KEEPER** and the flag points at them; walk back in for the reward ("?" over their head).
Quests with `random = false` only come from givers.

## Selling to stores
Store fields: `buysItems = true`, `buysGhosts = true`, `sellRate = 50` (items sell for 50% of their `price`).
Ghosts (box only, never your last one) sell for `Rules.ghost_price(ghost, store)` in `game/rules/ghost_price.kyo`.
In the store press TAB (or LEFT/RIGHT) for BUY · SELL ITEMS · SELL GHOSTS. Hook: `onSell(store, thing, kyo)` → return false to refuse.

## Turbz player builds (no mods, no LÖVE)
`bash scripts/build_player.sh` (also run by GitHub Actions) makes `Turbz.love` without mods (a `release.txt` switches mods off),
the browser version (`/play/`) and `Turbz-windows.zip` (Turbz.exe + the dlls it needs).
