-- Witch soul-collector. The playable witch only.
-- Source sheets are 96px frames (3x pixel art). The game loads a 32px bake,
-- one source pixel each, so clothes share the body's anchor. Callers still
-- pass a scale relative to that 32px frame.
-- NPCs must never use this sheet. They keep the sprites they had before the witch.

Character = Character or {}

local SHEET = "assets/characters/character_spritesheet_v5b_witch_sm.png"
local ARMOR = "assets/characters/armor_v2_spritesheet_sm.png"
local BLOCK, FRAME = 128, 32

Character.SKIN_COUNT = 12
Character.HAIR_COUNT = 20
Character.OUTFIT_COUNT = 60
Character.LAYERS = { "BODY", "BACK", "FEET", "LEGS", "CHEST", "HAIR", "HEAD" }

Character.SKIN_NAMES = {
  "Porcelain", "Fair", "Light", "Warm Beige", "Tan", "Caramel",
  "Brown", "Dark Brown", "Orc Green", "Undead", "Pale Rose", "Deep Umber",
}
Character.HAIR_NAMES = {
  "Pixie", "Bob", "Long Straight", "Ponytail", "Twin Tails", "Top Bun", "Side Braid", "Wavy Lob",
  "Hime Cut", "Messy Short", "Side Sweep", "Twin Buns", "Long Wavy", "Spiky", "Curtain",
  "Low Bun", "Fishtail", "Afro", "Wolf Cut", "Shaved",
}
Character.OUTFIT_NAMES = {
  "Widow Veil", "Ghost Bride", "Dirge Gown", "Wailing Shroud", "Eternal Mourner",
  "Soul Reaper", "Void Wraith", "Abyssal Witch", "Null Coven", "Phantom Sovereign",
  "Cinder Witch", "Pyre Dancer", "Ashborn Hex", "Flamecaller", "Inferno Oracle",
  "Saltweave", "Deepcaller", "Abyssal Coven", "Coral Siren", "Tidewitch Supreme",
  "Hedge Witch", "Briar Coven", "Mossbinder", "Root Oracle", "Ancient Grove",
  "Grave Witch", "Ossuary Hex", "Marrow Coven", "Deathweave", "Undying Lich",
  "Spark Witch", "Tempest Coven", "Arc Caller", "Thunder Oracle", "Storm Sovereign",
  "Frost Hex", "Glacier Coven", "Rime Oracle", "Crystal Witch", "Absolute Zero",
  "Moonwitch", "Starweave", "Celestial Coven", "Dawn Oracle", "Sol Invictus",
  "Owl Hex", "Feather Coven", "Gale Witch", "Sky Oracle", "Zephyr Sovereign",
  "Sigil Witch", "Runeweave", "Hex Coven", "Spirit Oracle", "Arcane Sovereign",
  "Blood Hex", "Crimson Coven", "Moon Witch", "Sacrifice Oracle", "Eternal Bloodmoon",
}
Character.HAIR_COLORS = {
  { name = "Black",  r = 0.16, g = 0.16, b = 0.16 },
  { name = "Brown",  r = 0.42, g = 0.27, b = 0.14 },
  { name = "Blonde", r = 0.90, g = 0.78, b = 0.43 },
  { name = "Red",    r = 0.71, g = 0.28, b = 0.12 },
  { name = "Auburn", r = 0.55, g = 0.27, b = 0.18 },
  { name = "White",  r = 0.92, g = 0.92, b = 0.94 },
  { name = "Blue",   r = 0.25, g = 0.40, b = 0.85 },
  { name = "Green",  r = 0.25, g = 0.65, b = 0.35 },
  { name = "Pink",   r = 0.90, g = 0.45, b = 0.65 },
  { name = "Purple", r = 0.55, g = 0.30, b = 0.75 },
}

-- Outfit index % 5 is the family's quality step. A light wash so sets read as rarer.
local TIER_WASH = {
  { 1.00, 1.00, 1.00 },
  { 0.78, 1.00, 0.82 },
  { 0.70, 0.84, 1.00 },
  { 0.86, 0.68, 1.00 },
  { 1.00, 0.88, 0.48 },
}
local QUALITY_WASH = {
  worn = { 0.72, 0.72, 0.74 },
  common = { 1, 1, 1 },
  fine = { 0.72, 1, 0.80 },
  rare = { 0.62, 0.80, 1 },
  epic = { 0.82, 0.58, 1 },
  legendary = { 1, 0.84, 0.42 },
}

local sheetImg, armorImg
local quadCache = {}

local function loadImg(path)
  if not love.filesystem.getInfo(path) then return nil end
  local ok, img = pcall(love.graphics.newImage, path)
  if not ok or not img then return nil end
  img:setFilter("nearest", "nearest")
  return img
end

function Character.ensureSheet()
  if sheetImg then return sheetImg end
  sheetImg = loadImg(SHEET)
  return sheetImg
end

function Character.ensureArmor()
  if armorImg then return armorImg end
  armorImg = loadImg(ARMOR)
  return armorImg
end

function Character.bodyKind()
  return "female"
end

function Character.outfitOrigin(setIndex)
  local s = (setIndex or 0) % Character.OUTFIT_COUNT
  local cell = s * 4
  local col = cell % 20
  local row = 2 + math.floor(cell / 20)
  return col * BLOCK, row * BLOCK
end

function Character.armorOrigin(setNumber, slotIndex)
  local n = ((setNumber or 1) - 1) % 20
  local row = math.floor(n / 4)
  local col = (n % 4) * 5 + (slotIndex or 0)
  return col * BLOCK, row * BLOCK
end

local function quadOn(img, which, ox, oy, direction, frame)
  if not img then return nil end
  direction = math.max(0, math.min(3, direction or 0))
  frame = math.max(0, math.min(3, frame or 0))
  local key = table.concat({ which, ox, oy, direction, frame }, ":")
  if quadCache[key] then return quadCache[key] end
  local q = love.graphics.newQuad(ox + frame * FRAME, oy + direction * FRAME, FRAME, FRAME, img:getDimensions())
  quadCache[key] = q
  return q
end

function Character.defaultLook()
  return {
    bodyType = "female",
    skin = 1,
    hair = 2,
    hairColor = 3,
    outfit = 52,
  }
end

function Character.rollLook(seed)
  seed = tonumber(seed) or 1
  local function rnd(n)
    seed = (seed * 1103515245 + 12345) % 2147483648
    return seed % n
  end
  return {
    bodyType = "female",
    skin = rnd(Character.SKIN_COUNT),
    hair = rnd(Character.HAIR_COUNT),
    hairColor = rnd(#Character.HAIR_COLORS) + 1,
    outfit = rnd(Character.OUTFIT_COUNT),
  }
end

function Character.randomLook(seed)
  return Character.rollLook(seed or love.math.random(1, 2000000000))
end

function Character.rollWorldCast()
  S.npcLooks = {}
  local function take(term)
    if not All then return end
    for _, def in ipairs(All(term) or {}) do
      if def and def.id then
        S.npcLooks[def.id] = Character.rollLook(love.math.random(1, 2000000000))
      end
    end
  end
  take("TownNPC")
  take("QuestGiver")
  take("Blurb")
end

function Character.npcLookFromId(id, _)
  if S and S.npcLooks and id and S.npcLooks[id] then
    local look = S.npcLooks[id]
    look.bodyType = "female"
    if look.outfit == nil then look.outfit = (tonumber(look.head) or 0) % Character.OUTFIT_COUNT end
    return look
  end
  local h = 17
  local s = tostring(id or "npc")
  for i = 1, #s do h = (h * 33 + s:byte(i)) % 2147483647 end
  local look = Character.rollLook(h)
  if S then
    S.npcLooks = S.npcLooks or {}
    if id then S.npcLooks[id] = look end
  end
  return look
end

function Character.ensurePlayerLook()
  S.look = S.look or Character.defaultLook()
  S.look.bodyType = "female"
  if S.look.outfit == nil then S.look.outfit = 52 end
  S.look.skin = (S.look.skin or 1) % Character.SKIN_COUNT
  S.look.hair = (S.look.hair or 0) % Character.HAIR_COUNT
  return S.look
end

function Character.effectiveLook(look)
  look = look or Character.ensurePlayerLook()
  local out = {}
  for k, v in pairs(look) do out[k] = v end
  out.bodyType = "female"
  if out.outfit == nil then out.outfit = 52 end
  return out
end

local function drawScale(scale)
  -- Snap to whole pixels. A fractional nearest sample shifts the gown off the body.
  scale = scale or 1
  local dest = math.max(FRAME, math.floor(FRAME * scale + 0.5))
  return dest / FRAME
end

local function blit(img, which, ox, oy, direction, frame, px, py, scale, r, g, b)
  local q = quadOn(img, which, ox, oy, direction, frame)
  if not q then return end
  love.graphics.setColor(r or 1, g or 1, b or 1, 1)
  love.graphics.draw(img, q, px, py, 0, scale, scale)
end

local ARMOR_SLOT = { accessory = 0, back = 0, head = 1, chest = 2, legs = 3, feet = 4 }

local function equippedPieces()
  local eq = S and S.equippedArmor
  if not eq then return {} end
  local out = {}
  for slot, index in pairs(ARMOR_SLOT) do
    local p = eq[slot]
    if p and slot ~= "back" then
      local set = 1
      if type(p.visual) == "table" and p.visual.set then set = p.visual.set
      elseif type(p.visual) == "number" then set = (p.visual % 20) + 1 end
      out[#out + 1] = { slot = slot, index = index, set = set, quality = p.quality }
    end
  end
  table.sort(out, function(a, b) return a.index < b.index end)
  return out
end

function Character.draw(look, cx, cy, scale, direction, frame, opts)
  if not Character.ensureSheet() then return end
  opts = opts or {}
  if not opts.raw then look = Character.effectiveLook(look) else look = look or Character.defaultLook() end
  look.bodyType = "female"
  scale = drawScale(scale)
  direction = direction or 0
  frame = frame or 0
  local px = math.floor(cx - (FRAME / 2) * scale)
  local py = math.floor(cy - (FRAME - 0.5) * scale)

  blit(sheetImg, "body", (look.skin or 0) % Character.SKIN_COUNT * BLOCK, 0, direction, frame, px, py, scale, 1, 1, 1)

  local pieces = (not opts.raw) and equippedPieces() or {}
  local helm = false
  for _, p in ipairs(pieces) do if p.slot == "head" then helm = true end end

  if not helm and (look.hair or 0) >= 0 then
    local c = Character.HAIR_COLORS[look.hairColor or 2] or Character.HAIR_COLORS[1]
    blit(sheetImg, "hair", (look.hair or 0) % Character.HAIR_COUNT * BLOCK, BLOCK, direction, frame, px, py, scale, c.r, c.g, c.b)
  end

  local wearing = #pieces > 0
  local outfit = (look.outfit or 0) % Character.OUTFIT_COUNT
  local wash = TIER_WASH[(outfit % 5) + 1]
  local ox, oy = Character.outfitOrigin(outfit)
  -- Gown first, armor after, same origin and scale. Plates cover the dress
  -- instead of the dress drawing through them.
  blit(sheetImg, "outfit", ox, oy, direction, frame, px, py, scale, 0.84 + wash[1] * 0.16, 0.84 + wash[2] * 0.16, 0.84 + wash[3] * 0.16)
  if wearing and Character.ensureArmor() then
    local rank = { feet = 1, legs = 2, chest = 3, accessory = 4, head = 5 }
    table.sort(pieces, function(a, b) return (rank[a.slot] or 9) < (rank[b.slot] or 9) end)
    for _, p in ipairs(pieces) do
      local qwash = QUALITY_WASH[p.quality or ""] or { 1, 1, 1 }
      local ax, ay = Character.armorOrigin(p.set, p.index)
      blit(armorImg, "armor", ax, ay, direction, frame, px, py, scale, qwash[1], qwash[2], qwash[3])
    end
  end
  love.graphics.setColor(1, 1, 1, 1)
end

function Character.dirFromFacing(dx, dy)
  if math.abs(dx or 0) > math.abs(dy or 0) then
    return (dx or 0) < 0 and 1 or 2
  end
  return (dy or 0) < 0 and 3 or 0
end

function Character.walkFrame(steps, moving)
  if not moving then return 0 end
  return (steps or 0) % 4
end

function Character.applyLook(look)
  if not look then return end
  S.look = { bodyType = "female", skin = look.skin or 1, hair = look.hair or 0, hairColor = look.hairColor or 2, outfit = look.outfit or 52 }
  if LocalSave then LocalSave() end
end

function Character.ensureWardrobe()
  S.unlockedClothes = S.unlockedClothes or {}
  return S.unlockedClothes
end
function Character.hasClothes() return false end
function Character.unlockClothes() end
function Character.equipClothes() end
