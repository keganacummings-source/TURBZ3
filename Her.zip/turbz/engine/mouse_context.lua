-- Pure-mouse gameplay: right-click world tiles for a context menu.
-- Choosing an action pathfinds the player there and runs the action on arrival.

MouseCtx = MouseCtx or {}

local function screenToTile(sx, sy)
  local c = World._cam
  if not c then return S.px, S.py end
  local camX, camY, ets = c[1], c[2], c[6]
  local tx = math.floor(camX + sx / ets)
  local ty = math.floor(camY + sy / ets)
  return tx, ty
end

local function dist2(ax, ay, bx, by)
  local dx, dy = ax - bx, ay - by
  return dx * dx + dy * dy
end

-- Simple BFS path (4-dir) limited length
local function pathfind(x0, y0, x1, y1, maxSteps)
  maxSteps = maxSteps or 80
  if not World.walkable(x1, y1) then return nil end
  if x0 == x1 and y0 == y1 then return {} end
  local key = function(x, y) return y * (World.w or 1) + x end
  local q, head = { { x0, y0 } }, 1
  local came, seen = {}, {}
  seen[key(x0, y0)] = true
  local dirs = { { 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 } }
  local steps = 0
  while head <= #q and steps < maxSteps * 8 do
    steps = steps + 1
    local cur = q[head]; head = head + 1
    local cx, cy = cur[1], cur[2]
    if cx == x1 and cy == y1 then
      local path = {}
      local k = key(cx, cy)
      while came[k] do
        local p = came[k]
        path[#path + 1] = { cx, cy }
        cx, cy = p[1], p[2]
        k = key(cx, cy)
      end
      -- reverse
      local out = {}
      for i = #path, 1, -1 do out[#out + 1] = path[i] end
      return out
    end
    for _, d in ipairs(dirs) do
      local nx, ny = cx + d[1], cy + d[2]
      local nk = key(nx, ny)
      if not seen[nk] and World.walkable(nx, ny) then
        seen[nk] = true
        came[nk] = { cx, cy }
        q[#q + 1] = { nx, ny }
      end
    end
  end
  return nil
end

function MouseCtx.actionsAt(tx, ty)
  local acts = {}
  if not World.inMap(tx, ty) then return acts end

  acts[#acts + 1] = { id = "walk", label = "WALK HERE" }
  acts[#acts + 1] = { id = "place_camp", label = "PLACE CAMP" }

  local place = PlaceAt and PlaceAt(tx, ty)
  if place then
    if place.kind == "TownNPC" or place.kind == "Blurb" or place.kind == "QuestGiver" then
      acts[#acts + 1] = { id = "talk", label = "TALK", place = place }
    elseif place.kind == "Store" then
      acts[#acts + 1] = { id = "shop", label = "OPEN SHOP", place = place }
    elseif place.kind == "Boss" then
      acts[#acts + 1] = { id = "fight", label = "CHALLENGE", place = place }
    else
      acts[#acts + 1] = { id = "use_place", label = "INTERACT", place = place }
    end
  end

  if S.npcCompanions and Get then
    for _, id in ipairs(S.npcCompanions) do
      local pos = S.npcCompanionPos and S.npcCompanionPos[id]
      local def = Get("TownNPC", id)
      if def and pos and math.floor(pos.x + 0.5) == tx and math.floor(pos.y + 0.5) == ty then
        acts[#acts + 1] = { id = "talk", label = "TALK", place = def }
        break
      end
    end
  end

  if ResourceNodes and ResourceNodes.at then
    local n = ResourceNodes.at(tx, ty)
    if n then acts[#acts + 1] = { id = "harvest", label = "HARVEST", node = n } end
  end

  if Camp and Camp.has and Camp.has() and S.camp and S.camp.x == tx and S.camp.y == ty then
    acts[#acts + 1] = { id = "camp", label = "OPEN CAMP" }
  end

  local wb = WorldBoss and WorldBoss.active and WorldBoss.active()
  if wb and wb.x == tx and wb.y == ty then
    acts[#acts + 1] = { id = "world_boss", label = "FIGHT WARLORD" }
  end

  if Mechanics and Mechanics.isFishable and Mechanics.isFishable(tx, ty) then
    acts[#acts + 1] = { id = "fish", label = "FISH HERE" }
  end

  -- Nearby wilds
  if S.wilds then
    for _, w in ipairs(S.wilds) do
      if w.x == tx and w.y == ty then
        acts[#acts + 1] = { id = "battle", label = "BATTLE GHOST", wild = w }
        break
      end
    end
  end

  if SessionNet and SessionNet.mode ~= "offline" then
    for id, p in pairs(SessionNet.players or {}) do
      if p.x == tx and p.y == ty and id ~= SessionNet.playerId then
        acts[#acts + 1] = { id = "pvp", label = "CHALLENGE PVP", pid = id }
      end
    end
  end

  acts[#acts + 1] = { id = "cancel", label = "CANCEL" }
  return acts
end

function MouseCtx.open(sx, sy)
  local tx, ty = screenToTile(sx, sy)
  S.ctxMenu = {
    x = sx, y = sy,
    tx = tx, ty = ty,
    acts = MouseCtx.actionsAt(tx, ty),
    index = 1,
  }
  Play("step")
end

function MouseCtx.close()
  S.ctxMenu = nil
end

function MouseCtx.run(act)
  if not act or act.id == "cancel" then MouseCtx.close() return end
  local tx, ty = S.ctxMenu.tx, S.ctxMenu.ty
  MouseCtx.close()
  -- Free-move steer toward tile center, run action on arrival
  if Movement and Movement.setTarget then
    S._pendingMouseAct = act
    S._pendingMouseTile = { tx, ty }
    Movement.setTarget(tx + 0.5, ty + 0.5, false)
    -- poll arrival via mouseOrder lightweight flag
    S.mouseOrder = { free = true, act = act, tx = tx, ty = ty }
  end
end

function MouseCtx.update()
  local ord = S.mouseOrder
  if not ord then return end
  if S.battle or (S.screen and S.screen ~= "explore") then
    S.mouseOrder = nil
    return
  end
  -- Step along path one tile per call (driven from explore onTick)
  -- Respect walk cooldown so pathing matches keyboard movement speed
  if (S.moveCd or 0) > 0 then return end
  if ord.pathI <= #(ord.path) then
    local step = ord.path[ord.pathI]
    if step and World.walkable(step[1], step[2]) then
      local dx, dy = step[1] - S.px, step[2] - S.py
      S.dir = { dx, dy }
      if Step then
        Step(dx, dy)
      else
        S.px, S.py = step[1], step[2]
        S.rx, S.ry = S.px, S.py
        S.steps = (S.steps or 0) + 1
        S.moveCd = Settings.stepTicks or 4
      end
    end
    ord.pathI = ord.pathI + 1
    return
  end
  -- Arrived — perform action
  local act = ord.act
  S.mouseOrder = nil
  if not act then return end
  if act.id == "walk" then
    -- done
  elseif act.id == "talk" and act.place then
    if TalkToPlace then TalkToPlace(act.place)
    elseif PlaceKinds and PlaceKinds[act.place.kind] then PlaceKinds[act.place.kind](act.place)
    else
      S.townTalk = { id = act.place.id, mode = "menu", index = 1 }
      Go("town_dialog")
    end
  elseif act.id == "shop" and act.place and PlaceKinds and PlaceKinds.Store then
    PlaceKinds.Store(act.place)
  elseif act.id == "fight" and act.place and PlaceKinds and PlaceKinds.Boss then
    PlaceKinds.Boss(act.place)
  elseif act.id == "use_place" and act.place and PlaceKinds and PlaceKinds[act.place.kind] then
    PlaceKinds[act.place.kind](act.place)
  elseif act.id == "harvest" then
    if ResourceNodes and ResourceNodes.interactFacing then ResourceNodes.interactFacing() end
    -- also try exact tile
    if ResourceNodes and ResourceNodes.at then
      local n, i = ResourceNodes.at(ord.tx, ord.ty)
      if n then ResourceNodes.harvest(n, i) end
    end
  elseif act.id == "camp" then
    if Camp and Camp.openMenu then Camp.openMenu() end
  elseif act.id == "battle" and act.wild then
    if StartWildBattle then StartWildBattle(act.wild)
    elseif EncounterWild then EncounterWild(act.wild) end
  elseif act.id == "pvp" and act.pid and SessionNet and SessionNet.challengePlayer then
    SessionNet.challengePlayer(act.pid)
  elseif act.id == "fish" and Mechanics and Mechanics.tryFish then
    Mechanics.tryFish()
  elseif act.id == "world_boss" and WorldBoss and WorldBoss.tryEngage then
    WorldBoss.tryEngage()
  elseif act.id == "place_camp" and Camp and Camp.placeAt then
    Camp.placeAt(tx, ty)
  end
end

function MouseCtx.draw()
  local m = S.ctxMenu
  if not m or not m.acts then return end
  local W, H = Engine.W or 480, Engine.H or 480
  local rowH = 26
  local w = 196
  local h = #m.acts * rowH + 12
  local x = math.min(m.x, W - w - 6)
  local y = math.min(m.y, H - h - 6)
  x = math.max(6, x)
  y = math.max(6, y)
  Box(x + 3, y + 3, w, h, "#00000088")
  Box(x, y, w, h, "panel")
  Frame(x, y, w, h, "kyo")
  Box(x, y, 3, h, "blood")
  m._box = { x, y, w, h }
  m._rows = {}
  for i, act in ipairs(m.acts) do
    local ry = y + 6 + (i - 1) * rowH
    local sel = i == (m.index or 1)
    if sel then Box(x + 6, ry, w - 10, rowH - 2, "panel2") end
    TextFit(act.label, x + 12, ry + 16, w - 20, sel and "kyo" or "ink", 8, 8)
    m._rows[i] = { x + 6, ry, w - 10, rowH - 2, act }
  end
end
