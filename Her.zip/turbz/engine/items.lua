-- Items: Item "potion" { onUse = function(e) ... end }.  Bag lives in S.bag  { potion = 3 }
function GiveItem(id, n, why)
  if not Get("Item", id) then Engine.warn('GiveItem: no Item "' .. tostring(id) .. '"', true) return end
  S.bag = S.bag or {}
  S.bag[id] = (S.bag[id] or 0) + (n or 1)
  Fire("item_got", { item = id, count = n or 1, why = why })
  if SiteFeed and SiteFeed.onItem then SiteFeed.onItem(id, n or 1, why) end
end
function ItemCount(id)
  local it = Get("Item", id)
  if it and it.onCount then return it.onCount() or 0 end
  return S.bag[id] or 0
end
function HasItem(id) return ItemCount(id) > 0 end
function TakeItem(id, n) S.bag[id] = math.max(0, ItemCount(id) - (n or 1)) if S.bag[id] == 0 then S.bag[id] = nil end end

function BagList()
  local out = {}
  for _, it in ipairs(All("Item")) do if HasItem(it.id) or (it.always and not (S.battle and it.where == "field")) then table.insert(out, it) end end
  table.sort(out, function(a, b) if a.order == b.order then return a.id < b.id end return a.order < b.order end)
  return out
end

-- catch the wild ghost in battle. bonus = extra percent
function TryCatch(bonus)
  local b = S.battle
  if not b or not b.wild then Say(Word("cant_catch")) if b then b.line = Word("cant_catch") end return false end
  local foe = b.foe
  local dead = foe and ((foe.hp or 1) <= 0)
  local ok = dead or Chance(Rules.catch_chance(foe, bonus or 0))
  if ok then
    b.line = Word("caught", Upper(foe.name))
    b.caught = true
    b.wait, b.pending = Settings.faintTicks, function() WinBattle() end
    Play("win")
    if AddSkillXp then AddSkillXp("catching", dead and 18 or 12) end
    return true
  end
  b.line = Word("broke_free", Upper(foe.name))
  return false
end

-- Post-battle guaranteed catch of a defeated wild ghost (uses one ghost jar).
function CatchDefeatedGhost(ghost)
  if not ghost then return false end
  if not HasItem("ghost_jar") then
    Say("NEED A GHOST JAR")
    Play("bump")
    return false
  end
  TakeItem("ghost_jar", 1)
  local sp = Species(ghost)
  local prev = S.best and S.best[sp.id]
  local better = (not prev) or StatSum(ghost) > StatSum(prev)
  if better and S.best then S.best[sp.id] = ghost end
  table.insert(S.box, ghost)
  S.caught = S.caught or {}
  S.caught[sp.id] = S.caught[sp.id] or {}
  S.caught[sp.id][ghost.rarity or "faded"] = true
  if sp and sp.onCaught then sp.onCaught(ghost, { ghost = ghost }) end
  S.statsLifetime = S.statsLifetime or {}; S.statsLifetime.caught = (S.statsLifetime.caught or 0) + 1; Fire("ghost_caught", { ghost = ghost, region = RegionAt and RegionAt(S.px, S.py) and RegionAt(S.px, S.py).id })
  if CompanionCongratsRare then CompanionCongratsRare(ghost) end
  if AddSkillXp then AddSkillXp("catching", 20) end
  Say(Upper(GhostName(ghost)) .. " CAUGHT")
  Play("win")
  return true
end

function FleeBattle()
  local b = S.battle
  if not b then return end
  if b.enemy or b.boss or b.shrine or b.pvp or not b.wild then
    b.line = Word("cant_flee")
    return false
  end
  S.battle = nil
  Go("explore")
  Say(Word("fled"))
  Fire("battle_fled", b)
  return true
end

-- use an item. In battle it costs your turn (the foe still attacks)
function UseItem(id, ghost)
  local it = Get("Item", id)
  if not it or (not HasItem(id) and not it.always) then return false end
  local b = S.battle
  if b and it.where == "field" then Say(Word("not_now")) return false end
  if not b and it.where == "battle" then Say(Word("not_now")) return false end
  local e = { item = it, battle = b, user = b and b.me, target = b and b.foe, ghost = ghost or (b and b.me.ghost) or LeadGhost(), used = true }
  if it.onUse then it.onUse(e) end
  if not e.used then return false end
  if it.consume then TakeItem(id) end
  Fire("item_used", e)
  if b and S.battle == b and not b.caught and not b.pending then BattleItemTurn() end
  return true
end
