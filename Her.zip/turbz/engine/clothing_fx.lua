-- Clothing particle FX overlay from assets/fx/clothing_fx.png
-- 320 effects, 4 frames each, 32x32, block i: BX=(i%16)*128, BY=(i//16)*32

ClothingFX = ClothingFX or {}

local SHEET = "assets/fx/clothing_fx.png"
local img, w, h
local quads = {}

function ClothingFX.ensure()
  if img then return img end
  if not love.filesystem.getInfo(SHEET) then return nil end
  local ok, i = pcall(love.graphics.newImage, SHEET)
  if not ok or not i then return nil end
  i:setFilter("nearest", "nearest")
  img, w, h = i, i:getWidth(), i:getHeight()
  return img
end

function ClothingFX.quad(fxId, frame)
  fxId = fxId or 0
  frame = (frame or 0) % 4
  local key = fxId .. ":" .. frame
  if quads[key] then return quads[key] end
  if not ClothingFX.ensure() then return nil end
  local BX = (fxId % 16) * 128
  local BY = math.floor(fxId / 16) * 32
  local x = BX + frame * 32
  if x + 32 > w or BY + 32 > h then return nil end
  local q = love.graphics.newQuad(x, BY, 32, 32, w, h)
  quads[key] = q
  return q
end

-- Draw one equipped clothing effect, aligned to the character's 32px frame.
-- Only the first effect plays, slowly, so stacked sheets do not strobe across the world.
function ClothingFX.drawOnCharacter(cx, cy, scale, frame)
  if not Armor or not Armor.activeFx then return end
  if not ClothingFX.ensure() then return end
  scale = scale or 1
  local list = Armor.activeFx()
  local id = list and list[1]
  if id == nil then return end
  local anim = math.floor(((S and S.t) or 0) / 10) % 4
  local q = ClothingFX.quad(id, anim)
  if not q then return end
  local px = math.floor(cx - 16 * scale)
  local py = math.floor(cy - 30 * scale)
  love.graphics.setBlendMode("alpha")
  love.graphics.setColor(1, 1, 1, 0.85)
  love.graphics.draw(img, q, px, py, 0, scale, scale)
  love.graphics.setColor(1, 1, 1, 1)
  love.graphics.setBlendMode("alpha")
end
