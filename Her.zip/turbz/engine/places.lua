-- Places: things that stand on a map tile (Boss, Store, Trader). Walk into one to use it.
-- Make your own kind:  NewTerm "Healer" { map = "", x = 0, y = 0, sprite = "" }  then  PlaceKinds.Healer = function(def) ... end
PlaceKinds = {}

local function bossSize(def) return def.kind == "Boss" and Settings.bossTiles or 1 end

function PlaceVisible(def)
  if def.map ~= S.map and not (S.map == "giant_world" and def.map == "giant_world") then return false end
  -- Once a TownNPC joins the player, render them in the companion trail rather than at home.
  if def.kind == "TownNPC" then
    for _, id in ipairs(S.npcCompanions or {}) do if id == def.id then return false end end
  end
  if def.kind == "Boss" then
    local st = S.bosses[def.id]
    if st and (def.once or (S.turn or 0) - st.turn < def.respawnTurns) then return false end
  end
  if def.kind == "EnemyCamp" then
    local t = S.campCleared and S.campCleared[def.id]
    if t then return false end
  end
  if def.kind == "Trader" and def.once and S.trades[def.id] then return false end
  if def.kind == "QuestGiver" and S.trainer < def.minTrainer then return false end
  return true
end

function AllPlaces()
  local out = {}
  for kind in pairs(PlaceKinds) do
    for _, def in ipairs(All(kind)) do if PlaceVisible(def) then table.insert(out, def) end end
  end
  return out
end

-- the place covering tile x, y (bosses cover Settings.bossTiles x bossTiles)
function PlaceAt(x, y)
  for _, def in ipairs(AllPlaces()) do
    local n = bossSize(def)
    if x >= def.x and x < def.x + n and y >= def.y and y < def.y + n then return def end
  end
  return nil
end

function UsePlace(def)
  local open = PlaceKinds[def.kind]
  if def.onTalk and def.onTalk(def) == false then return end
  if open then open(def) end
  if Mechanics and Mechanics.onTalkSocial then Mechanics.onTalkSocial() end
  Fire("place_used", def)
end

function DrawPlace(def)
  local z = WorldSpriteScale()
  local n = bossSize(def)
  local cx, cy = WorldToScreen(def.x + (n - 1) / 2, def.y + (n - 1) / 2)
  if def.kind == "Boss" then
    DrawGhostAt(BossLook(def), cx, cy + Sin(Tick() / 18) * 2, Settings.bossScale * z)
  elseif def.kind == "TownNPC" or def.kind == "Blurb" or def.kind == "QuestGiver" then
    -- Townsfolk keep the sprites they had before the witch. Never her body or her armor.
    local sprite = (def.sprite and def.sprite ~= "" and def.sprite) or "keeper"
    DrawSpriteAt(sprite, cx, cy, z, def.palette)
    local mark = def.kind == "QuestGiver" and GiverMark and GiverMark(def)
    if mark then Text(mark, cx - 3, cy - 14, mark == "?" and "green" or "kyo", 8) end
    if def.kind == "TownNPC" or def.kind == "Blurb" then
      local dx, dy = def.x - (S.px or 0), def.y - (S.py or 0)
      if dx * dx + dy * dy <= 36 then
        local relation = (S.npcReactions or {})[def.id] or 0
        local cue, cueColor = "...", "kyo"
        if relation > 0 then cue, cueColor = "+", "green"
        elseif relation < 0 then cue, cueColor = "!", "blood" end
        if WorldLife and WorldLife.bubble then
          local b = WorldLife.bubble(def)
          if b then cue, cueColor = b, "kyo" end
        end
        Text(cue, cx - 10, cy - 20, cueColor, 8)
      end
      if WorldLife and WorldLife.petOf then
        local st = WorldLife.petOf(def)
        if st and st.pet then
          DrawGhostAt({ species = st.pet, rarity = nil, mass = 1, speed = 2 }, cx - 10 * z, cy + 6, z * 0.72)
        end
      end
    end
  elseif def.kind == "Settlement" then
    DrawSpriteAt(def.sprite ~= "" and def.sprite or "quest_flag", cx, cy, z)
    Text(def.city and "CITY" or "PLACE", cx - 14, cy - 14, "kyo", 8)
  elseif def.kind == "EnemyCamp" then
    local look = Sheets and Sheets.fromId and Sheets.fromId("skeleton", def.id or def.name, "ghoul", "faded")
    if look and Sheets.draw then
      local frame = math.floor((Tick() or 0) / 10) % 4
      Sheets.draw(look, cx, cy, z, 0, frame)
    else
      DrawSpriteAt(def.sprite ~= "" and def.sprite or "skeleton", cx, cy, z)
    end
    Text("CAMP", cx - 14, cy - 14, "blood", 8)
  else
    DrawSpriteAt(def.sprite, cx, cy, z, def.palette)
    local mark = def.kind == "QuestGiver" and GiverMark(def)
    if mark then Text(mark, cx - 3, cy - 10 + (Blink(20) and 1 or 0), mark == "?" and "green" or "kyo") end
  end
end

-- BOSSES ------------------------------------------------------------
function BossLook(def)
  local look = { species = def.ghost, rarity = def.rarity ~= "" and def.rarity or "eclipse", sprite = def.sprite ~= "" and def.sprite or nil, mass = 3, speed = 3, type = "ghoul" }
  if Sheets and Sheets.fromId then
    look.layers = Sheets.fromId("boss", def.id or def.name, "ghoul", look.rarity)
  end
  return look
end

PlaceKinds.Boss = function(def)
  if S.screen ~= "explore" or S.book then return end
  S.intro = { boss = def, t = 0, sx = def.x + (Settings.bossTiles - 1) / 2, sy = def.y + (Settings.bossTiles - 1) / 2 }
  Go("intro")
  S.shake = 14
  Play("jump")
  Say(def.intro ~= "" and Upper(def.intro) or Word("wants_fight", Upper(def.name)))
end

function BossTeam(def)
  local g = MakeGhost(def.ghost, def.level, def.rarity ~= "" and def.rarity or nil)
  g.nick = def.name
  if def.sprite ~= "" then g.sprite = def.sprite end
  local u = MakeUnit(g)
  u.hp, u.max = Round(u.hp * def.hpMultiplier), Round(u.max * def.hpMultiplier)
  u.shown, u.boss = u.hp, def
  local team = { u }
  for _, m in ipairs(def.minions) do
    local mg = Get("Ghost", m.ghost) and MakeGhost(m.ghost, m.level or def.level, m.rarity)
    if mg then table.insert(team, MakeUnit(mg)) end
  end
  return team
end

function BossBeaten(def)
  S.bosses[def.id] = { turn = S.turn or 0, wins = ((S.bosses[def.id] or {}).wins or 0) + 1 }
  for id, n in pairs(def.drops) do if Get("Item", id) then GiveItem(id, n) end end
  Fire("boss_defeated", { boss = def.id, def = def })
end

-- STORES ------------------------------------------------------------
-- S.stores[id] = { shelf = { { item, price, left } }, turn = world turn of the last restock }
local function shelfEntry(st, id)
  for _, e in ipairs(st.shelf) do if e.item == id then return e end end
  return nil
end

-- one "add": walk the stock in random order, the first entry that wins its % chance goes on the shelf
local function addOne(def, st)
  local order = {}
  for _, s in ipairs(def.stock) do table.insert(order, s) end
  for i = #order, 2, -1 do local j = love.math.random(i) order[i], order[j] = order[j], order[i] end
  for _, s in ipairs(order) do
    local e = shelfEntry(st, s.item)
    local full = (e and e.left >= (s.max or 99)) or (not e and #st.shelf >= def.maxShelf)
    if Get("Item", s.item) and not full and Chance(s.chance or 100) then
      if e then e.left = Min(s.max or 99, e.left + (s.amount or 1))
      else table.insert(st.shelf, { item = s.item, price = s.price or 1, left = s.amount or 1 }) end
      return true
    end
  end
  return false
end

function RestockStore(def, adds)
  local st = S.stores[def.id]
  for _ = 1, adds or def.itemsPerRestock do addOne(def, st) end
  st.turn = S.turn or 0
  if def.onRestock then def.onRestock(def, st.shelf) end
  Fire("store_restocked", { store = def.id, shelf = st.shelf })
end

function StoreState(def)
  if not S.stores[def.id] then
    S.stores[def.id] = { shelf = {}, turn = S.turn or 0 }
    RestockStore(def, def.startItems)
  end
  return S.stores[def.id]
end

-- runs every world turn: stores add new items every restockTurns
function StoresTick()
  for _, def in ipairs(All("Store")) do
    local st = StoreState(def)
    if def.restockTurns > 0 and (S.turn or 0) - st.turn >= def.restockTurns then RestockStore(def) end
  end
end

function BuyFromStore(def, n)
  local st = StoreState(def)
  local e = st.shelf[n]
  if not e then return false end
  local price = e.price or 0
  if SkillShopPriceMult then price = math.max(1, math.floor(price * SkillShopPriceMult())) end
  if Armor and Armor.get then price = math.max(1, math.floor(price * (1 - Armor.get("shop_charm") / 100))) end
  if S.kyo < price then Say(Word("need_kyo", price)) Play("bump") return false end
  if def.onBuy and def.onBuy(def, e) == false then return false end
  S.kyo = S.kyo - price
  GiveItem(e.item)
  e.left = e.left - 1
  if e.left <= 0 then table.remove(st.shelf, n) end
  Say(Word("bought", Upper(Get("Item", e.item).name), price))
  Play("quest")
  if AddSkillXp then AddSkillXp("trading", 4) end
  Fire("item_bought", { store = def.id, item = e.item, price = price })
  return true
end

-- SELLING: items for sellRate % of their price, spare box ghosts for Rules.ghost_price
function ItemSellPrice(def, id)
  local it, base = Get("Item", id), 0
  for _, s in ipairs(def.stock) do if s.item == id then base = s.price or 0 end end
  if it and it.price > 0 then base = it.price end
  if base <= 0 or (it and (it.onCount or not it.sellable)) then return 0 end
  local kyo = Max(1, Floor(base * def.sellRate / 100))
  if SkillSellPriceMult then kyo = Max(1, Floor(kyo * SkillSellPriceMult())) end
  if Armor and Armor.get then kyo = Max(1, Floor(kyo * (1 + Armor.get("sell_boost") / 100))) end
  return kyo
end

function SellableItems(def)
  local out = {}
  if not def.buysItems then return out end
  for _, it in ipairs(BagList()) do if ItemSellPrice(def, it.id) > 0 and ItemCount(it.id) > 0 then table.insert(out, it) end end
  return out
end

function SellableGhosts(def)
  if not def.buysGhosts then return {} end
  return S.box
end

local function paid(def, what, kyo, name)
  if def.onSell and def.onSell(def, what, kyo) == false then return false end
  S.kyo = S.kyo + kyo
  Say(Word("sold", name, kyo))
  Play("quest")
  return true
end

function SellItem(def, id)
  local kyo = ItemSellPrice(def, id)
  if not def.buysItems or kyo <= 0 or ItemCount(id) <= 0 then Say(Word("wont_buy")) Play("bump") return false end
  if not paid(def, id, kyo, Upper(Get("Item", id).name)) then return false end
  TakeItem(id)
  Fire("item_sold", { store = def.id, item = id, kyo = kyo })
  return true
end

function SellGhost(def, g)
  if not def.buysGhosts then Say(Word("wont_buy")) Play("bump") return false end
  if #Owned() <= 1 then Say(Word("last_ghost")) Play("bump") return false end
  local kyo = Rules.ghost_price(g, def)
  if SkillSellPriceMult then kyo = Max(1, Floor(kyo * SkillSellPriceMult())) end
  if Armor and Armor.get then kyo = Max(1, Floor(kyo * (1 + Armor.get("sell_boost") / 100))) end
  if AddSkillXp then AddSkillXp("trading", 6) end
  if not paid(def, g, kyo, GhostName(g)) then return false end
  RemoveOwned(g)
  Fire("ghost_sold", { store = def.id, ghost = g, kyo = kyo })
  return true
end

PlaceKinds.Store = function(def)
  StoreState(def)
  S.place, S.storeIndex, S.storeTab = def, 1, "buy"
  Go("store")
end

-- TRADERS -----------------------------------------------------------
-- wants = { type = "normal", ghost = "gaikotsu", minLevel = 3, rarity = "faded" }  (all optional)
function TraderWants(def, g)
  local w, sp = def.wants, Species(g)
  if w.ghost and g.species ~= w.ghost then return false end
  if w.type and sp.type ~= w.type then return false end
  if w.rarity and g.rarity ~= w.rarity then return false end
  if w.minLevel and g.level < w.minLevel then return false end
  if def.onCheck then return def.onCheck(def, g) ~= false end
  return true
end

function TradeOptions(def)
  local out = {}
  for _, g in ipairs(Owned()) do if TraderWants(def, g) then table.insert(out, g) end end
  return out
end

function RemoveOwned(g)
  for i = 1, Settings.partySize do if S.party[i] == g then S.party[i] = nil return true end end
  for i, b in ipairs(S.box) do if b == g then table.remove(S.box, i) return true end end
  return false
end

function TradeGhost(def, g)
  if #Owned() <= 1 then Say(Word("last_ghost")) Play("bump") return false end
  RemoveOwned(g)
  LeadGhost()
  GiveReward(def.gives)
  S.trades[def.id] = (S.trades[def.id] or 0) + 1
  Say(Word("traded", GhostName(g), RewardText(def.gives)))
  Play("win")
  Fire("ghost_traded", { trader = def.id, ghost = g })
  return true
end

PlaceKinds.Trader = function(def)
  S.place, S.tradeIndex = def, 1
  Go("trade")
end

-- QUEST GIVERS -------------------------------------------------------
-- S.givers[id] = { done = { questId = true }, active = questId or nil }
function GiverState(def)
  S.givers[def.id] = S.givers[def.id] or { done = {} }
  return S.givers[def.id]
end

-- the quest this giver would hand out now (nil = none left)
function GiverNextQuest(def)
  local st = GiverState(def)
  local left = {}
  for _, id in ipairs(def.quests) do
    local q = Get("Quest", id)
    if q and q.enabled and not st.done[id] and S.trainer >= q.minTrainer then
      if def.order == "list" then return id end
      table.insert(left, id)
    elseif q and def.order == "list" and not st.done[id] then return nil end
  end
  if #left == 0 and def.repeatable and next(st.done) then st.done = {} return GiverNextQuest(def) end
  st.offer = st.offer and InList(left, st.offer) and st.offer or Pick(left)
  return st.offer
end

function GiverMark(def)
  local q = S.quest
  if q and q.giver == def.id then return q.done and "?" or nil end
  if GiverNextQuest(def) then return "!" end
  return nil
end

function AcceptGiverQuest(def)
  local id = GiverNextQuest(def)
  if not id then return false end
  GiverState(def).active = id
  NewQuest(id, def.id)
  Say(Word("quest_taken", Upper(Get("Quest", id).name)))
  Fire("giver_quest_taken", { giver = def.id, quest = id })
  return true
end

function GiverReturned(giverId, questId)
  if not S or type(S.givers) ~= "table" or not giverId then return end
  local st = S.givers[giverId]
  if type(st) ~= "table" then return end
  st.done = st.done or {}
  st.done[questId], st.active, st.offer = true, nil, nil
end

PlaceKinds.QuestGiver = function(def)
  if S.quest and S.quest.giver == def.id and S.quest.done then Go("reward") return end
  S.place = def
  Go("giver")
end
