-- SaveGame / LoadGame. Saves go to the LOVE save folder (see README)
-- party + box are saved as ghost ids; each ghost lives in its own ghosts/<gid>.ghost file
local SAVE_KEYS = { "worldVersion", "map", "bag", "px", "py", "steps", "trainer", "kills", "need", "sound", "kyo", "quest", "seen", "caught", "best", "uid", "vars",
  "bosses", "stores", "trades", "givers", "questsDone", "imported", "turn", "discovered", "wearing", "wearables", "favorites", "zoom", "shrineBest", "shrineSeen", "bank", "quests", "npcReactions", "npcCompanions", "npcQuestState", "npcCompanionPos", "playerName",
  "folk", "campCleared", "resourceNodes", "_nodeSeed", "_nodeOffscreen", "_ambushIn", "story", "storiesDone", "storyMemory", "storyEscort" }

local function ser(v)
  local t = type(v)
  if t == "number" or t == "boolean" then return tostring(v) end
  if t == "string" then return string.format("%q", v) end
  if t ~= "table" then return "nil" end
  local parts = {}
  for k, val in pairs(v) do
    local kt, vt = type(k), type(val)
    if (kt == "string" or kt == "number") and vt ~= "function" and vt ~= "userdata" then
      local key = kt == "number" and ("[" .. k .. "]") or ("[" .. string.format("%q", k) .. "]")
      table.insert(parts, key .. "=" .. ser(val))
    end
  end
  return "{" .. table.concat(parts, ",") .. "}"
end
Serialize = ser


-- Active save isolation. Legacy single-player continues using Settings.saveFile for
-- compatibility; each multiplayer world/player pair gets a completely separate root.
local function safeSavePart(value, fallback)
  local out = tostring(value or ""):gsub("[^%w_-]", "")
  if out == "" then return fallback or "unknown" end
  return out:sub(1, 48)
end

function ActiveSaveDir()
  if S and S.sessionMode == "multiplayer" and S.sessionWorldId and S.sessionPlayerId then
    local root = "multiplayer/" .. safeSavePart(S.sessionWorldId, "world") .. "/players/" .. safeSavePart(S.sessionPlayerId, "player")
    love.filesystem.createDirectory(root)
    return root
  end
  return ""
end

function ActiveSavePath(relative)
  local root = ActiveSaveDir()
  if root == "" then return relative end
  return root .. "/" .. tostring(relative or "save.lua")
end

function ActiveSaveFile()
  if S and S.sessionMode == "multiplayer" then return ActiveSavePath("save.lua") end
  return Settings.saveFile
end

-- Write the active local savestate (single-player legacy path or isolated multiplayer path).
-- silent: no toast. ghosts: refresh the active save root ghost files.
local function writeSave(opts)
  opts = opts or {}
  local out = {}
  for _, k in ipairs(SAVE_KEYS) do out[k] = S[k] end
  if opts.ghosts ~= false and SaveGhostFiles then SaveGhostFiles() end
  out.skills = S.skills or {}
  out.look = S.look
  out.armorBag = S.armorBag
  out.equippedArmor = S.equippedArmor
  out.enchantStash = S.enchantStash
  out.bmListings = S.bmListings
  out.camps = S.camps
  out.campIndex = S.campIndex
  out.stamina = S.stamina
  out.staminaMax = S.staminaMax
  out.spirit = S.spirit
  out.spiritMax = S.spiritMax
  out.woke = S.woke
  out.tokens = S.tokens
  out.statsLifetime = S.statsLifetime
  out.skillPerks = S.skillPerks
  out.camp = S.camp
  out.zoomIndex = S.zoomIndex
  out.zoom = S.zoom
  out.musicEnabled = S.musicEnabled
  out.musicVolume = S.musicVolume
  out.unlockedClothes = S.unlockedClothes or {}
  out.equippedClothes = S.equippedClothes or {}
  out.npcLooks = S.npcLooks
  out.ghostForms = S.ghostForms
  out.worldGhostSeed = S.worldGhostSeed
  out.ghoulRoster = S.ghoulRoster
  out.shroomMarket = S.shroomMarket
  out.party, out.box = {}, {}
  for i = 1, Settings.partySize do if S.party[i] then out.party[i] = S.party[i].gid end end
  for i, g in ipairs(S.box) do out.box[i] = g.gid end
  local ok, err = pcall(love.filesystem.write, ActiveSaveFile(), "return " .. ser(out))
  if not ok then Engine.warn("Local save failed: " .. tostring(err), false) end
  return out, ok
end

-- Silent local autosave: one file, no cloud, no message. Safe to call every step.
function LocalSave()
  if Settings.localAutosave == false then return end
  if not S or not S.map then return end
  if S._localSaveLock then return end
  S._localSaveLock = true
  local out = writeSave({ ghosts = true })
  S._localSaveLock = false
  S._lastLocalSave = love.timer and love.timer.getTime() or (S.t or 0)
  Fire("local_saved", out)
end

-- Manual save: local-only, routed to the active single-player or multiplayer save root.
function SaveGame()
  local out = writeSave({ ghosts = true })
  Say(Word("saved"))
  Fire("saved", out)
end

local function valid(g)
  if not g or not Get("Ghost", g.species) then return false end
  if not Get("Rarity", g.rarity or "") then g.rarity = g.sleeping and "sleeping" or CommonRarity() end
  return true
end

function LoadGame()
  if not HasSave() then return false end
  local ok, chunk = pcall(love.filesystem.load, ActiveSaveFile())
  if not ok or not chunk then return false end
  local ran, d = pcall(chunk)
  if not ran or type(d) ~= "table" then Engine.warn("Save file is broken - starting fresh", true) return false end
  for _, k in ipairs(SAVE_KEYS) do if d[k] ~= nil then S[k] = d[k] end end
  local function ghost(v) if type(v) == "table" then return v end return LoadGhostFile(v) end
  S.skills = d.skills or S.skills or {}
  S.look = d.look or S.look
  S.armorBag = d.armorBag or S.armorBag or {}
  S.equippedArmor = d.equippedArmor or S.equippedArmor or {}
  S.enchantStash = d.enchantStash or S.enchantStash or {}
  S.bmListings = d.bmListings or S.bmListings or {}
  S.camps = d.camps or S.camps or {}
  S.campIndex = d.campIndex or 1
  S.stamina = d.stamina or 100
  S.staminaMax = d.staminaMax or 100
  S.spirit = d.spirit or 8
  S.spiritMax = d.spiritMax or 36
  S.woke = d.woke
  S.tokens = d.tokens or 0
  S.statsLifetime = d.statsLifetime or S.statsLifetime or {}
  S.skillPerks = d.skillPerks or S.skillPerks or {}
  if Camp and Camp.ensure then Camp.ensure() end
  if Armor and Armor.syncVisuals then Armor.syncVisuals() end
  S.camp = d.camp or S.camp
  if d.zoomIndex then S.zoomIndex = d.zoomIndex end
  if d.zoom then S.zoom = d.zoom end
  if d.musicEnabled ~= nil then S.musicEnabled = d.musicEnabled end
  if d.musicVolume then S.musicVolume = d.musicVolume end
  S.unlockedClothes = d.unlockedClothes or {}
  S.equippedClothes = d.equippedClothes or {}
  S.npcLooks = d.npcLooks or S.npcLooks
  S.ghostForms = d.ghostForms or S.ghostForms
  S.worldGhostSeed = d.worldGhostSeed or S.worldGhostSeed
  S.ghoulRoster = d.ghoulRoster or S.ghoulRoster
  if GhoulRoster and GhoulRoster.restore then GhoulRoster.restore() end
  if WorldGhosts and WorldGhosts.ensure then WorldGhosts.ensure() end
  if Character and Character.rollWorldCast and not (S.npcLooks and next(S.npcLooks)) then
    Character.rollWorldCast()
  end
  if Skills and Skills.initFromSave then Skills.initFromSave(S.skills) end
  S.shroomMarket = d.shroomMarket or S.shroomMarket
  S.party, S.box = {}, {}
  for i = 1, Settings.partySize do S.party[i] = d.party and d.party[i] and ghost(d.party[i]) or nil end
  for _, v in ipairs(d.box or {}) do table.insert(S.box, ghost(v)) end
  if S.quest and not Get("Quest", S.quest.id or "") then S.quest = nil end
  S.npcReactions = S.npcReactions or {}
  S.npcCompanions = S.npcCompanions or {}
  S.npcQuestState = S.npcQuestState or {}
  if Stories and Stories.restore then Stories.restore() end
  -- Companion positions are rebuilt against the current global map, never reused
  -- from a legacy save that may have stored coordinates in a separate map.
  S.npcCompanionPos, S.companionBanter = {}, nil
  for id in pairs(d.caughtSleep or {}) do S.caught[id] = S.caught[id] or {}; S.caught[id].sleeping = true end
  for i = 1, Settings.partySize do if S.party[i] and not valid(S.party[i]) then S.party[i] = nil end end
  local box = {}
  for _, g in ipairs(S.box) do if valid(g) then table.insert(box, g) end end
  S.box = box
  for _, g in ipairs(Owned()) do EnsureGid(g) g.uid = g.uid or NextUid() end
  for _, g in ipairs(Owned()) do if NormalizeGhostTyping then NormalizeGhostTyping(g) end end
  for id, g in pairs(S.best) do if not valid(g) then S.best[id] = nil elseif NormalizeGhostTyping then NormalizeGhostTyping(g) end end
  local savedMap = S.map
  local savedWorldVersion = d.worldVersion or 0
  -- Separate-map saves and prior global-world layouts have coordinates for
  -- different terrain. Move older versions to Crownfall once, then preserve
  -- discovered regions so the atlas fast-travel network is retained.
  if savedMap ~= "giant_world" or savedWorldVersion < 5 then
    S.map = "giant_world"
    World.build("giant_world")
    S.px, S.py = World.map.start[1], World.map.start[2]
    S.discovered = S.discovered or {}
    local startRegion = RegionAt(S.px, S.py)
    if startRegion and startRegion.id then S.discovered[startRegion.id] = true end
  else
    World.build("giant_world")
    if not World.walkable(S.px, S.py) then
      S.px, S.py = World.map.start[1], World.map.start[2]
    end
  end
  S.rx, S.ry = S.px, S.py
  S.worldVersion = 5
  if TownCompanionStep then TownCompanionStep() end
  Fire("loaded", d)
  return true
end
