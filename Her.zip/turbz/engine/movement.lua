-- Free (non-tile-based) player movement with smooth camera and click-to-move.
-- S.px / S.py are continuous world coords in tile units.
-- Collision samples nearby solid tiles; interactions use nearest tile.

Movement = Movement or {}

local SPEED = 4.2          -- tiles per second (keyboard)
local CLICK_SPEED = 4.8    -- tiles per second (click-to-move)
local ARRIVE_EPS = 0.12
local CAM_LERP = 12         -- higher = tighter camera follow (less lag/shake)

function Movement.tile(x, y)
  return math.floor((x or 0) + 0.5), math.floor((y or 0) + 0.5)
end

function Movement.solid(x, y)
  local tx, ty = math.floor(x), math.floor(y)
  if not World or not World.walkable then return false end
  local canSwim = Transform and Transform.canSwim and Transform.canSwim()
  local function blocked(sx, sy)
    local t = World.tileAt and World.tileAt(sx, sy)
    if canSwim and (t == "ocean" or t == "water" or t == "shore" or t == "shallow" or t == "reef") then
      return false
    end
    return not World.walkable(sx, sy)
  end
  local r = 0.28
  for _, o in ipairs({
    { 0, 0 }, { r, 0 }, { -r, 0 }, { 0, r }, { 0, -r },
    { r * 0.7, r * 0.7 }, { -r * 0.7, r * 0.7 }, { r * 0.7, -r * 0.7 }, { -r * 0.7, -r * 0.7 },
  }) do
    local sx, sy = math.floor(x + o[1]), math.floor(y + o[2])
    if blocked(sx, sy) then return true end
  end
  return false
end

function Movement.tryMove(dx, dy)
  if not dx and not dy then return false end
  local nx, ny = S.px + (dx or 0), S.py + (dy or 0)
  -- axis separation for sliding along walls
  local moved = false
  if dx and dx ~= 0 then
    local tx = S.px + dx
    if not Movement.solid(tx, S.py) then
      S.px = tx
      moved = true
    end
  end
  if dy and dy ~= 0 then
    local ty = S.py + dy
    if not Movement.solid(S.px, ty) then
      S.py = ty
      moved = true
    end
  end
  if moved then
    S.steps = (S.steps or 0) + 1
    local tx, ty = Movement.tile(S.px, S.py)
    local here = World.regionAt and World.regionAt(tx, ty)
    if here and here.id then
      S.discovered = S.discovered or {}
      S.discovered[here.id] = true
    end
    -- Tile-edge interactions (once per discrete tile change)
    local key = tx .. "," .. ty
    if key ~= S._lastTileKey then
      S._lastTileKey = key
      if Skills and Skills.noteTileWalk then Skills.noteTileWalk() end
      if here and here.id and Skills and Skills.noteDiscover then Skills.noteDiscover(here.id) end
      -- Dog: extra mushroom finds while walking
      if Transform and Transform.shroomMult and Transform.shroomMult() > 1 then
        -- Dog still finds more when you harvest. It does not plant nodes at your feet.
      end
      if NpcAt then
        local npc = NpcAt(tx, ty)
        if npc and StartEnemyIntro then StartEnemyIntro(npc) return moved end
      end
      if PlaceAt then
        local place = PlaceAt(tx, ty)
        if place and UsePlace then UsePlace(place) return moved end
      end
      if WildAt then
        local hit = WildAt(tx, ty)
        if hit and StartIntro then StartIntro(hit) return moved end
      end
      if Fire then Fire("step", { x = tx, y = ty }) end
      if LocalSave and (S.steps % 30) == 0 then LocalSave() end
    end
    if Mechanics and Mechanics.weatherStep and (S.steps % 12) == 0 then
      Mechanics.weatherStep()
    end
  end
  return moved
end

function Movement.setDirFromVec(dx, dy)
  if math.abs(dx) > math.abs(dy) then
    S.dir = { dx > 0 and 1 or -1, 0 }
  elseif math.abs(dy) > 0.01 then
    S.dir = { 0, dy > 0 and 1 or -1 }
  end
end

function Movement.clearOrder()
  S.moveTarget = nil
  S.moveInteract = nil
  S.mouseOrder = nil
end

function Movement.setTarget(tx, ty, interact)
  S.moveTarget = { x = tx, y = ty }
  S.moveInteract = interact and true or false
end

function Movement.update(dt)
  if S.screen ~= "explore" or S.battle or S.afk then return end
  dt = math.min(dt or 0.016, 0.05)

  local mx, my = 0, 0
  if KeyHeld then
    if KeyHeld("up") then my = my - 1 end
    if KeyHeld("down") then my = my + 1 end
    if KeyHeld("left") then mx = mx - 1 end
    if KeyHeld("right") then mx = mx + 1 end
  end

  if mx ~= 0 or my ~= 0 then
    -- keyboard cancels click path
    Movement.clearOrder()
    local len = math.sqrt(mx * mx + my * my)
    mx, my = mx / len, my / len
    Movement.setDirFromVec(mx, my)
    local spd = SPEED
    if Armor and Armor.get then
      spd = spd * (1 + math.min(0.35, (Armor.get("swift") or 0) / 100))
    end
    if Transform and Transform.speedMult then spd = spd * Transform.speedMult() end
    if SkillAdventuringSpeed then spd = spd * SkillAdventuringSpeed() end
    Movement.tryMove(mx * spd * dt, my * spd * dt)
  elseif S.moveTarget then
    local tx, ty = S.moveTarget.x, S.moveTarget.y
    local dx, dy = tx - S.px, ty - S.py
    local dist = math.sqrt(dx * dx + dy * dy)
    if dist <= ARRIVE_EPS then
      S.px, S.py = tx, ty
      local doInteract = S.moveInteract
      Movement.clearOrder()
      S._moveStuck = nil
      if doInteract and TalkInteract then
        TalkInteract()
      end
    else
      local prevX, prevY = S.px, S.py
      local spd = CLICK_SPEED * dt
      if Transform and Transform.speedMult then spd = spd * Transform.speedMult() end
      if dist < spd then spd = dist end
      local nx, ny = dx / dist, dy / dist
      Movement.setDirFromVec(nx, ny)
      Movement.tryMove(nx * spd, ny * spd)
      local movedDist = math.abs(S.px - prevX) + math.abs(S.py - prevY)
      if movedDist < 0.001 then
        S._moveStuck = (S._moveStuck or 0) + dt
        if (S._moveStuck or 0) > 0.35 then
          Movement.clearOrder()
          S._moveStuck = nil
        end
      else
        S._moveStuck = 0
      end
    end
  end

  -- Smooth camera: exponential lerp toward player (no step snapping)
  local t = 1 - math.exp(-CAM_LERP * dt)
  S.rx = (S.rx or S.px) + (S.px - (S.rx or S.px)) * t
  S.ry = (S.ry or S.py) + (S.py - (S.ry or S.py)) * t

  -- Follower trail (fractional)
  if S.followers then
    if (S._trailT or 0) <= 0 then
      table.insert(S.followers, 1, { S.px, S.py })
      local humanCount = #(S.npcCompanions or {})
      local trailLimit = math.max(8, ((EffectivePartySize and EffectivePartySize()) or 6) + humanCount + 4)
      while #S.followers > trailLimit do table.remove(S.followers) end
      S._trailT = 0.08
    else
      S._trailT = (S._trailT or 0) - dt
    end
  end
end

-- Double-click detection
local lastClickT, lastClickX, lastClickY = 0, 0, 0

function Movement.onClick(x, y, button)
  if S.screen ~= "explore" then return false end
  button = button or 1
  if button ~= 1 then return false end

  local c = World and World._cam
  if not c then return false end
  local ets = c[6] or 16
  local wx = c[1] + x / ets
  local wy = c[2] + y / ets

  local now = love.timer and love.timer.getTime() or 0
  local double = (now - lastClickT) < 0.35
    and math.abs(x - lastClickX) < 12 and math.abs(y - lastClickY) < 12
  lastClickT, lastClickX, lastClickY = now, x, y

  Movement.setTarget(wx, wy, double)
  if double then
    Say("GOING...")
  end
  return true
end
