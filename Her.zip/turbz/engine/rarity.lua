-- Rarity: rolls a rarity for new ghosts and recolours ANY ghost palette automatically
function CommonRarity()
  for _, r in ipairs(All("Rarity")) do if r.oneIn <= 0 then return r.id end end
  return "awake"
end

function RarityOf(g) return Get("Rarity", g and g.rarity or "") or Get("Rarity", CommonRarity()) end

function RarityList()
  local list = All("Rarity")
  table.sort(list, function(a, b) if a.order == b.order then return a.id < b.id end return a.order < b.order end)
  return list
end

-- rarest first: each tier gets its own 1-in-N roll
function RollRarity()
  local list = All("Rarity")
  table.sort(list, function(a, b) return a.oneIn > b.oneIn end)
  local luck = Settings.rarityLuck or 1
  for _, r in ipairs(list) do
    if r.oneIn > 0 and love.math.random() < luck / r.oneIn then return r.id end
  end
  return CommonRarity()
end

-- real chance of each tier after the rarer rolls (percent)
function RarityChance(id)
  local list = All("Rarity")
  table.sort(list, function(a, b) return a.oneIn > b.oneIn end)
  local left, luck = 100, Settings.rarityLuck or 1
  for _, r in ipairs(list) do
    if r.oneIn > 0 then
      local p = left * math.min(1, luck / r.oneIn)
      if r.id == id then return p end
      left = left - p
    end
  end
  return left
end

-- colour maths (any colour in, colour table out)
function MixColor(a, b, amount)
  a, b = ToColor(a), ToColor(b)
  local t = (amount or 50) / 100
  return { a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t, a[3] + (b[3] - a[3]) * t, a[4] or 1 }
end

function Saturate(c, percent)
  c = ToColor(c)
  local g = c[1] * 0.3 + c[2] * 0.59 + c[3] * 0.11
  local t = percent / 100
  return { g + (c[1] - g) * t, g + (c[2] - g) * t, g + (c[3] - g) * t, c[4] or 1 }
end

function Brighten(c, percent)
  if percent >= 0 then return MixColor(c, { 1, 1, 1, 1 }, percent) end
  return MixColor(c, { 0, 0, 0, 1 }, -percent)
end

function ApplyRarity(pal, g, sp, time)
  local r = RarityOf(g)
  if not r then return nil end
  for k, v in pairs(pal) do
    local c = ToColor(v)
    if r.saturation ~= 100 then c = Saturate(c, r.saturation) end
    if r.brightness ~= 0 then c = Brighten(c, r.brightness) end
    if r.mix ~= "" and r.amount > 0 then c = MixColor(c, r.mix, r.amount) end
    pal[k] = c
  end
  for k, v in pairs(r.letters) do pal[k] = v end
  if r.rainbow then
    local hue = time * 8
    pal.B, pal.L, pal.F = HSL(hue, 85, 62), HSL(hue + 40, 90, 78), HSL(hue + 180, 90, 70)
  end
  local spr = Get("Sprite", sp.sprite)
  local own = spr and spr.rarity[r.id]
  if own then for k, v in pairs(own) do pal[k] = v end end
  if r.onLook then r.onLook(pal, g, time) end
  return r
end

function SpriteSize(id)
  local sp = Get("Sprite", id)
  if not sp then return 8, 8 end
  local rows = #sp.frames > 0 and sp.frames[1] or sp
  local w = 0
  for i = 1, #rows do w = math.max(w, #rows[i]) end
  return w, #rows
end

-- crowns, sparks and tears drawn on top of the ghost
function DrawRarityExtras(r, spriteId, x, y, s, time)
  local w, h = SpriteSize(spriteId)
  if r.crown ~= "" then
    local cx = x + math.floor(w / 2) * s
    local top = y - 3 * s
    Box(cx - 2 * s, top + s, 5 * s, 2 * s, r.crown)
    Box(cx - 2 * s, top, s, s, r.crown)
    Box(cx, top - s, s, 2 * s, r.crown)
    Box(cx + 2 * s, top, s, s, r.crown)
    if r.crownGem ~= "" then Box(cx, top + s, s, s, r.crownGem) end
  end
  if r.sparks ~= "" then
    for i = 1, r.sparkCount do
      if r.sparkStyle == "drip" then
        local dx = x + math.floor(w * i / (r.sparkCount + 1)) * s
        local fall = (time * 0.4 + i * 9) % (h * s)
        Box(dx, y + math.floor(h * 0.45) * s + fall * 0.6, s, s, r.sparks)
      elseif math.floor(time / 5 + i * 3) % 4 ~= 0 then
        local seed = math.floor(time / 20) + i * 17
        local sx = x - s + (seed * 7919) % ((w + 2) * s)
        local sy = y - s + (seed * 104729) % ((h + 2) * s)
        Box(sx, sy, s, s, r.sparks)
      end
    end
  end
end
