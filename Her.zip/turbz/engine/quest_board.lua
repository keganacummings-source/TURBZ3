-- Procedural quest board + follower quests with strong rewards.

QuestBoard = QuestBoard or {}

local TYPES = {
  { kind = "hunt", label = "HUNT", goals = function()
      return { { kind = "kill", count = love.math.random(3, 8) } }
    end },
  { kind = "catch", label = "CATCH", goals = function()
      return { { kind = "catch", count = love.math.random(2, 5) } }
    end },
  { kind = "gather", label = "GATHER", goals = function()
      return { { kind = "collect", count = love.math.random(4, 10) } }
    end },
  { kind = "explore", label = "EXPLORE", goals = function()
      local regions = All("Region") or {}
      local r = regions[love.math.random(1, math.max(1, #regions))]
      return { { kind = "visit", region = r and r.id, count = 1 } }
    end },
  { kind = "fish", label = "FISH RUN", goals = function()
      return { { kind = "fish", count = love.math.random(2, 6) } }
    end },
  { kind = "shroom", label = "MYCO RUN", goals = function()
      return { { kind = "shroom", count = love.math.random(3, 7) } }
    end },
}

function QuestBoard.rollReward(opts)
  opts = opts or {}
  local armorChance = opts.armorChance or 18
  local follower = opts.follower
  if follower then armorChance = armorChance + 25 end
  local kyo = love.math.random(40, 180) + (S.trainer or 1) * 3
  local tokens = love.math.random(1, 3)
  local rewards = {
    kyo = kyo,
    tokens = tokens,
  }
  if love.math.random(1, 100) <= armorChance then
    rewards.armor = true
  end
  if love.math.random(1, 100) <= 22 then
    rewards.food = ({ "meat", "ration", "bread", "fish_meal" })[love.math.random(1, 4)]
  end
  if love.math.random(1, 100) <= 12 then
    rewards.ghost = true
  end
  return rewards
end

function QuestBoard.generate(opts)
  opts = opts or {}
  local t = TYPES[love.math.random(1, #TYPES)]
  local goals = t.goals()
  local rewards = QuestBoard.rollReward(opts)
  local id = "board_" .. tostring(love.timer.getTime()) .. "_" .. love.math.random(100, 999)
  -- Register a transient quest def
  Game.data.Quest = Game.data.Quest or {}
  Game.order.Quest = Game.order.Quest or {}
  local def = {
    id = id,
    kind = "Quest",
    name = t.label .. (opts.follower and " (COMPANION)" or ""),
    about = "Board contract — finish for solid pay.",
    goals = goals,
    rewards = {
      { kind = "kyo", amount = rewards.kyo },
    },
    _board = rewards,
    _follower = opts.follower and true or false,
    source = "quest_board",
  }
  if not Game.data.Quest[id] then table.insert(Game.order.Quest, id) end
  Game.data.Quest[id] = def
  return id, def
end

function QuestBoard.accept(opts)
  local id, def = QuestBoard.generate(opts)
  S.quest = {
    id = id,
    progress = {},
    done = false,
    board = def._board,
    follower = def._follower,
  }
  if QuestFlag then QuestFlag() end
  Say("QUEST: " .. Upper(def.name or id))
  Play("quest")
  return true
end

function QuestBoard.completePay()
  local q = S.quest
  if not q or not q.board then
    -- still try standard rewards
    return
  end
  local r = q.board
  if r.kyo then S.kyo = (S.kyo or 0) + r.kyo Say("+" .. r.kyo .. " KYO") end
  if r.tokens and Tokens then Tokens.add(r.tokens) Say("+" .. r.tokens .. " TOKENS") end
  if r.food and GiveItem then GiveItem(r.food, 1, "quest") Say("+" .. Upper(r.food)) end
  if r.armor and Armor and Armor.createPiece then
    local slots = Armor.SLOTS or { "head", "chest", "legs", "feet" }
    local piece = Armor.createPiece(slots[love.math.random(1, #slots)], math.max(8, (S.trainer or 5) + love.math.random(0, 12)), { quality = "worn" })
    if piece and Armor.give then Armor.give(piece, "quest") end
    Say("ARMOR REWARD!")
  end
  if r.ghost then
    local all = GhostList and GhostList() or All("Ghost") or {}
    if #all > 0 and MakeGhost then
      local sp = all[love.math.random(1, #all)]
      local sid = type(sp) == "table" and sp.id or sp
      S.box = S.box or {}
      local g = sid and MakeGhost(sid, math.max(5, math.floor((S.trainer or 5) * 0.8)))
      if g then table.insert(S.box, g) Say("GHOST REWARD!") end
    end
  end
  S.statsLifetime = S.statsLifetime or {}
  S.statsLifetime.quests = (S.statsLifetime.quests or 0) + 1
  if AddSkillXp then AddSkillXp("adventuring", 20) end
end

-- Companion offers
function QuestBoard.tryFollowerOffer()
  if S.quest and not S.quest.done then return end
  if not S.npcCompanions or #S.npcCompanions == 0 then return end
  if love.math.random(1, 100) > 8 then return end
  S.followerQuestOffer = true
  Say("A COMPANION HAS A JOB FOR YOU (TAB QUESTS)")
end
