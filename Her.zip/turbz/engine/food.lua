-- Food: stamina meals, hearth cooking, and a few spirit-touched bowls.

Food = Food or {}

Food.MEALS = {
  bread = 25, meat = 40, berry = 15, ration = 50, fish_meal = 35, candy = 10,
  raw_fish = 20, mushroom_broth = 30, spirit_broth = 15, hearty_stew = 70,
  coast_soup = 55, camp_pie = 80, honey = 18, cheese = 32, apple = 16, roast = 60,
}

Food.REGEN = {
  hearty_stew = 1.4, camp_pie = 1.1, roast = 0.8, ration = 0.4, coast_soup = 0.5,
}

Food.RECIPES = {
  { need = { "meat", "bread" }, out = "hearty_stew" },
  { need = { "raw_fish", "berry" }, out = "coast_soup" },
  { need = { "fish_meal", "berry" }, out = "coast_soup" },
  { need = { "mushroom_broth", "ration" }, out = "camp_pie" },
  { need = { "meat", "honey" }, out = "roast" },
  { need = { "raw_fish", "cheese" }, out = "fish_meal" },
}

function Food.amount(id)
  local base = Food.MEALS[id]
  if not base then return nil end
  local mult = 1
  if Armor and Armor.get then mult = mult + (Armor.get("food_power") or 0) / 100 end
  if SkillLevel then
    mult = mult + math.min(0.4, ((SkillLevel("hunting") or 1) - 1) * 0.0015)
    mult = mult + math.min(0.25, ((SkillLevel("fishing") or 1) - 1) * 0.0008)
  end
  return math.max(1, math.floor(base * mult))
end

function Food.eat(itemId)
  local heal = Food.amount(itemId)
  if not heal then return false end
  if not (TakeItem and TakeItem(itemId, 1)) then return false end
  S.staminaMax = S.staminaMax or 100
  S.stamina = math.min(S.staminaMax, (S.stamina or 0) + heal)
  local regen = Food.REGEN[itemId]
  if regen and Armor and Armor.get then regen = regen * (1 + (Armor.get("cook_pot") or 0) / 100) end
  if regen then
    S._foodRegen = math.max(S._foodRegen or 0, regen)
    S._foodRegenT = math.max(S._foodRegenT or 0, 18)
  end
  if itemId == "spirit_broth" or itemId == "mushroom_broth" or itemId == "candy" then
    if Spirit and Spirit.gain then Spirit.gain(itemId == "spirit_broth" and 14 or 4) end
  end
  Say("ATE " .. Upper(itemId) .. "  STA " .. math.floor(S.stamina))
  Play("quest")
  return true
end

local function has(id)
  return (S.bag and S.bag[id] or 0) >= 1
end

function Food.cook()
  for _, rec in ipairs(Food.RECIPES) do
    local ok = true
    for _, id in ipairs(rec.need) do if not has(id) then ok = false break end end
    if ok then
      for _, id in ipairs(rec.need) do TakeItem(id, 1) end
      local extra = 0
      if Armor and Armor.get and Armor.get("cook_pot") >= 12 and love.math.random(1, 100) <= 40 then extra = 1 end
      GiveItem(rec.out, 1 + extra)
      local item = Get("Item", rec.out)
      Say("COOKED " .. Upper((item and item.name) or rec.out))
      if AddSkillXp then AddSkillXp("alchemy", 8) AddSkillXp("hunting", 3) end
      Play("quest")
      return true
    end
  end
  Say("NOTHING TO COOK  (MEAT+BREAD, FISH+BERRY, BROTH+RATION)")
  return false
end
