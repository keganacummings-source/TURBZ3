-- Branching story quests. One active story at a time.
-- Beats are talk, escort+visit, defeat-while-escorted, or a choice between people.
-- Completing one pays far more than a board contract.

Stories = Stories or {}

local function regionName(id)
  local r = RegionById and RegionById(id)
  return (r and r.name) or id or "the wild"
end

local function following(id)
  if not id then return true end
  for _, v in ipairs(S.npcCompanions or {}) do if v == id then return true end end
  return false
end

local function npcName(id)
  local d = Get("TownNPC", id)
  return d and d.name or id or "Someone"
end

local STORIES = {
  gate = {
    id = "gate",
    name = "The Gate and the Archive",
    hook = "captain_vey",
    lead = "Talk to Captain Vey in Crownfall.",
    about = "Vey wants the south road shut. Orien thinks the packs are answering something older.",
    beats = {
      sella_road = {
        type = "visit", escort = "capital_guard_sella", region = "wz_20",
        line = "SELLA FALLS IN BEHIND YOU. WALK HER TO CROWNFALL NORTH WATCH, THEN COME BACK TO THE GATE.",
        hud = "ESCORT SELLA TO CROWNFALL NORTH WATCH",
        next = "fork",
      },
      fork = {
        type = "choice", npc = { "captain_vey", "scribe_orien" },
        line = "THE BARROWS WENT QUIET. VEY AND ORIEN ARE BOTH WAITING ON YOUR WORD.",
        hud = "CHOOSE: TALK TO VEY OR ORIEN",
        prompt = "VEY: SEAL THE NORTH WATCH WITH ME. FOUR PACKS, THEN THE GATE HOLDS. ORIEN: THE RECORDS SAY THE PACKS ARE ANSWERING THE MARKET STONES. DO NOT GIVE VEY A SLAUGHTER HE CANNOT UNDO.",
        options = {
          { label = "WALK WITH VEY AND BREAK THE PACKS", next = "vey_hunt",
            memory = { scribe_orien = "YOU CHOSE THE SPEAR. ORIEN WILL NOT FORGET THAT." } },
          { label = "WALK WITH ORIEN AND READ THE WARD", next = "orien_miret",
            memory = { captain_vey = "YOU WALKED PAST THE GATE. VEY IS DONE ASKING." } },
        },
      },
      vey_hunt = {
        type = "defeat", escort = "captain_vey", count = 4,
        line = "VEY COMES WITH YOU. PUT DOWN FOUR FIGHTS. HE COUNTS THEM.",
        hud = "FIGHT WITH VEY",
        next = "vey_close",
      },
      vey_close = {
        type = "talk", npc = "captain_vey", escort = "captain_vey",
        line = "VEY STAYS AT YOUR SHOULDER. SPEAK WITH HIM. HE COUNTS THE FIGHTS AS DONE.",
        prompt = "VEY: FOUR PACKS. THE ROAD IS OURS AGAIN. TAKE THIS. YOU EARNED MORE THAN A BOARD CHIT.",
        choice = "TAKE VEY'S PAY",
        reward = "vey",
      },
      orien_miret = {
        type = "talk", npc = "caretaker_miret", escort = "scribe_orien",
        line = "ORIEN COMES WITH YOU. MIRET KNOWS WHICH STONES HUM.",
        hud = "TAKE ORIEN TO MIRET",
        prompt = "MIRET: THE HUM IS NOT IN THE BARROWS. IT IS IN THE MARKET WARD STONES. WALK ORIEN THROUGH CROWNFALL MARKET WARD AND LISTEN.",
        choice = "WE WILL WALK THE WARD",
        next = "orien_ward",
      },
      orien_ward = {
        type = "visit", escort = "scribe_orien", region = "wz_31",
        hud = "CROSS CROWNFALL MARKET WARD WITH ORIEN",
        next = "orien_close",
      },
      orien_close = {
        type = "talk", npc = "scribe_orien", escort = "scribe_orien",
        prompt = "ORIEN: THE STONE ANSWERED. NOT A CURSE. A CALL. VEY WILL HATE THIS ANSWER. YOU STILL KEPT PEOPLE ALIVE. TAKE THE ARCHIVE'S PAY.",
        choice = "TAKE THE ARCHIVE PAY",
        reward = "orien",
      },
    },
  },

  letter = {
    id = "letter",
    name = "The Road That Ate a Letter",
    hook = "capital_runner_eli",
    lead = "Talk to Eli, the message runner.",
    about = "A letter for Mara never arrived. Eli will not walk the north ward alone again.",
    beats = {
      drown = {
        type = "visit", escort = "capital_runner_eli", region = "wz_21",
        line = "ELI FALLS IN BEHIND YOU. THE LETTER WAS LAST SEEN IN CROWNFALL NORTH WARD.",
        hud = "TAKE ELI TO CROWNFALL NORTH WARD",
        next = "bones",
      },
      bones = {
        type = "defeat", escort = "capital_runner_eli", count = 3,
        line = "THE POST IS EMPTY. BONE PACKS HAVE THE SATCHEL. ELI WILL NOT LEAVE YOUR SIDE UNTIL THREE OF THEM ARE DOWN.",
        hud = "WIN 3 FIGHTS WITH ELI",
        next = "deliver",
      },
      deliver = {
        type = "talk", npc = "capital_resident_mara", escort = "capital_runner_eli",
        hud = "BRING ELI AND WHAT IS LEFT TO MARA",
        prompt = "MARA: THAT IS MY BROTHER'S HAND. TORN, BUT IT IS HIS. ELI GOT IT HERE BECAUSE YOU WALKED WITH HIM. THAT IS WORTH MORE THAN A FETCH.",
        choice = "GIVE MARA THE LETTER",
        reward = "letter",
      },
    },
  },

  roofs = {
    id = "roofs",
    name = "Two Roofs",
    hook = { "capital_shelter_renn", "capital_guard_sella" },
    lead = "Talk to Renn at the shelter, and Sella on the gate.",
    about = "One night watch. Two people who both need it. You cannot stand both roofs.",
    beats = {
      hear = {
        type = "hear",
        need = { "capital_shelter_renn", "capital_guard_sella" },
        prompts = {
          capital_shelter_renn = "RENN: THE SLEEPING HALL FREEZES. IF THE WATCH STANDS HERE, PEOPLE LIVE. IF IT STANDS ON THE GATE, SELLA'S SPEARS HOLD AND WE SHIVER.",
          capital_guard_sella = "SELLA: THE GATE HAS SPEARS WITH NO HEADS. IF YOU STAND WITH ME, THE HALL GOES COLD. IF YOU STAND WITH RENN, THE ROAD COMES IN.",
        },
        hud = "HEAR BOTH RENN AND SELLA",
        next = "pick",
      },
      pick = {
        type = "choice", npc = { "capital_shelter_renn", "capital_guard_sella" },
        prompt = "ONE WATCH. RENN'S HALL OR SELLA'S GATE. THE OTHER WILL KNOW WHAT YOU REFUSED.",
        hud = "CHOOSE A ROOF",
        options = {
          { label = "STAND THE NIGHT IN RENN'S HALL", next = "renn_night",
            memory = { capital_guard_sella = "YOU LEFT THE GATE OPEN. SELLA DOES NOT OWE YOU A WORD." } },
          { label = "STAND THE NIGHT ON SELLA'S GATE", next = "sella_night",
            memory = { capital_shelter_renn = "THE HALL STAYED COLD. RENN REMEMBERS WHO WALKED PAST THE BEDS." } },
        },
      },
      renn_night = {
        type = "defeat", escort = "capital_shelter_renn", count = 3,
        line = "RENN COMES WITH YOU. THREE FIGHTS, THEN THE HALL CAN SLEEP.",
        hud = "HOLD THE NIGHT WITH RENN",
        next = "renn_close",
      },
      renn_close = {
        type = "talk", npc = "capital_shelter_renn", escort = "capital_shelter_renn",
        prompt = "RENN: THEY SLEPT. THAT IS THE WHOLE JOB. TAKE THIS. DO NOT CALL IT A CHORE.",
        choice = "TAKE THE HALL'S THANKS",
        reward = "renn",
      },
      sella_night = {
        type = "defeat", escort = "capital_guard_sella", count = 3,
        line = "SELLA COMES WITH YOU. THREE FIGHTS ON THE ROAD, THEN THE GATE IS A GATE AGAIN.",
        hud = "HOLD THE NIGHT WITH SELLA",
        next = "sella_close",
      },
      sella_close = {
        type = "talk", npc = "capital_guard_sella", escort = "capital_guard_sella",
        prompt = "SELLA: THE ROAD STOPPED TESTING US. THE HALL WILL HATE YOU FOR IT. I WILL NOT. TAKE THE GATE'S PAY.",
        choice = "TAKE THE GATE'S PAY",
        reward = "sella",
      },
    },
  },

  hum = {
    id = "hum",
    name = "The Stone Hum",
    hook = "caretaker_miret",
    lead = "Talk to Miret, the old caretaker.",
    about = "The walls are humming. Miret will not walk the North Watch without someone who has read the maps.",
    beats = {
      ask_orien = {
        type = "talk", npc = "scribe_orien",
        line = "MIRET: ASK ORIEN BEFORE YOU DRAG ME NORTH. THE MAPS DISAGREE AND I AM TOO OLD TO GUESS.",
        hud = "ASK ORIEN ABOUT THE HUM",
        prompt = "ORIEN: THE OLD MAPS GO BLANK AT THE NORTH WATCH. IF MIRET IS RIGHT, THE HUM STARTS THERE. I WILL NOT WALK IT. HE WILL, IF YOU DO.",
        choice = "I WILL TAKE MIRET TO THE NORTH WATCH",
        next = "the_hush",
      },
      the_hush = {
        type = "visit", escort = "caretaker_miret", region = "wz_20",
        line = "MIRET FALLS IN BEHIND YOU. THE NORTH WATCH IS WHERE THE MAPS END.",
        hud = "ESCORT MIRET TO CROWNFALL NORTH WATCH",
        next = "hum_close",
      },
      hum_close = {
        type = "talk", npc = "caretaker_miret", escort = "caretaker_miret",
        hud = "BRING MIRET HOME AND HEAR WHAT HE HEARD",
        prompt = "MIRET: IT IS NOT A CURSE AND IT IS NOT NOTHING. SOMETHING UNDER THE NORTH WATCH IS CALLING THEM. YOU WALKED AN OLD MAN TO THE EDGE OF THE MAPS. THIS PAY IS NOT A FETCH FEE.",
        choice = "TAKE MIRET'S PAY",
        reward = "hum",
      },
    },
  },

  bells = {
    id = "bells",
    name = "The Two Bells",
    hook = { "barrow_priest_keel", "barrow_digger_wren" },
    lead = "In Dust Barrows, talk to Keel and Wren.",
    about = "One barrow, two bells. Keel wants it sealed. Wren wants the people inside brought up. You cannot ring both.",
    beats = {
      hear = {
        type = "hear",
        need = { "barrow_priest_keel", "barrow_digger_wren" },
        prompts = {
          barrow_priest_keel = "KEEL: IF THAT DOOR OPENS, DUST BARROWS STOPS BEING A TOWN. SEAL IT WITH ME. WREN WILL CALL YOU A COWARD. THE LIVING WILL STILL HAVE A STREET.",
          barrow_digger_wren = "WREN: THREE NAMES ARE STILL DOWN THERE. KEEL HAS ALREADY STRUCK THEM FROM THE BOOK. WALK WITH ME TO ASHEN COMMON AND WE BRING BACK WHOEVER ANSWERS.",
        },
        hud = "HEAR BOTH KEEL AND WREN IN DUST BARROWS",
        next = "pick",
      },
      pick = {
        type = "choice", npc = { "barrow_priest_keel", "barrow_digger_wren" },
        prompt = "SEAL THE BARROW WITH KEEL, OR DIG WITH WREN. THE ONE YOU REFUSE WILL NOT FORGET THE BELL YOU DID NOT RING.",
        hud = "CHOOSE A BELL",
        options = {
          { label = "SEAL THE BARROW WITH KEEL", next = "keel_road",
            memory = { barrow_digger_wren = "YOU LET KEEL SHUT THE DOOR. WREN SAYS THE NAMES UNDER IT ARE ON YOU." } },
          { label = "OPEN THE WAY WITH WREN", next = "wren_road",
            memory = { barrow_priest_keel = "YOU CHOSE THE DIG. KEEL WILL NOT BLESS YOUR NAME IN THIS TOWN." } },
        },
      },
      keel_road = {
        type = "visit", escort = "barrow_priest_keel", region = "wz_36",
        line = "KEEL COMES WITH YOU. THE CRACK THAT FEEDS THE BARROW STARTS IN VOLT CHASM.",
        hud = "TAKE KEEL TO VOLT CHASM",
        next = "keel_fight",
      },
      keel_fight = {
        type = "defeat", escort = "barrow_priest_keel", count = 3,
        line = "THE CRACK HAS A PACK ON IT. THREE FIGHTS WITH KEEL, THEN THE DOOR CAN BE SEALED.",
        hud = "FIGHT WITH KEEL",
        next = "keel_close",
      },
      keel_close = {
        type = "talk", npc = "barrow_priest_keel", escort = "barrow_priest_keel",
        prompt = "KEEL: THE BELL FOR THE DEAD STAYS UNRUNG. THAT IS HOW A TOWN KEEPS ITS STREETS. THIS PAY IS THE SEAL, NOT A CHORE FEE.",
        choice = "TAKE THE SEAL'S PAY",
        reward = "keel",
      },
      wren_road = {
        type = "visit", escort = "barrow_digger_wren", region = "wz_34",
        line = "WREN COMES WITH YOU. THE OLD PAY CHEST WAS LAST MARKED ON ASHEN COMMON.",
        hud = "TAKE WREN TO ASHEN COMMON",
        next = "wren_fight",
      },
      wren_fight = {
        type = "defeat", escort = "barrow_digger_wren", count = 3,
        line = "THE COMMON IS NOT EMPTY. THREE FIGHTS WITH WREN, THEN YOU CAN BRING WORD BACK.",
        hud = "FIGHT WITH WREN",
        next = "wren_close",
      },
      wren_close = {
        type = "talk", npc = "barrow_digger_wren", escort = "barrow_digger_wren",
        prompt = "WREN: ONE OF THEM ANSWERED. NOT A FETCH. A PERSON. KEEL WILL HATE THE OPEN DOOR. I WILL NOT. TAKE THIS.",
        choice = "TAKE WREN'S PAY",
        reward = "wren",
      },
    },
  },

  debt = {
    id = "debt",
    name = "The Chancel Debt",
    hook = { "chancel_sister_ada", "chancel_warden_holt" },
    lead = "At Wraith Chancel, talk to Ada and Holt.",
    about = "The chancel owes the wild a debt. Ada says walk to The Hush. Holt says pay it in fights. One of them leaves angry.",
    beats = {
      hear = {
        type = "hear",
        need = { "chancel_sister_ada", "chancel_warden_holt" },
        prompts = {
          chancel_sister_ada = "ADA: THE HUSH CALLED US. A DEBT ANSWERED WITH SWORDS JUST MAKES A LOUDER CALL. WALK THERE WITH ME.",
          chancel_warden_holt = "HOLT: I HAVE BURIED FOUR PEOPLE WHO TRIED ADA'S WALK. STAND WITH ME AND WE END THE THING THAT KEEPS COMING BACK.",
        },
        hud = "HEAR BOTH ADA AND HOLT",
        next = "pick",
      },
      pick = {
        type = "choice", npc = { "chancel_sister_ada", "chancel_warden_holt" },
        prompt = "WALK THE HUSH WITH ADA, OR FIGHT THE DEBT DOWN WITH HOLT. YOU DO NOT GET BOTH ENDINGS.",
        hud = "CHOOSE HOW THE DEBT IS PAID",
        options = {
          { label = "WALK THE HUSH WITH ADA", next = "ada_walk",
            memory = { chancel_warden_holt = "YOU WALKED PAST THE WARDS. HOLT IS DONE OFFERING YOU A SPEAR." } },
          { label = "FIGHT THE DEBT WITH HOLT", next = "holt_fight",
            memory = { chancel_sister_ada = "YOU PAID IN BLOOD. ADA WILL NOT CALL THAT MERCY." } },
        },
      },
      ada_walk = {
        type = "visit", escort = "chancel_sister_ada", region = "wz_48",
        line = "ADA FALLS IN BEHIND YOU. THE HUSH IS WHERE THE CALL IS LOUDEST.",
        hud = "ESCORT ADA TO THE HUSH",
        next = "ada_close",
      },
      ada_close = {
        type = "talk", npc = "chancel_sister_ada", escort = "chancel_sister_ada",
        prompt = "ADA: IT HEARD US AND IT WENT QUIET. THAT IS A DEBT PAID WITHOUT A GRAVE. HOLT WILL SPIT. TAKE THE CHANCEL'S REAL PAY.",
        choice = "TAKE ADA'S PAY",
        reward = "ada",
      },
      holt_fight = {
        type = "defeat", escort = "chancel_warden_holt", count = 4,
        line = "HOLT COMES WITH YOU. FOUR FIGHTS. HE COUNTS EVERY ONE.",
        hud = "PAY THE DEBT WITH HOLT",
        next = "holt_close",
      },
      holt_close = {
        type = "talk", npc = "chancel_warden_holt", escort = "chancel_warden_holt",
        prompt = "HOLT: FOUR. THE ROAD IS QUIET ENOUGH TO SLEEP. ADA WILL CALL YOU CRUEL. I CALL YOU DONE. THIS IS NOT BOARD PAY.",
        choice = "TAKE HOLT'S PAY",
        reward = "holt",
      },
    },
  },
}

local REWARDS = {
  vey = { kyo = 1800, xp = 320, kills = 6, armor = "rare", items = { { "ghost_jar", 5 }, { "potion", 5 } }, note = "THE GATE HOLDS", keep = "captain_vey", cold = "scribe_orien" },
  orien = { kyo = 2000, xp = 360, kills = 6, armor = "epic", ghost = true, items = { { "ghost_jar", 4 }, { "big_potion", 2 } }, note = "THE ARCHIVE PAYS", keep = "scribe_orien", cold = "captain_vey" },
  letter = { kyo = 1400, xp = 260, kills = 4, armor = "rare", items = { { "potion", 6 }, { "ghost_jar", 3 } }, note = "THE LETTER IS DELIVERED", keep = "capital_runner_eli" },
  renn = { kyo = 1600, xp = 280, kills = 4, armor = "rare", items = { { "potion", 5 } }, note = "THE HALL SLEPT", keep = "capital_shelter_renn", cold = "capital_guard_sella" },
  sella = { kyo = 1600, xp = 280, kills = 4, armor = "rare", ghost = true, items = { { "ghost_jar", 4 } }, note = "THE GATE HELD", keep = "capital_guard_sella", cold = "capital_shelter_renn" },
  hum = { kyo = 2400, xp = 420, kills = 8, armor = "epic", ghost = true, items = { { "ghost_jar", 6 }, { "big_potion", 3 } }, note = "MIRET HEARD THE CALL", keep = "caretaker_miret" },
  keel = { kyo = 1900, xp = 340, kills = 5, armor = "epic", items = { { "ghost_jar", 4 }, { "potion", 4 } }, note = "THE BARROW STAYS SHUT", keep = "barrow_priest_keel", cold = "barrow_digger_wren" },
  wren = { kyo = 1900, xp = 340, kills = 5, armor = "rare", ghost = true, items = { { "ghost_jar", 5 } }, note = "WREN BROUGHT A NAME UP", keep = "barrow_digger_wren", cold = "barrow_priest_keel" },
  ada = { kyo = 2200, xp = 400, kills = 6, armor = "epic", ghost = true, items = { { "ghost_jar", 5 }, { "big_potion", 2 } }, note = "THE HUSH WENT QUIET", keep = "chancel_sister_ada", cold = "chancel_warden_holt" },
  holt = { kyo = 2200, xp = 400, kills = 6, armor = "epic", items = { { "ghost_jar", 5 }, { "potion", 4 } }, note = "THE DEBT IS SETTLED", keep = "chancel_warden_holt", cold = "chancel_sister_ada" },
}

local function storyDef()
  return S.story and STORIES[S.story.id] or nil
end

local function beat()
  local def = storyDef()
  return def and def.beats[S.story.beat] or nil
end

local function hooked(def, who)
  if type(who) == "table" then
    for _, id in ipairs(who) do if id == def.id then return true end end
    return false
  end
  return who == def.id
end

local function npcListed(list, id)
  if type(list) == "table" then
    for _, v in ipairs(list) do if v == id then return true end end
    return false
  end
  return list == id
end

function Stories.follow(id)
  local def = Get("TownNPC", id)
  if not def then return end
  S.npcCompanions = S.npcCompanions or {}
  S.npcCompanionPos = S.npcCompanionPos or {}
  local has = false
  for _, v in ipairs(S.npcCompanions) do if v == id then has = true break end end
  if not has then
    table.insert(S.npcCompanions, 1, id)
    S.npcCompanionPos[id] = { x = S.px, y = S.py, rx = S.px, ry = S.py }
    Say(Upper(def.name) .. " FALLS IN BEHIND YOU.")
  else
    for i, v in ipairs(S.npcCompanions) do
      if v == id then table.remove(S.npcCompanions, i) break end
    end
    table.insert(S.npcCompanions, 1, id)
  end
  S.storyEscort = id
end

function Stories.releaseEscort(keep)
  local id = S.storyEscort
  if not keep and id then
    for i = #(S.npcCompanions or {}), 1, -1 do
      if S.npcCompanions[i] == id then table.remove(S.npcCompanions, i) end
    end
    if S.npcCompanionPos then S.npcCompanionPos[id] = nil end
  end
  S.storyEscort = nil
end

local function applyMemory(mem)
  if not mem then return end
  S.storyMemory = S.storyMemory or {}
  S.npcReactions = S.npcReactions or {}
  for id, line in pairs(mem) do
    S.storyMemory[id] = line
    S.npcReactions[id] = -1
  end
end

local function grantKills(n)
  for _ = 1, (n or 0) do
    S.kills = (S.kills or 0) + 1
    if Rules and Rules.trainer_level and (S.kills or 0) >= (S.need or 1) then
      local before = S.trainer or 1
      Rules.trainer_level()
      if (S.trainer or 1) == before then break end
    end
  end
end

local function pay(id)
  local r = REWARDS[id]
  if not r then return end
  S.kyo = (S.kyo or 0) + (r.kyo or 0)
  if AddSkillXp then AddSkillXp("adventuring", r.xp or 80) end
  grantKills(r.kills or 3)
  if GiveXp then
    local gxp = math.floor((r.xp or 200) * (1.5 + (S.trainer or 1) * 0.08))
    for _, g in ipairs(S.party or {}) do
      if g then GiveXp(g, gxp) end
    end
    r._gxp = gxp
  end
  if r.items and GiveItem then
    for _, it in ipairs(r.items) do GiveItem(it[1], it[2] or 1) end
  end
  if r.armor and Armor and Armor.createPiece and Armor.give then
    local slots = Armor.SLOTS or { "head", "chest", "legs", "feet" }
    local slot = slots[love.math.random(1, #slots)]
    local piece = Armor.createPiece(slot, math.max(14, (S.trainer or 8) + 6), { quality = r.armor, minEnchants = r.armor == "epic" and 3 or 2 })
    if piece then Armor.give(piece) end
  end
  if r.ghost and MakeGhost then
    local all = GhostList and GhostList() or {}
    if #all > 0 then
      local sp = all[love.math.random(1, #all)]
      local g = MakeGhost(sp.id, math.max(8, S.trainer or 8), "faded")
      if g then
        S.box = S.box or {}
        table.insert(S.box, g)
        if S.seen and g.species then S.seen[g.species] = true end
        Say("A GHOST JOINS YOUR BOX")
      end
    end
  end
  if r.keep then
    S.npcReactions = S.npcReactions or {}
    S.npcReactions[r.keep] = 1
    Stories.releaseEscort(true)
    local d = Get("TownNPC", r.keep)
    if d and not following(r.keep) then Stories.follow(r.keep) end
    S.storyEscort = nil
  else
    Stories.releaseEscort(false)
  end
  if r.cold then
    S.npcReactions = S.npcReactions or {}
    S.npcReactions[r.cold] = -1
  end
  Say("STORY COMPLETE — " .. (r.note or "DONE") .. "  +" .. tostring(r.kyo or 0) .. " KYO  +" .. tostring(r.xp or 0) .. " ADVENTURING XP  +" .. tostring(r._gxp or 0) .. " GHOST XP")
  Play("win")
end

local function enterBeat(id)
  local def = storyDef()
  local b = def and def.beats[id]
  if not b then return end
  local prev = S.storyEscort
  S.story.beat = id
  S.story.kills = 0
  S.story.heard = S.story.heard or {}
  if b.escort then
    if prev and prev ~= b.escort then
      S.storyEscort = prev
      Stories.releaseEscort(false)
    end
    Stories.follow(b.escort)
  elseif prev then
    Stories.releaseEscort(false)
  end
  if b.line then Say(b.line) end
end

function Stories.start(id)
  local def = STORIES[id]
  if not def then return false end
  if S.storiesDone and S.storiesDone[id] then
    Say("THAT STORY IS ALREADY TOLD")
    return false
  end
  if S.story and S.story.id ~= id then
    Say("FINISH " .. Upper(storyDef().name) .. " FIRST")
    return false
  end
  if S.story and S.story.id == id then return true end
  S.story = { id = id, beat = def.first or next(def.beats), kills = 0, heard = {} }
  -- first beat is the first key we set explicitly
  S.story.beat = def.start or S.story.beat
  Say("STORY — " .. Upper(def.name))
  enterBeat(S.story.beat)
  Play("quest")
  return true
end

-- explicit start beats (first key iteration is not stable)
STORIES.gate.start = "sella_road"
STORIES.letter.start = "drown"
STORIES.roofs.start = "hear"
STORIES.hum.start = "ask_orien"
STORIES.bells.start = "hear"
STORIES.debt.start = "hear"

local function npcSpot(id)
  if not id then return nil end
  local npc = Get("TownNPC", id)
  local name = (npc and npc.name) or id
  if following(id) then
    local pos = S.npcCompanionPos and S.npcCompanionPos[id]
    if pos and pos.x then return pos.x, pos.y, name end
    return S.px, S.py, name
  end
  if npc then return npc.x, npc.y, name end
  return nil
end

local function regionHostile(r)
  if not r then return false end
  if (r.maxGhosts or 0) > 0 then return true end
  if (r.maxEnemies or 0) > 0 then return true end
  return false
end

local function nearestFightSpot()
  local here = RegionAt and RegionAt(math.floor((S.px or 0) + 0.5), math.floor((S.py or 0) + 0.5))
  if regionHostile(here) then return nil end
  local best, bd
  for _, r in ipairs((World and World.regions) or {}) do
    if regionHostile(r) and World.center then
      local x, y = World.center(r)
      local d = math.abs(x - (S.px or 0)) + math.abs(y - (S.py or 0))
      if not bd or d < bd then best, bd = r, d end
    end
  end
  if not best or not World.center then return nil end
  local x, y = World.center(best)
  return x, y, best.name or "A FIGHT"
end

function Stories.marker()
  local b = beat()
  if not b then return nil end
  if b.type == "defeat" then return nearestFightSpot() end
  if b.type == "visit" and b.region then
    local r = RegionById and RegionById(b.region)
    if r and World and World.center then
      local x, y = World.center(r)
      return x, y, r.name or b.region
    end
  end
  if b.type == "talk" then return npcSpot(b.npc) end
  if b.type == "hear" then
    for _, id in ipairs(b.need or {}) do
      if not (S.story.heard and S.story.heard[id]) then return npcSpot(id) end
    end
    local need = b.need or {}
    return npcSpot(need[1])
  end
  if b.type == "choice" then
    local list = type(b.npc) == "table" and b.npc or { b.npc }
    local best, bd
    for _, id in ipairs(list) do
      local x, y, name = npcSpot(id)
      if x then
        local d = math.abs(x - (S.px or 0)) + math.abs(y - (S.py or 0))
        if not bd or d < bd then best, bd = { x, y, name }, d end
      end
    end
    if best then return best[1], best[2], best[3] end
  end
  if b.escort then return npcSpot(b.escort) end
  return nil
end

function Stories.talkTarget()
  local b = beat()
  if not b then return nil end
  if b.type == "talk" then
    if following(b.npc) then return b.npc end
    return nil
  end
  if b.type == "hear" then
    for _, id in ipairs(b.need or {}) do
      if not (S.story.heard and S.story.heard[id]) and following(id) then return id end
    end
  end
  if b.escort and following(b.escort) and (b.type == "visit" or b.type == "defeat") then
    return b.escort
  end
  return nil
end

function Stories.compass()
  local b = beat()
  if b and b.type == "defeat" then
    local prog = tostring(S.story and S.story.kills or 0) .. "/" .. tostring(b.count or 1)
    local x, y, name = Stories.marker()
    if not x then return "STORY  ·  FIGHT HERE  " .. prog end
    local dx, dy = x - (S.px or 0), y - (S.py or 0)
    local dist = math.floor(math.abs(dx) + math.abs(dy))
    local dir = (math.abs(dy) >= math.abs(dx)) and (dy < 0 and "NORTH" or "SOUTH") or (dx > 0 and "EAST" or "WEST")
    return "STORY  ·  FIGHTS " .. prog .. "  ·  " .. dir .. " " .. dist .. "  " .. Upper(name or "")
  end
  local x, y, name = Stories.marker()
  if not x then return nil end
  local dx = x - (S.px or 0)
  local dy = y - (S.py or 0)
  local dist = math.floor(math.abs(dx) + math.abs(dy))
  if dist < 8 then return "STORY  ·  " .. Upper(name or "HERE") .. " IS WITH YOU" end
  local dir
  if math.abs(dy) >= math.abs(dx) then dir = dy < 0 and "NORTH" or "SOUTH"
  else dir = dx > 0 and "EAST" or "WEST" end
  return "STORY  ·  " .. dir .. "  " .. dist .. "  " .. Upper(name or "")
end

function Stories.brief()
  local def, b = storyDef(), beat()
  if not def or not b then return nil end
  return {
    name = def.name,
    about = def.about,
    hud = b.hud or def.name,
    prompt = b.prompt or b.line or "",
  }
end

function Stories.line()
  local def, b = storyDef(), beat()
  if not def or not b then return nil end
  if b.type == "defeat" then
    return "STORY: " .. (b.hud or def.name) .. " " .. tostring(S.story.kills or 0) .. "/" .. tostring(b.count or 1)
  end
  if b.type == "hear" then
    local n = 0
    for _ in pairs(S.story.heard or {}) do n = n + 1 end
    return "STORY: " .. (b.hud or "LISTEN") .. " " .. n .. "/" .. #b.need
  end
  return "STORY: " .. (b.hud or def.name)
end

function Stories.prompt(def)
  if not def then return nil end
  local mem = S.storyMemory and S.storyMemory[def.id]
  local active, b = storyDef(), beat()
  if active and b then
    if b.type == "choice" and npcListed(b.npc, def.id) then
      local labels = {}
      for _, op in ipairs(b.options or {}) do labels[#labels + 1] = op.label end
      return labels, b.prompt
    end
    if b.type == "talk" and b.npc == def.id then
      return { b.choice or "CONTINUE" }, b.prompt or b.line
    end
    if b.type == "hear" then
      for _, id in ipairs(b.need or {}) do
        if id == def.id then
          return { "I HEAR YOU" }, b.prompts and b.prompts[id] or b.line
        end
      end
    end
    if (b.type == "visit" or b.type == "defeat") and (b.escort == def.id or npcListed(b.npc, def.id)) then
      return { "I AM STILL WITH YOU" }, "STORY: " .. (b.hud or active.name)
    end
  end
  if not (S.storiesDone and S.storiesDone[def.id]) then
    for _, st in pairs(STORIES) do
      if not (S.storiesDone and S.storiesDone[st.id]) and hooked(def, st.hook) then
        if S.story and S.story.id == st.id then
          return nil
        end
        if S.story then
          return { "NOT NOW" }, "YOU ARE ALREADY IN " .. Upper(storyDef().name) .. ". FINISH IT BEFORE ANOTHER STORY."
        end
        return { "BEGIN: " .. Upper(st.name) }, st.about .. " THIS ONE PAYS FAR MORE THAN A BOARD CONTRACT."
      end
    end
  end
  if mem then return nil, mem end
  return nil
end

function Stories.handle(def, label)
  if not def or not label or label == "LEAVE" then return false end
  local active, b = storyDef(), beat()
  if label:sub(1, 6) == "BEGIN:" then
    for _, st in pairs(STORIES) do
      if hooked(def, st.hook) and label == "BEGIN: " .. Upper(st.name) then
        return Stories.start(st.id)
      end
    end
  end
  if label == "NOT NOW" then
    Say("FINISH THE STORY YOU ARE IN")
    return true
  end
  if not active or not b then return false end
  if b.type == "choice" then
    for _, op in ipairs(b.options or {}) do
      if op.label == label then
        applyMemory(op.memory)
        if op.memory then
          for id, line in pairs(op.memory) do Say(line) end
        end
        enterBeat(op.next)
        return true
      end
    end
  end
  if b.type == "talk" and b.npc == def.id then
    if b.reward then
      S.storiesDone = S.storiesDone or {}
      S.storiesDone[active.id] = b.reward
      local keepId = REWARDS[b.reward] and REWARDS[b.reward].keep
      pay(b.reward)
      S.story = nil
      if keepId then S.npcReactions[keepId] = 1 end
      return true
    end
    if b.next then enterBeat(b.next) end
    return true
  end
  if b.type == "hear" then
    S.story.heard = S.story.heard or {}
    S.story.heard[def.id] = true
    Say(Upper(def.name) .. " HAS SAID THEIR PIECE.")
    local all = true
    for _, id in ipairs(b.need or {}) do if not S.story.heard[id] then all = false end end
    if all and b.next then enterBeat(b.next) end
    return true
  end
  if label == "I AM STILL WITH YOU" then
    if b.escort and not following(b.escort) then Stories.follow(b.escort) end
    Say(Stories.line() or "KEEP GOING")
    return true
  end
  return false
end

function Stories.tick()
  local b = beat()
  if not b or not S.story then return end
  if b.type == "visit" then
    if b.escort and not following(b.escort) then return end
    local here = RegionAt and RegionAt(math.floor((S.px or 0) + 0.5), math.floor((S.py or 0) + 0.5))
    if here and here.id == b.region then
      Say("YOU REACH " .. Upper(regionName(b.region)) .. (b.escort and (" WITH " .. Upper(npcName(b.escort))) or "") .. ".")
      if b.next then enterBeat(b.next) end
    end
  end
end

function Stories.onWin()
  local b = beat()
  if not b or b.type ~= "defeat" then return end
  if b.escort and not following(b.escort) then
    Say(Upper(npcName(b.escort)) .. " IS NOT WITH YOU. THE FIGHT DOES NOT COUNT.")
    return
  end
  S.story.kills = (S.story.kills or 0) + 1
  Say("STORY FIGHT " .. S.story.kills .. "/" .. tostring(b.count or 1))
  if S.story.kills >= (b.count or 1) and b.next then enterBeat(b.next) end
end

function Stories.catalog()
  local out = {}
  for _, id in ipairs({ "gate", "letter", "roofs", "hum", "bells", "debt" }) do
    local st = STORIES[id]
    local state = "OPEN"
    if S.storiesDone and S.storiesDone[id] then state = "TOLD"
    elseif S.story and S.story.id == id then state = "NOW" end
    out[#out + 1] = { id = id, name = st.name, lead = st.lead, state = state, about = st.about }
  end
  return out
end

function Stories.abandon()
  if not S.story then return false end
  Stories.releaseEscort(false)
  Say("YOU SET THE STORY ASIDE. THE PEOPLE WILL REMEMBER THE WALK.")
  S.story = nil
  return true
end

function Stories.restore()
  local b = beat()
  if b and b.escort then Stories.follow(b.escort) end
end

When("battle_won")(function()
  if Stories and Stories.onWin then Stories.onWin() end
end)
