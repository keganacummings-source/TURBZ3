-- Skills engine: long-term skill tracks that persist across deaths.
-- Skills: mining, woodcutting, hunting, catching, trading, fishing, social, shroom
-- Max level 400 each. Scale like ghost/player levels. Kept between deaths.

Skills = Skills or {}

local SKILL_IDS = {
  "mining", "woodcutting", "hunting", "catching",
  "trading", "fishing", "social", "shroom", "alchemy", "adventuring"
}

local DEFAULT_MAX = 400

function Skills.ids()
  return SKILL_IDS
end

function EnsureSkill(id)
  S.skills = S.skills or {}
  if not S.skills[id] then
    S.skills[id] = { level = 1, xp = 0 }
  end
  return S.skills[id]
end

function SkillXpNeeded(id, level)
  local m = Get("Mastery", id)
  local base = (m and m.xpBase) or 80
  local scale = (m and m.xpScale) or 1.12
  -- Gentle curve so 400 is reachable with long-term play
  return math.max(20, math.floor(base * (scale ^ math.min(level - 1, 120)) * (1 + (level - 1) * 0.015)))
end

function SkillLevel(id)
  local st = EnsureSkill(id)
  return st.level or 1
end

function SkillProgress(id)
  local st = EnsureSkill(id)
  local needed = SkillXpNeeded(id, st.level)
  return st.xp or 0, needed, math.min(1, (st.xp or 0) / math.max(1, needed))
end

function AddSkillXp(id, amount)
  local m = Get("Mastery", id)
  if not m and not tableContains(SKILL_IDS, id) then return false end
  local st = EnsureSkill(id)
  local maxLvl = (m and m.maxLevel) or DEFAULT_MAX
  if st.level >= maxLvl then return false end

  st.xp = (st.xp or 0) + (amount or 10)
  local needed = SkillXpNeeded(id, st.level)
  local leveled = false

  while st.xp >= needed and st.level < maxLvl do
    st.xp = st.xp - needed
    st.level = st.level + 1
    leveled = true
    needed = SkillXpNeeded(id, st.level)
    -- Every level grants 1 Token
    if Tokens and Tokens.add then Tokens.add(1) end
    local name = (m and m.name) or Upper(id)
    local bonus = Skills.levelLine and Skills.levelLine(id, st.level) or ""
    if st.level % 5 == 0 then
      S.skillPerks = S.skillPerks or {}
      S.skillPerks[id] = S.skillPerks[id] or {}
      local perkN = math.floor(st.level / 5)
      S.skillPerks[id][perkN] = true
      if SkillPerks and SkillPerks.apply then SkillPerks.apply(id, perkN) end
    end
    local extra = ""
    if Armor and Armor.get and Armor.get("token_luck") > 0 and love.math.random(1, 100) <= math.min(40, Armor.get("token_luck")) then
      if Tokens and Tokens.add then Tokens.add(1) end
      extra = "  +1 TOKEN"
    end
    Say(name .. " LV " .. st.level .. "  " .. bonus .. extra)
    Play("win")
    Fire("skill_level_up", { skill = id, level = st.level })
  end

  if not leveled then
    Fire("skill_xp_gained", { skill = id, amount = amount })
  end
  return leveled
end

function tableContains(t, v)
  for _, x in ipairs(t) do if x == v then return true end end
  return false
end

-- Bonuses ---------------------------------------------------------------

-- Fishing: catch speed (higher = faster bite / lower wait)
function SkillFishingCatchSpeed()
  local lv = SkillLevel("fishing")
  -- +0.4% per level, soft-capped
  return 1 + math.min(1.6, (lv - 1) * 0.004)
end

-- Resource skills: more XP and resources this life instance
function SkillResourceYieldBonus(skillId)
  local lv = SkillLevel(skillId)
  return 1 + math.min(2.0, (lv - 1) * 0.0035)
end

function SkillResourceXpBonus(skillId)
  local lv = SkillLevel(skillId)
  return 1 + math.min(1.5, (lv - 1) * 0.0025)
end

-- Social: every few levels increase party size
function SkillPartyBonus()
  local lv = SkillLevel("social")
  -- +1 party slot every 40 levels (max +10 at 400)
  return math.floor((lv - 1) / 40)
end

function EffectivePartySize()
  local n = (Settings.partySize or 6) + SkillPartyBonus()
  if Armor and Armor.get then n = n + Armor.get("party_bond") end
  return n
end

-- Trading: shops cheaper, sell for more
function SkillShopPriceMult()
  local lv = SkillLevel("trading")
  -- up to ~40% cheaper
  return math.max(0.55, 1 - (lv - 1) * 0.001)
end

function SkillSellPriceMult()
  local lv = SkillLevel("trading")
  -- up to ~50% more
  return 1 + math.min(0.5, (lv - 1) * 0.00125)
end

-- Catching: better catch chance
function SkillCatchBonus()
  local lv = SkillLevel("catching")
  return math.min(25, (lv - 1) * 0.05) -- flat % bonus, soft
end

-- Hunting: encounter / damage edge vs wild enemies
function SkillHuntBonus()
  local lv = SkillLevel("hunting")
  return 1 + math.min(0.4, (lv - 1) * 0.001)
end

-- Shroom: discovery & yield
function SkillShroomDiscoveryBonus()
  local lv = SkillLevel("shroom")
  return math.min(30, (lv - 1) * 0.06)
end

function SkillShroomYieldBonus()
  local lv = SkillLevel("shroom")
  return 1 + math.min(1.5, (lv - 1) * 0.003)
end

-- Persist skills across wipeouts (call from LoseBattle / Bank)
function Skills.preserveOnDeath()
  -- S.skills is intentionally NOT cleared on death
  return S.skills
end

function Skills.initFromSave(data)
  if data and type(data) == "table" then
    S.skills = data
  else
    S.skills = S.skills or {}
  end
  for _, id in ipairs(SKILL_IDS) do EnsureSkill(id) end
end

function Skills.ensureAll()
  S.skills = S.skills or {}
  for _, id in ipairs(SKILL_IDS) do EnsureSkill(id) end
end

-- Alchemy soft bonus: slight brew value at high levels
function SkillAlchemyValueMult()
  local lv = SkillLevel("alchemy")
  return 1 + math.min(0.35, (lv - 1) * 0.0008)
end

-- Every level does something. The skill screen reads these lines.
function Skills.milestoneRank(level)
  return math.floor((level or 1) / 5) * 5
end

function Skills.milestoneText(id, rank)
  local m = Get("Mastery", id)
  if m and m.perks and m.perks[rank] and m.perks[rank] ~= "" then return tostring(m.perks[rank]) end
  local line = Skills.levelLine and Skills.levelLine(id, math.max(1, rank)) or ""
  if line ~= "" then return line end
  return "Practice holds"
end

-- Ranks to show: a window of every 5 levels around the current rank, plus named perks.
function Skills.milestoneRows(id)
  local lv = SkillLevel(id)
  local m = Get("Mastery", id)
  local maxL = (m and m.maxLevel) or DEFAULT_MAX
  local earned = Skills.milestoneRank(lv)
  local rows, seen = {}, {}
  local function add(rank)
    rank = math.floor(rank or 0)
    if rank < 5 or rank > maxL or seen[rank] then return end
    seen[rank] = true
    rows[#rows + 1] = rank
  end
  local start = math.max(5, earned - 10)
  for rank = start, math.min(maxL, start + 30), 5 do add(rank) end
  if earned < 5 then add(5) end
  if m and m.perks then
    for rank, _ in pairs(m.perks) do add(rank) end
  end
  table.sort(rows)
  return rows, earned
end

function Skills.levelLine(id, level)
  local n = math.max(0, (level or SkillLevel(id)) - 1)
  if id == "mining" or id == "woodcutting" then
    return string.format("+%0.1f%% YIELD", n * 0.35)
  elseif id == "hunting" then
    return string.format("+%0.1f%% WILD DAMAGE", math.min(40, n * 0.1))
  elseif id == "catching" then
    return string.format("+%0.2f%% CATCH", math.min(25, n * 0.05))
  elseif id == "trading" then
    return string.format("%0.2f%% CHEAPER SHOPS", math.min(45, n * 0.1))
  elseif id == "fishing" then
    return string.format("+%0.1f%% BITE SPEED", math.min(160, n * 0.4))
  elseif id == "social" then
    return "+" .. math.floor(n / 40) .. " PARTY"
  elseif id == "shroom" or id == "mycology" then
    return string.format("+%0.1f%% FIND", math.min(30, n * 0.06))
  elseif id == "alchemy" then
    return string.format("+%0.2f%% BREW VALUE", math.min(35, n * 0.08))
  elseif id == "adventuring" then
    return string.format("+%0.2f STA/s", n * 0.012)
  end
  return "+" .. n .. " PRACTICE"
end

function Skills.bonusLines(id)
  local lv = SkillLevel(id)
  local n = math.max(0, lv - 1)
  local lines = {}
  lines[#lines + 1] = "EACH LEVEL"
  if id == "mining" then
    lines[#lines + 1] = "NOW  " .. string.format("+%0.1f%% ore yield, +%0.1f%% mining XP", n * 0.35, n * 0.25)
    lines[#lines + 1] = "PER LEVEL  +0.35% yield from ore veins"
  elseif id == "woodcutting" then
    lines[#lines + 1] = "NOW  " .. string.format("+%0.1f%% timber yield, +%0.1f%% wood XP", n * 0.35, n * 0.25)
    lines[#lines + 1] = "PER LEVEL  +0.35% wood from stands"
  elseif id == "hunting" then
    lines[#lines + 1] = "NOW  " .. string.format("+%0.1f%% damage vs wild foes", math.min(40, n * 0.1))
    lines[#lines + 1] = "PER LEVEL  stronger hunts and more meat from trails"
    lines[#lines + 1] = "ALSO  meals restore a little more"
  elseif id == "catching" then
    lines[#lines + 1] = "NOW  " .. string.format("+%0.2f%% jar catch chance", math.min(25, n * 0.05))
    lines[#lines + 1] = "PER LEVEL  +0.05% catch, forever"
  elseif id == "trading" then
    lines[#lines + 1] = "NOW  " .. string.format("shops %0.1f%% cheaper, sells +%0.1f%%", math.min(45, n * 0.1), math.min(50, n * 0.125))
    lines[#lines + 1] = "PER LEVEL  a sharper price, both ways"
  elseif id == "fishing" then
    lines[#lines + 1] = "NOW  " .. string.format("+%0.1f%% bite speed", math.min(160, n * 0.4))
    lines[#lines + 1] = "PER LEVEL  faster bites, more fish, stranger hooks"
  elseif id == "social" then
    lines[#lines + 1] = "NOW  +" .. math.floor(n / 40) .. " party slots"
    lines[#lines + 1] = "PER LEVEL  trust. Every 40 levels, another slot"
  elseif id == "shroom" or id == "mycology" then
    lines[#lines + 1] = "NOW  " .. string.format("+%0.1f%% discovery, +%0.1f%% yield", math.min(30, n * 0.06), math.min(150, n * 0.3))
    lines[#lines + 1] = "PER LEVEL  you see more patches and pull more"
  elseif id == "alchemy" then
    lines[#lines + 1] = "NOW  " .. string.format("+%0.2f%% brew value", math.min(35, n * 0.08))
    lines[#lines + 1] = "PER LEVEL  the hearth and the alembic pay a little more"
  elseif id == "adventuring" then
    lines[#lines + 1] = "NOW  " .. string.format("+%0.2f stamina/s and a deeper spirit", n * 1.2)
    lines[#lines + 1] = "PER LEVEL  +0.012 stamina each second, +spirit max"
  else
    lines[#lines + 1] = "NOW  rank " .. tostring(lv)
    lines[#lines + 1] = "PER LEVEL  +1 token and a little more practice"
  end
  return lines
end
