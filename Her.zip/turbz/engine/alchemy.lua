
-- Alchemy: combine TWO mushrooms only into a brew (2x sell value). Grants alchemy XP.

function EnsureAlchemy()
  S.alchemy = S.alchemy or {}
  S.alchemy.brewedCount = S.alchemy.brewedCount or 0
  return S.alchemy
end

function AlchemyIngredientList()
  local out = {}
  S.bag = S.bag or {}
  for key, count in pairs(S.bag) do
    if count and count > 0 and string.match(tostring(key), "^shroom_") then
      local mid, p = string.match(key, "^shroom_(.+)_p(%d+)$")
      local m = mid and Get("Mushroom", mid)
      local pure = ShroomMarket and ShroomMarket.purityByIndex and ShroomMarket.purityByIndex(tonumber(p) or 3)
      local price = (ShroomMarket and ShroomMarket.price and ShroomMarket.price(mid, tonumber(p))) or 5
      out[#out + 1] = {
        key = key,
        name = ((pure and pure.name) or "P") .. " " .. ((m and m.name) or mid or key),
        count = count,
        price = price,
        kind = "shroom",
      }
    end
  end
  table.sort(out, function(a, b) return a.name < b.name end)
  return out
end

local function takeShroom(key, n)
  n = n or 1
  S.bag = S.bag or {}
  if (S.bag[key] or 0) < n then return false end
  S.bag[key] = S.bag[key] - n
  if S.bag[key] <= 0 then S.bag[key] = nil end
  return true
end

function AlchemyCombine(keyA, keyB)
  EnsureAlchemy()
  if not keyA or not keyB then
    Say("PICK TWO MUSHROOMS")
    Play("bump")
    return false
  end
  if not string.match(tostring(keyA), "^shroom_") or not string.match(tostring(keyB), "^shroom_") then
    Say("ONLY MUSHROOMS CAN BE BREWED")
    Play("bump")
    return false
  end
  local list = AlchemyIngredientList()
  local a, b
  for _, it in ipairs(list) do
    if it.key == keyA then a = it end
    if it.key == keyB then b = it end
  end
  if not a or not b then Say("MISSING MUSHROOMS") Play("bump") return false end
  if keyA == keyB and a.count < 2 then Say("NEED TWO OF THAT") Play("bump") return false end

  if not takeShroom(keyA, 1) then return false end
  if not takeShroom(keyB, 1) then
    -- refund A
    S.bag[keyA] = (S.bag[keyA] or 0) + 1
    return false
  end

  local value = math.max(2, math.floor(((a.price or 1) + (b.price or 1)) * 2))
  if SkillAlchemyValueMult then value = math.floor(value * SkillAlchemyValueMult()) end
  local uid = "brew_" .. tostring(love.timer.getTime()) .. "_" .. love.math.random(1000, 9999)
  S.bag[uid] = (S.bag[uid] or 0) + 1
  S.alchemyBrews = S.alchemyBrews or {}
  S.alchemyBrews[uid] = {
    name = "Shroom Brew",
    price = value,
    from = { a.name, b.name },
  }
  local alc = EnsureAlchemy()
  alc.brewedCount = (alc.brewedCount or 0) + 1
  if AddSkillXp then AddSkillXp("alchemy", 14 + math.floor(value / 5)) end
  Say("BREWED +" .. value .. "K VALUE")
  Play("quest")
  return true
end

function AlchemySellBrew(uid)
  S.alchemyBrews = S.alchemyBrews or {}
  local b = S.alchemyBrews[uid]
  if not b then return false end
  local price = b.price or 10
  if SkillSellPriceMult then price = math.floor(price * SkillSellPriceMult()) end
  S.kyo = (S.kyo or 0) + price
  S.bag[uid] = nil
  S.alchemyBrews[uid] = nil
  Say("SOLD BREW +" .. price .. "K")
  Play("win")
  if AddSkillXp then AddSkillXp("alchemy", 4) end
  return true
end

function CanBrew(id) return false, "Use Alchemy — mushrooms only" end
