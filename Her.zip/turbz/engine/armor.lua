-- Armor system: equipable pieces with multi-stack enchants (up to 20) and clothing FX (up to 3).
-- Drops from world bosses (always), wild ghosts (chance by level), and camp traders.
-- The table must exist before any Armor.* function is defined (Lua indexes Armor at parse/call time).

Armor = Armor or {}

function Armor.rollVisual(slot)
  local set = love.math.random(1, 20)
  return { index = set, set = set, sheet = "armor_v2", tint = { 1, 1, 1 } }
end

Armor.SLOTS = { "head", "chest", "legs", "feet", "accessory" }
Armor.MAX_ENCHANTS = 20
Armor.MAX_FX = 3
Armor.DISENCHANT_COST = 10000

-- Enchant definitions: id, name, about, maxPower, unit ("%" or "flat"), apply key
Armor.ENCHANTS = {
  { id = "double_strike", name = "Double Strike", about = "Chance attacks hit twice", max = 40, unit = "%", key = "doubleStrike" },
  { id = "second_chance", name = "Second Chance", about = "Break instead of dying once", max = 1, unit = "flat", key = "secondChance" },
  { id = "loot_find", name = "Loot Find", about = "More and better drops", max = 50, unit = "%", key = "lootFind" },
  { id = "rarity_aura", name = "Rarity Aura", about = "Higher rare ghost spawns", max = 35, unit = "%", key = "rarityAura" },
  { id = "xp_boost", name = "XP Boost", about = "More battle XP", max = 40, unit = "%", key = "xpBoost" },
  { id = "catch_boost", name = "Catch Boost", about = "Better jar catch rate", max = 30, unit = "%", key = "catchBoost" },
  { id = "kyo_find", name = "Kyo Magnet", about = "More Kyo from sales & wins", max = 45, unit = "%", key = "kyoFind" },
  { id = "ward", name = "Ward", about = "Take less damage", max = 35, unit = "%", key = "ward" },
  { id = "might", name = "Might", about = "Deal more damage", max = 35, unit = "%", key = "might" },
  { id = "swift", name = "Swift", about = "Move cooldown reduction", max = 25, unit = "%", key = "swift" },
  { id = "harvest", name = "Harvest", about = "Better resource yields", max = 40, unit = "%", key = "harvest" },
  { id = "fish_luck", name = "Fish Luck", about = "Better fishing bites", max = 40, unit = "%", key = "fishLuck" },
  { id = "teleport", name = "Camp Recall", about = "Unlock free camp teleport", max = 1, unit = "flat", key = "campRecall" },
  { id = "party_bond", name = "Party Bond", about = "Extra party slot", max = 2, unit = "flat", key = "partyBond" },
  { id = "shop_charm", name = "Shop Charm", about = "Cheaper shops", max = 30, unit = "%", key = "shopCharm" },
  { id = "sell_boost", name = "Merchant Tongue", about = "Higher sell prices", max = 30, unit = "%", key = "sellBoost" },
  { id = "ghost_xp", name = "Spirit Tutor", about = "Ghosts gain extra XP", max = 35, unit = "%", key = "ghostXp" },
  { id = "crit_edge", name = "Crit Edge", about = "Higher crit chance", max = 25, unit = "%", key = "critEdge" },
  { id = "regen", name = "Afterglow", about = "Heal a bit after battles", max = 20, unit = "%", key = "regen" },
  { id = "boss_bane", name = "Boss Bane", about = "Extra damage to bosses", max = 40, unit = "%", key = "bossBane" },
  { id = "shroom_sense", name = "Shroom Sense", about = "Find mushrooms easier", max = 35, unit = "%", key = "shroomSense" },
  { id = "void_step", name = "Void Step", about = "Chance to ignore terrain bump", max = 20, unit = "%", key = "voidStep" },
  { id = "echo_guard", name = "Echo Guard", about = "Chance to ignore a hit", max = 15, unit = "%", key = "echoGuard" },
  { id = "spark_life", name = "Spark of Life", about = "Start battles with shield HP", max = 25, unit = "%", key = "sparkLife" },
}

do
  local extra = require("engine.enchant_catalog")
  local seen = {}
  for _, e in ipairs(Armor.ENCHANTS) do seen[e.id] = true end
  for _, e in ipairs(extra or {}) do
    if e.id and not seen[e.id] then
      seen[e.id] = true
      Armor.ENCHANTS[#Armor.ENCHANTS + 1] = e
    end
  end
end

Armor.ENCHANT_BY_ID = {}
for _, e in ipairs(Armor.ENCHANTS) do Armor.ENCHANT_BY_ID[e.id] = e end

local SLOT_NAMES = {
  head = { "Hood", "Helm", "Circlet", "Mask", "Crown", "Cowl", "Visor", "Tiara" },
  chest = { "Robes", "Mail", "Plate", "Vest", "Mantle", "Cuirass", "Coat", "Wrap" },
  legs = { "Greaves", "Leggings", "Skirt", "Pants", "Tassets", "Sabatons" },
  feet = { "Boots", "Sabatons", "Sandals", "Treads", "Slippers", "Clogs" },
  accessory = { "Amulet", "Charm", "Ring", "Cloak", "Sash", "Talisman", "Orb", "Band" },
}

local QUALITIES = {
  { id = "worn", name = "Worn", mult = 0.6, color = "dim" },
  { id = "common", name = "Common", mult = 1.0, color = "ink" },
  { id = "fine", name = "Fine", mult = 1.25, color = "green" },
  { id = "rare", name = "Rare", mult = 1.6, color = "kyo" },
  { id = "epic", name = "Epic", mult = 2.1, color = "purple" },
  { id = "legendary", name = "Legendary", mult = 3.0, color = "blood" },
}

local function rollQuality(level, force)
  if force then
    for _, q in ipairs(QUALITIES) do if q.id == force then return q end end
  end
  level = level or 1
  local r = love.math.random(1, 1000)
  if level < 100 then
    -- starter-ish
    if r <= 50 then return QUALITIES[3]
    elseif r <= 250 then return QUALITIES[2]
    else return QUALITIES[1] end
  elseif level < 200 then
    if r <= 20 then return QUALITIES[5]
    elseif r <= 80 then return QUALITIES[4]
    elseif r <= 250 then return QUALITIES[3]
    elseif r <= 600 then return QUALITIES[2]
    else return QUALITIES[1] end
  else
    if r <= 40 then return QUALITIES[6]
    elseif r <= 120 then return QUALITIES[5]
    elseif r <= 300 then return QUALITIES[4]
    elseif r <= 550 then return QUALITIES[3]
    else return QUALITIES[2] end
  end
end

local function rollEnchantPower(def, qualityMult, level)
  local maxP = def.max or 20
  local base = love.math.random(1, math.max(1, math.floor(maxP * 0.35)))
  local fromLevel = math.floor((level or 1) / 20)
  local power = math.min(maxP, math.floor((base + fromLevel) * (qualityMult or 1)))
  if power < 1 then power = 1 end
  if def.unit == "flat" and maxP <= 2 then
    power = love.math.random(1, maxP)
  end
  return power
end

local function rollEnchants(level, quality, guaranteed)
  local q = quality or QUALITIES[2]
  local count
  if level and level < 100 then
    count = love.math.random(1, 3)
  else
    count = love.math.random(2, math.min(Armor.MAX_ENCHANTS, 4 + math.floor((level or 1) / 40)))
  end
  if guaranteed then count = math.max(count, guaranteed) end
  local pool = {}
  for i, e in ipairs(Armor.ENCHANTS) do pool[i] = e end
  -- shuffle
  for i = #pool, 2, -1 do
    local j = love.math.random(1, i)
    pool[i], pool[j] = pool[j], pool[i]
  end
  local out = {}
  for i = 1, math.min(count, #pool) do
    local def = pool[i]
    out[#out + 1] = {
      id = def.id,
      power = rollEnchantPower(def, q.mult, level),
    }
  end
  return out
end

local function rollFx(level, quality)
  local n = 1
  if level and level >= 100 then n = love.math.random(1, 2) end
  if level and level >= 200 then n = love.math.random(1, 3) end
  if quality and (quality.id == "epic" or quality.id == "legendary") then
    n = math.max(n, 2)
  end
  n = math.min(Armor.MAX_FX, n)
  local fx = {}
  local used = {}
  for _ = 1, n do
    local id = love.math.random(0, 319)
    if not used[id] then
      used[id] = true
      fx[#fx + 1] = id
    end
  end
  return fx
end

Armor.V2_SETS = {
  "Solaris Paladin", "Jade Emperor", "Stormcaller Aegis", "Cogwork Titan",
  "Shogun Kabuto", "Sun Pharaoh", "Valkyrie Wingguard", "Colossus Centurion",
  "Amethyst Oracle", "Eclipse Sentinel", "Ashen Vow", "Tidecaller",
  "Thorn Regalia", "Bone Sovereign", "Stormweave", "Frost Coronet",
  "Lunar Aegis", "Feather Court", "Hexweave", "Bloodmoon",
}

local function visualForSlot(slot, level)
  local set = love.math.random(1, #Armor.V2_SETS)
  if level and level >= 160 then set = love.math.random(1, 8)
  elseif level and level >= 80 then set = love.math.random(1, 16) end
  return { set = set, sheet = "armor_v2" }
end

local function makeName(slot, quality, level, visual)
  local setName = Armor.V2_SETS[(visual and visual.set) or 1] or "Witch"
  local slotName = ({ head = "Helm", chest = "Raiment", legs = "Skirt", feet = "Boots", accessory = "Mantle" })[slot] or "Relic"
  return (quality and quality.name or "Rare") .. " " .. setName .. " " .. slotName
end

function Armor.createPiece(slot, level, opts)
  opts = opts or {}
  slot = slot or Armor.SLOTS[love.math.random(1, #Armor.SLOTS)]
  level = level or 1
  local quality = rollQuality(level, opts.quality)
  local piece = {
    uid = (S and S.uid or 0) .. "-arm-" .. tostring(love.math.random(100000, 999999)),
    slot = slot,
    name = makeName(slot, quality, level),
    level = level,
    quality = quality.id,
    qualityName = quality.name,
    color = quality.color,
    enchants = rollEnchants(level, quality, opts.minEnchants),
    fx = rollFx(level, quality),
    visual = visualForSlot(slot, level),
  }
  piece.name = makeName(slot, quality, level, piece.visual)
  if opts.enchants then piece.enchants = opts.enchants end
  if opts.fx then piece.fx = opts.fx end
  if opts.name then piece.name = opts.name end
  if opts.visual then piece.visual = opts.visual end
  -- price from enchants
  local ep = 0
  for _, e in ipairs(piece.enchants) do ep = ep + (e.power or 1) * 40 end
  piece.price = math.max(50, math.floor((piece.price or 100) + ep))
  return piece
end

function Armor.bag()
  S.armorBag = S.armorBag or {}
  return S.armorBag
end

function Armor.equipped()
  S.equippedArmor = S.equippedArmor or {}
  return S.equippedArmor
end

function Armor.give(piece, why)
  if not piece then return end
  local bag = Armor.bag()
  bag[#bag + 1] = piece
  Say("FOUND " .. Upper(piece.name or "ARMOR"))
  Play("quest")
  if SiteFeed and SiteFeed.onArmor then SiteFeed.onArmor(piece, why) end
  return piece
end

function Armor.equip(piece)
  -- after equip, sync visuals
  if not piece or not piece.slot then return false end
  local eq = Armor.equipped()
  local bag = Armor.bag()
  -- unequip current into bag
  if eq[piece.slot] then
    bag[#bag + 1] = eq[piece.slot]
  end
  -- remove piece from bag
  for i, p in ipairs(bag) do
    if p == piece or (p.uid and piece.uid and p.uid == piece.uid) then
      table.remove(bag, i)
      break
    end
  end
  eq[piece.slot] = piece
  Armor.syncVisuals()
  Say("EQUIPPED " .. Upper(piece.name))
  Play("step")
  return true
end

function Armor.unequip(slot)
  local eq = Armor.equipped()
  local p = eq[slot]
  if not p then return end
  eq[slot] = nil
  Armor.bag()[#Armor.bag() + 1] = p
  Armor.syncVisuals()
  Play("step")
end

function Armor.syncVisuals()
  -- Drive character look slots from equipped armor visuals
  S.equippedClothes = S.equippedClothes or {}
  local eq = Armor.equipped()
  for _, slot in ipairs(Armor.SLOTS) do
    local p = eq[slot]
    if p and p.visual ~= nil then
      S.equippedClothes[slot] = p.visual
    else
      S.equippedClothes[slot] = nil
    end
  end
end

function Armor.activeFx()
  local out, seen = {}, {}
  local eq = Armor.equipped()
  for _, slot in ipairs(Armor.SLOTS) do
    local p = eq[slot]
    if p and p.fx then
      for _, id in ipairs(p.fx) do
        if not seen[id] then
          seen[id] = true
          out[#out + 1] = id
        end
      end
    end
  end
  return out
end

-- Aggregate enchant powers. Channels (the def.key) are what the game reads,
-- so Ember Might and plain Might both feed Armor.get("might").
function Armor.channels()
  if S and S._enchFrame == S.t and S._enchChannels then return S._enchChannels end
  local tot = {}
  local eq = Armor.equipped()
  for _, slot in ipairs(Armor.SLOTS) do
    local p = eq[slot]
    if p and p.enchants then
      for _, e in ipairs(p.enchants) do
        local def = Armor.ENCHANT_BY_ID[e.id]
        local key = (def and (def.key or def.id)) or e.id
        -- Older hand-written keys were camelCase. Accept both.
        tot[key] = (tot[key] or 0) + (e.power or 0)
        if def and def.id ~= key then tot[def.id] = (tot[def.id] or 0) + (e.power or 0) end
      end
    end
  end
  local caps = { party_bond = 3, second_chance = 1, teleport = 1, campRecall = 1, partyBond = 3, secondChance = 1 }
  for id, v in pairs(tot) do
    local cap = caps[id] or 140
    tot[id] = math.min(cap, v)
  end
  if S then S._enchFrame = S.t S._enchChannels = tot end
  return tot
end

function Armor.totals()
  return Armor.channels()
end

function Armor.get(id)
  local t = Armor.channels()
  if t[id] then return t[id] end
  -- camelCase aliases used by the original enchant list
  local alias = {
    doubleStrike = "double_strike", secondChance = "second_chance", lootFind = "loot_find",
    rarityAura = "rarity_aura", xpBoost = "xp_boost", catchBoost = "catch_boost", kyoFind = "kyo_find",
    campRecall = "teleport", partyBond = "party_bond", shopCharm = "shop_charm", sellBoost = "sell_boost",
    ghostXp = "ghost_xp", critEdge = "crit_edge", bossBane = "boss_bane", shroomSense = "shroom_sense",
    voidStep = "void_step", echoGuard = "echo_guard", sparkLife = "spark_life", fishLuck = "fish_luck",
  }
  if alias[id] and t[alias[id]] then return t[alias[id]] end
  for camel, snake in pairs(alias) do
    if id == snake and t[camel] then return t[camel] end
  end
  return 0
end

function Armor.has(id)
  return Armor.get(id) > 0
end

-- Merge two enchant entries of same id into one (sum powers, cap)
function Armor.mergeEnchant(a, b)
  if not a then return b end
  if not b then return a end
  if a.id ~= b.id then return a end
  local def = Armor.ENCHANT_BY_ID[a.id]
  local cap = def and def.max or 99
  -- When combining onto one piece, allow up to max*2 before hard cap on total worn
  local power = math.min(cap, (a.power or 0) + (b.power or 0))
  return { id = a.id, power = power }
end

function Armor.disenchant(piece, index)
  if not piece or not piece.enchants or not piece.enchants[index] then return nil end
  if (S.kyo or 0) < Armor.DISENCHANT_COST then
    Say("NEED " .. Armor.DISENCHANT_COST .. " KYO")
    Play("bump")
    return nil
  end
  S.kyo = S.kyo - Armor.DISENCHANT_COST
  local e = table.remove(piece.enchants, index)
  S.enchantStash = S.enchantStash or {}
  S.enchantStash[#S.enchantStash + 1] = e
  Say("DISENCHANTED " .. Upper((Armor.ENCHANT_BY_ID[e.id] and Armor.ENCHANT_BY_ID[e.id].name) or e.id))
  Play("quest")
  return e
end

function Armor.applyStash(piece, stashIndex)
  if not piece then return false end
  S.enchantStash = S.enchantStash or {}
  local e = S.enchantStash[stashIndex]
  if not e then return false end
  piece.enchants = piece.enchants or {}
  -- Merge if same id exists
  for i, cur in ipairs(piece.enchants) do
    if cur.id == e.id then
      piece.enchants[i] = Armor.mergeEnchant(cur, e)
      table.remove(S.enchantStash, stashIndex)
      Say("MERGED " .. Upper((Armor.ENCHANT_BY_ID[e.id] and Armor.ENCHANT_BY_ID[e.id].name) or e.id))
      Play("win")
      return true
    end
  end
  if #piece.enchants >= Armor.MAX_ENCHANTS then
    Say("MAX ENCHANTS ON PIECE")
    Play("bump")
    return false
  end
  piece.enchants[#piece.enchants + 1] = e
  table.remove(S.enchantStash, stashIndex)
  Say("ENCHANTED")
  Play("quest")
  return true
end

-- Drop chance from a killed ghost by level
function Armor.tryDropFromGhost(level, isBoss)
  level = level or 1
  if isBoss then
    local slot = Armor.SLOTS[love.math.random(1, #Armor.SLOTS)]
    return Armor.give(Armor.createPiece(slot, math.max(level, 120), { minEnchants = 4 }), "kill")
  end
  local chance = 2 + math.floor(level / 25)
  if level < 100 then chance = 3 end
  if love.math.random(1, 100) > chance then return nil end
  local slot = Armor.SLOTS[love.math.random(1, #Armor.SLOTS)]
  return Armor.give(Armor.createPiece(slot, level), "kill")
end

function Armor.shopStock(level)
  level = level or (S.trainer or 10)
  local stock = {}
  for i = 1, 4 do
    local slot = Armor.SLOTS[((i - 1) % #Armor.SLOTS) + 1]
    local p = Armor.createPiece(slot, level + love.math.random(0, 30))
    stock[#stock + 1] = p
  end
  return stock
end
