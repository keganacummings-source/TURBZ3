-- Camp system: place a campfire in the wild as your personal base.
-- - Becomes respawn point
-- - Teleport back anytime
-- - Send followers here
-- - Camp vault stores resources; more resources = more visiting traders

Camp = Camp or {}

-- Multi-camp support: S.camps = { {x,y,map,vault,visitors}, ... }; S.camp points at active
function Camp.list()
  S.camps = S.camps or {}
  -- migrate legacy single camp
  if S.camp and S.camp.x and #S.camps == 0 then
    S.camps[1] = S.camp
  end
  return S.camps
end

function Camp.activeIndex()
  Camp.list()
  return S.campIndex or 1
end

function Camp.setActive(i)
  local list = Camp.list()
  if not list[i] then return false end
  S.campIndex = i
  S.camp = list[i]
  return true
end

function Camp.nearest(x, y, map)
  local list = Camp.list()
  local best, bi, bd = nil, nil, 1e12
  x, y = x or S.px, y or S.py
  map = map or S.map
  for i, c in ipairs(list) do
    if c.x and (not map or not c.map or c.map == map) then
      local dx, dy = (c.x - x), (c.y - y)
      local d = dx * dx + dy * dy
      if d < bd then best, bi, bd = c, i, d end
    end
  end
  return best, bi
end

function Camp.remove(i)
  local list = Camp.list()
  i = i or S.campIndex or 1
  if not list[i] then return false end
  table.remove(list, i)
  if #list == 0 then
    S.camp = { vault = {}, visitors = {} }
    S.campIndex = 1
  else
    S.campIndex = math.min(i, #list)
    S.camp = list[S.campIndex]
  end
  Say("CAMP REMOVED")
  Play("bump")
  return true
end


function Camp.ensure()
  S.camps = S.camps or {}
  S.camp = S.camp or {
    x = nil, y = nil, map = nil,
    vault = {},
    visitors = {},
    lastVisitRoll = 0,
  }
  S.camp.vault = S.camp.vault or {}
  S.camp.visitors = S.camp.visitors or {}
  if S.camp.x and #S.camps == 0 then S.camps[1] = S.camp; S.campIndex = 1 end
  if S.campIndex and S.camps[S.campIndex] then S.camp = S.camps[S.campIndex] end
  return S.camp
end

function Camp.has()
  Camp.ensure()
  Camp.list()
  if S.camp and S.camp.x then return true end
  for _, c in ipairs(S.camps or {}) do if c.x then return true end end
  return false
end

function Camp.vaultTotal()
  Camp.ensure()
  local n = 0
  for _, c in pairs(S.camp.vault) do n = n + (c or 0) end
  return n
end

function Camp.deposit(id, count)
  Camp.ensure()
  count = math.floor(tonumber(count) or 1)
  if count <= 0 or not id then return false end
  local have = ItemCount and ItemCount(id) or 0
  if have < count then Say("NOT ENOUGH") Play("bump") return false end
  if TakeItem then TakeItem(id, count) end
  S.camp.vault[id] = (S.camp.vault[id] or 0) + count
  Say("STORED x" .. count .. " IN CAMP VAULT")
  Play("quest")
  Camp.refreshVisitors()
  return true
end

function Camp.withdraw(id, count)
  Camp.ensure()
  count = math.floor(tonumber(count) or 1)
  local have = S.camp.vault[id] or 0
  if have < count then Say("NOT IN VAULT") Play("bump") return false end
  S.camp.vault[id] = have - count
  if S.camp.vault[id] <= 0 then S.camp.vault[id] = nil end
  if GiveItem then GiveItem(id, count) end
  Say("TOOK x" .. count .. " FROM VAULT")
  Play("step")
  Camp.refreshVisitors()
  return true
end

-- Place camp at current tile (must be walkable wild, not city)
function Camp.place()
  Camp.ensure()
  if not World.walkable(S.px, S.py) then Say("CANNOT CAMP HERE") Play("bump") return false end
  S.camp.x, S.camp.y, S.camp.map = S.px, S.py, S.map
  Say("CAMPFIRE SET. THIS IS YOUR NEW SPAWN.")
  Play("win")
  Fire("camp_placed", { x = S.px, y = S.py })
  Camp.refreshVisitors()
  if LocalSave then LocalSave() end
  return true
end

function Camp.teleport()
  if not Camp.has() then Say("NO CAMP SET. USE CAMP ITEM IN THE WILD.") Play("bump") return false end
  S.px, S.py = S.camp.x, S.camp.y
  if S.camp.map then S.map = S.camp.map end
  S.rx, S.ry, S.followers, S.fpos = S.px, S.py, {}, {}
  Say("RETURNED TO CAMP")
  Play("quest")
  Fire("camp_teleport")
  return true
end

function Camp.sendFollowers()
  if not Camp.has() then Say("NO CAMP") Play("bump") return false end
  if not S.npcCompanions or #S.npcCompanions == 0 then Say("NO FOLLOWERS") Play("bump") return false end
  S.camp.followersAtCamp = S.camp.followersAtCamp or {}
  for _, id in ipairs(S.npcCompanions) do
    S.camp.followersAtCamp[id] = true
  end
  S.npcCompanions = {}
  S.npcCompanionPos = {}
  Say("FOLLOWERS WAIT AT CAMP")
  Play("quest")
  return true
end

function Camp.recallFollowers()
  Camp.ensure()
  local waiting = S.camp.followersAtCamp or {}
  local any = false
  for id, _ in pairs(waiting) do
    local def = Get("TownNPC", id)
    if def and AddTownCompanion then
      AddTownCompanion(def)
      any = true
    end
    waiting[id] = nil
  end
  if any then Say("FOLLOWERS REJOINED") Play("quest") else Say("NO ONE WAITING") Play("bump") end
end

-- Visitors scale with vault size
local EXOTIC_OUTFITS = {
  "voidwoven_mantle", "starforge_plate", "mycelium_crown_robes", "echo_silk_suit", "rift_emperor_regalia",
}

local VISITOR_POOL = {
  { name = "Road Peddler", stock = { { item = "ghost_jar", price = 5 }, { item = "potion", price = 3 } } },
  { name = "Spore Broker", stock = { { item = "blue_lantern", price = 12 }, { item = "dreamspore", price = 18 } } },
  { name = "Rift Scout", stock = { { item = "smoke_bomb", price = 9 }, { item = "big_potion", price = 10 } } },
  { name = "Quiet Fence", stock = { { item = "ghost_jar", price = 4 }, { item = "cleanse_salt", price = 3 } } },
}

function Camp.refreshVisitors()
  Camp.ensure()
  local total = Camp.vaultTotal()
  local slots = 0
  if total >= 5 then slots = 1 end
  if total >= 20 then slots = 2 end
  if total >= 50 then slots = 3 end
  if total >= 100 then slots = 4 end
  S.camp.visitors = {}
  local highZone = false
  if S.camp.x and World.regionAt then
    local reg = World.regionAt(S.camp.x, S.camp.y)
    local danger = (reg and (reg.danger or reg.level or 0)) or (S.trainer or 1)
    if type(danger) == "number" and danger >= 12 then highZone = true end
    if reg and reg.name and (string.find(string.lower(reg.name), "rift") or string.find(string.lower(reg.name), "ash") or string.find(string.lower(reg.name), "void") or string.find(string.lower(reg.name), "north")) then
      highZone = true
    end
    if (S.trainer or 1) >= 20 then highZone = true end
  end
  local discount = math.min(0.4, total * 0.002) -- up to 40% off
  for i = 1, slots do
    local base = VISITOR_POOL[((i + total) % #VISITOR_POOL) + 1]
    local stock = {}
    for _, s in ipairs(base.stock) do
      stock[#stock + 1] = {
        item = s.item,
        price = math.max(1, math.floor(s.price * (1 - discount))),
      }
    end
    -- High-level zone camps: exotic over-enchanted outfits (most expensive goods)
    if highZone and i == 1 then
      local oid = EXOTIC_OUTFITS[((total + i) % #EXOTIC_OUTFITS) + 1]
      local c = Get("Clothes", oid)
      if c then
        stock[#stock + 1] = {
          item = oid,
          clothes = true,
          price = math.max(1000, math.floor((c.price or 25000) * (1 - discount * 0.5))),
          label = c.name,
        }
      end
    end
    -- Armor stock for this visitor
    if Armor and Armor.shopStock then
      local arm = Armor.shopStock((S.trainer or 10) + (highZone and 40 or 0))
      for _, piece in ipairs(arm) do
        stock[#stock + 1] = {
          item = piece.uid or piece.name,
          armor = piece,
          price = piece.price or 500,
          label = piece.name,
        }
      end
    end
    S.camp.visitors[#S.camp.visitors + 1] = {
      name = highZone and ("Exotic " .. base.name) or base.name,
      stock = stock,
      discount = math.floor(discount * 100),
    }
  end
end

function Camp.openMenu()
  Camp.ensure()
  if not Camp.has() then
    -- allow placing if standing here
    Camp.place()
  end
  Go("camp")
end

-- Draw campfire marker in world
function Camp.draw()
  local list = Camp.list and Camp.list() or {}
  if #list == 0 and Camp.has and Camp.has() and S.camp and S.camp.x then list = { S.camp } end
  for _, c in ipairs(list) do
    if c.x and OnScreen and OnScreen(c.x, c.y) then
      local cx, cy = WorldToScreen(c.x, c.y)
      local zs = WorldSpriteScale and WorldSpriteScale() or 1
      Box(cx - 6 * zs, cy - 8 * zs, 12 * zs, 12 * zs, "blood")
      Frame(cx - 6 * zs, cy - 8 * zs, 12 * zs, 12 * zs, "kyo")
      Text("C", cx - 4 * zs, cy - 2 * zs, "ink", 8)
    end
  end
end

-- Override respawn to camp if set
function Camp.applySpawn()
  if Camp.has() then
    S.px, S.py = S.camp.x, S.camp.y
    if S.camp.map then S.map = S.camp.map end
    S.rx, S.ry = S.px, S.py
    return true
  end
  return false
end
