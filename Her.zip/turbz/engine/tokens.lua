-- Skill Tokens: +1 per skill level gained. Spend on blind buys.

Tokens = Tokens or {}

function Tokens.ensure()
  S.tokens = S.tokens or 0
  S.skillPerks = S.skillPerks or {} -- skillId -> { [perkLevel] = true }
  return S.tokens
end

function Tokens.add(n)
  Tokens.ensure()
  n = math.floor(tonumber(n) or 0)
  if n <= 0 then return end
  S.tokens = (S.tokens or 0) + n
end

function Tokens.spend(n)
  Tokens.ensure()
  n = math.floor(tonumber(n) or 0)
  if n <= 0 then return true end
  if (S.tokens or 0) < n then
    Say("NEED " .. n .. " TOKENS")
    Play("bump")
    return false
  end
  S.tokens = S.tokens - n
  return true
end

function Tokens.count()
  Tokens.ensure()
  return S.tokens or 0
end

-- Blind buy armor: 5 tokens
function Tokens.buyArmor()
  if not Tokens.spend(5) then return false end
  if not Armor or not Armor.createPiece then
    Say("ARMOR SYSTEM OFFLINE")
    return false
  end
  local slots = Armor.SLOTS or { "head", "chest", "legs", "feet" }
  local slot = slots[love.math.random(1, #slots)]
  local level = math.max(5, math.floor((S.trainer or 5) * 0.8 + love.math.random(0, 20)))
  local piece = Armor.createPiece(slot, level, { quality = "worn" })
  if piece and Armor.give then Armor.give(piece) end
  Say("BLIND ARMOR: " .. Upper((piece and piece.name) or slot))
  Play("quest")
  return true
end

-- Blind buy stored enchant: 3 tokens
function Tokens.buyEnchant()
  if not Tokens.spend(3) then return false end
  if not Armor or not Armor.rollEnchant then
    -- fallback store generic
    S.enchantStash = S.enchantStash or {}
    local names = { "swift", "might", "ward", "fortune", "second_chance", "double_hit", "loot_boost" }
    local id = names[love.math.random(1, #names)]
    S.enchantStash[#S.enchantStash + 1] = { id = id, power = love.math.random(5, 18), name = id }
    Say("BLIND ENCHANT: " .. Upper(id))
    Play("quest")
    return true
  end
  local e = Armor.rollEnchant(love.math.random(10, 40))
  S.enchantStash = S.enchantStash or {}
  S.enchantStash[#S.enchantStash + 1] = e
  Say("BLIND ENCHANT: " .. Upper((e and e.name) or (e and e.id) or "?"))
  Play("quest")
  return true
end

-- Blind buy ghost: 4 tokens
function Tokens.buyGhost()
  if not Tokens.spend(4) then return false end
  local all = GhostList and GhostList() or All("Ghost") or {}
  if #all == 0 then Say("NO GHOSTS") return false end
  local sp = all[love.math.random(1, #all)]
  local lv = math.max(3, math.floor((S.trainer or 5) * 0.7 + love.math.random(0, 15)))
  local g = MakeGhost and MakeGhost(sp.id, lv)
  if g then
    table.insert(S.box, g)
    Say("BLIND GHOST: " .. Upper(GhostName and GhostName(g) or sp.name or sp.id))
    Play("quest")
    return true
  end
  Say("FAILED ROLL")
  return false
end
