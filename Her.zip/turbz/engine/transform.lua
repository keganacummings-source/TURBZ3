-- Animal transforms: dog (shroom 10), cat (adventuring 10), kiwi (fishing 10).
-- Costs stamina per second; food restores stamina.

Transform = Transform or {}

Transform.FORMS = {
  dog = {
    name = "Dog",
    skill = "shroom",
    need = 10,
    speedMult = 0.65,
    staminaPerSec = 4,
    sheet = "assets/transforms/dog_walk.png",
    frames = 6,
    about = "Sniffs out twice as many mushrooms while roaming.",
  },
  cat = {
    name = "Cat",
    skill = "adventuring",
    need = 10,
    speedMult = 3.0,
    staminaPerSec = 6,
    sheet = "assets/transforms/cat_walk.png",
    frames = 6,
    about = "Triple movement speed on top of other bonuses.",
  },
  kiwi = {
    name = "Kiwi",
    skill = "fishing",
    need = 10,
    speedMult = 0.9,
    staminaPerSec = 5,
    canSwim = true,
    fishMult = 2.0,
    sheet = "assets/transforms/kiwi_walk.png",
    frames = 4,
    about = "Swim water tiles; double fishing power.",
  },
}

local sheetCache = {}

function Transform.unlocked(id)
  local f = Transform.FORMS[id]
  if not f then return false end
  return (SkillLevel and SkillLevel(f.skill) or 1) >= (f.need or 10)
end

function Transform.current()
  return S.transform
end

function Transform.set(id)
  if not id then
    S.transform = nil
    Say("BACK TO HUMAN")
    Play("step")
    return true
  end
  local f = Transform.FORMS[id]
  if not f then return false end
  if not Transform.unlocked(id) then
    Say("NEED " .. Upper(f.skill) .. " LV " .. tostring(f.need))
    Play("bump")
    return false
  end
  S.stamina = S.stamina or 100
  if (S.stamina or 0) < 5 then
    Say("TOO TIRED — EAT FOOD")
    Play("bump")
    return false
  end
  S.transform = id
  Say("TRANSFORM: " .. Upper(f.name))
  Play("quest")
  return true
end

function Transform.toggle(id)
  if S.transform == id then return Transform.set(nil) end
  return Transform.set(id)
end

function Transform.speedMult()
  local id = S.transform
  if not id then return 1 end
  local f = Transform.FORMS[id]
  return (f and f.speedMult) or 1
end

function Transform.canSwim()
  local id = S.transform
  if not id then return false end
  local f = Transform.FORMS[id]
  return f and f.canSwim
end

function Transform.fishMult()
  local id = S.transform
  if id == "kiwi" then return 2 end
  return 1
end

function Transform.shroomMult()
  if S.transform == "dog" then return 2 end
  return 1
end

function Transform.update(dt)
  dt = dt or 0.016
  S.stamina = S.stamina or 100
  local adv = SkillLevel and (SkillLevel("adventuring") or 1) or 1
  local enchMax = Armor and Armor.get and Armor.get("stamina_well") or 0
  S.staminaMax = math.floor(100 + (adv - 1) * 0.35 + enchMax)
  if (S._foodRegenT or 0) > 0 then
    S._foodRegenT = S._foodRegenT - dt
    if S._foodRegenT <= 0 then S._foodRegen, S._foodRegenT = 0, 0 end
  end
  local id = S.transform
  if id then
    local f = Transform.FORMS[id]
    if not f then S.transform = nil return end
    if not Transform.unlocked(id) then
      S.transform = nil
      Say("FORM FADED")
      return
    end
    local resist = Armor and Armor.get and Armor.get("beast_breath") or 0
    local cost = (f.staminaPerSec or 5) * dt * (1 - math.min(0.55, resist / 100))
    S.stamina = math.max(0, S.stamina - cost)
    if S.stamina <= 0 then
      S.transform = nil
      S.stamina = 0
      Say("EXHAUSTED — FORM DROPS")
      Play("bump")
    end
    return
  end
  local regen = 0.35 + (adv - 1) * 0.012
  regen = regen + ((SkillLevel and SkillLevel("hunting") or 1) - 1) * 0.002
  if Armor and Armor.get then regen = regen + (Armor.get("second_wind") or 0) * 0.02 end
  regen = regen + (S._foodRegen or 0)
  if (S.stamina or 0) < S.staminaMax then
    S.stamina = math.min(S.staminaMax, S.stamina + regen * dt)
  end
end

function Transform.eat(itemId)
  if Food and Food.eat then return Food.eat(itemId) end
  local food = {
    bread = 25, meat = 40, berry = 15, ration = 50, fish_meal = 35, candy = 10,
  }
  local heal = food[itemId]
  if not heal then return false end
  if TakeItem then TakeItem(itemId, 1) else return false end
  S.stamina = math.min(S.staminaMax or 100, (S.stamina or 0) + heal)
  Say("ATE " .. Upper(itemId) .. "  STA " .. math.floor(S.stamina))
  Play("quest")
  return true
end

function Transform.draw(cx, cy, scale)
  local id = S.transform
  if not id then return false end
  local f = Transform.FORMS[id]
  if not f then return false end
  local path = f.sheet
  if not sheetCache[path] then
    if love.filesystem.getInfo(path) then
      local ok, img = pcall(love.graphics.newImage, path)
      if ok and img then
        img:setFilter("nearest", "nearest")
        sheetCache[path] = img
      end
    end
  end
  local img = sheetCache[path]
  if not img then return false end
  local frames = f.frames or 4
  local iw, ih = img:getWidth(), img:getHeight()
  local fw = math.floor(iw / frames)
  local frame = math.floor(((S and S.t) or 0) / 6) % frames
  local q = love.graphics.newQuad(frame * fw, 0, fw, ih, iw, ih)
  scale = (scale or 1) * 1.2
  local dw, dh = fw * scale * 0.5, ih * scale * 0.5
  -- mirror by facing
  local sx = scale * 0.5
  if S.dir and (S.dir[1] or 0) < 0 then sx = -sx end
  love.graphics.setColor(1, 1, 1, 1)
  love.graphics.draw(img, q, cx, cy, 0, sx, scale * 0.5, fw / 2, ih * 0.85)
  return true
end
