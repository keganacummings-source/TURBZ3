-- AFK auto-play: grind nearby wilds that are safe relative to your party level,
-- skip high-level threats, progress quests, and auto-battle with the strongest move.

function ToggleAfk()
  S.afk = not S.afk
  if S.afk then
    Say(Word("afk_on") or "AFK ON - AUTO GRIND")
  else
    Say(Word("afk_off") or "AFK OFF")
  end
end

local function partyBestLevel()
  local best = 1
  for i = 1, ((EffectivePartySize and EffectivePartySize()) or Settings.partySize or 6) do
    local g = S.party and S.party[i]
    if g and (g.level or 1) > best then best = g.level or 1 end
  end
  return best
end

local function wildLevel(w)
  if not w then return 999 end
  if w.ghost and w.ghost.level then return w.ghost.level end
  if w.level then return w.level end
  return 1
end

-- Max level AFK will engage: party best + flee gap (default +5)
local function huntCap()
  return partyBestLevel() + (Settings.fleeLevelGap or 5)
end

function AfkStep()
  -- Auto-battle: pick strongest available move
  if S.screen == "battle" and S.battle then
    if BattleBusy and BattleBusy() then return end
    -- If foe is way above us, try bag flee item or just keep fighting with best move
    local foe = S.battle.foe
    local foeLv = foe and foe.ghost and foe.ghost.level or 1
    if foeLv > huntCap() + 10 and ItemCount and ItemCount("smoke_bomb") and ItemCount("smoke_bomb") > 0 then
      -- try to use smoke bomb if available via bag index - fall through to attack if not simple
    end
    return UseMove(BestMove(S.battle.me, S.battle.foe) or 1)
  end
  if S.screen == "result" then S.result = nil Go("explore") return end
  if S.screen == "reward" then return ClaimQuestReward(1) end
  if S.screen == "intro" then return end  -- let intro play
  if S.screen ~= "explore" then return end
  if S.book then return end

  local cap = huntCap()
  local target, best = nil, 999

  -- Prefer safe wilds within level cap
  for _, w in ipairs(S.wilds or {}) do
    local lvl = wildLevel(w)
    if lvl <= cap then
      local d = math.abs((w.x or 0) - S.px) + math.abs((w.y or 0) - S.py)
      -- Prefer closer, slightly prefer under-level for easy XP
      local score = d + math.max(0, lvl - partyBestLevel()) * 0.25
      if score < best then best, target = score, w end
    end
  end

  -- No safe wild: walk toward quest flag if any
  if not target and S.quest and S.quest.x then
    target = S.quest
  end

  local dx, dy
  if target then
    if World.nextToward then
      dx, dy = World.nextToward(target.x or target.px or S.px, target.y or target.py or S.py)
    end
  end
  -- Idle wander if nothing to do
  if not dx and not dy then
    local dirs = { {1,0}, {-1,0}, {0,1}, {0,-1} }
    local d = dirs[(math.floor((S.t or 0) / 30) % 4) + 1]
    dx, dy = d[1], d[2]
  end
  if Step then Step(dx or 0, dy or 0) end
end
