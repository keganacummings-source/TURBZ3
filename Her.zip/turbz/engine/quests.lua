-- Quests: Quest "id" { goals = {...}, rewards = {...} } in game/quests/.  Goal kinds are files in game/goals/
-- S.quest = { id, progress = { [goal#] = n }, choices = { reward#, ... }, done, x, y }   (x, y = the flag on the map)
function QuestDef() return S.quest and Get("Quest", S.quest.id) or nil end

function RegionById(id)
  for _, r in ipairs(World.regions or {}) do if r.id == id then return r end end
  return nil
end

-- a random walkable spot inside a region where a flag can stand
function RegionSpot(r)
  if not r or not r.x then return nil end
  local spots = {}
  for y = r.y + 1, r.y + r.h - 2 do
    for x = r.x + 1, r.x + r.w - 2 do
      local tile = Get("Tile", World.tileAt(x, y))
      if World.walkable(x, y) and tile and tile.questSpot and not PortalAt(x, y) and not PlaceAt(x, y) then table.insert(spots, { x, y }) end
    end
  end
  local s = Pick(spots)
  if s then return s[1], s[2] end
  return World.center(r)
end

local function goalCount(goal) return goal.count or 1 end
function GoalDone(i, entry)
  entry = entry or S.quest
  local def = entry and Get("Quest", entry.id) or nil
  return def and def.goals[i] and (entry.progress[i] or 0) >= goalCount(def.goals[i])
end

-- text for one goal, like "CATCH FIRE 1/2"
function GoalText(goal, have)
  local kind = Get("Goal", goal.kind)
  local text = goal.text or (kind and kind.onText and kind.onText(goal)) or Upper(goal.kind)
  return Upper(text) .. " " .. Min(have or 0, goalCount(goal)) .. "/" .. goalCount(goal)
end

-- the line under the HUD: next goal, or "RETURN TO ..." for a finished giver quest
function QuestLine()
  if Stories and Stories.line then
    local story = Stories.line()
    if story then return story end
  end
  if not S.quest then return nil end
  local gv = S.quest.giver and Get("QuestGiver", S.quest.giver)
  if S.quest.done and gv then return "RETURN TO " .. Upper(gv.name) end
  local goal, i = CurrentGoal()
  return goal and GoalText(goal, S.quest.progress[i]) or nil
end

function CurrentGoal()
  local q = QuestDef()
  if not q then return nil end
  for i, goal in ipairs(q.goals) do if not GoalDone(i) then return goal, i end end
  return nil
end

function UpdateQuestFlag()
  if not S.quest then return end
  if S.quest.done and S.quest.giver then
    local gv = Get("QuestGiver", S.quest.giver)
    S.quest.flagFor, S.quest.x, S.quest.y = "giver", gv and gv.map == S.map and gv.x - 1 or nil, gv and gv.y or nil
    return
  end
  local goal, i = CurrentGoal()
  local kind = goal and Get("Goal", goal.kind)
  local key = goal and (goal.kind .. ":" .. tostring(i))
  if key == S.quest.flagFor then return end
  S.quest.flagFor, S.quest.x, S.quest.y = key, nil, nil
  if kind and kind.onFlag then S.quest.x, S.quest.y = kind.onFlag(goal) end
end

local function available()
  local out = {}
  for _, q in ipairs(All("Quest")) do
    if q.enabled and q.random and S.trainer >= q.minTrainer and (q.map == "" or q.map == S.map) and not (q.once and S.questsDone[q.id]) then
      table.insert(out, q)
    end
  end
  return out
end

local function pickChoices(q)
  local idx = {}
  for i = 1, #q.rewards do table.insert(idx, i) end
  for i = #idx, 2, -1 do local j = love.math.random(i) idx[i], idx[j] = idx[j], idx[i] end
  local out = {}
  for i = 1, Min(#idx, Settings.rewardChoices or 3) do table.insert(out, idx[i]) end
  table.sort(out)
  return out
end

-- start a quest (id = a Quest id, or nil = random by weight). giver = QuestGiver id it came from
function NewQuest(id, giver)
  S.quests = S.quests or {}
  local weights, list = {}, available()
  for _, q in ipairs(list) do
    local already = false
    for _, aq in ipairs(S.quests) do if aq.id == q.id and not aq.done then already = true break end end
    if not already then weights[q.id] = q.weight end
  end
  local q = Get("Quest", id or PickWeighted(weights) or "")
  if not q then return end
  -- already tracking this quest?
  for _, aq in ipairs(S.quests) do
    if aq.id == q.id and not aq.done then
      Say("ALREADY ON: " .. Upper(q.name))
      S.quest = aq
      UpdateQuestFlag()
      return
    end
  end
  local entry = { id = q.id, progress = {}, choices = pickChoices(q), done = false, giver = giver }
  for i in ipairs(q.goals) do entry.progress[i] = 0 end
  table.insert(S.quests, entry)
  S.quest = entry  -- focused quest
  if q.onStart then q.onStart(entry) end
  UpdateQuestFlag()
  Say(Word("quest_new", Upper(q.name)) .. " (" .. #S.quests .. " ACTIVE)")
  Fire("quest_new", entry)
end

-- checks every goal (runs after events and while exploring)
function QuestCheck(name, e)
  S.quests = S.quests or {}
  if S.quest then
    local found = false
    for _, x in ipairs(S.quests) do if x == S.quest or x.id == S.quest.id then found = true break end end
    if not found then table.insert(S.quests, S.quest) end
  end
  for _, entry in ipairs(S.quests) do
    if not entry.done then
      local qdef = Get("Quest", entry.id)
      if qdef then
        local prev = S.quest
        S.quest = entry
        for i, goal in ipairs(qdef.goals) do
          local kind = Get("Goal", goal.kind)
          local have = entry.progress[i] or 0
          if kind and not GoalDone(i, entry) then
            if name and kind.onEvent then have = have + (kind.onEvent(goal, name, e or {}) or 0) end
            if kind.onProgress then have = kind.onProgress(goal, have) or have end
            entry.progress[i] = have
            if GoalDone(i, entry) then Say(Word("goal_done", GoalText(goal, have))) Play("quest") end
          end
        end
        local finished = true
        for i in ipairs(qdef.goals) do if not GoalDone(i, entry) then finished = false end end
        if qdef.onCheck then finished = qdef.onCheck(entry, finished) end
        if finished then
          entry.done = true
          for _, goal in ipairs(qdef.goals) do
            local kind = Get("Goal", goal.kind)
            if kind and kind.onFinish then kind.onFinish(goal) end
          end
          if qdef.onFinish then qdef.onFinish(entry) end
          local gv = entry.giver and Get("QuestGiver", entry.giver)
          if not gv then
            -- auto-complete non-giver quests
            if not S.questsDone then S.questsDone = {} end
            S.questsDone[entry.id] = true
          end
          Say(gv and Word("quest_return", Upper(gv.name)) or Word("quest_done", Upper(qdef.name)))
          Play("win")
          Fire("quest_done", entry)
        end
        S.quest = prev or entry
      end
    end
  end
  for _, entry in ipairs(S.quests) do
    if not entry.done then S.quest = entry break end
  end
  UpdateQuestFlag()
end


-- { kyo = 15 }  { item = "potion", count = 3 }  { ghost = "onibi", level = 5, rarity = "faded" }  { name = "...", onGive = function() end }
function RewardText(r)
  if r.name then return Upper(r.name) end
  if r.kyo then return r.kyo .. " KYO" end
  if r.item then local it = Get("Item", r.item) return Upper(it and it.name or r.item) .. " x" .. (r.count or 1) end
  if r.ghost then
    local sp, rare = Get("Ghost", r.ghost), Get("Rarity", r.rarity or "")
    return (rare and (Upper(rare.name) .. " ") or "") .. Upper(sp and sp.name or r.ghost) .. " LV" .. (r.level or 1)
  end
  return "???"
end

function GiveReward(r)
  if type(r) ~= "table" then return end
  S.box = S.box or {}
  S.seen = S.seen or {}
  S.kyo = S.kyo or 0
  local kyo = r.kyo or ((r.kind == "kyo") and (r.amount or r.count))
  if type(kyo) == "number" then S.kyo = S.kyo + kyo end
  local item = r.item or ((r.kind == "item") and (r.id or r.name))
  if item and GiveItem then GiveItem(item, r.count or r.amount or 1, "quest") end
  if r.ghost then
    local species = r.ghost
    if species == true then species = nil end
    if type(species) == "table" then species = species.id end
    local g = species and MakeGhost and MakeGhost(species, r.level or 1, r.rarity)
    if g then table.insert(S.box, g) S.seen[g.species] = true end
  end
  if type(r.onGive) == "function" then r.onGive(r) end
  Fire("reward_given", r)
end

local function doneTally(id)
  local prev = S.questsDone and S.questsDone[id]
  if type(prev) == "number" then return prev end
  if prev then return 1 end
  return 0
end

function ClaimQuestReward(n)
  local q = QuestDef()
  if not q or not S.quest or not S.quest.done then return end
  S.questsDone = S.questsDone or {}
  local finished = q.id
  local ok, err = pcall(function()
    if S.quest.board and QuestBoard and QuestBoard.completePay then
      QuestBoard.completePay()
    else
      local choices = S.quest.choices
      local index = (type(choices) == "table" and choices[n]) or (type(choices) == "table" and choices[1]) or n or 1
      if type(index) ~= "number" then index = 1 end
      local rewards = q.rewards
      local r = type(rewards) == "table" and rewards[index] or nil
      if type(r) == "table" then
        GiveReward(r)
        Say(Word("reward_got", RewardText(r)))
      end
    end
  end)
  if not ok then
    Say("THE REWARD SLIPPED. THE QUEST STILL CLOSES.")
    if Engine and Engine.warn then Engine.warn("quest reward: " .. tostring(err), true) end
  end
  S.questsDone[finished] = doneTally(finished) + 1
  if S.quest.giver and GiverReturned then GiverReturned(S.quest.giver, finished) end
  Fire("quest_claimed", { quest = finished, giver = S.quest.giver })
  local keep = {}
  for _, entry in ipairs(S.quests or {}) do
    if entry.id ~= finished then keep[#keep + 1] = entry end
  end
  S.quests = keep
  S.quest = nil
  pcall(NewQuest)
  Go("explore")
end


function QuestMaybeArmorReward()
  if love.math.random(1, 100) <= 28 and Armor and Armor.createPiece then
    local slot = Armor.SLOTS[love.math.random(1, #Armor.SLOTS)]
    local level = math.max(5, math.floor((S.trainer or 5) * 0.6))
    local piece = Armor.createPiece(slot, level, { quality = "worn" })
    -- softer enchants for quest gear
    if piece.enchants and #piece.enchants > 2 then
      while #piece.enchants > 2 do table.remove(piece.enchants) end
    end
    Armor.give(piece, "quest")
  end
end
