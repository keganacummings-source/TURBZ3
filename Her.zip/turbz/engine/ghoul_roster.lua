-- Each new save rolls 300 unique ghouls off the ghoul sheet and files them in the book.

GhoulRoster = GhoulRoster or {}

local FIRST = {
  "Ash", "Marrow", "Dusk", "Rot", "Pale", "Briar", "Cinder", "Grave", "Moss", "Hollow",
  "Salt", "Vein", "Wick", "Sable", "Rime", "Thorn", "Umber", "Gloom", "Silk", "Bramble",
}
local SECOND = {
  "Wretch", "Maw", "Saint", "Drifter", "Howler", "Widow", "Stitch", "Regent", "Child", "Oracle",
  "Hex", "Lurker", "Pilgrim", "Cantor", "Butcher", "Nun", "Keeper", "Wisp", "Eater", "Crown",
}
local TYPES = { "normal", "fire", "water", "earth", "air", "electric", "ice", "void", "light", "spirit", "ghoul" }

local function liveTypes()
  local out = {}
  for _, id in ipairs(TYPES) do
    if Get and Get("Type", id) then out[#out + 1] = id end
  end
  if #out == 0 then out[1] = "normal" end
  return out
end

local function defineOne(e)
  if not Define then return end
  Define("Ghost", e.id, {
    number = e.number,
    name = e.name,
    type = e.type,
    spooky = e.spooky, sleepy = e.sleepy, speed = e.speed, damage = e.damage, mass = e.mass,
    catchRate = e.catchRate or 28,
    sprite = "ghoul_fallback",
    about = e.about or "A ghoul rolled for this save alone.",
    turnTime = 14,
    moves = {},
  })
end

function GhoulRoster.attach(g)
  if not g or not S or not S.ghoulLooks then return g end
  local e = S.ghoulLooks[g.species]
  if not e then return g end
  g.layers = {
    sheet = "ghoul",
    body = e.body, hair = e.hair, head = e.head, chest = e.chest,
    legs = e.legs, feet = e.feet, accessory = e.accessory,
    type = e.type, rarity = g.rarity,
  }
  g.imageSprite = nil
  return g
end

function GhoulRoster.list()
  if not S or not S.ghoulRoster then return nil end
  local out = {}
  for _, e in ipairs(S.ghoulRoster) do
    local sp = Get and Get("Ghost", e.id)
    if sp then out[#out + 1] = sp end
  end
  return out
end

function GhoulRoster.apply(entries, markSeen)
  S.ghoulRoster = entries
  S.ghoulLooks = {}
  for _, e in ipairs(entries) do
    S.ghoulLooks[e.id] = e
    defineOne(e)
    if markSeen and S.seen then S.seen[e.id] = true end
  end
  if Settings then Settings.starter = entries[1] and entries[1].id or Settings.starter end
end

function GhoulRoster.roll(seed)
  seed = tonumber(seed) or (os.time() % 2000000000)
  local function rnd(n)
    seed = (seed * 1103515245 + 12345) % 2147483648
    return seed % n
  end
  local types = liveTypes()
  local used, names = {}, {}
  local entries = {}
  local guard = 0
  while #entries < 300 and guard < 8000 do
    guard = guard + 1
    local e = {
      body = rnd(10), hair = rnd(10), head = rnd(20), chest = rnd(20),
      legs = rnd(20), feet = rnd(20), accessory = rnd(20),
    }
    local key = string.format("%d:%d:%d:%d:%d:%d:%d", e.body, e.hair, e.head, e.chest, e.legs, e.feet, e.accessory)
    if not used[key] then
      used[key] = true
      local n = #entries + 1
      local name = FIRST[rnd(#FIRST) + 1] .. " " .. SECOND[rnd(#SECOND) + 1]
      if names[name] then name = name .. " " .. n end
      names[name] = true
      e.id = string.format("ghoul_%03d", n)
      e.number = n
      e.name = name
      e.type = types[((n - 1) % #types) + 1]
      e.spooky = 2 + (n % 7)
      e.sleepy = 2 + ((n * 3) % 7)
      e.speed = 2 + ((n * 5) % 7)
      e.damage = 2 + ((n * 7) % 8)
      e.mass = 2 + ((n * 11) % 7)
      e.catchRate = 18 + (n % 20)
      e.about = "Rolled when this save began. No other world has this ghoul."
      entries[n] = e
    end
  end
  GhoulRoster.apply(entries, true)
  return entries
end

function GhoulRoster.restore()
  if S and S.ghoulRoster and #S.ghoulRoster > 0 then
    GhoulRoster.apply(S.ghoulRoster, false)
  end
end
