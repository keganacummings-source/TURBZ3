-- Builds the map (base Map + every MapAddon for it), smooth animation and drawing
World = { w = 1, h = 1, tiles = {}, zone = {}, regions = {}, portals = {} }
DIRS = { { 1, 0 }, { -1, 0 }, { 0, 1 }, { 0, -1 } }

local function idx(x, y) return y * World.w + x end
local function inside(x, y) return x >= 0 and y >= 0 and x < World.w and y < World.h end
local function set(x, y, tile) if inside(x, y) then World.tiles[idx(x, y)] = tile end end

function World.prepareMask()
  if World._mask then return true end
  local path = "assets/map/overview_mask.bin"
  if not love.filesystem.getInfo(path) then return false end
  local data = love.filesystem.read(path)
  if not data or data:sub(1, 4) ~= "KYOM" or #data < 10 then return false end
  local function u16(i)
    local a, b = data:byte(i, i + 1)
    return a + b * 256
  end
  local pw, ph, scale = u16(5), u16(7), data:byte(9)
  if pw < 8 or ph < 8 or scale < 1 or scale > 16 then return false end
  if #data < 10 + pw * ph then return false end
  World._mask, World._maskW, World._maskH, World._maskScale = data, pw, ph, scale
  World._maskBase = 10
  return true
end

function World.maskByte(x, y)
  local data = World._mask
  if not data then return 0 end
  local scale = World._maskScale or 8
  local px = math.floor(x / scale)
  local py = math.floor(y / scale)
  if px < 0 or py < 0 or px >= World._maskW or py >= World._maskH then return 0 end
  return data:byte(World._maskBase + py * World._maskW + px) or 0
end

function World.baseTile(x, y)
  local b = World.maskByte(x, y)
  if not b or b <= 0 then return "ocean" end
  if b >= 128 then return "shore" end
  return "floor"
end

function World.installVirtualTiles()
  World._over = {}
  World.tiles = setmetatable({}, {
    __index = function(_, i)
      local over = World._over[i]
      if over ~= nil then return over end
      local x = i % World.w
      local y = (i - x) / World.w
      return World.baseTile(x, y)
    end,
    __newindex = function(_, i, v)
      World._over[i] = v
    end,
  })
  World.zone = {}
  World._virtual = true
end

function World.paint(x, y, tile)
  x = math.floor(x or 0)
  y = math.floor(y or 0)
  if x >= 1 and y >= 1 and x < World.w - 1 and y < World.h - 1 then
    World.tiles[idx(x, y)] = tile
  end
end
function World.inMap(x, y) return x >= 1 and y >= 1 and x < World.w - 1 and y < World.h - 1 end
function World.tileAt(x, y) if inside(x, y) then return World.tiles[idx(x, y)] end return nil end
function World.walkable(x, y)
  if not World.inMap(x, y) then return false end
  local t = Get("Tile", World.tiles[idx(x, y)])
  return t ~= nil and t.walkable
end
function World.regionAt(x, y)
  if not World.inMap(x, y) then return World.road end
  if World._virtual then
    World._regionHit = World._regionHit or {}
    local key = math.floor(x / 24) * 100000 + math.floor(y / 24)
    local cached = World._regionHit[key]
    if cached ~= nil then return cached == false and World.road or cached end
    local found = nil
    for _, r in ipairs(World.regions or {}) do
      if x >= r.x and y >= r.y and x < r.x + r.w and y < r.y + r.h then found = r break end
    end
    if World._regionHitN and World._regionHitN > 12000 then
      World._regionHit = {}
      World._regionHitN = 0
    end
    World._regionHit[key] = found or false
    World._regionHitN = (World._regionHitN or 0) + 1
    return found or World.road
  end
  return World.zone[idx(x, y)] or World.road
end
function World.center(r) return r.x + math.floor(r.w / 2), r.y + math.floor(r.h / 2) end

function RegionAt(x, y) return World.regionAt(x, y) end
function TileAt(x, y) return World.tileAt(x, y) end
function Walkable(x, y) return World.walkable(x, y) end
function MapRegions() return World.regions end
function CurrentMap() return World.map end

local function stamp(m, r)
  for y = r.y, r.y + r.h - 1 do
    for x = r.x, r.x + r.w - 1 do set(x, y, m.floor) end
  end
  if r.pool then
    local cx, cy = World.center(r)
    for y = cy - 2, cy + 2 do
      for x = cx - 3, cx + 3 do
        if (x - cx) ^ 2 / 9 + (y - cy) ^ 2 / 4 <= 1 then set(x, y, m.pool) end
      end
    end
  end
end


-- Organic coastlines: region rectangles are only biome anchors, not the visible land shape.
local function stampNaturalRegion(m, r)
  local cx, cy = r.x + (r.w - 1) / 2, r.y + (r.h - 1) / 2
  local hx, hy = (r.w - 1) / 2, (r.h - 1) / 2
  -- Larger corner radius + multi-frequency noise = less rectangular blobs
  local radius = math.max(3, math.min(28, hx * 0.28, hy * 0.28))
  local pad = math.max(8, math.floor(radius + 6))
  for y = math.max(1, r.y - pad), math.min(World.h - 2, r.y + r.h + pad) do
    for x = math.max(1, r.x - pad), math.min(World.w - 2, r.x + r.w + pad) do
      local qx = math.abs(x - cx) - (hx - radius)
      local qy = math.abs(y - cy) - (hy - radius)
      local ox, oy = math.max(qx, 0), math.max(qy, 0)
      local sdf = math.sqrt(ox * ox + oy * oy) + math.min(math.max(qx, qy), 0) - radius
      local wave = math.sin((x + r.x * 3.1) * 0.18 + (y + r.y * 1.7) * 0.14) * 4.2
        + math.cos((x - r.y * 2.7) * 0.11 - (y + r.x) * 0.17) * 3.6
        + math.sin((x * 0.07) + (y * 0.09) + r.x * 0.02) * 2.8
        + math.cos((x * 0.031) - (y * 0.027)) * 2.1
      if sdf <= wave then set(x, y, m.floor) end
    end
  end
end


-- The large-world regions describe biome/encounter ownership; these authored masks
-- define the actual coastlines. They make one broad, irregular central continent and
-- a southwest peninsula rather than a matrix of rounded rectangular zones.
local function pointInPolygon(x, y, polygon)
  local insidePolygon = false
  local j = #polygon
  for i = 1, #polygon do
    local xi, yi = polygon[i][1], polygon[i][2]
    local xj, yj = polygon[j][1], polygon[j][2]
    if ((yi > y) ~= (yj > y)) and x < (xj - xi) * (y - yi) / ((yj - yi) ~= 0 and (yj - yi) or 1) + xi then
      insidePolygon = not insidePolygon
    end
    j = i
  end
  return insidePolygon
end

local function stampContinentMasks(m)
  if m.id ~= "giant_world" then return end
  local islandGroups = {
    -- These shapes trim outer zone unions into island/secondary-continent coastlines.
    { bounds = {1960,390,3130,1160}, polygon = {
      {2100,505},{2245,415},{2510,410},{2765,465},{2995,505},{3075,615},{3060,850},
      {2965,990},{2830,1100},{2670,1110},{2510,1050},{2345,1120},{2190,1040},{2090,915},{2045,740} } },
    { bounds = {710,1700,1860,2550}, polygon = {
      {900,1850},{1100,1735},{1355,1750},{1560,1830},{1725,1935},{1800,2070},{1735,2200},
      {1755,2315},{1635,2435},{1430,2490},{1220,2440},{1055,2495},{895,2400},{800,2245},
      {755,2080},{805,1950} } },
    { bounds = {5240,500,6420,1350}, polygon = {
      {5350,780},{5400,660},{5550,565},{5825,550},{6075,615},{6250,700},
      {6365,825},{6330,1005},{6210,1155},{6060,1245},{5850,1290},{5670,1215},
      {5500,1240},{5385,1120},{5300,975} } },
    { bounds = {5640,1690,6810,2510}, polygon = {
      {5740,1925},{5825,1800},{6040,1735},{6250,1775},{6480,1750},{6685,1850},
      {6750,1995},{6705,2165},{6625,2300},{6470,2395},{6290,2440},{6110,2365},
      {5930,2405},{5775,2295},{5700,2165},{5695,2025} } },
    { bounds = {4910,3125,6100,3930}, polygon = {
      {5040,3345},{5160,3230},{5350,3190},{5550,3230},{5740,3175},{5915,3265},
      {6025,3385},{5950,3550},{5880,3705},{5700,3800},{5505,3855},{5340,3775},
      {5180,3800},{5050,3690},{4975,3530} } },
    { bounds = {730,2470,1310,3020}, polygon = {
      {865,2570},{985,2510},{1130,2525},{1235,2615},{1285,2730},{1245,2855},
      {1150,2945},{1020,2970},{895,2920},{815,2820},{790,2695} } }
  }
  for _, group in ipairs(islandGroups) do
    local bounds, polygon = group.bounds, group.polygon
    for y = bounds[2], bounds[4] do
      for x = bounds[1], bounds[3] do
        if inside(x, y) and not pointInPolygon(x, y, polygon) and World.tiles[idx(x, y)] == m.floor then
          set(x, y, "ocean")
        end
      end
    end
  end

  local polygons = {
    -- Main continent: northwestern shoulder, broad inland heart and jagged eastern cape.
    {
      {2600,1460},{2725,1350},{2900,1280},{3100,1240},{3300,1300},{3500,1180},{3710,905},
      {3875,875},{4045,950},{4200,1035},{4400,1100},{4640,1115},{4850,1195},{5055,1310},
      {5270,1430},{5415,1575},{5525,1730},{5585,1900},{5550,2055},{5615,2215},
      {5555,2380},{5485,2555},{5365,2700},{5225,2825},{5035,2945},{4860,3075},
      {4680,3175},{4495,3275},{4305,3295},{4140,3235},{3965,3315},{3800,3230},{3630,3240},
      {3455,3150},{3280,3145},{3120,3035},{2955,2925},{2800,2830},{2645,2720},{2530,2600},
      {2410,2500},{2310,2390},{2235,2255},{2175,2105},{2175,1950},{2220,1790},{2300,1665},
      {2370,1550},{2480,1475}
    },
    -- The southwest cape widens gradually toward Crownfall instead of a thin bridge.
    {
      {2550,2500},{2710,2655},{2735,2825},{2655,2980},{2525,3145},{2405,3290},{2265,3430},
      {2115,3555},{1985,3660},{1820,3785},{1640,3900},{1470,4025},{1300,4135},{1125,4235},
      {960,4290},{795,4255},{735,4155},{815,4050},{935,3950},{1075,3845},{1245,3740},
      {1410,3650},{1570,3545},{1730,3440},{1860,3325},{1965,3195},{2070,3055},{2155,2905},
      {2240,2760},{2325,2635},{2435,2540}
    }
  }
  for _, polygon in ipairs(polygons) do
    local minX, maxX, minY, maxY = World.w, 0, World.h, 0
    for _, point in ipairs(polygon) do
      minX, maxX = math.min(minX, point[1]), math.max(maxX, point[1])
      minY, maxY = math.min(minY, point[2]), math.max(maxY, point[2])
    end
    for y = math.max(1, minY), math.min(World.h - 2, maxY) do
      for x = math.max(1, minX), math.min(World.w - 2, maxX) do
        if pointInPolygon(x, y, polygon) then set(x, y, m.floor) end
      end
    end
  end
end

local function rectGap(a, b)
  local dx, dy = 0, 0
  if a.x + a.w - 1 < b.x then dx = b.x - (a.x + a.w - 1)
  elseif b.x + b.w - 1 < a.x then dx = a.x - (b.x + b.w - 1) end
  if a.y + a.h - 1 < b.y then dy = b.y - (a.y + a.h - 1)
  elseif b.y + b.h - 1 < a.y then dy = a.y - (b.y + b.h - 1) end
  return dx, dy
end

local function closestEdges(a, b)
  local dx, dy = rectGap(a, b)
  local ax, ay, bx, by
  if dx > 0 and dy == 0 then
    local lo, hi = math.max(a.y, b.y), math.min(a.y + a.h - 1, b.y + b.h - 1)
    local y = math.floor((lo + hi) / 2 + 0.5)
    if a.x < b.x then ax, bx = a.x + a.w - 1, b.x else ax, bx = a.x, b.x + b.w - 1 end
    ay, by = y, y
  elseif dy > 0 and dx == 0 then
    local lo, hi = math.max(a.x, b.x), math.min(a.x + a.w - 1, b.x + b.w - 1)
    local x = math.floor((lo + hi) / 2 + 0.5)
    if a.y < b.y then ay, by = a.y + a.h - 1, b.y else ay, by = a.y, b.y + b.h - 1 end
    ax, bx = x, x
  else
    local acx, acy = a.x + (a.w - 1) / 2, a.y + (a.h - 1) / 2
    local bcx, bcy = b.x + (b.w - 1) / 2, b.y + (b.h - 1) / 2
    ax, ay = Clamp(bcx, a.x, a.x + a.w - 1), Clamp(bcy, a.y, a.y + a.h - 1)
    bx, by = Clamp(acx, b.x, b.x + b.w - 1), Clamp(acy, b.y, b.y + b.h - 1)
  end
  return math.floor(ax + 0.5), math.floor(ay + 0.5), math.floor(bx + 0.5), math.floor(by + 0.5)
end

-- 4-direction connected line with optional cross-width. Keeps links walkable in grid movement.
local function traceLink(x0, y0, x1, y1, tile, width, wavy, seed)
  local x, y, guard = x0, y0, 0
  local dx, dy = x1 - x0, y1 - y0
  local sx, sy = dx >= 0 and 1 or -1, dy >= 0 and 1 or -1
  local majorX = math.abs(dx) >= math.abs(dy)
  local total = math.max(1, math.abs(dx) + math.abs(dy))
  local function stampAt(px, py, n)
    local jitter = 0
    if wavy then jitter = math.floor(math.sin(n * 0.19 + seed) * 2.25 + 0.5) end
    if majorX then py = py + jitter else px = px + jitter end
    if width <= 1 then set(px, py, tile)
    else
      for o = -math.floor(width / 2), math.floor(width / 2) do
        if majorX then set(px, py + o, tile) else set(px + o, py, tile) end
      end
    end
  end
  while true do
    stampAt(x, y, guard)
    if x == x1 and y == y1 then break end
    local remainX, remainY = math.abs(x1 - x), math.abs(y1 - y)
    if remainX > 0 and remainY > 0 then
      if (guard % 2 == 0 and remainX >= remainY) or remainX > remainY then x = x + sx
      else y = y + sy end
    elseif remainX > 0 then x = x + sx
    else y = y + sy end
    guard = guard + 1
    if guard > total * 3 + 20 then break end
  end
end

local function connectNearbyLand(regions, m)
  for i = 1, #regions do
    for j = i + 1, #regions do
      local a, b = regions[i], regions[j]
      local gx, gy = rectGap(a, b)
      -- Join nearby natural coastlines with a narrow, winding strip of the local biome.
      -- This is intentionally not a grid of wide rectangular roads.
      if (gx > 0 or gy > 0) and math.sqrt(gx * gx + gy * gy) <= 15 then
        local x0, y0, x1, y1 = closestEdges(a, b)
        traceLink(x0, y0, x1, y1, m.floor, 3, true, i * 0.73 + j * 1.19)
      end
    end
  end
end

local function nearestFloorPoint(m, x, y, radius)
  -- Coastline curves can leave a region's bounding-box edge in the sea. Anchor
  -- each bridge to real land so its centre tile joins the continent's walkable edge.
  local bestX, bestY, bestD = x, y, 1e18
  radius = radius or 8
  for oy = -radius, radius do
    for ox = -radius, radius do
      local px, py = x + ox, y + oy
      if inside(px, py) and World.tiles[idx(px, py)] == m.floor then
        local d = ox * ox + oy * oy
        if d < bestD then bestX, bestY, bestD = px, py, d end
      end
    end
  end
  return bestX, bestY
end

local function nearestCoastPoint(m, x, y, radius)
  local bestX, bestY, bestD = x, y, 1e18
  radius = radius or 60
  for oy = -radius, radius do
    for ox = -radius, radius do
      local px, py = x + ox, y + oy
      if inside(px, py) and World.tiles[idx(px, py)] == m.floor then
        local coast = World.tiles[idx(px + 1, py)] == "ocean" or World.tiles[idx(px - 1, py)] == "ocean"
          or World.tiles[idx(px, py + 1)] == "ocean" or World.tiles[idx(px, py - 1)] == "ocean"
        if coast then
          local d = ox * ox + oy * oy
          if d < bestD then bestX, bestY, bestD = px, py, d end
        end
      end
    end
  end
  if bestD == 1e18 then return nearestFloorPoint(m, x, y, radius) end
  return bestX, bestY
end

local function carveBridgeLinks(m, regions)
  for _, pair in ipairs(m.bridges or {}) do
    local a, b = Get("Region", pair[1]), Get("Region", pair[2])
    if a and b then
      local x0, y0, x1, y1 = closestEdges(a, b)
      x0, y0 = nearestCoastPoint(m, x0, y0, 60)
      x1, y1 = nearestCoastPoint(m, x1, y1, 60)
      -- Only these designated long-distance links are true plank bridges.
      -- Long inter-continent crossings use a three-tile deck so they read as
      -- deliberate causeways at this world scale, not single-file tile seams.
      traceLink(x0, y0, x1, y1, "bridge", 3, false, 0)
    else
      Engine.warn('Map "' .. m.id .. '" bridge is missing region "' .. tostring(not a and pair[1] or pair[2]) .. '"', true)
    end
  end
end

-- A final connectivity sweep protects the global landmass from tiny islands
-- made only of coastline noise. It removes detached specks (<=64 walkable
-- tiles), but never silently deletes a major landmass: large disconnected areas
-- are preserved and reported so their missing causeway can be repaired.
local function pruneDisconnectedLandSpecks(m)
  if not m or m.id ~= "giant_world" then return end
  local start = m.start or { World.manorX or 1, World.manorY or 1 }
  local startIndex = idx(start[1], start[2])
  local visited, walkCache = {}, {}
  local pruned, largeOrphans = 0, 0
  local function canWalk(tileIndex)
    local tileId = World.tiles[tileIndex]
    local ok = walkCache[tileId]
    if ok == nil then
      local def = Get("Tile", tileId)
      ok = def ~= nil and def.walkable == true
      walkCache[tileId] = ok
    end
    return ok
  end
  for y = 1, World.h - 2 do
    for x = 1, World.w - 2 do
      local seed = idx(x, y)
      if not visited[seed] and canWalk(seed) then
        local queue, small = { seed }, {}
        local head, count, hasStart = 1, 0, false
        visited[seed] = true
        while head <= #queue do
          local current = queue[head]
          head, count = head + 1, count + 1
          if current == startIndex then hasStart = true end
          if small then
            if #small < 64 then small[#small + 1] = current else small = nil end
          end
          local cx, cy = current % World.w, math.floor(current / World.w)
          for _, d in ipairs(DIRS) do
            local nx, ny = cx + d[1], cy + d[2]
            if World.inMap(nx, ny) then
              local ni = idx(nx, ny)
              if not visited[ni] and canWalk(ni) then
                visited[ni] = true
                queue[#queue + 1] = ni
              end
            end
          end
        end
        if not hasStart then
          if small and count <= 64 then
            for _, tileIndex in ipairs(small) do
              World.tiles[tileIndex] = "ocean"
              World.zone[tileIndex] = nil
              pruned = pruned + 1
            end
          else
            largeOrphans = largeOrphans + 1
          end
        end
      end
    end
  end
  World.prunedLandSpecks = pruned
  World.disconnectedLandmasses = largeOrphans
  if largeOrphans > 0 then
    Engine.warn('Map "giant_world" has ' .. largeOrphans .. ' disconnected major landmass(es); add or repair a bridge link.', false)
  end
end

local function buildCapitalFortress()
  -- Castle geometry is authored in a compact local coordinate sketch, then
  -- expanded into crisp 3x3 tile blocks for the giant global world.
  local rawSet, rawTrace = set, traceLink
  local function cityX(x) return 36 + x * 3 end
  local function cityY(y) return 743 + (y - 48) * 3 end
  local capitalZone = Get("Region", "wz_40") or World.manor
  local function set(x, y, tile)
    local gx, gy = cityX(x), cityY(y)
    for oy = 0, 2 do
      for ox = 0, 2 do
        local tx, ty = gx + ox, gy + oy
        rawSet(tx, ty, tile)
        local zoneIndex = idx(tx, ty)
        if World.zone[zoneIndex] == nil then World.zone[zoneIndex] = capitalZone or World.road end
      end
    end
  end
  local function traceLink(x0, y0, x1, y1, tile, width, wavy, seed)
    rawTrace(cityX(x0), cityY(y0), cityX(x1), cityY(y1), tile, math.max(1, width * 3), wavy, seed)
  end
  -- Crownfall occupies six former world regions in a 2-by-3 district at the
  -- bottom-left of the atlas. The city follows an irregular coastline rather
  -- than inheriting six visible rectangular map edges.
  local cx, cy, rx, ry = 23.5, 83, 22.5, 34
  World.capitalX, World.capitalY = cityX(cx), cityY(cy)
  for y = 48, 118 do
    for x = 0, 47 do
      local nx, ny = (x - cx) / rx, (y - cy) / ry
      local wave = math.sin(x * 0.41 + y * 0.23) * 0.035 + math.cos(x * 0.17 - y * 0.31) * 0.025
      if nx * nx + ny * ny <= 1 + wave then
        -- Lived-in paving, with deterministic chips and scattered fallen stone.
        set(x, y, ((x * 7 + y * 11) % 29 == 0) and "capital_rubble" or "capital_floor")
      end
    end
  end
  -- A worn, non-straight approach joins the starting square to the gate.
  -- This is paving through the city, not a bridge or a map transition.
  traceLink(12, 112, 23, 100, "capital_floor", 5, true, 3.7)

  -- Enormous curtain wall: repaired in places, broken in others. The southern
  -- gate aligns with the new city road and the player's starting area.
  local x0, y0, x1, y1 = 7, 60, 40, 101
  for x = x0, x1 do
    if x < 11 or x > 14 then set(x, y0, "capital_wall") end
    if x ~= 23 and x ~= 24 and x ~= 31 then set(x, y1, "capital_wall") end
  end
  for y = y0, y1 do
    if y < 72 or y > 75 then set(x0, y, "capital_wall") end
    if y < 80 or y > 83 then set(x1, y, "capital_wall") end
  end
  -- The south gate remains usable. Side gates and collapsed wall gaps are rubble-lined.
  set(23, y1, "capital_gate") set(24, y1, "capital_gate")
  set(x0, 73, "capital_gate") set(x1, 81, "capital_gate")
  for _, p in ipairs({ {55,300}, {60,300}, {65,300}, {155,300}, {160,300}, {35,360}, {35,380}, {200,395}, {200,420}, {90,505}, {95,505}, {150,505} }) do
    set(p[1], p[2], "capital_rubble")
  end
  -- The spawn tile stays safe even when a procedural coastline cuts close to the oval's edge.
  set(12, 112, "capital_floor")

  -- The original castle keep stands inside: larger than the surrounding houses,
  -- with a split roofline, open great-hall gate and old stonework partly collapsed.
  local kx0, ky0, kx1, ky1 = 13, 67, 34, 85
  for y = ky0 + 1, ky1 - 1 do
    for x = kx0 + 1, kx1 - 1 do
      set(x, y, ((x * 5 + y * 13) % 31 == 0) and "capital_rubble" or "capital_floor")
    end
  end
  for x = kx0, kx1 do
    if x ~= 23 and x ~= 24 and x ~= 28 then set(x, ky0, "capital_wall") end
    if x ~= 23 and x ~= 24 then set(x, ky1, "capital_wall") end
  end
  for y = ky0, ky1 do
    if y ~= 73 then set(kx0, y, "capital_wall") end
    if y ~= 78 and y ~= 79 then set(kx1, y, "capital_wall") end
  end
  set(23, ky1, "capital_gate") set(24, ky1, "capital_gate")
  -- Upper tower and side-wing doors join the keep instead of making sealed rooms.
  set(18, ky0, "capital_gate") set(29, ky0, "capital_gate")
  set(kx0, 81, "capital_gate") set(kx1, 81, "capital_gate")
  set(kx0, 73, "capital_rubble") set(kx1, 78, "capital_rubble")

  -- Distinct ruined towers and reused wings, so the fortress reads as a complex
  -- rather than a plain box. Every enclosed building keeps an open entrance.
  for _, b in ipairs({ {15,62,20,66,18}, {27,62,32,66,29}, {10,73,12,81,11}, {35,72,37,81,36} }) do
    local bx0, by0, bx1, by1, door = b[1], b[2], b[3], b[4], b[5]
    for x = bx0, bx1 do set(x, by0, "capital_wall") if x ~= door then set(x, by1, "capital_wall") end end
    for y = by0, by1 do set(bx0, y, "capital_wall") set(bx1, y, "capital_wall") end
    set(door, by1, "capital_gate")
  end
  for _, p in ipairs({ {75,335}, {80,335}, {160,340}, {165,340}, {65,420}, {70,420}, {165,425}, {170,425}, {90,375}, {100,395}, {145,370}, {150,400}, {40,435}, {190,455}, {75,480}, {165,485} }) do
    set(p[1], p[2], "capital_rubble")
  end
end

local function carve(m, a, b)
  local x, y = World.center(a)
  local x1, y1 = World.center(b)
  local function toward(p, q) if p == q then return 0 elseif p < q then return 1 end return -1 end
  while x ~= x1 do
    for o = -1, 1 do if World.inMap(x, y + o) then set(x, y + o, m.road) end end
    x = x + toward(x, x1)
  end
  while y ~= y1 do
    for o = -1, 1 do if World.inMap(x + o, y) then set(x + o, y, m.road) end end
    y = y + toward(y, y1)
  end
end

local function stampLayout(owner, layout, legend, wall, ox, oy)
  for y, row in ipairs(layout) do
    for x = 1, #row do
      local ch = row:sub(x, x)
      if ch ~= " " then
        local tile = legend[ch]
        if not tile then Engine.warn(owner .. ': layout letter "' .. ch .. '" is not in the legend', true) end
        set(ox + x - 1, oy + y - 1, tile or wall)
      end
    end
  end
end

local function layoutSize(layout)
  local w = 0
  for _, row in ipairs(layout) do w = math.max(w, #row) end
  return w, #layout
end

local function regionsOf(ids, owner)
  local out = {}
  for _, id in ipairs(ids) do
    local r = Get("Region", id)
    if r then table.insert(out, r) else Engine.warn(owner .. ' lists region "' .. id .. '" but there is no Region with that name', true) end
  end
  return out
end

local function carveRoads(m, roads, owner)
  for _, pair in ipairs(roads) do
    local a, b = Get("Region", pair[1]), Get("Region", pair[2])
    if a and b then carve(m, a, b)
    else Engine.warn(owner .. ': road "' .. tostring(pair[1]) .. '" to "' .. tostring(pair[2]) .. '" - a region is missing', true) end
  end
end


-- Instant load: cache built tiles to save dir after first generation.
function World.cachePath(mapId)
  return "world_cache_" .. tostring(mapId or "giant_world") .. "_v12.bin"
end

function World.tryLoadCache(mapId)
  -- The painted world is millions of tiles. Expanding a cache into a Lua table
  -- is what ran the browser build out of memory. The mask stays packed instead.
  if mapId == "giant_world" then return false end
  local path = World.cachePath(mapId)
  local info = love.filesystem.getInfo(path)
  if not info then return false end
  local data = love.filesystem.read(path)
  if not data or #data < 16 then return false end
  -- format: "KYO1" + uint32 w + uint32 h + tiles as uint16 indices into id table
  if data:sub(1, 4) ~= "KYO1" then return false end
  local function u32(i)
    local a,b,c,d = data:byte(i, i+3)
    return a + b*256 + c*65536 + d*16777216
  end
  local ww, hh = u32(5), u32(9)
  if ww < 8 or hh < 8 or ww > 20000 or hh > 20000 then return false end
  local nIds = u32(13)
  local pos = 17
  local ids = {}
  for i = 1, nIds do
    local len = data:byte(pos); pos = pos + 1
    ids[i] = data:sub(pos, pos + len - 1); pos = pos + len
  end
  local idToTile = ids
  World.w, World.h = ww, hh
  World.tiles, World.zone = {}, {}
  local expected = ww * hh
  for i = 0, expected - 1 do
    if pos + 1 > #data then break end
    local lo, hi = data:byte(pos, pos+1)
    pos = pos + 2
    local idx = lo + hi * 256
    if idx > 0 and idToTile[idx] then
      World.tiles[i] = idToTile[idx]
    end
  end
  return true
end

function World.saveCache(mapId)
  if World._virtual or not World.w or not World.tiles then return end
  if World.w * World.h > 2000000 then return end
  local idList, idMap = {}, {}
  local function idOf(t)
    if not t then return 0 end
    local i = idMap[t]
    if i then return i end
    idList[#idList + 1] = t
    idMap[t] = #idList
    return #idList
  end
  local parts = { "KYO1" }
  local function putu32(n)
    n = math.floor(n) % 4294967296
    return string.char(n % 256, math.floor(n/256) % 256, math.floor(n/65536) % 256, math.floor(n/16777216) % 256)
  end
  parts[#parts + 1] = putu32(World.w)
  parts[#parts + 1] = putu32(World.h)
  -- first pass collect ids
  for i = 0, World.w * World.h - 1 do
    local t = World.tiles[i]
    if t then idOf(t) end
  end
  parts[#parts + 1] = putu32(#idList)
  for _, name in ipairs(idList) do
    parts[#parts + 1] = string.char(#name) .. name
  end
  local tileParts = {}
  for i = 0, World.w * World.h - 1 do
    local idx = idOf(World.tiles[i])
    tileParts[#tileParts + 1] = string.char(idx % 256, math.floor(idx / 256) % 256)
  end
  parts[#parts + 1] = table.concat(tileParts)
  local blob = table.concat(parts)
  love.filesystem.write(World.cachePath(mapId), blob)
end

-- Crownfall, the southwest castle. A walled city of houses, streets and a plaza.
-- The player wakes in one of the houses. No spirit is allowed to remain inside.
local CROWN = { x0 = 282, y0 = 4579, x1 = 446, y1 = 4703 }
local WAKE = { x = 353, y = 4668, w = 15, h = 13, bedX = 360, bedY = 4675, doorX = 360, doorY = 4680 }

function World.noteDressing()
  World.crownfall = { x = CROWN.x0, y = CROWN.y0, w = CROWN.x1 - CROWN.x0, h = CROWN.y1 - CROWN.y0, name = "Crownfall" }
  World.capitalX = math.floor((CROWN.x0 + CROWN.x1) / 2)
  World.capitalY = math.floor((CROWN.y0 + CROWN.y1) / 2)
  World.wakeHouse = { x = WAKE.bedX, y = WAKE.bedY, doorX = WAKE.doorX, doorY = WAKE.doorY + 2 }
  World.roadLines = World.roadLines or {}
end

function World.inHaven(x, y)
  local c = World.crownfall
  if not c then return false end
  x = math.floor((x or 0) + 0.5)
  y = math.floor((y or 0) + 0.5)
  return x >= c.x and x <= c.x + c.w and y >= c.y and y <= c.y + c.h
end

local function stampCrownfallCity(m)
  local x0, y0, x1, y1 = CROWN.x0, CROWN.y0, CROWN.x1, CROWN.y1
  local function paint(x, y, tile)
    if x >= 1 and y >= 1 and x < World.w - 1 and y < World.h - 1 then set(x, y, tile) end
  end
  -- Join the southwest castle to the continent with a broad, even causeway.
  local cx = math.floor((x0 + x1) / 2)
  local half = 16
  for y = y0 - 1, math.max(2, y0 - 1400), -1 do
    local landed = false
    if y < y0 - 10 then
      for x = cx - half, cx + half do
        local t = World.tileAt(x, y)
        if t and t ~= "ocean" and t ~= "shore" then landed = true break end
      end
    end
    for x = cx - half, cx + half do paint(x, y, "floor") end
    paint(cx - half - 1, y, "shore")
    paint(cx + half + 1, y, "shore")
    if landed then break end
  end
  local function house(hx, hy, hw, hh, doorX, doorY, wall)
    wall = wall or "wood_wall"
    for x = hx, hx + hw - 1 do
      paint(x, hy, wall)
      paint(x, hy + hh - 1, wall)
    end
    for y = hy, hy + hh - 1 do
      paint(hx, y, wall)
      paint(hx + hw - 1, y, wall)
    end
    for y = hy + 1, hy + hh - 2 do
      for x = hx + 1, hx + hw - 2 do paint(x, y, "capital_floor") end
    end
    paint(doorX, doorY, "capital_gate")
  end

  for y = y0, y1 do
    for x = x0, x1 do paint(x, y, "capital_floor") end
  end
  for x = x0, x1 do
    paint(x, y0, "stone_wall")
    paint(x, y1, "stone_wall")
  end
  for y = y0, y1 do
    paint(x0, y, "stone_wall")
    paint(x1, y, "stone_wall")
  end
  local midX = math.floor((x0 + x1) / 2)
  local midY = math.floor((y0 + y1) / 2)
  for o = -1, 1 do
    paint(midX + o, y0, "capital_gate")
    paint(midX + o, y1, "capital_gate")
    paint(x0, midY + o, "capital_gate")
    paint(x1, midY + o, "capital_gate")
  end

  local vxs, hys = {}, {}
  for x = x0 + 8, x1 - 8, 20 do vxs[#vxs + 1] = x end
  for y = y0 + 8, y1 - 8, 18 do hys[#hys + 1] = y end
  for _, x in ipairs(vxs) do
    for y = y0 + 1, y1 - 1 do paint(x, y, "road") paint(x + 1, y, "road") end
  end
  for _, y in ipairs(hys) do
    for x = x0 + 1, x1 - 1 do paint(x, y, "road") paint(x, y + 1, "road") end
  end

  local plaza = { x0 = 334, y0 = 4614, x1 = 400, y1 = 4664 }
  for iy = 1, #hys - 1 do
    for ix = 1, #vxs - 1 do
      local hx, hy = vxs[ix] + 4, hys[iy] + 4
      local hw, hh = 12, 9
      local cx, cy = hx + hw / 2, hy + hh / 2
      local inPlaza = cx >= plaza.x0 and cx <= plaza.x1 and cy >= plaza.y0 and cy <= plaza.y1
      local inWake = hx < WAKE.x + WAKE.w and hx + hw > WAKE.x and hy < WAKE.y + WAKE.h and hy + hh > WAKE.y
      if not inPlaza and not inWake and hx + hw < vxs[ix + 1] - 1 and hy + hh < hys[iy + 1] - 1 then
        house(hx, hy, hw, hh, hx + math.floor(hw / 2), hy + hh - 1)
      end
    end
  end

  -- The keep sits on the north side of the town. The wake house is last so streets cannot cut the bedroom.
  house(346, 4588, 36, 22, 364, 4609, "stone_wall")
  paint(364, 4596, "pool")
  house(WAKE.x, WAKE.y, WAKE.w, WAKE.h, WAKE.doorX, WAKE.doorY, "wood_wall")
  paint(WAKE.bedX, WAKE.bedY, "capital_floor")
  paint(WAKE.bedX, WAKE.bedY + 1, "capital_floor")
  -- Path from the bedroom door down to the south gate.
  for y = WAKE.doorY, y1 - 1 do paint(WAKE.doorX, y, y == WAKE.doorY and "capital_gate" or "capital_floor") end
  for o = -1, 1 do paint(midX + o, y1, "capital_gate") end
  -- A little lived-in scatter in the plaza. Rubble is still walkable.
  for _, p in ipairs({ {348, 4628}, {376, 4636}, {358, 4652}, {388, 4644} }) do
    paint(p[1], p[2], "capital_rubble")
  end

  if m.start then m.start[1], m.start[2] = WAKE.bedX, WAKE.bedY end
  World.manorX, World.manorY = WAKE.bedX, WAKE.bedY
  World.noteDressing()
end

local function landish(x, y)
  local t = World.tileAt(x, y)
  return t and t ~= "ocean"
end

local function snapLand(x, y)
  if landish(x, y) then return x, y end
  for r = 2, 48, 2 do
    for a = 0, 7 do
      local px = x + math.floor(math.cos(a) * r)
      local py = y + math.floor(math.sin(a) * r)
      if landish(px, py) then return px, py end
    end
  end
  return nil
end

local function landRatio(x0, y0, x1, y1)
  local steps = math.max(1, math.max(math.abs(x1 - x0), math.abs(y1 - y0)))
  local hop = math.max(4, math.floor(steps / 80))
  local land, n = 0, 0
  for i = 0, steps, hop do
    local t = i / steps
    local x = math.floor(x0 + (x1 - x0) * t + 0.5)
    local y = math.floor(y0 + (y1 - y0) * t + 0.5)
    n = n + 1
    if landish(x, y) then land = land + 1 end
  end
  return land / math.max(1, n)
end

function World.refreshRoads(paint)
  local hubs = {
    { "Crownfall", 364, 4710 },
    { "Southmere", 1800, 4800 },
    { "Starfall", 2700, 4450 },
    { "Mire Sea", 1750, 3270 },
    { "Whisper Isles", 1120, 2200 },
    { "Northwatch", 2100, 1200 },
    { "Silver Coast", 370, 1150 },
    { "Verdant", 2650, 1950 },
    { "Willow Creek", 3200, 2100 },
    { "Goldroad", 4400, 1450 },
    { "Hollow Reach", 3320, 3050 },
    { "Dusk Corridor", 3650, 3770 },
    { "Stoneford", 4100, 3500 },
    { "Eastgate", 5200, 2400 },
    { "Rift Marches", 5170, 3300 },
    { "Ember Spine", 6150, 2070 },
  }
  local pts = {}
  for _, h in ipairs(hubs) do
    local x, y = snapLand(h[2], h[3])
    if x then pts[#pts + 1] = { name = h[1], x = x, y = y } end
  end
  local lines = {}
  local used = {}
  local function link(a, b)
    local key = a.name .. ">" .. b.name
    local rev = b.name .. ">" .. a.name
    if used[key] or used[rev] then return end
    if landRatio(a.x, a.y, b.x, b.y) < 0.62 then return end
    used[key] = true
    lines[#lines + 1] = { a.x, a.y, b.x, b.y, a.name, b.name }
    if paint then
      local x, y, guard = a.x, a.y, 0
      local x1, y1 = b.x, b.y
      local dx, dy = x1 - x, y1 - y
      local sx, sy = dx >= 0 and 1 or -1, dy >= 0 and 1 or -1
      local total = math.max(1, math.abs(dx) + math.abs(dy))
      while true do
        for o = -1, 1 do
          local px, py = x, y + o
          if math.abs(dx) < math.abs(dy) then px, py = x + o, y end
          local tile = World.tileAt(px, py)
          if tile and tile ~= "ocean" and tile ~= "capital_wall" and tile ~= "capital_gate"
            and tile ~= "stone_wall" and tile ~= "wood_wall" and tile ~= "ruin_wall" then
            set(px, py, "highway")
          end
        end
        if x == x1 and y == y1 then break end
        local remainX, remainY = math.abs(x1 - x), math.abs(y1 - y)
        if remainX > 0 and remainY > 0 then
          if (guard % 2 == 0 and remainX >= remainY) or remainX > remainY then x = x + sx
          else y = y + sy end
        elseif remainX > 0 then x = x + sx
        else y = y + sy end
        guard = guard + 1
        if guard > total * 3 + 20 then break end
      end
    end
  end
  -- Minimum spanning tree on land-connected hubs, then a few extra local roads.
  if #pts > 1 then
    local inTree = { [1] = true }
    local count = 1
    while count < #pts do
      local best, bi, bj, bd = nil, nil, nil, 1e18
      for i = 1, #pts do
        if inTree[i] then
          for j = 1, #pts do
            if not inTree[j] then
              local dx, dy = pts[i].x - pts[j].x, pts[i].y - pts[j].y
              local d = dx * dx + dy * dy
              if d < bd and landRatio(pts[i].x, pts[i].y, pts[j].x, pts[j].y) >= 0.62 then
                best, bi, bj, bd = d, i, j, d
              end
            end
          end
        end
      end
      if not bj then break end
      inTree[bj] = true
      count = count + 1
      link(pts[bi], pts[bj])
    end
    for i = 1, #pts do
      local bestJ, bestD = nil, 1e18
      for j = 1, #pts do
        if i ~= j then
          local dx, dy = pts[i].x - pts[j].x, pts[i].y - pts[j].y
          local d = dx * dx + dy * dy
          if d < bestD and d < 900 * 900 then bestJ, bestD = j, d end
        end
      end
      if bestJ then link(pts[i], pts[bestJ]) end
    end
  end
  World.roadLines = lines
  World.roadHubs = pts
end

-- Crownfall keep, painted on the rebuilt overview so the manor spawn stays walled and walkable.
local function stampCrownfallKeep(m)
  stampCrownfallCity(m)
  World.refreshRoads(true)
end

function World.smoothCoasts()
  local w, h = World.w, World.h
  local tiles = World.tiles
  if not w or not tiles then return end
  local function ocean(t) return t == "ocean" end
  local function solid(t) return t and t ~= "ocean" and t ~= "shore" end
  for pass = 1, 2 do
    local kill, fill = {}, {}
    for y = 2, h - 3 do
      local row = y * w
      for x = 2, w - 3 do
        local t = tiles[row + x]
        if t and not ocean(t) then
          local o, i = 0, row + x
          if ocean(tiles[i + 1]) then o = o + 1 end
          if ocean(tiles[i - 1]) then o = o + 1 end
          if ocean(tiles[i + w]) then o = o + 1 end
          if ocean(tiles[i - w]) then o = o + 1 end
          if o >= 3 then kill[#kill + 1] = i end
        elseif ocean(t) then
          local n, i = 0, row + x
          if solid(tiles[i + 1]) then n = n + 1 end
          if solid(tiles[i - 1]) then n = n + 1 end
          if solid(tiles[i + w]) then n = n + 1 end
          if solid(tiles[i - w]) then n = n + 1 end
          if n >= 3 then fill[#fill + 1] = i end
        end
      end
    end
    for _, i in ipairs(kill) do
      local t = tiles[i]
      if t ~= "capital_wall" and t ~= "capital_gate" and t ~= "capital_floor" then tiles[i] = "ocean" end
    end
    for _, i in ipairs(fill) do tiles[i] = "floor" end
  end
end

function World.stampHamlets(m)
  local rng = love.math.newRandomGenerator((m and m.seed) or 47)
  local made = 0
  local function land(x, y)
    local t = World.tileAt(x, y)
    return t == "floor" or t == "grass_tuft" or t == "shore" or t == "bone"
  end
  for _ = 1, 220 do
    if made >= 18 then break end
    local x = rng:random(40, World.w - 50)
    local y = rng:random(40, World.h - 50)
    local hw, hh = 8, 6
    local ok = not (x > 260 and x < 470 and y > 4550 and y < 4720)
    if ok then
      for iy = 0, hh - 1 do
        for ix = 0, hw - 1 do
          if not land(x + ix, y + iy) then ok = false break end
        end
        if not ok then break end
      end
    end
    if ok then
      for iy = 0, hh - 1 do
        for ix = 0, hw - 1 do
          local edge = ix == 0 or iy == 0 or ix == hw - 1 or iy == hh - 1
          local door = iy == hh - 1 and ix == math.floor(hw / 2)
          if door then set(x + ix, y + iy, "capital_gate")
          elseif edge then set(x + ix, y + iy, "wood_wall")
          else set(x + ix, y + iy, "camp_floor") end
        end
      end
      made = made + 1
    end
  end
end

-- MAP_OVERVIEW_REBUILT.png baked to assets/map/overview_mask.bin (1 pixel = 8 tiles).
-- 0 = ocean, 1..127 = land floor, 128+ = shore. Region ids live in overview_regions.lua.
function World.applyRebuiltOverview(m)
  if not World.prepareMask() then return false end
  if World._virtual then
    World.stampHamlets(m)
    stampCrownfallKeep(m)
    if WorldDress and WorldDress.stamp then WorldDress.stamp() end
    return true
  end
  local data = World._mask
  local pw, ph, scale = World._maskW, World._maskH, World._maskScale
  local floorTile = (m and m.floor) or "floor"
  local base = World._maskBase or 10
  local i = 0
  for py = 0, ph - 1 do
    local y0 = py * scale
    for px = 0, pw - 1 do
      local b = data:byte(base + i)
      i = i + 1
      if b and b > 0 then
        local tile = b >= 128 and "shore" or floorTile
        local x0 = px * scale
        for oy = 0, scale - 1 do
          local ty = y0 + oy
          if ty > 0 and ty < World.h - 1 then
            local row = ty * World.w
            for ox = 0, scale - 1 do
              local tx = x0 + ox
              if tx > 0 and tx < World.w - 1 then World.tiles[row + tx] = tile end
            end
          end
        end
      end
    end
  end
  World.smoothCoasts()
  World.stampHamlets(m)
  stampCrownfallKeep(m)
  return true
end

function World.build(mapId)
  if mapId == "giant_world" and World.tryLoadCache and World.tryLoadCache(mapId) then
    local m = Get("Map", mapId)
    if not m then Engine.fail('No Map "' .. tostring(mapId) .. '"') return end
    World.map = m
    World.regions = {}
    for _, id in ipairs(m.regions or {}) do
      local r = Get("Region", id)
      if r then
        World.regions[#World.regions + 1] = r
        for y = r.y, r.y + r.h - 1 do
          for x = r.x, r.x + r.w - 1 do
            if World.inMap(x, y) then World.zone[y * World.w + x] = r end
          end
        end
      end
    end
    local manor = nil
    for _, r in ipairs(World.regions) do
      if r.id == "crownfall" or (r.name and string.find(string.lower(r.name), "crown")) then manor = r break end
    end
    if m.start then World.manorX, World.manorY = m.start[1], m.start[2]
    elseif manor then
      World.manorX = manor.x + math.floor(manor.w / 2)
      World.manorY = manor.y + math.floor(manor.h / 2)
    else
      World.manorX, World.manorY = 1, 1
    end
    World.portals = World.portals or {}
    World.maxDist = World.maxDist or 500
    World.noteDressing()
    World.refreshRoads(false)
    if WorldLife and WorldLife.onWorld then WorldLife.onWorld() end
    Fire("world_built", World)
    return
  end
  -- In the seamless-world build, old save files and legacy calls that name a
  -- former region map are normalized to the one global map.
  if Settings.map == "giant_world" then mapId = "giant_world" end
  local m = Get("Map", mapId or S.map or Settings.map)
  if not m then
    Engine.warn("There is no Map called '" .. tostring(mapId or S.map or Settings.map) .. "'", true)
    m = All("Map")[1] or Define("Map", "fallback", { width = 20, height = 20, start = { 10, 10 } })
  end
  S.map = m.id
  local addons = {}
  for _, a in ipairs(All("MapAddon")) do if a.map == m.id then table.insert(addons, a) end end
  local baseRegions = regionsOf(m.regions, 'Map "' .. m.id .. '"')
  World.map, World.addons, World.regions = m, addons, {}
  for _, r in ipairs(baseRegions) do table.insert(World.regions, r) end
  for _, a in ipairs(addons) do
    for _, r in ipairs(regionsOf(a.regions, 'MapAddon "' .. a.id .. '"')) do table.insert(World.regions, r) end
  end

  local w, h = m.width, m.height
  if #m.layout > 0 then w, h = layoutSize(m.layout) end
  for _, r in ipairs(World.regions) do w, h = math.max(w, r.x + r.w + 1), math.max(h, r.y + r.h + 1) end
  for _, a in ipairs(addons) do
    if #a.layout > 0 then
      local lw, lh = layoutSize(a.layout)
      w, h = math.max(w, a.at[1] + lw), math.max(h, a.at[2] + lh)
    end
  end
  World.w, World.h = w, h
  World._tintCache = {}
  World._virtual = false
  World.zone = {}
  if m.id == "giant_world" and World.prepareMask() then
    World.installVirtualTiles()
  else
    World.tiles = {}
    local cells = w * h
    if cells > 0 and cells <= 2500000 then
      for i = 0, cells - 1 do World.tiles[i] = m.wall end
    end
  end
  World.road = { id = "road", name = m.roadName, tint = m.roadTint, spawns = m.roadSpawns, levels = m.roadLevels,
    maxGhosts = m.roadMaxGhosts, enemies = m.roadEnemies, maxEnemies = m.roadMaxEnemies }

  -- Rebuilt painted map wins over the old rectangle coastlines.
  World._fromOverview = false
  if m.id == "giant_world" and #m.layout == 0 and World.applyRebuiltOverview then
    World._fromOverview = World.applyRebuiltOverview(m) and true or false
  end

  if not World._fromOverview then
  if #m.layout > 0 then
    stampLayout('Map "' .. m.id .. '"', m.layout, m.legend, m.wall, 0, 0)
  else
    for _, r in ipairs(baseRegions) do
      if m.id == "giant_world" then stampNaturalRegion(m, r) else stamp(m, r) end
    end
    if m.id ~= "giant_world" then
      carveRoads(m, m.roads, 'Map "' .. m.id .. '"')
    end
    if #World.regions == 0 then for y = 1, h - 2 do for x = 1, w - 2 do set(x, y, m.floor) end end end
  end
  for _, a in ipairs(addons) do
    for _, r in ipairs(regionsOf(a.regions, a.id)) do
      if m.id == "giant_world" then stampNaturalRegion(m, r) else stamp(m, r) end
    end
    if m.id ~= "giant_world" then carveRoads(m, a.roads, 'MapAddon "' .. a.id .. '"') end
    if #a.layout > 0 then
      local legend = next(a.legend) and a.legend or m.legend
      stampLayout('MapAddon "' .. a.id .. '"', a.layout, legend, m.wall, a.at[1], a.at[2])
    end
  end
  if m.id == "giant_world" then
    stampContinentMasks(m)
    connectNearbyLand(World.regions, m)
    carveBridgeLinks(m, World.regions)
  end
  end

  if not World._virtual then
  for _, r in ipairs(World.regions) do
    for y = r.y, r.y + r.h - 1 do
      for x = r.x, r.x + r.w - 1 do if inside(x, y) then World.zone[idx(x, y)] = r end end
    end
  end
  end

  -- CONTINUOUS OVERWORLD: remove inter-region walls/bridges.
  -- Every interior wall tile becomes walkable floor; zone = nearest region (biome blend).
  local function nearestRegion(tx, ty)
    local best, bd = nil, 1e18
    for _, r in ipairs(World.regions) do
      local cx, cy = r.x + r.w / 2, r.y + r.h / 2
      -- distance to region AABB (0 if inside)
      local dx = 0
      if tx < r.x then dx = r.x - tx elseif tx >= r.x + r.w then dx = tx - (r.x + r.w - 1) end
      local dy = 0
      if ty < r.y then dy = r.y - ty elseif ty >= r.y + r.h then dy = ty - (r.y + r.h - 1) end
      local d = dx * dx + dy * dy
      if d < bd then bd, best = d, r end
    end
    return best
  end

  -- Manor anchor (bottom-left hub) for distance scaling + respawn
  local manor = nil
  if m.id == "giant_world" then
    for _, r in ipairs(World.regions) do if r.id == "wz_40" or r.biome == "capital" then manor = r break end end
  end
  if not manor then
    for _, r in ipairs(World.regions) do
      if r.id == "manor_heart" or (r.biome == "manor") then manor = r break end
    end
  end
  if not manor and #World.regions > 0 then
    -- southernmost-westernmost region as hub
    for _, r in ipairs(World.regions) do
      if not manor or (r.y + r.h > manor.y + manor.h) or (r.y + r.h == manor.y + manor.h and r.x < manor.x) then
        manor = r
      end
    end
  end
  World.manor = manor
  if m.id == "giant_world" and m.start then
    World.manorX, World.manorY = m.start[1], m.start[2]
  elseif manor then
    World.manorX = manor.x + math.floor(manor.w / 2)
    World.manorY = manor.y + math.floor(manor.h / 2)
  else
    World.manorX, World.manorY = 1, h - 2
  end
  -- Measure progression against the outer edge of the populated land, not empty ocean corners.
  local maxd = 1
  for _, r in ipairs(World.regions) do
    for _, c in ipairs({ {r.x, r.y}, {r.x+r.w-1, r.y}, {r.x, r.y+r.h-1}, {r.x+r.w-1, r.y+r.h-1} }) do
      local dx, dy = c[1] - World.manorX, c[2] - World.manorY
      maxd = math.max(maxd, math.sqrt(dx * dx + dy * dy))
    end
  end
  World.maxDist = maxd

  if not World._virtual then
  for y = 1, h - 2 do
    for x = 1, w - 2 do
      local t = World.tiles[idx(x, y)]
      if t == m.wall or t == nil then
        set(x, y, m.id == "giant_world" and "ocean" or m.floor)
      end
      -- Empty ocean needs no biome ownership. Assign fallback zones only to
      -- walkable land/causeways, keeping giant-world startup proportional to
      -- the actual land area rather than every water tile on the whole map.
      local ti = idx(x, y)
      if not World.zone[ti] and World.tiles[ti] ~= "ocean" then
        World.zone[ti] = nearestRegion(x, y) or World.road
      end
    end
  end

  local rng = love.math.newRandomGenerator(m.seed)
  for y = 0, h - 1 do
    for x = 0, w - 1 do
      if World.tiles[idx(x, y)] == m.floor then
        local n, acc = rng:random() * 100, 0
        local zone = World.zone[idx(x, y)]
        local list = (zone and zone.scatter and #zone.scatter > 0) and zone.scatter or m.scatter
        for _, s in ipairs(list) do
          acc = acc + s[2]
          if n < acc then World.tiles[idx(x, y)] = s[1] break end
        end
      end
    end
  end

  -- The rebuilt overview already has coasts, rivers, and islands. Do not erode it back into blobs.
  if m.id == "giant_world" and not World._fromOverview then
    -- Pass 1: jagged erosion — convert land next to 2+ ocean neighbors with noise
    for pass = 1, 2 do
      local toOcean = {}
      for y = 2, h - 3 do
        for x = 2, w - 3 do
          local t = World.tiles[idx(x, y)]
          if t == m.floor or t == "shore" then
            local oceans = 0
            for _, d in ipairs(DIRS) do
              if World.tiles[idx(x + d[1], y + d[2])] == "ocean" then oceans = oceans + 1 end
            end
            local noise = math.sin(x * 0.37 + y * 0.29) + math.cos(x * 0.13 - y * 0.21)
            if oceans >= 3 or (oceans >= 2 and noise > 0.35) then
              toOcean[#toOcean + 1] = { x, y }
            end
          end
        end
      end
      for _, p in ipairs(toOcean) do set(p[1], p[2], "ocean") end
    end
    -- Pass 2: shore band (including diagonal ocean contact)
    for y = 1, h - 2 do
      for x = 1, w - 2 do
        local t = World.tiles[idx(x, y)]
        if t == m.floor then
          local nearOcean = false
          for dy = -1, 1 do
            for dx = -1, 1 do
              if not (dx == 0 and dy == 0) and World.tiles[idx(x + dx, y + dy)] == "ocean" then
                nearOcean = true
              end
            end
          end
          if nearOcean then set(x, y, "shore") end
        end
      end
    end
    -- Pass 3: inland variety — scatter bone / grass_tuft / road-ish features
    local floor = m.floor or "floor"
    for y = 3, h - 4, 3 do
      for x = 3, w - 4, 3 do
        if World.tiles[idx(x, y)] == floor then
          local n = math.sin(x * 0.17 + y * 0.23) * math.cos(x * 0.09 - y * 0.11)
          if n > 0.72 and Get("Tile", "grass_tuft") then set(x, y, "grass_tuft")
          elseif n < -0.78 and Get("Tile", "bone") then set(x, y, "bone")
          elseif math.abs(n) < 0.04 and Get("Tile", "road") and love.math.random(1, 100) <= 8 then
            set(x, y, "road")
          end
        end
      end
    end
    buildCapitalFortress()
    pruneDisconnectedLandSpecks(m)
  end
  end

  -- Biome floor colours are blended at render time so area boundaries are not box-shaped.
  World.portals = {}
  for _, p in ipairs(All("Portal")) do
    if m.id ~= "giant_world" and p.map == m.id then
      if not World.walkable(p.x, p.y) then set(p.x, p.y, m.floor) end
      table.insert(World.portals, p)
    end
  end
  if m and m.id == "giant_world" and World.saveCache then pcall(World.saveCache, m.id) end
  if WorldLife and WorldLife.onWorld then WorldLife.onWorld() end
  World._paintRev = (World._paintRev or 0) + 1
  Fire("world_built", World)
end

-- Cached per-tile terrain colors are shared by the live renderer and the atlas.
-- This makes neighboring biome tints blend into each other in both views, rather
-- than showing the rectangular region definitions as hard color blocks.
function World.tintAt(tx, ty)
  if not inside(tx, ty) then return "bg" end
  World._tintCache = World._tintCache or {}
  local tileIndex = idx(tx, ty)
  local cached = World._tintCache[tileIndex]
  if cached ~= nil then return cached end
  local t = Get("Tile", World.tiles[tileIndex])
  if not t then return "#ff00ff" end
  local region = World.regionAt(tx, ty)
  local tint = (t.color == "zone") and (region and region.tint or "bg") or t.color
  if t.color == "zone" and World.map and World.map.id == "giant_world" and region and ToColor then
    local cr, cg, cb, total = 0, 0, 0, 2.8
    local baseCol = ToColor(region.tint or "#2e332f")
    cr, cg, cb = baseCol[1] * total, baseCol[2] * total, baseCol[3] * total
    for _, other in ipairs(World.regions) do
      if other ~= region then
        local dx, dy = 0, 0
        if tx < other.x then dx = other.x - tx elseif tx >= other.x + other.w then dx = tx - (other.x + other.w - 1) end
        if ty < other.y then dy = other.y - ty elseif ty >= other.y + other.h then dy = ty - (other.y + other.h - 1) end
        local d = math.sqrt(dx * dx + dy * dy)
        if d < 5 then
          local weight = (5 - d) / 5 * 0.9
          local c = ToColor(other.tint or "#2e332f")
          cr, cg, cb, total = cr + c[1] * weight, cg + c[2] * weight, cb + c[3] * weight, total + weight
        end
      end
    end
    if total > 0 then tint = { cr / total, cg / total, cb / total, 1 } end
  end
  World._tintCache[tileIndex] = tint
  return tint
end

local TILE_TEX = {
  ocean = "assets/tiles/water_32.png",
  shore = "assets/tiles/sand_32.png",
  floor = "assets/tiles/grass_32.png",
  road = "assets/tiles/path_32.png",
  highway = "assets/tiles/path_32.png",
  capital_floor = "assets/tiles/stone_32.png",
  capital_wall = "assets/tiles/stone_wall.png",
  capital_gate = "assets/tiles/path_32.png",
  capital_rubble = "assets/tiles/dirt_32.png",
  wood_wall = "assets/tiles/wood_wall.png",
  stone_wall = "assets/tiles/stone_wall.png",
  camp_floor = "assets/tiles/dirt_32.png",
  campfire = "assets/tiles/campfire.png",
  ruin_wall = "assets/tiles/stone2_32.png",
  ruin_floor = "assets/tiles/dirt_32.png",
  forest_tree_a = "assets/tiles/grass2_32.png",
  forest_tree_b = "assets/tiles/grass3_32.png",
  mountain_cliff_a = "assets/tiles/cliff.png",
  mountain_cliff_b = "assets/tiles/cliff.png",
  mountain_path = "assets/tiles/path_32.png",
  bone = "assets/tiles/dirt_32.png",
  grass_tuft = "assets/tiles/grass2_32.png",
  pool = "assets/tiles/water2_32.png",
  moon_obelisk = "assets/tiles/monument_obelisk.png",
  bone_arch = "assets/tiles/monument_arch.png",
  bell_spire = "assets/tiles/monument_bell.png",
  wishing_well = "assets/tiles/monument_well.png",
  knight_statue = "assets/tiles/monument_statue.png",
  stone_cairn = "assets/tiles/monument_cairn.png",
  witch_pyre = "assets/tiles/monument_pyre.png",
  star_gate = "assets/tiles/monument_gate.png",
  raven_totem = "assets/tiles/monument_raven.png",
  moonwell = "assets/tiles/monument_moonwell.png",
  hanged_cage = "assets/tiles/monument_cage.png",
  sword_shrine = "assets/tiles/monument_sword.png",
  lantern_post = "assets/tiles/monument_lantern.png",
  bone_pile = "assets/tiles/monument_bones.png",
  witch_circle = "assets/tiles/monument_circle.png",
  crowned_pillar = "assets/tiles/monument_crown.png",
  ship_rib = "assets/tiles/monument_ship.png",
  blood_font = "assets/tiles/monument_font.png",
  owl_stone = "assets/tiles/monument_owl.png",
  clock_ruin = "assets/tiles/monument_clock.png",
}
local BIOME_TEX = {
  ice = "assets/tiles/snow.png", frost = "assets/tiles/snow.png",
  marsh = "assets/tiles/water2_32.png", tide = "assets/tiles/sand_32.png",
  ashen = "assets/tiles/dirt_32.png", fire = "assets/tiles/dirt_32.png",
  forest = "assets/tiles/grass2_32.png", verdant = "assets/tiles/grass3_32.png",
  coast = "assets/tiles/sand_32.png", mountain = "assets/tiles/stone_32.png",
  capital = "assets/tiles/stone_32.png", crypt = "assets/tiles/stone2_32.png",
  void = "assets/tiles/stone2_32.png", spirit = "assets/tiles/grass3_32.png",
}
local FLOOR_VARIANTS = {
  "assets/tiles/grass_32.png",
  "assets/tiles/grass2_32.png",
  "assets/tiles/grass3_32.png",
}

function World.drawTile(tx, ty, sx, sy, ts)
  ts = ts or Settings.tileSize
  local sc = ts / Settings.tileSize
  local fill = math.ceil(ts) + 1
  local id = World.tiles[idx(tx, ty)]
  local t = Get("Tile", id)
  if not t then Box(sx, sy, fill, fill, "#ff00ff") return end
  local path = TILE_TEX[id]
  if id == "floor" or id == "shore" or id == "grass_tuft" then
    local region = World.regionAt(tx, ty)
    local biome = region and region.biome
    if biome and BIOME_TEX[biome] then path = BIOME_TEX[biome]
    elseif id == "floor" then
      local n = (tx * 13 + ty * 7) % 3
      path = FLOOR_VARIANTS[n + 1]
    end
  end
  local img = path and LoadImage and LoadImage(path)
  if img then
    love.graphics.setColor(1, 1, 1, 1)
    local iw, ih = img:getWidth(), img:getHeight()
    love.graphics.draw(img, math.floor(sx), math.floor(sy), 0, fill / iw, fill / ih)
  else
    Box(sx, sy, fill, fill, World.tintAt(tx, ty))
    local px, py = (S and S.px) or tx, (S and S.py) or ty
    if math.abs(tx - px) + math.abs(ty - py) <= 14 then
      for _, d in ipairs(t.detail or {}) do
        Box(sx + d[1] * sc, sy + d[2] * sc, math.max(1, d[3] * sc), math.max(1, d[4] * sc), d[5])
      end
    end
  end
  if t.onDraw then t.onDraw(sx, sy, tx, ty) end
end

-- smooth movement: render positions slide toward grid positions
local function approach(r, t, spd)
  if not r then return t end
  local d = t - r
  if math.abs(d) > 3 or math.abs(d) <= spd then return t end
  return r + (d > 0 and spd or -spd)
end

function World.animate()
  local spd = Settings.moveSpeed
  S.rx, S.ry = approach(S.rx, S.px, spd), approach(S.ry, S.py, spd)
  for _, list in ipairs({ S.wilds, S.npcs }) do
    for _, e in ipairs(list) do
      if OnScreen(e.x, e.y) then
        e.rx, e.ry = approach(e.rx, e.x, spd * 0.7), approach(e.ry, e.y, spd * 0.7)
      else
        e.rx, e.ry = e.x, e.y
      end
    end
  end
  for i = 1, ((EffectivePartySize and EffectivePartySize()) or Settings.partySize or 6) do
    local slot = S.followers[i + 1] or { S.px - i, S.py }
    local f = S.fpos[i] or { slot[1], slot[2] }
    f[1], f[2] = approach(f[1], slot[1], spd), approach(f[2], slot[2], spd)
    S.fpos[i] = f
  end
  if TownCompanionAnimate then TownCompanionAnimate() end
end

-- current world camera/zoom. View fills the whole canvas (to the screen edges).
-- Discrete zoom levels: index 1 = full zoom-out (default / base). + zooms in up to 4 steps.
-- Spawn range is unaffected (still Settings.spawnRange).
World.ZOOM_LEVELS = { 1, 1.25, 1.55, 1.9, 2.35 } -- 1 = base. Wider than this flooded the frame with tiles.

function World.zoomLevelCount()
  return #(World.ZOOM_LEVELS or { 0.5 })
end

function World.ensureZoom()
  if not S then return 1 end
  if not S.zoomIndex then
    -- Map legacy continuous zoom onto nearest discrete level; default base (1)
    local z = S.zoom or World.ZOOM_LEVELS[1]
    local best, bd = 1, 1e9
    for i, v in ipairs(World.ZOOM_LEVELS) do
      local d = math.abs(v - z)
      if d < bd then best, bd = i, d end
    end
    S.zoomIndex = best
  end
  S.zoomIndex = Clamp(S.zoomIndex, 1, World.zoomLevelCount())
  S.zoom = World.ZOOM_LEVELS[S.zoomIndex]
  return S.zoom
end

function World.zoomIn()
  World.ensureZoom()
  if S.zoomIndex >= World.zoomLevelCount() then return false end
  S.zoomIndex = S.zoomIndex + 1
  S.zoom = World.ZOOM_LEVELS[S.zoomIndex]
  return true
end

function World.zoomOut()
  World.ensureZoom()
  if S.zoomIndex <= 1 then return false end
  S.zoomIndex = S.zoomIndex - 1
  S.zoom = World.ZOOM_LEVELS[S.zoomIndex]
  return true
end

function WorldScale()
  local c = World._cam
  if c then return c[3] end
  return (S and S.zoom) or World.ZOOM_LEVELS[1]
end

-- Sprites stay proportional to tiles at every zoom (same relative size as at base).
-- Never floor to 1 while tiles shrink — that made actors look giant when zoomed out.
function CharScale()
  local c = World._cam
  local ets = c and c[6] or ((Settings.tileSize or 16) * ((S and S.zoom) or 1))
  local mul = Settings.charScale or 1.35
  return math.max(0.45, (ets / (Settings.tileSize or 16)) * mul)
end

function WorldSpriteScale()
  local z = WorldScale() or World.ensureZoom()
  return math.max(1, z)
end

local function viewMetrics()
  local ts = Settings.tileSize
  local z = World.ensureZoom()
  -- Integer tile pixels. Fractional zoom was shrinking actors off the canvas.
  local ets = math.max(8, math.floor(ts * z + 0.5))
  return ts, ets / ts, ets, (Engine.W or 320) / ets, (Engine.H or 320) / ets
end

-- centre pixel of a tile on the canvas (zoom-aware; same answer inside or outside the world draw)
function WorldToScreen(x, y)
  local c = World._cam
  if not c then
    local ts = Settings.tileSize
    return math.floor((x - ((S.rx or S.px) - 9)) * ts + ts / 2 + 0.5), math.floor((y - ((S.ry or S.py) - 8)) * ts + ts / 2 + 0.5)
  end
  local camX, camY, ets = c[1], c[2], c[6]
  return math.floor((x - camX) * ets + ets / 2 + 0.5), math.floor((y - camY) * ets + ets / 2 + 0.5)
end

function OnScreen(x, y)
  local c = World._cam
  if not c then return math.abs(x - (S.px or 1)) <= 10 and math.abs(y - (S.py or 1)) <= 10 end
  return x >= c[1] - 1 and x < c[1] + c[4] + 1 and y >= c[2] - 1 and y < c[2] + c[5] + 1
end

local mapPaint = {}

local function drawCachedGround(camX, camY, ets, vw, vh)
  local margin = 12
  local reuse = mapPaint.canvas and mapPaint.ets == ets and mapPaint.rev == (World._paintRev or 0)
    and camX >= mapPaint.ox + 1 and camY >= mapPaint.oy + 1
    and camX + vw <= mapPaint.ox + mapPaint.tw - 1
    and camY + vh <= mapPaint.oy + mapPaint.th - 1
  if not reuse then
    local ox = math.floor(camX) - margin
    local oy = math.floor(camY) - margin
    local tw = math.ceil(vw) + margin * 2
    local th = math.ceil(vh) + margin * 2
    local cw, ch = math.max(1, tw * ets), math.max(1, th * ets)
    if not mapPaint.canvas or mapPaint.cw ~= cw or mapPaint.ch ~= ch then
      mapPaint.canvas = love.graphics.newCanvas(cw, ch)
      mapPaint.canvas:setFilter("nearest", "nearest")
      mapPaint.cw, mapPaint.ch = cw, ch
    end
    local prev = love.graphics.getCanvas()
    love.graphics.push()
    love.graphics.origin()
    love.graphics.setCanvas(mapPaint.canvas)
    love.graphics.clear(0, 0, 0, 0)
    for ty = 0, th - 1 do
      for tx = 0, tw - 1 do
        local wx, wy = ox + tx, oy + ty
        local sx, sy = tx * ets, ty * ets
        if World.inMap(wx, wy) then World.drawTile(wx, wy, sx, sy, ets)
        else Box(sx, sy, ets + 1, ets + 1, "bg") end
      end
    end
    love.graphics.setCanvas(prev)
    love.graphics.pop()
    mapPaint.ox, mapPaint.oy, mapPaint.tw, mapPaint.th = ox, oy, tw, th
    mapPaint.ets, mapPaint.rev = ets, World._paintRev or 0
  end
  love.graphics.setColor(1, 1, 1, 1)
  love.graphics.draw(mapPaint.canvas, math.floor((mapPaint.ox - camX) * ets + 0.5), math.floor((mapPaint.oy - camY) * ets + 0.5))
end

local function drawWorldInner()
  local ts, z, ets, vw, vh = viewMetrics()
  -- Keep actors proportional to tile size at every zoom (relative to base zoom proportions).
  local zs = WorldSpriteScale()
  local cs = CharScale()
  local camX = (S.rx or S.px) - vw / 2 + 0.5
  local camY = (S.ry or S.py) - vh / 2 + 0.5
  World._cam = { camX, camY, z, vw, vh, ets }
  if S.shake and S.shake > 0 then
    local s = math.min(2, S.shake * 0.35)
    love.graphics.translate(((S.t or 0) % 2 == 1) and s or -s, (math.floor((S.t or 0) / 2) % 2 == 1) and s * 0.5 or -s * 0.5)
  end
  drawCachedGround(camX, camY, ets, vw, vh)
  if S.quest and S.quest.x then
    local cx, cy = WorldToScreen(S.quest.x, S.quest.y)
    DrawSpriteAt("quest_flag", cx, cy, zs)
  end
  if Stories and Stories.marker then
    local sx, sy = Stories.marker()
    if sx and not (S.quest and S.quest.x == sx and S.quest.y == sy) then
      local cx, cy = WorldToScreen(sx, sy)
      DrawSpriteAt("quest_flag", cx, cy + 6, zs)
    end
  end
  local list = {}
  for _, w in ipairs(S.wilds) do
    if OnScreen(w.x, w.y) then
      table.insert(list, { w.ry, function()
        local cx, cy = WorldToScreen(w.rx, w.ry)
        DrawGhostAt(w.ghost, cx, cy + math.floor(math.sin((S.t + w.bob * 7) / 12) * 1.5 + 0.5), zs, w.bob)
      end })
    end
  end
  for _, n in ipairs(S.npcs) do
    if OnScreen(n.x, n.y) then
      local def = Get("Enemy", n.enemy)
      if def then table.insert(list, { n.ry, function()
        local cx, cy = WorldToScreen(n.rx, n.ry)
        local frame = math.floor(((S.t or 0) / 8) + (n.uid or 0)) % 4
        if n.layers and Sheets and Sheets.draw and Sheets.draw(n.layers, cx, cy, zs, 0, frame) then return end
        if not n.layers and Sheets and Sheets.fromId then
          n.layers = Sheets.fromId("skeleton", n.uid or n.enemy, "ghoul", n.enemy == "skeleton_knight" and "eclipse" or "faded")
          if Sheets.draw(n.layers, cx, cy, zs, 0, frame) then return end
        end
        DrawSpriteAt(def.sprite, cx, cy, zs)
      end }) end
    end
  end
  for _, def in ipairs(AllPlaces()) do
    if OnScreen(def.x, def.y) then
      table.insert(list, { def.y + (def.kind == "Boss" and Settings.bossTiles - 1 or 0) + 0.02, function() DrawPlace(def) end })
    end
  end
  for i = 1, ((EffectivePartySize and EffectivePartySize()) or Settings.partySize or 6) do
    local g, f = S.party[i], S.fpos[i]
    if g and f then
      table.insert(list, { f[2] - 0.01, function()
        local cx, cy = WorldToScreen(f[1], f[2])
        -- Followers use the same fixed world-sprite footprint at every level.
        DrawGhostAt(g, cx, cy, zs, i * 3)
      end })
    end
  end
  if S.armoredSkeletons then
    for _, sk in ipairs(S.armoredSkeletons) do
      table.insert(list, { sk.y + 0.04, function()
        local cx, cy = WorldToScreen(sk.x, sk.y)
        Box(cx - 8 * zs, cy - 14 * zs, 16 * zs, 20 * zs, "dim")
        Frame(cx - 8 * zs, cy - 14 * zs, 16 * zs, 20 * zs, "blood")
        Text("SK", cx - 7 * zs, cy - 2 * zs, "ink", 8)
      end })
    end
  end
  local wb = WorldBoss and WorldBoss.active and WorldBoss.active()
  if wb then
    table.insert(list, { wb.y + 0.05, function()
      local cx, cy = WorldToScreen(wb.x, wb.y)
      local frame = math.floor((S.t or 0) / 8) % 4
      if wb.layers and Sheets and Sheets.draw and Sheets.draw(wb.layers, cx, cy, zs * 1.35, 0, frame) then
        Text(Upper(wb.name or "BOSS"), cx - 28, cy - 36 * zs, "blood", 8)
        return
      end
      Box(cx - 10 * zs, cy - 18 * zs, 20 * zs, 28 * zs, "blood")
      Frame(cx - 10 * zs, cy - 18 * zs, 20 * zs, 28 * zs, "kyo")
      Text("WB", cx - 8 * zs, cy - 4 * zs, "ink", 8)
    end })
  end
  if S.roamCamps then
    for _, c in ipairs(S.roamCamps) do
      if not c.triggered and OnScreen(c.x, c.y) then
        table.insert(list, { c.y + 0.03, function()
          local cx, cy = WorldToScreen(c.x, c.y)
          local look = c.layers
          if look and Sheets and Sheets.draw then Sheets.draw(look, cx, cy, zs, 0, 0) end
          Text("CAMP", cx - 14, cy - 16, "blood", 8)
        end })
      end
    end
  end
  table.insert(list, { S.ry + 0.01, function() local cx, cy = WorldToScreen(S.rx, S.ry) DrawPlayerAt(cx, cy, cs) end })
  table.sort(list, function(a, b) return a[1] < b[1] end)
  for _, item in ipairs(list) do item[2]() end
  if DrawTownCompanions then DrawTownCompanions() end
  if Camp and Camp.draw then Camp.draw() end
  if ResourceNodes and ResourceNodes.draw then ResourceNodes.draw() end
  -- Lightweight, cosmetic weather. It uses no assets and draws only a small
  -- fixed particle budget, so it remains inexpensive on lower-end devices.
  local weather = (S and S.weather) or "clear"
  if weather ~= "clear" and weather ~= "off" then
    local count = weather == "rain" and 34 or (weather == "snow" and 20 or (weather == "embers" and 12 or 10))
    local ww, wh = Engine.W, Engine.H
    for i = 1, count do
      local seed = i * 37
      local px = (seed * 17 + math.floor((S.t or 0) * (weather == "rain" and 2.8 or 0.35))) % ww
      local py = (seed * 29 + math.floor((S.t or 0) * (weather == "rain" and 5 or 0.7))) % wh
      if weather == "rain" then
        love.graphics.setColor(0.58, 0.76, 0.94, 0.30)
        love.graphics.line(px, py, px - 2, py + 5)
      elseif weather == "snow" then
        love.graphics.setColor(0.88, 0.94, 1, 0.65)
        love.graphics.rectangle("fill", px, py, 2, 2)
      elseif weather == "embers" then
        love.graphics.setColor(1, 0.53, 0.22, 0.48)
        love.graphics.rectangle("fill", px, py, 2, 2)
      else
        love.graphics.setColor(0.68, 0.72, 0.86, 0.10)
        love.graphics.rectangle("fill", px, py, 12, 5)
      end
    end
    love.graphics.setColor(1, 1, 1, 1)
  end
  Fire("draw_world", { camX = camX, camY = camY })
end

function DrawWorld()
  love.graphics.push()
  local ok, err = pcall(drawWorldInner)
  love.graphics.pop()
  if not ok then error(err, 0) end
end

function World.emptyNear(x, y, range, minDist)
  -- Player coordinates are continuous. Sampling from a float index never hits a
  -- real tile, which made resource nodes (and some spawns) fail to appear.
  x = math.floor((x or 0) + 0.5)
  y = math.floor((y or 0) + 0.5)
  local spots = {}
  range, minDist = range or 6, minDist or 3
  for dy = -range, range do
    for dx = -range, range do
      local nx, ny = x + dx, y + dy
      if World.walkable(nx, ny) and math.abs(dx) + math.abs(dy) >= minDist and not WildAt(nx, ny)
        and not NpcAt(nx, ny) and not PortalAt(nx, ny) and not PlaceAt(nx, ny) and not (nx == x and ny == y) then
        table.insert(spots, { nx, ny })
      end
    end
  end
  return spots
end

function World.nextToward(tx, ty)
  local function key(x, y) return x .. "," .. y end
  local prev = { [key(S.px, S.py)] = false }
  local q, i = { { S.px, S.py } }, 1
  while i <= #q and i <= 900 do
    local x, y = q[i][1], q[i][2]
    if x == tx and y == ty then break end
    for _, d in ipairs(DIRS) do
      local nx, ny = x + d[1], y + d[2]
      if World.walkable(nx, ny) and prev[key(nx, ny)] == nil then
        prev[key(nx, ny)] = { x, y }
        table.insert(q, { nx, ny })
      end
    end
    i = i + 1
  end
  if not prev[key(tx, ty)] then return nil end
  local cur = { tx, ty }
  while true do
    local p = prev[key(cur[1], cur[2])]
    if not p then return nil end
    if p[1] == S.px and p[2] == S.py then return cur[1] - S.px, cur[2] - S.py end
    cur = p
  end
end
