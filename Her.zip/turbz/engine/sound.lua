-- Play "step"  -> builds a beep from a Sound file, or plays Sound.file if you gave one
local cache = {}

function Engine.clearSounds() cache = {} end

local function wave(kind, phase)
  if kind == "sine" then return math.sin(phase * 2 * math.pi) end
  if kind == "saw" then return 2 * phase - 1 end
  if kind == "triangle" then return 1 - 4 * math.abs(phase - 0.5) end
  if kind == "noise" then return love.math.random() * 2 - 1 end
  return phase < 0.5 and 1 or -1
end

local function build(d)
  if d.file ~= "" then return love.audio.newSource(d.file, "static") end
  local rate = 22050
  local n = math.max(1, math.floor(rate * d.length))
  local data = love.sound.newSoundData(n, rate, 16, 1)
  local vol = d.volume * (Settings.volume or 1)
  for i = 0, n - 1 do
    local t = i / rate
    local env = 0.0001 ^ (t / d.length)
    data:setSample(i, math.max(-1, math.min(1, wave(d.wave, (t * d.freq) % 1) * vol * env)))
  end
  return love.audio.newSource(data, "static")
end

function Play(id)
  if not S.sound then return end
  local d = Get("Sound", id)
  if not d then return end
  if not cache[id] then
    local ok, src = pcall(build, d)
    if not ok then Engine.warn('Sound "' .. id .. '": ' .. tostring(src), true) cache[id] = false return end
    cache[id] = src
  end
  if cache[id] then cache[id]:stop(); cache[id]:play() end
end
