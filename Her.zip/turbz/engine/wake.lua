-- The first morning in Crownfall. Nell walks in, warns you, and hands over a
-- rolled ghost plus a piece of gear that leans into one early playstyle.

Wake = Wake or {}

local ARCHES = {
  { name = "HUNTER", types = { "normal", "earth" }, slot = "chest", gear = "Hunter's Coat",
    enchants = { "might", "crit_edge", "skeleton_bane" }, boon = "might" },
  { name = "WARDEN", types = { "light", "spirit" }, slot = "head", gear = "Warden Circlet",
    enchants = { "ward", "echo_guard", "spark_life" }, boon = "ward" },
  { name = "ANGLER", types = { "water", "ice" }, slot = "feet", gear = "Tide Treads",
    enchants = { "fish_luck", "rare_hook", "swift" }, boon = "fish_luck" },
  { name = "FORAGER", types = { "earth", "normal" }, slot = "legs", gear = "Forager's Leggings",
    enchants = { "harvest", "shroom_sense", "food_power" }, boon = "harvest" },
  { name = "CATCHER", types = { "spirit", "electric" }, slot = "accessory", gear = "Jar Charm",
    enchants = { "catch_boost", "rarity_aura", "ghost_xp" }, boon = "catch_boost" },
  { name = "MERCHANT", types = { "normal", "light" }, slot = "accessory", gear = "Coin Sash",
    enchants = { "shop_charm", "kyo_find", "sell_boost" }, boon = "kyo_find" },
}

function Wake.grant()
  if S.woke then return S._wakeGift end
  S.woke = true
  local arch = ARCHES[love.math.random(1, #ARCHES)]
  local ghosts = (GhoulRoster and GhoulRoster.list and GhoulRoster.list()) or All("Ghost") or {}
  local pool = {}
  for _, g in ipairs(ghosts) do
    for _, t in ipairs(arch.types) do
      if g.type == t then pool[#pool + 1] = g break end
    end
  end
  if #pool == 0 then pool = ghosts end
  local rareRoll = { "weeping", "weeping", "eclipse", "faded", "kyo_touched" }
  local rare = rareRoll[love.math.random(1, #rareRoll)]
  if not Get("Rarity", rare) then rare = nil end
  local ghostName = "A SPIRIT"
  if #pool > 0 and MakeGhost then
    local sp = pool[love.math.random(1, #pool)]
    local ghost = MakeGhost(sp.id, love.math.random(4, 7), rare)
    if ghost then
      ghost.boon = { id = arch.boon, power = love.math.random(8, 16) }
      if GhostSprite and GhostSprite.ensure then GhostSprite.ensure(ghost) end
      S.party[1] = ghost
      ghostName = GhostName and GhostName(ghost) or (ghost.name or sp.name or "SPIRIT")
    end
  end
  local gearName = arch.gear
  if Armor and Armor.createPiece then
    local piece = Armor.createPiece(arch.slot, 8, {
      quality = (love.math.random(1, 100) <= 30) and "epic" or "rare",
      enchants = {
        { id = arch.enchants[1], power = love.math.random(8, 14) },
        { id = arch.enchants[2], power = love.math.random(6, 12) },
        { id = arch.enchants[3], power = love.math.random(5, 11) },
      },
      name = arch.gear,
    })
    if piece then
      piece.fx = piece.fx or {}
      if #piece.fx < 2 then piece.fx[#piece.fx + 1] = love.math.random(0, 80) end
      Armor.give(piece)
      Armor.equip(piece)
      gearName = piece.name or gearName
    end
  end
  S._wakeGift = { style = arch.name, ghost = ghostName, gear = gearName }
  return S._wakeGift
end
