-- Bank: store KYO, items, and ghost gids. Only withdraw KYO freely on the "you died" screen.
-- Inventory outside the bank is wiped on wipeout.

Bank = Bank or {}

function Bank.ensure()
  S.bank = S.bank or { kyo = 0, items = {}, ghosts = {} }
  S.bank.items = S.bank.items or {}
  S.bank.ghosts = S.bank.ghosts or {}
  S.bank.kyo = S.bank.kyo or 0
end

function Bank.depositKyo(n)
  Bank.ensure()
  n = math.floor(tonumber(n) or 0)
  if n <= 0 then return false end
  if (S.kyo or 0) < n then Say("NOT ENOUGH KYO") Play("bump") return false end
  S.kyo = S.kyo - n
  S.bank.kyo = S.bank.kyo + n
  Say("DEPOSITED " .. n .. " KYO")
  Play("quest")
  return true
end

function Bank.withdrawKyo(n)
  Bank.ensure()
  n = math.floor(tonumber(n) or 0)
  if n <= 0 then return false end
  if S.bank.kyo < n then Say("BANK HAS " .. S.bank.kyo .. " KYO") Play("bump") return false end
  S.bank.kyo = S.bank.kyo - n
  S.kyo = (S.kyo or 0) + n
  Say("WITHDREW " .. n .. " KYO")
  Play("quest")
  return true
end

function Bank.depositItem(id, count)
  Bank.ensure()
  count = math.floor(tonumber(count) or 1)
  if count <= 0 or not id then return false end
  local have = ItemCount and ItemCount(id) or 0
  if have < count then Say("NOT ENOUGH") Play("bump") return false end
  if TakeItem then TakeItem(id, count) end
  S.bank.items[id] = (S.bank.items[id] or 0) + count
  Say("BANKED x" .. count)
  Play("step")
  return true
end

function Bank.withdrawItem(id, count)
  Bank.ensure()
  count = math.floor(tonumber(count) or 1)
  local have = S.bank.items[id] or 0
  if have < count then Say("NOT IN BANK") Play("bump") return false end
  S.bank.items[id] = have - count
  if S.bank.items[id] <= 0 then S.bank.items[id] = nil end
  if GiveItem then GiveItem(id, count) end
  Say("WITHDREW x" .. count)
  Play("step")
  return true
end

-- On wipeout: pocket KYO stays lost; bank KYO/items/ghosts are safe.
-- Party + box ghosts that were NOT deposited to the bank are destroyed.
-- Skills persist (S.skills is never cleared here).
function Bank.onWipeout()
  Bank.ensure()
  -- clear bag items (non-banked)
  if S.bag then
    for id in pairs(S.bag) do S.bag[id] = nil end
  end
  S.bag = {}

  -- Destroy all non-banked ghosts (party + box). Banked ghost records stay in S.bank.ghosts.
  S.party = {}
  S.box = {}
  -- pocket kyo already zeroed by LoseBattle
end

-- Deposit a live ghost object into the bank vault (by gid snapshot).
function Bank.depositGhost(g)
  Bank.ensure()
  if not g or not g.gid then return false end
  -- store a serializable snapshot id; full ghost files remain on disk
  table.insert(S.bank.ghosts, g.gid)
  if RemoveOwned then RemoveOwned(g) end
  Say("BANKED GHOST " .. Upper(tostring(g.name or g.species or g.gid)))
  Play("quest")
  return true
end

function Bank.withdrawGhost(gid)
  Bank.ensure()
  for i, id in ipairs(S.bank.ghosts) do
    if id == gid then
      table.remove(S.bank.ghosts, i)
      -- reload from ghostfile if available
      if LoadGhost and LoadGhost(gid) then
        local g = LoadGhost(gid)
        if g then table.insert(S.box, g) end
      end
      Say("WITHDREW GHOST")
      Play("step")
      return true
    end
  end
  Say("NOT IN BANK")
  Play("bump")
  return false
end
