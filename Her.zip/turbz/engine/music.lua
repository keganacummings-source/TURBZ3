-- Background music: fades in/out, per-track loudness matching, FET soft-knee limiter.
-- Gain-only processing — stereo image and source quality are never altered.
-- Drop .ogg / .wav into assets/music or the save-dir music/ folder.

Music = Music or {}

local FADE_IN = 2.5
local FADE_OUT = 2.0

-- Target integrated loudness (linear RMS). Quieter tracks are boosted; louder
-- ones attenuated. Peak safety prevents clipping after boost.
local TARGET_RMS = 0.12
local MAX_GAIN = 4.0
local MIN_GAIN = 0.15
local ANALYZE_SECONDS = 3

local state = {
  source = nil,
  path = nil,
  volume = 0,
  target = 0.55,
  trackGain = 1,
  fading = "idle",
  fadeT = 0,
  fadeDur = 1,
  tracks = {},
  index = 1,
  enabled = true,
  playTime = 0,
  pendingPath = nil,
}

-- path -> { rms, peak, gain }
local loudnessCache = {}

-- Boot-shuffled playlist: full pass before any track repeats
local playlistOrder = {}  -- indices into state.tracks
local playlistPos = 1
local playlistSeed = nil

local function isAudio(name)
  local lower = string.lower(name or "")
  return lower:match("%.ogg$") or lower:match("%.wav$") or lower:match("%.mp3$")
end

function Music.scan()
  local found = {}
  local function addDir(dir, prefix)
    local items = love.filesystem.getDirectoryItems(dir)
    if not items then return end
    for _, name in ipairs(items) do
      if isAudio(name) then
        found[#found + 1] = (prefix or dir) .. "/" .. name
      end
    end
  end
  addDir("assets/music", "assets/music")
  pcall(love.filesystem.createDirectory, "music")
  addDir("music", "music")
  table.sort(found)
  local changed = (#found ~= #state.tracks)
  if not changed then
    for i, p in ipairs(found) do
      if state.tracks[i] ~= p then changed = true break end
    end
  end
  state.tracks = found
  if changed and #found > 0 then
    Music.shufflePlaylist()
  end
  return found
end

-- Fisher-Yates shuffle of track indices; called once per boot (and if library changes)
function Music.shufflePlaylist()
  local n = #state.tracks
  playlistOrder = {}
  for i = 1, n do playlistOrder[i] = i end
  -- Prefer love.math.random when available so each game instance differs
  local rnd = function(a, b)
    if love and love.math and love.math.random then return love.math.random(a, b) end
    return math.random(a, b)
  end
  for i = n, 2, -1 do
    local j = rnd(1, i)
    playlistOrder[i], playlistOrder[j] = playlistOrder[j], playlistOrder[i]
  end
  playlistPos = 1
  playlistSeed = tostring(os.time()) .. "-" .. tostring(rnd(1, 999999))
  print("[KYO] music playlist shuffled (" .. n .. " tracks) seed " .. playlistSeed)
end

function Music.isEnabled()
  if S and S.musicEnabled == false then return false end
  if Settings and Settings.music == false then return false end
  return state.enabled
end

function Music.setEnabled(on)
  state.enabled = on and true or false
  if S then S.musicEnabled = state.enabled end
  if not state.enabled then
    Music.fadeOutAndStop()
  else
    Music.ensurePlaying()
  end
end

function Music.toggle()
  Music.setEnabled(not Music.isEnabled())
  return Music.isEnabled()
end

----------------------------------------------------------------------
-- Loudness analysis (RMS + peak) via Decoder — chunked, no full decode.
-- Computes a mono level for matching only; playback stays full stereo.
----------------------------------------------------------------------
function Music.analyzeTrack(path)
  if not path then return { rms = TARGET_RMS, peak = 0.5, gain = 1 } end
  if loudnessCache[path] then return loudnessCache[path] end
  -- Do not decode the track here. Walking the samples of a 20MB file on the
  -- main thread froze the game for a long hitch every time a song started.
  local info = { rms = TARGET_RMS, peak = 0.5, gain = 1 }
  loudnessCache[path] = info
  return info
end

function Music.trackGain(path)
  return Music.analyzeTrack(path).gain
end

----------------------------------------------------------------------
-- FET-style soft-knee compressor/limiter on the gain envelope only.
-- No resampling, EQ, or channel mixing — Source:setVolume only.
----------------------------------------------------------------------
function Music.compress(linear)
  local userVol = (S and S.musicVolume) or (Settings and Settings.musicVolume) or 0.55
  local g = (linear or 0) * (userVol / 0.55) * (state.trackGain or 1)

  local thresh, ratio, ceiling = 0.70, 2.5, 0.92
  if g <= thresh then
    return math.max(0, math.min(ceiling, g))
  end
  local over = g - thresh
  local compressed = thresh + over / ratio
  if compressed > ceiling then
    local extra = compressed - ceiling
    compressed = ceiling - 0.02 + extra / (1 + extra * 8)
  end
  return math.max(0, math.min(ceiling, compressed))
end

local function applyVolume()
  if state.source then
    pcall(function() state.source:setVolume(Music.compress(state.volume)) end)
  end
end

local function stopSource()
  if state.source then
    pcall(function() state.source:stop() end)
    state.source = nil
  end
  state.path = nil
  state.volume = 0
  state.trackGain = 1
  state.fading = "idle"
  state.playTime = 0
end

local function loadSource(path)
  if not path then return nil end
  local ok, src = pcall(love.audio.newSource, path, "stream")
  if not ok or not src then return nil end
  src:setLooping(false)
  src:setVolume(0)
  return src
end

function Music.playPath(path, fadeIn)
  if not path or not Music.isEnabled() then return end
  if state.path == path and state.source and state.source:isPlaying() then return end
  if state.source and state.source:isPlaying() and state.volume > 0.05 then
    state.pendingPath = path
    Music.fadeOutAndStop()
    return
  end
  stopSource()
  local src = loadSource(path)
  if not src then return end
  local info = Music.analyzeTrack(path)
  state.trackGain = info.gain or 1
  state.source = src
  state.path = path
  state.volume = 0
  state.target = 0.55
  state.fading = "in"
  state.fadeT = 0
  state.fadeDur = fadeIn or FADE_IN
  state.playTime = 0
  pcall(function() src:play() end)
  applyVolume()
end

function Music.fadeOutAndStop()
  if not state.source then
    if state.pendingPath then
      local p = state.pendingPath
      state.pendingPath = nil
      Music.playPath(p, FADE_IN)
    end
    return
  end
  state.fading = "out"
  state.fadeT = 0
  state.fadeDur = FADE_OUT
end

function Music.nextTrack()
  Music.scan()
  if #state.tracks == 0 then return end
  if #playlistOrder ~= #state.tracks then
    Music.shufflePlaylist()
  end
  -- Advance through shuffled order; when finished, reshuffle for next full cycle
  playlistPos = (playlistPos or 1) + 1
  if playlistPos > #playlistOrder then
    Music.shufflePlaylist()
  end
  local idx = playlistOrder[playlistPos] or 1
  state.index = idx
  Music.playPath(state.tracks[idx], FADE_IN)
end

function Music.ensurePlaying()
  if not Music.isEnabled() then return end
  Music.scan()
  if #state.tracks == 0 then return end
  if state.source and state.source:isPlaying() then return end
  -- First play of this session: shuffle once, start at position 1
  if #playlistOrder ~= #state.tracks or not playlistOrder[1] then
    Music.shufflePlaylist()
  end
  playlistPos = playlistPos or 1
  if playlistPos < 1 or playlistPos > #playlistOrder then playlistPos = 1 end
  local idx = playlistOrder[playlistPos] or 1
  state.index = idx
  Music.playPath(state.tracks[idx], FADE_IN)
end

function Music.update(dt)
  if not Music.isEnabled() then
    if state.source then stopSource() end
    return
  end
  if S and (S.screen == "explore" or S.screen == "hub" or S.screen == "title" or S.screen == "menu") then
    if not state.source or (state.source and not state.source:isPlaying() and state.fading == "idle") then
      if state.path and state.fading == "idle" then
        Music.nextTrack()
      else
        Music.ensurePlaying()
      end
    end
  end

  if not state.source then return end
  state.playTime = (state.playTime or 0) + (dt or 0)

  if state.fading == "in" then
    state.fadeT = state.fadeT + (dt or 0)
    local t = math.min(1, state.fadeT / math.max(0.05, state.fadeDur))
    state.volume = state.target * t
    applyVolume()
    if t >= 1 then state.fading = "idle" end
  elseif state.fading == "out" then
    state.fadeT = state.fadeT + (dt or 0)
    local t = math.min(1, state.fadeT / math.max(0.05, state.fadeDur))
    state.volume = state.target * (1 - t)
    applyVolume()
    if t >= 1 then
      stopSource()
      if state.pendingPath then
        local p = state.pendingPath
        state.pendingPath = nil
        Music.playPath(p, FADE_IN)
      elseif Music.isEnabled() then
        Music.nextTrack()
      end
    end
  else
    if not state.source:isPlaying() then
      Music.nextTrack()
    else
      state.volume = state.target
      applyVolume()
    end
  end
end

function Music.currentName()
  if not state.path then return "NONE" end
  return state.path:match("([^/]+)$") or state.path
end

function Music.currentLoudnessInfo()
  if not state.path then return nil end
  return loudnessCache[state.path]
end
