-- Website-only notices. Desktop never posts. The bot, not the game, speaks in Discord.

SiteFeed = SiteFeed or {}

local function itemName(id)
  local it = Get and Get("Item", id)
  return (it and it.name) or tostring(id or "Item")
end

function SiteFeed.remember(kind, id, name)
  if not S then return end
  S.recentDrops = S.recentDrops or {}
  table.insert(S.recentDrops, 1, {
    id = tostring(id or "item"),
    name = tostring(name or id or "Item"):sub(1, 32),
    kind = kind or "item",
  })
  while #S.recentDrops > 8 do table.remove(S.recentDrops) end
end

function SiteFeed.push(payload)
  if not WebApi or not WebApi.on or not WebApi.postFeed then return end
  WebApi.postFeed(payload)
end

function SiteFeed.onItem(id, count, why)
  if why ~= "kill" and why ~= "quest" then return end
  if not id then return end
  local name = itemName(id)
  SiteFeed.remember("item", id, name)
  SiteFeed.push({ type = "drop", item = id, name = name, count = count or 1, why = why })
end

function SiteFeed.onArmor(piece, why)
  if why ~= "kill" and why ~= "quest" then return end
  if type(piece) ~= "table" then return end
  local name = piece.name or "Armor"
  local id = "armor_" .. tostring(piece.quality or "common")
  SiteFeed.remember("armor", id, name)
  SiteFeed.push({
    type = "drop",
    item = id,
    name = name,
    rarity = piece.qualityName or piece.quality or "Common",
    why = why or "armor",
  })
end

function SiteFeed.onDeath()
  local snap = {}
  if WebApi and WebApi.snapshot then snap = WebApi.snapshot() end
  snap.type = "death"
  snap.zone = S and S._diedZone and (S._diedZone.name or S._diedZone.id) or ""
  SiteFeed.push(snap)
end
