-- .ghost files: every owned ghost is its own scrambled seed file in the save folder (ghosts/<gid>.ghost).
-- EXPORT writes one to exports/ to send to a friend. Drag a .ghost file onto the game window to import it.
-- The code is scrambled + checksummed, so an edited or made-up file is refused.
local okBit, bit = pcall(require, "bit")
if not okBit then
  -- the browser version runs plain Lua 5.1 (no "bit" library): byte xor by hand
  bit = { bxor = function(a, b)
    local r, p = 0, 1
    for _ = 1, 8 do
      if a % 2 ~= b % 2 then r = r + p end
      a, b, p = Floor(a / 2), Floor(b / 2), p * 2
    end
    return r
  end }
end
local HEADER = "KYOGHOST1"
local SECRET = "zomnia-she-walks-they-follow"
local FIELDS = { "gid", "species", "nick", "level", "xp", "rarity", "moves", "battleMoves", "learned", "trades", "born", "from", "type", "type2", "types" }

local function hash(s) return love.data.encode("string", "hex", love.data.hash("sha1", s)) end

local function stream(salt, n)
  local out, i = {}, 0
  while #out < n do
    i = i + 1
    local h = love.data.hash("sha1", SECRET .. salt .. i)
    for k = 1, #h do out[#out + 1] = h:byte(k) end
  end
  return out
end

local function xor(data, salt)
  local key, bytes = stream(salt, #data), {}
  for i = 1, #data do bytes[i] = string.char(bit.bxor(data:byte(i), key[i])) end
  return table.concat(bytes)
end

local CHARS = "0123456789abcdefghijklmnopqrstuvwxyz"
function NewGid()
  local s = ""
  for _ = 1, 12 do local n = love.math.random(1, #CHARS) s = s .. CHARS:sub(n, n) end
  return s
end

function GhostSeed(g)
  local data = {}
  for _, k in ipairs(FIELDS) do data[k] = g[k] end
  for _, k in ipairs(Settings.stats) do data[k] = g[k] end
  local salt = NewGid():sub(1, 8)
  local body = love.data.encode("string", "base64", xor(Serialize(data), salt))
  return HEADER .. ":" .. salt .. ":" .. body .. ":" .. hash(SECRET .. salt .. body):sub(1, 16)
end

-- returns ghost, or nil + reason
function ReadGhostSeed(text)
  local salt, body, check = tostring(text or ""):gsub("%s", ""):match("^" .. HEADER .. ":(%w+):([%w%+/=]+):(%x+)$")
  if not salt then return nil, "not_ghost_file" end
  if hash(SECRET .. salt .. body):sub(1, 16) ~= check then return nil, "ghost_tampered" end
  local ok, raw = pcall(love.data.decode, "string", "base64", body)
  if not ok then return nil, "ghost_tampered" end
  local chunk = loadstring("return " .. xor(raw, salt))
  if not chunk then return nil, "ghost_tampered" end
  setfenv(chunk, {})
  local ran, d = pcall(chunk)
  if not ran or type(d) ~= "table" then return nil, "ghost_tampered" end
  local sp = Get("Ghost", d.species or "")
  if not sp then return nil, "ghost_unknown" end
  if not Get("Rarity", d.rarity or "") then d.rarity = CommonRarity() end
  if type(d.level) ~= "number" or d.level < 1 or d.level > Settings.maxLevel then return nil, "ghost_tampered" end
  for _, k in ipairs(Settings.stats) do
    if type(d[k]) ~= "number" or d[k] < 0 or d[k] > 10 then return nil, "ghost_tampered" end
  end
  if type(d.moves) ~= "table" then d.moves = {} end
  if type(d.battleMoves) ~= "table" then d.battleMoves = {} end
  if type(d.learned) ~= "table" then d.learned = {} end
  if NormalizeGhostTyping then NormalizeGhostTyping(d) end
  if EnsureBattleMoves then EnsureBattleMoves(d) end
  d.xp, d.trades = d.xp or 0, d.trades or 0
  return d
end

local function owned(gid)
  for _, g in ipairs(Owned()) do if g.gid == gid then return true end end
  return false
end

function EnsureGid(g)
  if not g.gid then g.gid = NewGid() end
  g.born = g.born or os.time()
  g.from = g.from or ""
  g.trades = g.trades or 0
end

-- every owned ghost -> ghosts/<gid>.ghost   (old files of ghosts you no longer own are removed)
function SaveGhostFiles()
  local dir = ActiveSavePath and ActiveSavePath("ghosts") or "ghosts"
  love.filesystem.createDirectory(dir)
  local keep = {}
  for _, g in ipairs(Owned()) do
    EnsureGid(g)
    keep[g.gid .. ".ghost"] = true
    love.filesystem.write(dir .. "/" .. g.gid .. ".ghost", GhostSeed(g))
  end
  for _, name in ipairs(love.filesystem.getDirectoryItems(dir)) do
    if not keep[name] then love.filesystem.remove(dir .. "/" .. name) end
  end
end

function LoadGhostFile(gid)
  local path = (ActiveSavePath and ActiveSavePath("ghosts") or "ghosts") .. "/" .. tostring(gid) .. ".ghost"
  local text = love.filesystem.read(path)
  if not text then return nil end
  return (ReadGhostSeed(text))
end

-- writes exports/<NAME>_<gid>.ghost.  Unless Settings.exportKeepsCopy, the ghost leaves your box (it's in the file now)
function ExportGhost(g)
  if not Settings.exportKeepsCopy and #Owned() <= 1 then Say(Word("last_ghost")) Play("bump") return false end
  EnsureGid(g)
  g.trades = g.trades + 1
  love.filesystem.createDirectory("exports")
  local file = "exports/" .. GhostName(g):gsub("[^%w]", "") .. "_" .. g.gid .. ".ghost"
  love.filesystem.write(file, GhostSeed(g))
  if not Settings.exportKeepsCopy then RemoveOwned(g) LeadGhost() end
  SaveGame()
  Say(Word("exported", GhostName(g)))
  Play("win")
  Fire("ghost_exported", { ghost = g, file = file })
  return file
end

function ImportGhostText(text)
  local g, why = ReadGhostSeed(text)
  if not g then Say(Word(why)) Play("bump") return nil end
  if owned(g.gid) then Say(Word("ghost_have")) Play("bump") return nil end
  if (S.imported[g.gid] or -1) >= g.trades then Say(Word("ghost_used")) Play("bump") return nil end
  S.imported[g.gid] = g.trades
  g.uid = NextUid()
  table.insert(S.box, g)
  S.seen[g.species] = true
  S.caught[g.species] = S.caught[g.species] or {}
  S.caught[g.species][g.rarity] = true
  SaveGame()
  Say(Word("imported", GhostName(g)))
  Play("win")
  Fire("ghost_imported", { ghost = g })
  return g
end

function OpenExportFolder()
  love.filesystem.createDirectory("exports")
  love.system.openURL("file://" .. love.filesystem.getSaveDirectory() .. "/exports")
end

function love.filedropped(file)
  if S.screen == "title" or S.screen == "menu" then Say(Word("ghost_ingame")) return end
  file:open("r")
  local text = file:read()
  file:close()
  ImportGhostText(text)
end
