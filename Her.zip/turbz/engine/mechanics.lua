-- Living mechanics: fishing shores, social XP, weather pressure, skill feedback.

Mechanics = Mechanics or {}

local SHORE_TILES = { shore = true, water = true, shallow = true, reef = true }

function Mechanics.isFishable(tx, ty)
  local t = World.tileAt and World.tileAt(tx, ty)
  if t and SHORE_TILES[t] then return true end
  -- adjacent ocean while standing on shore/floor
  if not World.inMap(tx, ty) then return false end
  for _, d in ipairs({ {1,0},{-1,0},{0,1},{0,-1} }) do
    local n = World.tileAt(tx + d[1], ty + d[2])
    if n == "ocean" or n == "shore" or (n and SHORE_TILES[n]) then return true end
  end
  return false
end

function Mechanics.tryFish()
  local dir = S.dir or { 0, 1 }
  local spots = {
    { S.px + dir[1], S.py + dir[2] },
    { S.px, S.py },
    { S.px + 1, S.py }, { S.px - 1, S.py },
    { S.px, S.py + 1 }, { S.px, S.py - 1 },
  }
  local at = nil
  for _, s in ipairs(spots) do
    if Mechanics.isFishable(s[1], s[2]) then at = s break end
  end
  if not at then return false end

  local speed = SkillFishingCatchSpeed and SkillFishingCatchSpeed() or 1
  -- higher skill = more often a bite (we resolve instantly with better odds)
  local biteChance = math.min(85, 35 + (SkillLevel and SkillLevel("fishing") or 1) * 0.1)
  if Transform and Transform.fishMult then biteChance = math.min(95, biteChance * Transform.fishMult()) end
  if AddSkillXp then AddSkillXp("fishing", 6) end

  if love.math.random(1, 100) > biteChance then
    Say("...NO BITE")
    Play("bump")
    return true
  end

  local fishLv = SkillLevel and SkillLevel("fishing") or 1
  local foodChance = 72 - math.min(24, fishLv * 0.04)
  if Armor and Armor.get then foodChance = foodChance - math.min(15, Armor.get("rare_hook") * 0.3) end
  if love.math.random(1, 100) <= foodChance then
    local foods = { "raw_fish", "raw_fish", "fish_meal", "berry" }
    local id = foods[love.math.random(1, #foods)]
    local n = 1
    if love.math.random(1, 100) <= math.min(40, fishLv * 0.1) then n = 2 end
    if GiveItem then GiveItem(id, n) end
    if AddSkillXp then AddSkillXp("fishing", 8) end
    if Spirit and Spirit.gain then Spirit.gain(1) end
    Say("CAUGHT " .. Upper(id) .. (n > 1 and " x2" or ""))
    Play("quest")
    return true
  end

  -- High rarity low level ghost hook (as designed)
  local rareRoll = love.math.random(1, 1000)
  local rarity = nil
  if rareRoll <= 3 then rarity = "kyo"
  elseif rareRoll <= 15 then rarity = "holy"
  elseif rareRoll <= 40 then rarity = "vivid"
  elseif rareRoll <= 90 then rarity = "bright"
  end

  local region = World.regionAt and World.regionAt(at[1], at[2])
  local species = nil
  if RollSpawn then
    species = select(1, RollSpawn(region))
  end
  if not species then
    local all = All("Ghost") or {}
    if #all > 0 then species = all[love.math.random(1, #all)].id end
  end
  if not species then
    Say("CAUGHT NOTHING")
    return true
  end

  local lvl = math.max(1, math.floor(1 + (S.trainer or 1) * 0.15 + love.math.random(0, 3)))
  -- fishing ghosts stay low level even when rare
  lvl = math.min(lvl, 12 + math.floor((SkillLevel("fishing") or 1) / 50))

  if MakeGhost and StartIntro then
    local g = MakeGhost(species, lvl, rarity)
    if g then
      -- present as a wild encounter near the player
      local wild = { x = at[1], y = at[2], ghost = g, species = species }
      Say("SOMETHING BITES!")
      Play("jump")
      if AddSkillXp then AddSkillXp("fishing", 14) end
      if StartIntro then StartIntro(wild)
      elseif StartWildBattle then StartWildBattle(wild)
      end
      return true
    end
  end

  -- Fallback: item fish
  if GiveItem then GiveItem("potion", 1) end
  Say("REELED IN A FIND")
  Play("quest")
  return true
end

function Mechanics.onTalkSocial()
  if AddSkillXp then AddSkillXp("social", 3) end
end

function Mechanics.onFollowSocial()
  if AddSkillXp then AddSkillXp("social", 8) end
end

function Mechanics.onWildWin(foe)
  if AddSkillXp then
    AddSkillXp("hunting", 10)
    if foe and foe.level then
      AddSkillXp("hunting", math.min(20, math.floor((foe.level or 1) / 4)))
    end
  end
end

-- Mild weather pressure on explore (not punitive)
function Mechanics.weatherStep()
  local w = S and S.weather
  if not w or w == "clear" then return end
  if w == "rain" and Mechanics.isFishable(S.px, S.py) then
    -- Rain no longer drops a node on the tile you are standing on.
  elseif w == "embers" and love.math.random(1, 200) <= 2 then
    if AddSkillXp then AddSkillXp("mining", 1) end
  elseif w == "fog" and love.math.random(1, 180) <= 2 then
    if AddSkillXp then AddSkillXp("hunting", 1) end
  end
end
