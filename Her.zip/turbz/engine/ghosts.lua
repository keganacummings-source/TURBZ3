-- Ghosts, wild spawning (timer + limits), world turns (TurnTime), enemies, portals, walking, naming
function Species(g) return g and Get("Ghost", g.species) or nil end

-- New ghosts are Normal by default and gain up to four independently rolled types.
-- The list form is authoritative; type/type2 remain mirrors for old UI and save compatibility.
function GhostTypes(g)
  local sp = Species(g)
  local out, seen = {}, {}
  local function add(t)
    if type(t) == "string" and t ~= "" and not seen[t] and #out < (Settings.maxGhostTypes or 5) then
      if t == "normal" or Get("Type", t) then
        out[#out + 1], seen[t] = t, true
      end
    end
  end
  if g and type(g.types) == "table" then
    for _, t in ipairs(g.types) do add(t) end
  else
    add((g and g.type) or "normal")
    if g then add(g.type2) end
  end
  if out[1] ~= "normal" then
    table.insert(out, 1, "normal")
    while #out > (Settings.maxGhostTypes or 5) do table.remove(out) end
  end
  if #out == 0 then out[1] = "normal" end
  return out
end

function GhostHasType(g, typeId)
  for _, t in ipairs(GhostTypes(g)) do if t == typeId then return true end end
  return false
end

-- Type rolls are individual and independent. Every ghost begins Normal and can
-- add up to four randomly ordered non-Normal types at a 10% chance each.
function RollGhostTypes()
  local maxTypes = math.max(1, math.min(5, Settings.maxGhostTypes or 5))
  local types, pool = { "normal" }, {}
  for _, t in ipairs(All("Type")) do if t.id ~= "normal" then pool[#pool + 1] = t.id end end
  for i = #pool, 2, -1 do local j = love.math.random(i) pool[i], pool[j] = pool[j], pool[i] end
  local chance = Settings.extraTypeChance or 10
  for _, t in ipairs(pool) do
    if #types >= maxTypes then break end
    if Chance(chance) then types[#types + 1] = t end
  end
  return types
end

function NormalizeGhostTyping(g)
  if not g then return nil end
  if type(g.types) ~= "table" or #g.types == 0 then
    -- Migrate old saves/ghost files without needlessly rerolling their old type
    -- identity. The historical primary/secondary types become bonus types on top
    -- of the new universal Normal baseline.
    local legacy, legacySeen = { "normal" }, { normal = true }
    local maxTypes = math.max(1, math.min(5, Settings.maxGhostTypes or 5))
    for _, t in ipairs({ g.type, g.type2 }) do
      if type(t) == "string" and t ~= "normal" and Get("Type", t) and not legacySeen[t] and #legacy < maxTypes then
        legacy[#legacy + 1], legacySeen[t] = t, true
      end
    end
    if #legacy > 1 then g.types = legacy else g.types = RollGhostTypes() end
  else
    local cleaned, seen = { "normal" }, { normal = true }
    for _, t in ipairs(g.types) do
      if t ~= "normal" and type(t) == "string" and Get("Type", t) and not seen[t] and #cleaned < (Settings.maxGhostTypes or 5) then
        cleaned[#cleaned + 1], seen[t] = t, true
      end
    end
    g.types = cleaned
  end
  g.type, g.type2 = g.types[1] or "normal", g.types[2]
  g.moves, g.learned = g.moves or {}, g.learned or {}
  local kept, seenMoves, hasNormal = {}, {}, false
  for _, id in ipairs(g.moves) do
    local a = Get("Attack", id)
    if a and (a.type == "normal" or GhostHasType(g, a.type)) and not seenMoves[id] and #kept < (Settings.maxMoves or 10) then
      kept[#kept + 1], seenMoves[id] = id, true
      g.learned[id] = true
      if a.type == "normal" then hasNormal = true end
    end
  end
  g.moves = kept
  if not hasNormal then
    local normal = {}
    for _, a in ipairs(All("Attack")) do if a.type == "normal" then normal[#normal + 1] = a end end
    if #normal > 0 then
      local id = Pick(normal).id
      if #g.moves >= (Settings.maxMoves or 10) then g.moves[#g.moves] = id else table.insert(g.moves, 1, id) end
      g.learned[id] = true
    end
  end
  local allowed, battle = {}, {}
  for _, id in ipairs(g.moves) do allowed[id] = true end
  for _, id in ipairs(g.battleMoves or {}) do
    if allowed[id] and #battle < (Settings.maxBattleMoves or 4) then battle[#battle + 1] = id end
  end
  g.battleMoves = battle
  EnsureBattleMoves(g)
  return g
end

function NextUid() S.uid = (S.uid or 0) + 1 return S.uid end

local function movesFrom(ids, sp, cap, ghost)
  local out, seen = {}, {}
  cap = cap or (Settings.maxMoves or 10)
  for _, id in ipairs(ids or {}) do
    local a = Get("Attack", id)
    local typeOk = not Settings.sameTypeMoves
    if Settings.sameTypeMoves and a then
      typeOk = ghost and GhostHasType(ghost, a.type) or (not ghost and sp and a.type == sp.type)
    end
    if a and typeOk and not seen[a.id] then
      out[#out + 1], seen[a.id] = a, true
      if #out >= cap then break end
    end
  end
  return out
end

function MovesOfSpecies(sp) return movesFrom(sp and sp.moves, sp, Settings.maxMoves or 10) end

-- Ensure battleMoves exists and is a valid subset of stored moves (max 4)
function EnsureBattleMoves(g)
  if not g then return end
  g.moves = g.moves or {}
  g.battleMoves = g.battleMoves or {}
  -- drop invalid battle picks
  local keep = {}
  for _, id in ipairs(g.battleMoves) do
    if IsEquipped(g, id) then keep[#keep + 1] = id end
    if #keep >= (Settings.maxBattleMoves or 4) then break end
  end
  g.battleMoves = keep
  -- if empty, auto-fill from stored moves
  if #g.battleMoves == 0 then
    for _, id in ipairs(g.moves) do
      table.insert(g.battleMoves, id)
      if #g.battleMoves >= (Settings.maxBattleMoves or 4) then break end
    end
  end
end

-- Moves used IN BATTLE (up to 4 selected from the 10 stored)
function MovesOf(g)
  local sp = Species(g)
  if not sp then return {} end
  EnsureBattleMoves(g)
  local ids = (g.battleMoves and #g.battleMoves > 0) and g.battleMoves
    or ((g.moves and #g.moves > 0) and g.moves or sp.moves)
  return movesFrom(ids, sp, Settings.maxBattleMoves or 4, g)
end

-- All STORED moves (up to 10)
function StoredMoves(g)
  local sp = Species(g)
  if not sp then return {} end
  return movesFrom((g.moves and #g.moves > 0) and g.moves or sp.moves, sp, Settings.maxMoves or 10, g)
end

function IsBattleMove(g, id)
  for _, m in ipairs(g.battleMoves or {}) do if m == id then return true end end
  return false
end

-- Toggle a stored move into the battle set of 4
function ToggleBattleMove(g, id)
  if not g or not IsEquipped(g, id) then return false end
  EnsureBattleMoves(g)
  if IsBattleMove(g, id) then
    if #g.battleMoves <= 1 then Say("NEED AT LEAST ONE BATTLE MOVE") Play("bump") return false end
    for i, m in ipairs(g.battleMoves) do if m == id then table.remove(g.battleMoves, i) break end end
    Play("step")
  else
    if #g.battleMoves >= (Settings.maxBattleMoves or 4) then
      Say("BATTLE SLOTS FULL (4) - DESELECT ONE FIRST")
      Play("bump")
      return false
    end
    table.insert(g.battleMoves, id)
    Play("quest")
  end
  return true
end

function GhostList()
  if GhoulRoster and GhoulRoster.list and S and S.ghoulRoster then
    local roster = GhoulRoster.list()
    if roster and #roster > 0 then return roster end
  end
  local list = All("Ghost")
  table.sort(list, function(a, b) if a.number == b.number then return a.id < b.id end return a.number < b.number end)
  return list
end

function GhostsOfType(typeId)
  local out = {}
  for _, g in ipairs(GhostList()) do if g.type == typeId then table.insert(out, g) end end
  return out
end

-- rarity: a Rarity id like "weeping" (leave it out = common)
function MakeGhost(speciesId, level, rarity)
  local sp = Get("Ghost", speciesId)
  if not sp then Engine.warn('MakeGhost: no Ghost "' .. tostring(speciesId) .. '"', true) return nil end
  if rarity == true then rarity = "sleeping" end
  if type(rarity) ~= "string" or not Get("Rarity", rarity) then rarity = CommonRarity() end
  local types = RollGhostTypes()
  local g = { uid = NextUid(), gid = NewGid(), born = os.time(), from = "", trades = 0,
    species = speciesId, level = Clamp(level or 1, 1, Settings.maxLevel or 400), rarity = rarity,
    xp = 0, moves = {}, battleMoves = {}, learned = {}, types = types, type = types[1], type2 = types[2] }

  local function addMove(a)
    if a and not g.learned[a.id] and #g.moves < (Settings.maxMoves or 10) then
      g.moves[#g.moves + 1] = a.id
      g.learned[a.id] = true
    end
  end
  local normalMoves = {}
  for _, a in ipairs(All("Attack")) do if a.type == "normal" then normalMoves[#normalMoves + 1] = a end end
  if #normalMoves > 0 then addMove(Pick(normalMoves)) end
  for _, a in ipairs(MovesOfSpecies(sp)) do if GhostHasType(g, a.type) then addMove(a) end end
  local compatible = {}
  for _, a in ipairs(All("Attack")) do if GhostHasType(g, a.type) then compatible[#compatible + 1] = a end end
  for i = #compatible, 2, -1 do local j = love.math.random(i) compatible[i], compatible[j] = compatible[j], compatible[i] end
  for _, a in ipairs(compatible) do addMove(a) if #g.moves >= (Settings.maxMoves or 10) then break end end
  if #g.moves == 0 and #All("Attack") > 0 then addMove(Pick(All("Attack"))) end
  EnsureBattleMoves(g)
  if Rules and Rules.new_ghost then Rules.new_ghost(g, sp) end
  if WorldGhosts and WorldGhosts.imageFor then
    g.imageSprite = WorldGhosts.imageFor(g)
  elseif sp.imageSprite and sp.imageSprite ~= "" then
    g.imageSprite = sp.imageSprite
  end
  if GhoulRoster and GhoulRoster.attach then GhoulRoster.attach(g) end
  g.look, g.lookCode = nil, nil
  if not g.boon and Armor and Armor.ENCHANTS and #Armor.ENCHANTS > 0 then
    local def = Armor.ENCHANTS[love.math.random(1, #Armor.ENCHANTS)]
    local cap = math.max(3, math.floor((def.max or 12) * 0.4))
    g.boon = { id = def.id, power = love.math.random(2, cap) }
  end
  Fire("ghost_made", { ghost = g })
  return g
end


function LearnedMoves(g)
  if not g then return {} end
  g.learned = g.learned or {}
  -- seed from equipped moves (older saves) so nothing is lost
  for _, id in ipairs(g.moves or {}) do g.learned[id] = true end
  local out, sp = {}, Species(g)
  for _, a in ipairs(All("Attack")) do
    local typeOk = (not Settings.sameTypeMoves) or GhostHasType(g, a.type)
    if g.learned[a.id] and typeOk then table.insert(out, a) end
  end
  table.sort(out, function(a, b) return a.name < b.name end)
  return out
end

function IsEquipped(g, id)
  for _, m in ipairs(g.moves or {}) do if m == id then return true end end
  return false
end

-- toggle a learned move into/out of the equipped list (keeps at least 1, cap at maxMoves)
function ToggleEquip(g, id)
  if not g or not (g.learned and g.learned[id] or IsEquipped(g, id)) then return false end
  g.moves = g.moves or {}
  if IsEquipped(g, id) then
    if #g.moves <= 1 then Say("NEED AT LEAST ONE MOVE") Play("bump") return false end
    for i, m in ipairs(g.moves) do if m == id then table.remove(g.moves, i) break end end
    -- also drop from battle set
    if g.battleMoves then
      for i, m in ipairs(g.battleMoves) do if m == id then table.remove(g.battleMoves, i) break end end
    end
    EnsureBattleMoves(g)
    Play("step")
  else
    if #g.moves >= (Settings.maxMoves or 10) then Say("MOVE SLOTS FULL (10) - REMOVE ONE FIRST") Play("bump") return false end
    table.insert(g.moves, id)
    EnsureBattleMoves(g)
    -- auto-add to battle if room
    if #(g.battleMoves or {}) < (Settings.maxBattleMoves or 4) then
      table.insert(g.battleMoves, id)
    end
    Play("quest")
  end
  return true
end

-- learn a new random move of the ghost's own type (called when it reaches a new multiple of 5)
function TryLearnMove(g)
  if not g then return nil end
  local sp = Species(g)
  g.learned = g.learned or {}
  for _, id in ipairs(g.moves or {}) do g.learned[id] = true end
  local pool = {}
  for _, a in ipairs(All("Attack")) do
    if GhostHasType(g, a.type) and not g.learned[a.id] then pool[#pool + 1] = a end
  end
  if #pool == 0 then return nil end
  local a = Pick(pool)
  g.learned[a.id] = true
  if #(g.moves or {}) < (Settings.maxMoves or 10) then table.insert(g.moves, a.id) end
  -- auto battle-slot if room
  EnsureBattleMoves(g)
  if #(g.battleMoves or {}) < (Settings.maxBattleMoves or 4) then
    table.insert(g.battleMoves, a.id)
  end
  Fire("move_learned", { ghost = g, move = a.id })
  return a
end

-- Species evolution (evolvesTo + evolveLevel on a Ghost). Returns the new species name if it evolved.
-- Note: Holy State (halo + 2x at Settings.holyLevel) is a separate, same-species change - see draw.lua.
function CheckEvolve(g)
  local evolved, guard = nil, 0
  local sp = Species(g)
  while sp and sp.evolvesTo and sp.evolvesTo ~= "" and (sp.evolveLevel or 0) > 0
    and g.level >= sp.evolveLevel and Get("Ghost", sp.evolvesTo) and guard < 10 do
    g.species, g.sprite = sp.evolvesTo, nil
    Fire("ghost_evolved", { ghost = g, into = g.species })
    sp = Species(g)
    evolved = sp and sp.name or g.species
    guard = guard + 1
  end
  return evolved
end

-- nickname if it has one, otherwise the species name
function GhostName(g)
  if g and g.nick and g.nick ~= "" then return Upper(g.nick) end
  local sp = Species(g)
  return sp and Upper(sp.name) or "???"
end

function StatSum(g)
  local n = 0
  for _, k in ipairs(Settings.stats) do n = n + (g[k] or 0) end
  return n
end

function Owned()
  local out = {}
  local _ps = (EffectivePartySize and EffectivePartySize()) or Settings.partySize or 6
  for i = 1, _ps do if S.party[i] then table.insert(out, S.party[i]) end end
  for _, g in ipairs(S.box) do table.insert(out, g) end
  return out
end

function LeadGhost()
  local _ps = (EffectivePartySize and EffectivePartySize()) or Settings.partySize or 6
  for i = 1, _ps do if S.party[i] then return S.party[i] end end
  S.party[1] = MakeGhost(Settings.starter, S.trainer, false)
  return S.party[1]
end

local function at(list, x, y)
  for _, e in ipairs(list) do if e.x == x and e.y == y then return e end end
  return nil
end
function WildAt(x, y) return at(S.wilds, x, y) end
function NpcAt(x, y) return at(S.npcs, x, y) end
function PortalAt(x, y) return at(World.portals or {}, x, y) end

local function countIn(list, region)
  local n = 0
  for _, e in ipairs(list) do if World.regionAt(e.x, e.y) == region then n = n + 1 end end
  return n
end

-- region.spawns = { fire = 50, nobi = 20, kaze = { weight = 10, levels = { 5, 9 } } }  (Type or Ghost ids)
-- region.levels = { min, max } for the whole region. Returns ghostId, level

-- Distance-from-manor level: bottom-left hub = low, top-right = high (up to maxLevel)
function LevelAtTile(x, y)
  local mx, my = World.manorX or 1, World.manorY or 1
  local maxd = World.maxDist or 1
  local dx, dy = (x or 0) - mx, (y or 0) - my
  local d = math.sqrt(dx * dx + dy * dy)
  local t = math.min(1, d / maxd)
  -- Quadratic progression keeps the capital and its connected approaches gentle;
  -- the outer island shores gradually reach the open-world cap.
  t = t * t
  local maxLv = (World.map and World.map.id == "giant_world") and (Settings.worldLevelMax or 180) or (Settings.maxLevel or 400)
  local minLv = 1
  return math.max(minLv, math.floor(minLv + t * (maxLv - minLv) + 0.5))
end

function LevelRangeAt(x, y)
  local mid = LevelAtTile(x, y)
  local spread = math.max(2, math.floor(mid * 0.08))
  local cap = (World.map and World.map.id == "giant_world") and (Settings.worldLevelMax or 180) or (Settings.maxLevel or 400)
  return math.max(1, mid - spread), math.min(cap, mid + spread)
end

function SpawnWeight(v) return type(v) == "table" and (v.weight or 1) or v end
function RollSpawn(region)
  local weights = {}
  for k, v in pairs(region.spawns or {}) do weights[k] = SpawnWeight(v) end
  local key = PickWeighted(weights)
  local sp = nil
  if key then
    sp = Get("Ghost", key) or Pick(GhostsOfType(key))
  end
  -- Fallback: any living roster ghost (old maps still reference deleted species)
  if not sp then
    local all = GhostList and GhostList() or All("Ghost") or {}
    if #all > 0 then sp = all[love.math.random(1, #all)] end
  end
  if not sp then return nil end
  local entry = region.spawns[key]
  local lv = (type(entry) == "table" and entry.levels) or region.levels or {}
  -- Prefer distance-from-manor scaling over static region levels
  local x = (region and region._spawnX) or S.px or World.manorX or 1
  local y = (region and region._spawnY) or S.py or World.manorY or 1
  local lo, hi = LevelRangeAt(x, y)
  -- Static 241+ bands belonged to the old tiny map. On the expanded world, distance
  -- progression is authoritative; explicit per-region levels remain for legacy maps.
  if not (World.map and World.map.id == "giant_world") and lv[1] and lv[1] > lo then lo = math.min(lv[1], hi) end
  local cap = (World.map and World.map.id == "giant_world") and (Settings.worldLevelMax or 180) or (Settings.maxLevel or 400)
  return sp.id, Clamp(Rules.wild_level(lo, hi), 1, cap)
end

-- While the player is still low-level (strongest ghost under Settings.levelMatchUnder),
-- keep WILD encounters within +/-5 of their own level so zones never badly over/under-level them.
function PlayerLevelRef()
  local best = 0
  for _, g in ipairs(S.party or {}) do if g and (g.level or 0) > best then best = g.level end end
  return best
end

function MatchWildLevel(level)
  -- Overworld uses distance-from-manor scaling; keep rolled level
  return level
end

local function spawnOutsideView()
  -- The window canvas changes width with aspect ratio and zoom. Use the camera's
  -- actual visible rectangle as the final guard, not just a guessed spawn radius.
  local tileSize = math.max(1, Settings.tileSize or 16)
  local minRange = math.max(Settings.spawnRange or 10,
    math.ceil(math.max(Engine.W or 320, Engine.H or 320) / tileSize * 0.62))
  local range = minRange + 16
  local candidates = World.emptyNear(S.px, S.py, range, 3)
  local safe = {}
  for _, pos in ipairs(candidates) do
    local distance = math.abs(pos[1] - S.px) + math.abs(pos[2] - S.py)
    if distance >= minRange and not OnScreen(pos[1], pos[2]) then
      safe[#safe + 1] = pos
    end
  end
  return Pick(safe)
end

function SpawnWild()
  if #S.wilds >= Settings.maxWilds then return end
  -- Never create a new ghost within the visible camera bounds; it approaches from
  -- off-screen and then keeps its world coordinates while out of view.
  local s = spawnOutsideView()
  if not s then return end
  if World.inHaven and (World.inHaven(S.px, S.py) or World.inHaven(s[1], s[2])) then return end
  local region = World.regionAt(s[1], s[2])
  local cap = (region and region.maxGhosts) or 4
  cap = math.max(8, cap * 2)
  if countIn(S.wilds, region) >= cap then return end
  region._spawnX, region._spawnY = s[1], s[2]
  local id, level = RollSpawn(region)
  if not id then return end
  -- Distance scaling is the balance; do not force-match player level
  local g = MakeGhost(id, level, RollRarity())
  if not g then return end
  local wild = { ghost = g, x = s[1], y = s[2], rx = s[1], ry = s[2],
    away = 0, awaySeconds = 0, lastSeenAt = 0, spawnedAt = love.timer.getTime(), bob = love.math.random(0, 19) }
  table.insert(S.wilds, wild)
  if wild.ghost and GhostSprite and GhostSprite.ensure then GhostSprite.ensure(wild.ghost) end
  Fire("wild_spawned", wild)
end

function SpawnEnemy()
  if #S.npcs >= (Settings.maxEnemies or 12) then return end
  local s = spawnOutsideView()
  if not s then return end
  if World.inHaven and (World.inHaven(S.px, S.py) or World.inHaven(s[1], s[2])) then return end
  local region = World.regionAt(s[1], s[2])
  local cap = region and region.maxEnemies or 0
  if cap <= 0 then cap = Settings.maxEnemies or 12 end
  if countIn(S.npcs, region) >= cap then return end
  local id = PickWeighted((region and region.enemies) or {})
  if not id or not Get("Enemy", id) then
    local lv = (LevelAtTile and LevelAtTile(s[1], s[2])) or 1
    id = lv >= 70 and "skeleton_knight" or "skeleton"
  end
  if not Get("Enemy", id) then return end
  local npc = { enemy = id, uid = NextUid(), x = s[1], y = s[2], rx = s[1], ry = s[2], away = 0 }
  if Sheets and Sheets.roll then
    npc.layers = Sheets.roll(id == "skeleton_knight" and "skeleton" or "skeleton", "ghoul", id == "skeleton_knight" and "eclipse" or "faded")
    npc.layers.type = "ghoul"
  end
  table.insert(S.npcs, npc)
  Fire("enemy_spawned", npc)
end

local function wander(e, chance)
  if not Chance(chance) then return nil end
  local d = Pick(DIRS)
  local nx, ny = e.x + d[1], e.y + d[2]
  if nx == S.px and ny == S.py then return "player" end
  if World.walkable(nx, ny) and not WildAt(nx, ny) and not NpcAt(nx, ny) and not PortalAt(nx, ny) and not PlaceAt(nx, ny) then e.x, e.y = nx, ny end
  return nil
end

-- one world turn: things wander, and things off screen for longer than their TurnTime vanish
function WorldTurn()
  S.turn = (S.turn or 0) + 1
  local keep, fled = {}, nil
  for _, w in ipairs(S.wilds) do
    local sp = Species(w.ghost)
    local visible = OnScreen(w.x, w.y)
    w.away = visible and 0 or (w.away or 0) + 1
    if visible then w.lastSeenAt = love.timer.getTime() end
    -- Keep off-screen ghosts in the world for two minutes. This avoids
    -- despawn/re-pop cycles when the player briefly pans away and returns.
    local offscreenTooLong = not visible and (w.awaySeconds or 0) >= 120
    if not sp or offscreenTooLong then
      Fire("wild_vanished", w)
    elseif S.trainer - w.ghost.level >= Settings.fleeLevelGap and Chance(Rules.flee_chance(w.ghost)) then
      fled = fled or w
    else
      wander(w, Settings.wanderChance)
      if not (World.inHaven and World.inHaven(w.x, w.y)) then table.insert(keep, w) end
    end
  end
  S.wilds = keep
  if fled then Say(Word("spooks_off", GhostName(fled.ghost))) end
  local npcs = {}
  for _, n in ipairs(S.npcs) do
    local def = Get("Enemy", n.enemy)
    if n.ambush then n.away = 0 end
    n.away = OnScreen(n.x, n.y) and 0 or (n.away or 0) + 1
    if def and not (def.turnTime > 0 and n.away > def.turnTime) and not (World.inHaven and World.inHaven(n.x, n.y)) then table.insert(npcs, n) end
  end
  S.npcs = npcs
  for _, n in ipairs(S.npcs) do
    if wander(n, Get("Enemy", n.enemy).wanderChance) == "player" then StartEnemyIntro(n) break end
  end
  StoresTick()
  Fire("world_turn", { turn = S.turn })
end

-- runs every frame while you explore: spawn timers + world turn timer
function ExploreUpdate(dt)
  -- Track real elapsed time out of view independently of turn speed.
  for _, w in ipairs(S.wilds or {}) do
    if OnScreen(w.x, w.y) then
      w.awaySeconds = 0
      w.lastSeenAt = love.timer.getTime()
    else
      w.awaySeconds = (w.awaySeconds or 0) + math.max(0, dt or 0)
    end
  end
  S.spawnTimer = (S.spawnTimer or 0) + dt
  if S.spawnTimer >= Settings.spawnSeconds then S.spawnTimer = 0 SpawnWild() end
  S.enemyTimer = (S.enemyTimer or 0) + dt
  if S.enemyTimer >= Settings.enemySeconds then S.enemyTimer = 0 SpawnEnemy() end
  S.turnTimer = (S.turnTimer or 0) + dt
  if S.turnTimer >= Settings.worldTurnSeconds then S.turnTimer = 0 WorldTurn() end
  if WorldLife and WorldLife.update then WorldLife.update(dt) end
  if S.quest and not S.quest.done then QuestCheck() end
  if Stories and Stories.tick then Stories.tick() end
  if ResourceNodes and ResourceNodes.tick then ResourceNodes.tick(dt) end
  if S.quest and S.quest.done and not S.quest.giver and S.screen == "explore" then Go("reward") end
end

function StartIntro(wild)
  S.seen[wild.ghost.species] = true
  S.intro = { wild = wild, t = 0, sx = wild.x, sy = wild.y }
  Go("intro")
  S.shake = 10
  Play(RarityOf(wild.ghost).jumpSound)
end

function StartEnemyIntro(npc)
  if S.screen ~= "explore" or S.book then return end
  local def = Get("Enemy", npc.enemy)
  S.intro = { npc = npc, t = 0, sx = npc.x, sy = npc.y }
  Go("intro")
  S.shake = 10
  Play("jump")
  Say(Word("wants_fight", Upper(def.name)))
end

function ChangeMap(mapId, x, y)
  if not Get("Map", mapId) then Engine.warn('Portal goes to map "' .. tostring(mapId) .. '" but it does not exist', true) return end
  S.wilds, S.npcs = {}, {}
  World.build(mapId)
  S.px, S.py = x or World.map.start[1], y or World.map.start[2]
  if not World.walkable(S.px, S.py) then S.px, S.py = World.map.start[1], World.map.start[2] end
  S.rx, S.ry, S.followers, S.fpos = S.px, S.py, {}, {}
  NewQuest()
  Say(Word("entered", Upper(World.map.name)))
  Play("quest")
  Fire("map_changed", World.map)
end

function Step(dx, dy)
  if S.screen ~= "explore" then return end
  S.dir = { dx, dy }
  -- Free-move: treat Step as a short continuous nudge (keyboard legacy / mouse path)
  if Movement and Movement.tryMove then
    Movement.tryMove(dx * 0.95, dy * 0.95)
    local nx, ny = math.floor(S.px + 0.5), math.floor(S.py + 0.5)
    local npc = NpcAt(nx, ny)
    if npc then return StartEnemyIntro(npc) end
    local place = PlaceAt(nx, ny)
    if place then return UsePlace(place) end
    local hit = WildAt(nx, ny)
    if hit then return StartIntro(hit) end
    Fire("step", { x = nx, y = ny })
    return
  end
  local nx, ny = S.px + dx, S.py + dy
  local npc = NpcAt(nx, ny)
  if npc then return StartEnemyIntro(npc) end
  local place = PlaceAt(nx, ny)
  if place then return UsePlace(place) end
  if not World.walkable(nx, ny) then
    if S.t - (S.lastBump or -99) > 20 then Play("bump") S.lastBump = S.t end
    return
  end
  S.px, S.py = nx, ny
  S.steps = S.steps + 1
  local here = World.regionAt(nx, ny)
  if here and here.id then S.discovered = S.discovered or {} S.discovered[here.id] = true end
  Play(S.steps % 2 == 0 and "step" or "step_alt")
  table.insert(S.followers, 1, { nx - dx, ny - dy })
  -- Preserve a long enough trail for party ghosts plus recruited human companions.
  local humanCount = #(S.npcCompanions or {})
  local trailLimit = math.max(8, (Settings.partySize or 6) + humanCount + 4)
  while #S.followers > trailLimit do table.remove(S.followers) end
  if TownCompanionStep then TownCompanionStep() end
  local hit = WildAt(nx, ny)
  if hit then return StartIntro(hit) end
  if Mechanics and Mechanics.weatherStep then Mechanics.weatherStep() end
  Fire("step", { x = nx, y = ny })
  if LocalSave then LocalSave() end
end

-- hold a direction key to keep walking one tile at a time
function WalkHeld()
  -- Free movement is driven by Movement.update(dt) each frame.
  -- Keep a thin shim so older calls don't break.
  if S.afk then return end
end

-- press the Talk key (Enter / T) to interact with whatever you are facing or next to:
-- a Store / Trader / QuestGiver, a nearby player in a peer-hosted session, or an enemy.
function TalkInteract()
  if S.screen ~= "explore" then return end
  local dir = S.dir or { 0, 1 }
  local px = math.floor((S.px or 0) + 0.5)
  local py = math.floor((S.py or 0) + 0.5)
  local tries = { { px + dir[1], py + dir[2] }, { px, py - 1 }, { px, py + 1 }, { px - 1, py }, { px + 1, py }, { px, py } }
  for _, t in ipairs(tries) do
    local place = PlaceAt(t[1], t[2])
    if place then return UsePlace(place) end
  end
  -- Resource zones are a single tile on a huge map. Accept a short step away.
  if AllPlaces then
    local best, bd
    for _, def in ipairs(AllPlaces()) do
      if def.kind == "ResourceZone" or def.kind == "ForagePatch" then
        local d = math.abs(def.x - px) + math.abs(def.y - py)
        if d <= 2 and (not bd or d < bd) then best, bd = def, d end
      end
    end
    if best then return UsePlace(best) end
  end
  -- Harvest resource node if facing one
  if ResourceNodes and ResourceNodes.interactFacing and ResourceNodes.interactFacing() then return end
  if WorldBoss and WorldBoss.tryEngage and WorldBoss.tryEngage() then return end
  -- Armored skeleton
  if S.armoredSkeletons then
    local px, py = math.floor((S.px or 0) + 0.5), math.floor((S.py or 0) + 0.5)
    for i, sk in ipairs(S.armoredSkeletons) do
      if math.abs(sk.x - px) + math.abs(sk.y - py) <= 1 then
        -- start a wild-like fight that flags armor drop
        local all = All("Ghost") or {}
        local sp = all[love.math.random(1, math.max(1, #all))]
        local ghost = MakeGhost and MakeGhost(sp.id, sk.level or 20)
        if ghost then
          S._armoredFight = true
          local wild = { x = sk.x, y = sk.y, ghost = ghost, species = sp.id }
          table.remove(S.armoredSkeletons, i)
          if StartIntro then StartIntro(wild) end
          return
        end
      end
    end
  end
  if Mechanics and Mechanics.tryFish and Mechanics.tryFish() then return end
  -- Following companions can be spoken to without standing next to them
  if TryTalkNearestCompanion and TryTalkNearestCompanion() then
    if QuestBoard and QuestBoard.tryFollowerOffer then QuestBoard.tryFollowerOffer() end
    return
  end
  if SessionNet and SessionNet.mode ~= "offline" then
    for id, p in pairs(SessionNet.players or {}) do
      if p.map == S.map and p.x and p.y and math.abs(p.x - S.px) + math.abs(p.y - S.py) <= 1 then
        Say("YOU ARE NEAR " .. Upper(p.name or "ANOTHER PLAYER") .. ". USE SESSION CHAT TO TALK.")
        return
      end
    end
  end
  for _, t in ipairs(tries) do
    local npc = NpcAt(t[1], t[2])
    if npc then return StartEnemyIntro(npc) end
  end
  Say("NOTHING TO TALK TO HERE")
end

-- naming: opens the "name" screen for a ghost
function NameGhost(g)
  if not g then return end
  S.naming = { ghost = g, text = g.nick or "", back = S.screen, book = S.book }
  S.book = false
  Go("name")
end

function FinishNaming(keep)
  local n = S.naming
  if not n then return end
  if keep then
    local name = n.text:gsub("^%s+", ""):gsub("%s+$", "")
    n.ghost.nick = name ~= "" and name or nil
    Say(Word("named", GhostName(n.ghost)))
    Fire("ghost_named", { ghost = n.ghost })
  end
  S.naming = nil
  Go(n.back)
  S.book = n.book
end
