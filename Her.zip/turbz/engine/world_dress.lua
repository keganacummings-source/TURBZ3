-- Villages, castles, camps, and monuments painted onto the packed world mask.
-- Only the stamps are stored. The ocean and open ground stay in the mask.

WorldDress = WorldDress or {}

local CROWN = { x0 = 270, y0 = 4565, x1 = 460, y1 = 4720 }
local MONUMENTS = {
  "moon_obelisk", "bone_arch", "bell_spire", "wishing_well",
  "knight_statue", "stone_cairn", "witch_pyre", "star_gate",
  "raven_totem", "moonwell", "hanged_cage", "sword_shrine",
  "lantern_post", "bone_pile", "witch_circle", "crowned_pillar",
  "ship_rib", "blood_font", "owl_stone", "clock_ruin",
}
local MONUMENT_LINES = {
  moon_obelisk = { "A pale obelisk drinks the moonlight.", "Names are cut into the stone, then scratched out." },
  bone_arch = { "An arch of fitted bone stands over the path.", "Wind moving through it sounds like a choir." },
  bell_spire = { "A bell hangs in a spire with no rope.", "It rings once when a ghost is born nearby." },
  wishing_well = { "Coins glint under black water.", "The wishes down there are not yours." },
  knight_statue = { "A stone knight watches the road.", "The visor is empty. Something still looks out." },
  stone_cairn = { "Travellers stacked these stones and moved on.", "A fresh rock sits on the top." },
  witch_pyre = { "The pyre is cold, but the ash is warm.", "Someone keeps feeding it when nobody is looking." },
  star_gate = { "Two pillars and a lintel frame a patch of sky.", "Step through and you are still here. The stars are not." },
  raven_totem = { "A raven carved from bog oak faces the wind.", "It turns its head when you are not looking." },
  moonwell = { "The well holds moonlight instead of water.", "Drink and the night gets longer." },
  hanged_cage = { "An iron cage hangs from a dead tree.", "The door is open. The lock is not." },
  sword_shrine = { "A sword is planted in the stone.", "The hilt is warm. The blade is not yours." },
  lantern_post = { "A lantern burns with no oil.", "The light stays on the path and nowhere else." },
  bone_pile = { "Bones are stacked the way a mason stacks brick.", "They were not all human." },
  witch_circle = { "Stones ring a patch of black grass.", "Step in and the wind learns your name." },
  crowned_pillar = { "A pillar wears a cracked crown.", "The kingdom it belonged to is not on any map." },
  ship_rib = { "A ship's ribs stand in a field.", "The tide never comes this far. The ship does not care." },
  blood_font = { "A stone basin holds something that is not water.", "It refills when a ghost is caught nearby." },
  owl_stone = { "An owl is cut into a standing stone.", "Its eyes are holes. They still blink." },
  clock_ruin = { "A clock face with no hands.", "It chimes for deaths that have not happened yet." },
}

local function land(x, y)
  local t = World.tileAt(x, y)
  return t == "floor" or t == "shore" or t == "grass_tuft" or t == "bone" or t == "road" or t == "highway"
end

local function clearPatch(x, y, w, h)
  if x < 8 or y < 8 or x + w >= World.w - 8 or y + h >= World.h - 8 then return false end
  if x + w > CROWN.x0 and x < CROWN.x1 and y + h > CROWN.y0 and y < CROWN.y1 then return false end
  local ok, n = 0, 0
  for iy = 0, h - 1, 2 do
    for ix = 0, w - 1, 2 do
      n = n + 1
      if land(x + ix, y + iy) then ok = ok + 1 end
    end
  end
  return n > 0 and (ok / n) >= 0.8
end

local function paint(x, y, tile)
  if World.paint then World.paint(x, y, tile) end
end

local function house(x, y, w, h, wall)
  for ix = 0, w - 1 do
    paint(x + ix, y, wall)
    paint(x + ix, y + h - 1, wall)
  end
  for iy = 0, h - 1 do
    paint(x, y + iy, wall)
    paint(x + w - 1, y + iy, wall)
  end
  for iy = 1, h - 2 do
    for ix = 1, w - 2 do paint(x + ix, y + iy, "capital_floor") end
  end
  paint(x + math.floor(w / 2), y + h - 1, "capital_gate")
end

local function village(x, y)
  house(x, y, 7, 5, "wood_wall")
  house(x + 9, y + 1, 6, 5, "wood_wall")
  house(x + 3, y + 7, 8, 5, "wood_wall")
  house(x + 12, y + 8, 5, 4, "wood_wall")
  for ix = 0, 16 do paint(x + ix, y + 6, "camp_floor") end
  paint(x + 8, y + 6, "campfire")
  paint(x + 1, y + 12, "wishing_well")
end

local function castle(x, y)
  local w, h = 22, 16
  for iy = 0, h - 1 do
    for ix = 0, w - 1 do
      local edge = ix == 0 or iy == 0 or ix == w - 1 or iy == h - 1
      local tower = (ix <= 2 or ix >= w - 3) and (iy <= 2 or iy >= h - 3)
      if tower or edge then paint(x + ix, y + iy, "stone_wall")
      else paint(x + ix, y + iy, "capital_floor") end
    end
  end
  paint(x + 10, y + h - 1, "capital_gate")
  paint(x + 11, y + h - 1, "capital_gate")
  house(x + 7, y + 4, 8, 6, "stone_wall")
  paint(x + 10, y + 6, "knight_statue")
  house(x + 2, y + 5, 4, 4, "stone_wall")
end

local function camp(x, y)
  for iy = 0, 7 do
    for ix = 0, 10 do
      local edge = ix == 0 or iy == 0 or ix == 10 or iy == 7
      if edge and not (iy == 7 and ix >= 4 and ix <= 6) then paint(x + ix, y + iy, "wood_wall")
      else paint(x + ix, y + iy, "camp_floor") end
    end
  end
  paint(x + 5, y + 3, "campfire")
  paint(x + 2, y + 2, "bone_pile")
end

local function monument(x, y, kind)
  paint(x, y, kind)
  paint(x + 1, y, "camp_floor")
  paint(x, y + 1, "camp_floor")
  local lines = MONUMENT_LINES[kind] or { "A monument.", "Someone still tends it." }
  local id = string.format("worlddress_%d_%d", x, y)
  if Define then
    Define("Blurb", id, {
      name = (kind:gsub("_", " ")),
      map = "giant_world",
      x = x + 1, y = y,
      sprite = "ruin_marker",
      lines = lines,
      greeting = lines[1],
      about = lines[2],
    })
  end
end

function WorldDress.stamp()
  if not World or not World.map or World.map.id ~= "giant_world" or not World._virtual then return end
  local order = (Game and Game.order and Game.order.Blurb) or {}
  for i = #order, 1, -1 do
    local id = order[i]
    if tostring(id):match("^worlddress_") then
      if Game.data and Game.data.Blurb then Game.data.Blurb[id] = nil end
      table.remove(order, i)
    end
  end
  local seed = 90210
  local function rnd(n)
    seed = (seed * 1103515245 + 12345) % 2147483648
    return seed % n
  end
  local placed = {}
  local counts = { castle = 0, village = 0, camp = 0, monument = 0 }
  local caps = { castle = 16, village = 42, camp = 30, monument = 84 }

  local function far(x, y, minD)
    for _, p in ipairs(placed) do
      if math.abs(p.x - x) + math.abs(p.y - y) < minD then return false end
    end
    return true
  end

  local function tryPlace(x, y, kind, minD)
    if not kind or counts[kind] >= caps[kind] then return false end
    local w, h = 22, 16
    if kind == "village" then w, h = 18, 14
    elseif kind == "camp" then w, h = 11, 8
    elseif kind == "monument" then w, h = 3, 3 end
    if not far(x, y, minD) or not clearPatch(x, y, w, h) then return false end
    if kind == "castle" then castle(x, y)
    elseif kind == "village" then village(x, y)
    elseif kind == "camp" then camp(x, y)
    else monument(x, y, MONUMENTS[rnd(#MONUMENTS) + 1]) end
    counts[kind] = counts[kind] + 1
    placed[#placed + 1] = { x = x, y = y, kind = kind }
    return true
  end

  local castleNames = { Northwatch = true, Eastgate = true, Southmere = true, Stoneford = true, Starfall = true }
  for _, h in ipairs(World.roadHubs or {}) do
    if h and h.name ~= "Crownfall" and h.x and h.y then
      local kind = castleNames[h.name] and "castle" or "village"
      if not tryPlace(h.x - 9, h.y - 7, kind, 70) then
        tryPlace(h.x - 4, h.y - 3, "camp", 70)
      end
      tryPlace(h.x + 16, h.y + 4, "monument", 24)
    end
  end

  for y = 150, (World.h or 0) - 150, 88 do
    for x = 150, (World.w or 0) - 150, 104 do
      if rnd(100) < 70 then
        local roll = rnd(12)
        local kind = "monument"
        if roll == 0 then kind = "castle"
        elseif roll <= 4 then kind = "village"
        elseif roll <= 7 then kind = "camp" end
        local gap = kind == "monument" and 72 or 130
        tryPlace(x + rnd(24) - 12, y + rnd(24) - 12, kind, gap)
      end
    end
  end
  WorldDress.counts = counts
  WorldDress.sites = placed
end
