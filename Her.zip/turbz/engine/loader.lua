-- Loads every .kyo / .lua file in game/ then every mod folder in mods/
-- Order inside a folder: terms/ folder first, then files (A-Z), then other folders (A-Z)
-- Anything starting with _ or . is skipped (rename a mod to _name to switch it off)
local EXT = { kyo = true, lua = true }

local function loadFile(path)
  Engine.file = path
  local ok, chunk, err = pcall(love.filesystem.load, path)
  if not ok then Engine.warn(chunk, true) return end
  if not chunk then Engine.warn(err or (path .. ": could not read file"), true) return end
  local ran, msg = pcall(chunk)
  if not ran then Engine.warn(msg, true) end
  Engine.loaded = Engine.loaded + 1
end

function Engine.loadFolder(dir)
  local items = love.filesystem.getDirectoryItems(dir)
  table.sort(items)
  local files, folders, terms = {}, {}, nil
  for _, name in ipairs(items) do
    local first = name:sub(1, 1)
    if first ~= "_" and first ~= "." then
      local path = dir .. "/" .. name
      local info = love.filesystem.getInfo(path)
      if info and info.type == "directory" then
        if name == "terms" then terms = path else table.insert(folders, path) end
      elseif EXT[(name:match("%.(%w+)$") or ""):lower()] then
        table.insert(files, path)
      end
    end
  end
  if terms then Engine.loadFolder(terms) end
  for _, f in ipairs(files) do loadFile(f) end
  for _, f in ipairs(folders) do Engine.loadFolder(f) end
end

function Engine.loadAll()
  Engine.loadFolder("game")
  Engine.mods = {}
  if Engine.loadModsEnabled then Engine.loadModsEnabled() end
  Engine.modsOn = Engine.modsOn or {}
  Engine.release = love.filesystem.getInfo("release.txt") ~= nil
  if not Engine.release and love.filesystem.getInfo("mods") then
    local mods = love.filesystem.getDirectoryItems("mods")
    table.sort(mods)
    for _, name in ipairs(mods) do
      local path = "mods/" .. name
      local info = love.filesystem.getInfo(path)
      -- OPT-IN: a mod loads only when the player has switched it ON (Engine.modsOn[name])
      if info and info.type == "directory" and name:sub(1, 1) ~= "_" and name:sub(1, 1) ~= "." and Engine.modsOn[name] then
        table.insert(Engine.mods, name)
        Engine.loadFolder(path)
      end
    end
  end
  Engine.file = "engine"
end
