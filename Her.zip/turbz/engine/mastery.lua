-- Mastery engine: manages skill progression (Mycology, Alchemy, etc.)
-- S.mastery = { [id] = { level = 1, xp = 0 } }

function EnsureMastery(id)
  S.mastery = S.mastery or {}
  if not S.mastery[id] then
    S.mastery[id] = { level = 1, xp = 0 }
  end
  return S.mastery[id]
end

function MasteryXpNeeded(id, level)
  local m = Get("Mastery", id)
  local base = m and m.xpBase or 100
  local scale = m and m.xpScale or 1.5
  return math.floor(base * (scale ^ (level - 1)))
end

function MasteryLevel(id)
  local st = EnsureMastery(id)
  return st.level or 1
end

function MasteryProgress(id)
  local st = EnsureMastery(id)
  local needed = MasteryXpNeeded(id, st.level)
  return st.xp or 0, needed, math.min(1, (st.xp or 0) / math.max(1, needed))
end

function AddMasteryXp(id, amount)
  local m = Get("Mastery", id)
  if not m then return false end
  local st = EnsureMastery(id)
  local maxLvl = m.maxLevel or 10
  if st.level >= maxLvl then return false end

  st.xp = (st.xp or 0) + (amount or 10)
  local needed = MasteryXpNeeded(id, st.level)
  local leveled = false

  while st.xp >= needed and st.level < maxLvl do
    st.xp = st.xp - needed
    st.level = st.level + 1
    leveled = true
    needed = MasteryXpNeeded(id, st.level)
    
    local perk = m.perks and m.perks[st.level]
    local perkText = perk and (" - Perk: " .. perk) or ""
    Say(Upper(m.name) .. " LEVEL " .. st.level .. "!" .. perkText)
    Play("win")
    Fire("mastery_level_up", { mastery = id, level = st.level, perk = perk })
  end

  if not leveled then
    Fire("mastery_xp_gained", { mastery = id, amount = amount, currentXp = st.xp })
  end
  return leveled
end

function HasMasteryPerk(id, level)
  local st = EnsureMastery(id)
  return (st.level or 1) >= level
end
