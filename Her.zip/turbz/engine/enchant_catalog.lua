-- Hundreds of named enchantments. Each one feeds a real channel (key) the
-- rest of the game already reads through Armor.get / Armor.channel.

local catalog = {}
local function add(id, name, about, max, unit, key)
  catalog[#catalog + 1] = { id = id, name = name, about = about, max = max, unit = unit or "%", key = key }
end

local aspects = {
  { "ember", "Ember" }, { "frost", "Frost" }, { "tide", "Tide" }, { "gale", "Gale" },
  { "stone", "Stone" }, { "void", "Void" }, { "halo", "Halo" }, { "grave", "Grave" },
  { "moss", "Moss" }, { "brine", "Brine" }, { "cinder", "Cinder" }, { "dawn", "Dawn" },
  { "dusk", "Dusk" }, { "thorn", "Thorn" }, { "salt", "Salt" }, { "glass", "Glass" },
  { "mire", "Mire" }, { "star", "Star" }, { "bone", "Bone" }, { "ash", "Ash" },
}

local channels = {
  { "might", "Might", "Deal more damage", 24 },
  { "ward", "Ward", "Take less damage", 24 },
  { "crit_edge", "Edge", "Higher crit chance", 16 },
  { "swift", "Swift", "Move a little faster", 14 },
  { "xp_boost", "Lesson", "More battle XP", 22 },
  { "catch_boost", "Jar", "Better catch rate", 18 },
  { "kyo_find", "Coin", "More Kyo", 20 },
  { "loot_find", "Find", "Better drops", 20 },
  { "harvest", "Harvest", "Fuller resource nodes", 22 },
  { "fish_luck", "Hook", "Better bites", 20 },
  { "ghost_xp", "Tutor", "Ghosts learn faster", 20 },
  { "shroom_sense", "Spore", "Better mushroom finds", 18 },
  { "shop_charm", "Haggle", "Cheaper shops", 16 },
  { "sell_boost", "Trade", "Higher sell prices", 16 },
}

for _, a in ipairs(aspects) do
  for _, c in ipairs(channels) do
    add(a[1] .. "_" .. c[1], a[2] .. " " .. c[2], c[3] .. ". " .. a[2] .. " aspect.", c[4], "%", c[1])
  end
end

local specials = {
  { "second_wind", "Second Wind", "Stamina returns faster while you walk", 20, "%", "second_wind" },
  { "long_breath", "Long Breath", "Deeper stamina reserves", 24, "flat", "stamina_well" },
  { "spirit_flow", "Spirit Flow", "Spirit regenerates faster", 18, "%", "spirit_flow" },
  { "spirit_well", "Spirit Well", "A larger spirit reserve", 20, "flat", "spirit_well" },
  { "beast_breath", "Beast Breath", "Animal forms cost less stamina", 30, "%", "beast_breath" },
  { "food_power", "Keen Appetite", "Meals restore more stamina", 30, "%", "food_power" },
  { "lifesteal", "Leechlight", "Hits restore a little HP", 12, "%", "lifesteal" },
  { "thorns", "Thorncoat", "Attackers take a scratch", 14, "%", "thorns" },
  { "token_luck", "Token Luck", "Skill levels sometimes grant an extra token", 40, "%", "token_luck" },
  { "ambush_ward", "Ambush Ward", "Skeleton ambushes are less eager", 30, "%", "ambush_ward" },
  { "skeleton_bane", "Bone Bane", "Extra harm to skeletons", 30, "%", "skeleton_bane" },
  { "quest_xp", "Storybound", "Story rewards grant more XP", 25, "%", "quest_xp" },
  { "rare_hook", "Rare Hook", "Fishing finds stranger ghosts", 20, "%", "rare_hook" },
  { "node_sense", "Node Sense", "You notice resources from farther away", 24, "flat", "node_sense" },
  { "cook_pot", "Cook Pot", "The hearth is kinder to you", 20, "%", "cook_pot" },
  { "rarity_aura", "Rarity Aura", "Stranger ghosts walk the wild", 20, "%", "rarity_aura" },
  { "party_bond", "Party Bond", "Room for another companion", 2, "flat", "party_bond" },
  { "double_strike", "Double Strike", "A chance to hit twice", 18, "%", "double_strike" },
  { "echo_guard", "Echo Guard", "A chance to shrug a hit", 12, "%", "echo_guard" },
  { "spark_life", "Spark of Life", "Begin a fight with a little shield", 16, "%", "spark_life" },
  { "void_step", "Void Step", "Easier to slip a blocked step", 14, "%", "void_step" },
  { "boss_bane", "Boss Bane", "Extra harm to bosses", 24, "%", "boss_bane" },
  { "regen", "Afterglow", "Heal a little after a fight", 16, "%", "regen" },
  { "camp_recall", "Camp Recall", "The road home is shorter in the mind", 1, "flat", "teleport" },
}

for _, s in ipairs(specials) do add(s[1], s[2], s[3], s[4], s[5], s[6]) end

return catalog
