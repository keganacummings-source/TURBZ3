-- Boot, menus/new game/continue, reload (F5), update, draw, input
local REQUIRED_RULES = { "unit_stats", "damage", "new_ghost", "flee_chance", "move_score", "trainer_level", "wild_level", "ghost_look", "xp_reward", "xp_needed", "catch_chance", "type_bonus", "kyo_level", "ghost_price" }
local REQUIRED_SCREENS = { "title", "menu", "pause", "name", "explore", "intro", "battle", "result", "hub", "boobook", "party", "wardrobe", "quests", "bag", "reward", "store", "trade", "ghost_view", "giver", "market", "bank", "died" }
local acc, afkAcc, fpsFrames, fpsClock = 0, 0, 0, 0
Engine.fps = 60
Engine.showPerf = false

function Engine.reset()
  Game.terms, Game.data, Game.order, Game.events = {}, {}, {}, {}
  for _, t in ipairs({ Settings, Colors, Words, Keys, Rules }) do
    for k in pairs(t) do rawset(t, k, nil) end
  end
  Engine.errors, Engine.seen, Engine.loaded = {}, {}, 0
  Engine.colorCache = {}
end

local function check(cond, msg) if not cond then Engine.warn(msg, true) end end

function Engine.link()
  for _, name in ipairs(REQUIRED_RULES) do check(Rules[name], 'Missing Rule "' .. name .. '" (game/rules/' .. name .. '.kyo)') end
  for _, name in ipairs(REQUIRED_SCREENS) do check(Get("Screen", name), 'Missing Screen "' .. name .. '" (game/screens/' .. name .. '.kyo)') end
  check(Get("Player", Settings.player), "Settings.player is '" .. tostring(Settings.player) .. "' but there is no Player with that name")
  check(Get("Ghost", Settings.starter), "Settings.starter is '" .. tostring(Settings.starter) .. "' but there is no Ghost with that name")
  for _, a in ipairs(All("Attack")) do
    check(Get("Type", a.type), a.source .. ': Attack "' .. a.id .. '" has type "' .. a.type .. '" but there is no Type with that name')
    check(Get("Effect", a.effect), a.source .. ': Attack "' .. a.id .. '" has effect "' .. a.effect .. '" but there is no Effect with that name')
  end
  for _, g in ipairs(All("Ghost")) do
    check(Get("Type", g.type), g.source .. ': Ghost "' .. g.id .. '" has type "' .. g.type .. '" but there is no Type with that name')
    if not Get("Sprite", g.sprite) then g.sprite = "ghoul_fallback" end
    check(Get("Sprite", g.sprite), g.source .. ': Ghost "' .. g.id .. '" uses sprite "' .. g.sprite .. '" but there is no Sprite with that name')
    for _, m in ipairs(g.moves) do check(Get("Attack", m), g.source .. ': Ghost "' .. g.id .. '" knows move "' .. m .. '" but there is no Attack with that name') end
  end
  for _, e in ipairs(All("Enemy")) do
    if not Get("Sprite", e.sprite) then e.sprite = "townfolk_001" end
    check(Get("Sprite", e.sprite), e.source .. ': Enemy "' .. e.id .. '" uses sprite "' .. e.sprite .. '" which does not exist')
    for _, p in ipairs(e.party) do check(p == "random" or Get("Ghost", p), e.source .. ': Enemy "' .. e.id .. '" party has "' .. p .. '" (use a Ghost id or "random")') end
  end
  -- Legacy portal definitions remain loadable for content compatibility, but the
  -- giant_world build deliberately does not validate or use them as map links.
  if Settings.map ~= "giant_world" then
    for _, p in ipairs(All("Portal")) do
      check(Get("Map", p.map) and Get("Map", p.to), p.source .. ': Portal "' .. p.id .. '" - map "' .. p.map .. '" or "' .. p.to .. '" does not exist')
    end
  end
  for _, t in ipairs(All("Type")) do
    for _, field in ipairs({ "strong_against", "weak_against", "immune_to" }) do
      for _, o in ipairs(t[field]) do check(Get("Type", o), t.source .. ': Type "' .. t.id .. '" ' .. field .. ' has "' .. o .. '" but there is no Type with that name') end
    end
  end
  for _, m in ipairs(All("Map")) do
    for k in pairs(m.roadSpawns) do check(Get("Type", k) or Get("Ghost", k), m.source .. ': Map "' .. m.id .. '" roadSpawns has "' .. k .. '" - no Type or Ghost with that name') end
  end
  local common = 0
  for _, r in ipairs(All("Rarity")) do if r.oneIn <= 0 then common = common + 1 end end
  check(common == 1, "Rarity: exactly ONE rarity needs oneIn = 0 (the common one). Found " .. common)
  for _, r in ipairs(All("Region")) do
    for t, v in pairs(r.spawns) do
      check(Get("Type", t) or Get("Ghost", t), r.source .. ': Region "' .. r.id .. '" spawns "' .. t .. '" but there is no Type or Ghost with that name')
      check(type(SpawnWeight(v)) == "number", r.source .. ': Region "' .. r.id .. '" spawns ' .. t .. ' needs a number or { weight = 10, levels = { 1, 5 } }')
    end
    for e in pairs(r.enemies) do check(Get("Enemy", e), r.source .. ': Region "' .. r.id .. '" lists enemy "' .. e .. '" but there is no Enemy with that name') end
  end
  for _, q in ipairs(All("Quest")) do
    check(#q.goals > 0, q.source .. ': Quest "' .. q.id .. '" needs at least one goal')
    for _, goal in ipairs(q.goals) do
      check(Get("Goal", goal.kind or ""), q.source .. ': Quest "' .. q.id .. '" has goal kind "' .. tostring(goal.kind) .. '" but there is no Goal with that name (game/goals/)')
      local kind = Get("Goal", goal.kind or "")
      if kind and kind.onValidate then local msg = kind.onValidate(goal) if msg then check(false, q.source .. ': Quest "' .. q.id .. '" - ' .. msg) end end
    end
    for _, r in ipairs(q.rewards) do
      check(not r.item or Get("Item", r.item), q.source .. ': Quest "' .. q.id .. '" reward item "' .. tostring(r.item) .. '" does not exist')
      check(not r.ghost or Get("Ghost", r.ghost), q.source .. ': Quest "' .. q.id .. '" reward ghost "' .. tostring(r.ghost) .. '" does not exist')
    end
  end
  for _, kind in ipairs({ "Boss", "Store", "Trader", "QuestGiver" }) do
    for _, p in ipairs(All(kind)) do check(Get("Map", p.map), p.source .. ": " .. kind .. ' "' .. p.id .. '" stands on map "' .. p.map .. '" which does not exist') end
  end
  for _, gv in ipairs(All("QuestGiver")) do
    for _, id in ipairs(gv.quests) do check(Get("Quest", id), gv.source .. ': QuestGiver "' .. gv.id .. '" gives quest "' .. id .. '" which does not exist') end
  end
  for _, bs in ipairs(All("Boss")) do check(Get("Ghost", bs.ghost), bs.source .. ': Boss "' .. bs.id .. '" uses ghost "' .. bs.ghost .. '" which does not exist') end
  for _, st in ipairs(All("Store")) do
    for _, s in ipairs(st.stock) do check(Get("Item", s.item or ""), st.source .. ': Store "' .. st.id .. '" sells "' .. tostring(s.item) .. '" but there is no Item with that name') end
  end
  for id in pairs(Settings.startBag or {}) do check(Get("Item", id), 'Settings.startBag has "' .. id .. '" but there is no Item with that name') end
  Fire("linked")
end

function Engine.loadEverything()
  Engine.reset()
  Engine.loadAll()
  Engine.link()
  Engine.clearSounds()
end

function Engine.newState()
  local sound = not (S and S.sound == false)
  S = { screen = "title", map = Settings.map, px = 1, py = 1, steps = 0, turn = 0, trainer = Settings.startLevel, kills = 0, need = Settings.startNeed,
    afk = false, sound = sound, book = false, bookTab = "party", pediaPage = 0, boxPage = 0, partySlot = 1, bagIndex = 1, zoom = 0.5, zoomIndex = 1, dir = { 0, 1 }, faceX = 1,
    wearing = {}, wearables = {}, favorites = {},
    look = nil, unlockedClothes = {}, equippedClothes = {},
    shrineBest = 0, shrineSeen = {}, shrineRun = nil, shrinePlace = nil, shrineEnded = nil,
    kyo = Settings.startKyo or 0, quest = nil, msg = Word("press_start"), t = S and S.t or 0, shake = 0, wilds = {}, npcs = {}, party = {}, box = {},
    seen = {}, caught = {}, best = {}, bosses = {}, stores = {}, trades = {}, givers = {}, questsDone = {}, imported = {}, bag = Copy(Settings.startBag or {}), followers = {}, fpos = {}, discovered = {},
    npcReactions = {}, npcCompanions = {}, npcCompanionPos = {}, companionBanter = nil,
    skills = {}, shroomMarket = nil,
    spawnTimer = 0, enemyTimer = 0, turnTimer = 0, moveCd = 0, menuIndex = 1, uid = 1, vars = {}, stamina = 100, staminaMax = 100 }
end

function Engine.placeAtStart()
  S.px, S.py = World.map.start[1], World.map.start[2]
  S.rx, S.ry, S.followers, S.fpos = S.px, S.py, {}, {}
end

function HasSave() return love.filesystem.getInfo(ActiveSaveFile and ActiveSaveFile() or Settings.saveFile) ~= nil end

function NewGame()
  Engine.newState()
  Engine.safe(World.build, Settings.map)
  Engine.placeAtStart()
  S.worldVersion = 5
  if WorldGhosts and WorldGhosts.roll then WorldGhosts.roll(os.time()) end
  if GhoulRoster and GhoulRoster.roll then GhoulRoster.roll(os.time()) end
  if Character and Character.rollWorldCast then Character.rollWorldCast() end
  S.party[1] = nil
  if GiveItem then GiveItem("camp_kit", 1) GiveItem("ghost_jar", 4) GiveItem("bread", 2) GiveItem("berry", 2) end
  S.woke = false
  S.spirit, S.spiritMax = 8, 36
  Engine.safe(NewQuest)
  -- Unlock free starter clothes
  if Character then
    Character.ensureWardrobe()
    Character.unlockClothes("traveler_cloak")
    S.createLook = Character.defaultLook()
    S._afterCreate = "wake"
  end
  Go("character_create")
  Say("DESIGN YOUR LOOK")
  Fire("new_game")
end

function ContinueGame()
  Engine.newState()
  if not Engine.safe(LoadGame) then return NewGame() end
  S.fpos = {}
  if not S.quest then Engine.safe(NewQuest) end
  Go("explore")
  Say(Word("welcome_back"))
end

local function writeErrorLog()
  love.filesystem.write("kyo_errors.txt", "TURBO ENGINE " .. Engine.version .. " - " .. Engine.loaded .. " files loaded\n\n" .. table.concat(Engine.errors, "\n") .. "\n")
end

function Engine.boot()
  love.keyboard.setKeyRepeat(false)
  Engine.loadEverything()
  Engine.initDraw()
  Engine.newState()
  Engine.safe(World.build, Settings.map)
  Engine.placeAtStart()
  if Settings.title then love.window.setTitle(Settings.title .. " - Turbo Engine " .. Engine.version) end
  print("[KYO] engine " .. Engine.version .. " loaded " .. Engine.loaded .. " files, " .. #Engine.mods .. " mods, " .. #Engine.errors .. " problems")
  writeErrorLog()
  Fire("boot")
  if WebApi and WebApi.boot then WebApi.boot() end
end

function Engine.reload()
  local keep = S
  Engine.loadEverything()
  Engine.initDraw()
  S = keep
  Engine.safe(World.build, S.map)
  S.wilds, S.npcs, S.battle, S.intro, S.result, S.naming = {}, {}, nil, nil, nil, nil
  if S.screen ~= "title" and S.screen ~= "menu" then S.screen = "explore" end
  if not World.walkable(S.px, S.py) then Engine.placeAtStart() end
  S.rx, S.ry, S.fpos = S.px, S.py, {}
  if not QuestDef() then Engine.safe(NewQuest) else S.quest.flagFor = nil Engine.safe(UpdateQuestFlag) end
  Say(Word("reloaded"))
  writeErrorLog()
  -- F5 also snapshots a timestamped copy of the error log for debugging
  Engine.copyErrorLog()
  Fire("boot")
end

function Engine.copyErrorLog()
  -- Always refresh master log first (includes live Engine.errors)
  local body = "TURBO ENGINE " .. tostring(Engine.version or "?") .. " - " .. tostring(Engine.loaded or 0) .. " files loaded\n"
  body = body .. "TIME " .. tostring(os.date("%Y-%m-%d %H:%M:%S")) .. "\n\n"
  if Engine.errors and #Engine.errors > 0 then
    body = body .. table.concat(Engine.errors, "\n") .. "\n"
  else
    body = body .. "(no errors recorded yet)\n"
  end
  -- Also append last runtime message if any
  if S and S.msg then body = body .. "\nLAST MSG: " .. tostring(S.msg) .. "\n" end
  pcall(function() love.filesystem.write("kyo_errors.txt", body) end)
  local stamp = os.date("%Y%m%d_%H%M%S")
  local dest = "kyo_errors_copy_" .. stamp .. ".txt"
  local ok, err = pcall(function() love.filesystem.write(dest, body) end)
  local saveDir = "?"
  pcall(function() saveDir = love.filesystem.getSaveDirectory() end)
  -- Try system clipboard when available (LÖVE 11+)
  pcall(function()
    if love.system and love.system.setClipboardText then
      love.system.setClipboardText(body)
    end
  end)
  print("[KYO] error log copied to " .. dest)
  print("[KYO] save directory: " .. tostring(saveDir))
  if Say then
    Say(ok and ("LOG COPY: " .. dest) or ("LOG COPY FAILED"))
  end
  return dest
end

function Engine.currentScreen()
  return Get("Screen", S.screen)
end

function Go(name)
  local scr = Get("Screen", name)
  if not scr then Engine.warn('Go: there is no Screen "' .. tostring(name) .. '"', true) return end
  S.screen = name
  if scr.onEnter then Engine.safe(scr.onEnter) end
end

local function systems(hook, ...)
  for _, sys in ipairs(All("System")) do
    if sys.enabled and sys[hook] then Engine.safe(sys[hook], ...) end
  end
end

function Engine.tick()
  local dt = love.timer and love.timer.getDelta() or (1/60)
  if Movement and Movement.update then Movement.update(dt) end
  if Transform and Transform.update then Transform.update(dt) end
  if Spirit and Spirit.update then Spirit.update(dt) end
  if GhostInspect and GhostInspect.update then GhostInspect.update(dt) end
  if BlackMarket and BlackMarket.update then BlackMarket.update(dt) end
  if WorldBoss and WorldBoss.update then WorldBoss.update(dt) end
  if Loot and Loot.trySpawnArmoredSkeleton and (S.t or 0) % 600 == 0 then Loot.trySpawnArmoredSkeleton() end
  S.t = S.t + 1
  if S.shake > 0 then S.shake = S.shake - 1 end
  Engine.safe(World.animate)
  if S.battle then Engine.safe(BattleTick) end
  local scr = Engine.currentScreen()
  if scr and scr.onTick then Engine.safe(scr.onTick) end
  systems("onTick")
end

function Engine.update(dt)
  if WebApi and WebApi.tick then WebApi.tick(dt) end
  if Music and Music.update then Music.update(dt) end
  -- Cap catch-up work after stalls; fixed simulation ticks keep movement consistent
  -- while the renderer can run at the monitor refresh rate.
  dt = math.max(0, math.min(dt or 0, 0.1))
  acc = math.min(acc + dt, 0.25)
  local steps = 0
  while acc >= 1 / 60 and steps < 5 do
    acc = acc - 1 / 60
    Engine.tick()
    steps = steps + 1
  end
  if steps == 5 and acc >= 1 / 60 then acc = 0 end
  if S.screen == "explore" and not S.book and not Engine.showErrors then Engine.safe(ExploreUpdate, dt) end
  if ShroomMarket and ShroomMarket.update then Engine.safe(ShroomMarket.update, dt) end
  afkAcc = afkAcc + dt
  if afkAcc >= (Settings.afkDelay or 0.24) then
    afkAcc = afkAcc % (Settings.afkDelay or 0.24)
    if S.afk and not S.book and not Engine.showErrors then Engine.safe(AfkStep) end
  end
  fpsFrames, fpsClock = fpsFrames + 1, fpsClock + dt
  if fpsClock >= 0.5 then
    Engine.fps = math.floor(fpsFrames / fpsClock + 0.5)
    fpsFrames, fpsClock = 0, 0
  end
end

function Engine.draw()
  love.graphics.setCanvas(Engine.canvas)
  love.graphics.clear(0, 0, 0, 1)
  love.graphics.origin()
  local scr = Engine.currentScreen()
  if scr and scr.onDraw then
    if scr.centerFixed320 then
      -- Legacy screens use a 320px UI design. Centre that design instead of
      -- pinning it to the left edge on 16:9/ultrawide canvases.
      Engine.centerFixedDraw = true
      love.graphics.push()
      love.graphics.translate(math.floor(((Engine.W or 320) - 320) / 2), 0)
      if UI and UI.beginFrame then UI.beginFrame() end
      Engine.safe(scr.onDraw)
      love.graphics.pop()
      Engine.centerFixedDraw = false
      local W, H = Engine.W or 320, Engine.H or 320
      local x = math.floor((W - 320) / 2)
      if x > 12 then
        Box(0, 0, x - 12, H, "#05040a")
        Box(x + 332, 0, math.max(0, W - (x + 332)), H, "#05040a")
        Box(0, 0, 6, H, "blood")
        Box(W - 6, 0, 6, H, "blood")
        Frame(x - 10, 8, 340, H - 16, "kyo")
        Frame(x - 6, 12, 332, H - 24, "edge")
      end
    else
      Engine.centerFixedDraw = false
      if UI and UI.beginFrame then UI.beginFrame() end
      Engine.safe(scr.onDraw)
    end
  end
  systems("onDraw")
  local global = Get("Screen", "global")
  if global and global.onDraw then Engine.safe(global.onDraw) end
  love.graphics.setCanvas()
  local ww, wh = love.graphics.getDimensions()
  -- Prefer the largest integer scale that fits the window so pixel art stays
  -- crisp. When the leftover letterbox is large, allow a half-step (n+0.5)
  -- only if it still uses nearest-neighbour sampling (canvas filter is nearest).
  local raw = math.min(ww / Engine.W, wh / Engine.H)
  -- Integer scale only. Fractional scales softens every pixel font glyph.
  local sc = raw >= 1 and math.max(1, math.floor(raw + 0.0001)) or math.max(0.25, raw)
  Engine.scale, Engine.ox, Engine.oy = sc, math.floor((ww - Engine.W * sc) / 2), math.floor((wh - Engine.H * sc) / 2)
  love.graphics.clear(ToColor("bg"))
  love.graphics.setColor(1, 1, 1, 1)
  love.graphics.setDefaultFilter("nearest", "nearest")
  if Engine.canvas and Engine.canvas.setFilter then Engine.canvas:setFilter("nearest", "nearest") end
  love.graphics.draw(Engine.canvas, Engine.ox, Engine.oy, 0, sc, sc)
  if Engine.showPerf then
    love.graphics.setColor(0.04, 0.06, 0.09, 0.88)
    love.graphics.rectangle("fill", 6, 6, 112, 22)
    love.graphics.setColor(0.65, 1, 0.78, 1)
    love.graphics.setFont(love.graphics.newFont(11))
    love.graphics.print("FPS " .. tostring(Engine.fps or 0) .. "  V2", 12, 11)
  end
  if Engine.showErrors and #Engine.errors > 0 then Engine.drawErrors() end
end

function Engine.key(key)
  if Engine.showErrors and #Engine.errors > 0 then
    if key == "return" or key == "kpenter" or key == "escape" or IsKey(key, "errors") then Engine.showErrors = false end
    if IsKey(key, "reload") then Engine.reload() end
    return
  end
  if IsKey(key, "reload") then return Engine.reload() end
  if IsKey(key, "errors") then Engine.showErrors = true; if Engine.copyErrorLog then Engine.copyErrorLog() end return end
  if key == "f5" and (love.keyboard.isDown("lctrl") or love.keyboard.isDown("rctrl")) then
    if Engine.copyErrorLog then Engine.copyErrorLog() end
    return
  end
  if key == "f3" then Engine.showPerf = not Engine.showPerf return end
  if key == "f4" and S then
    local weather = { "clear", "rain", "snow", "fog", "embers" }
    local at = 1
    for i, v in ipairs(weather) do if v == (S.weather or "clear") then at = i break end end
    S.weather = weather[at % #weather + 1]
    Say("WEATHER: " .. string.upper(S.weather))
    return
  end
  if S and S.screen == "explore" and not S.book and not S.battle then
    if SessionNet and SessionNet.pvp and SessionNet.pvp.phase == "incoming" then
      if key == "p" or key == "P" then SessionNet.acceptPvp() return end
      if key == "n" or key == "N" then SessionNet.declinePvp() return end
    end
    if key == "f6" and SessionNet and SessionNet.tryChallengeNearest then SessionNet.tryChallengeNearest() return end
    if key == "kp+" or key == "equals" or key == "plus" then
      if World.zoomIn then World.zoomIn() end
      return
    end
    if key == "kp-" or key == "minus" then
      if World.zoomOut then World.zoomOut() end
      return
    end
    if key == "0" then
      S.zoomIndex = 1
      if World.ensureZoom then World.ensureZoom() end
      return
    end
  end
  local scr = Engine.currentScreen()
  if not (scr and scr.captureKeys) then
    local global = Get("Screen", "global")
    if global and global.onKey and Engine.safe(global.onKey, key) then return end
    systems("onKey", key)
  end
  if scr and scr.onKey then Engine.safe(scr.onKey, key) end
end

function Engine.text(t)
  local scr = Engine.currentScreen()
  if scr and scr.onText then Engine.safe(scr.onText, t) end
end

function Engine.wheel(dy)
  if not S then return end
  local scr = Engine.currentScreen()
  if scr and scr.onWheel then
    Engine.safe(scr.onWheel, dy)
    return
  end
  if S.screen == "explore" then
    if dy > 0 then
      if World.zoomIn then World.zoomIn() end
    else
      if World.zoomOut then World.zoomOut() end
    end
    return
  end
  -- Do not silently swallow mouse-wheel input on menus. Screens with long lists
  -- should implement their own onWheel; otherwise map the wheel to the common selection.
  local fields = {
    hub = { "hubIndex", 12 }, pause = { "pauseIndex", 9 }, bag = { "bagIndex", nil },
    party = { "recentSel", nil }, town_dialog = { "townTalk", nil }, reward = { "rewardIndex", nil },
    giver = { "giverIndex", 2 }, worldmap = { "mapIndex", nil }, quests = { "questIndex", nil },
    boobook = { "pediaIndex", nil }, wardrobe = { "wardrobeIndex", nil }, store = { "storeIndex", nil },
  }
  local spec = fields[S.screen]
  if spec then
    local key, count = spec[1], spec[2]
    local current = S[key]
    if type(current) == "number" then
      if not count then count = math.max(1, current + 1) end
      S[key] = math.max(1, math.min(count, current + (dy < 0 and 1 or -1)))
    end
  end
end

local function canvasPointer(x, y)
  local sc = Engine.scale or 1
  return (x - (Engine.ox or 0)) / sc, (y - (Engine.oy or 0)) / sc
end

function Engine.moveMouse(x, y, dx, dy)
  if not S then return end
  local vx, vy = canvasPointer(x, y)
  local scale = Engine.scale or 1
  local scr = Engine.currentScreen()
  if scr and scr.centerFixed320 then vx = vx - math.floor(((Engine.W or 320) - 320) / 2) end
  systems("onMouseMove", vx, vy, (dx or 0) / scale, (dy or 0) / scale)
  if scr and scr.onMouseMove then Engine.safe(scr.onMouseMove, vx, vy, (dx or 0) / scale, (dy or 0) / scale) end
end

function Engine.releaseMouse(x, y, button)
  if not S then return end
  local vx, vy = canvasPointer(x, y)
  local scr = Engine.currentScreen()
  if scr and scr.centerFixed320 then vx = vx - math.floor(((Engine.W or 320) - 320) / 2) end
  systems("onMouseRelease", vx, vy, button)
  if scr and scr.onMouseRelease then Engine.safe(scr.onMouseRelease, vx, vy, button) end
end

function Engine.resize()
  Engine.sizeCanvas()
  Engine.initDraw()
end

function Engine.click(x, y, button)
  if Engine.showErrors and #Engine.errors > 0 then Engine.showErrors = false return end
  local vx, vy = (x - (Engine.ox or 0)) / (Engine.scale or 1), (y - (Engine.oy or 0)) / (Engine.scale or 1)
  if vx < 0 or vy < 0 or vx > Engine.W or vy > Engine.H then return end
  local scr = Engine.currentScreen()
  if scr and scr.centerFixed320 then vx = vx - math.floor(((Engine.W or 320) - 320) / 2) end
  if UI and UI.fire and UI.fire(vx, vy) then return end
  systems("onClick", vx, vy, button)
  if scr and scr.onClick then Engine.safe(scr.onClick, vx, vy, button) end
end


-- Drag-and-drop audio into the game window → save to music/ folder
function love.filedropped(file)
  local name = file:getFilename() or "track.ogg"
  local base = name:match("([^/\\]+)$") or "track.ogg"
  local lower = base:lower()
  if not (lower:match("%.ogg$") or lower:match("%.wav$") or lower:match("%.mp3$")) then
    if Say then Say("NOT AN AUDIO FILE") end
    return
  end
  pcall(love.filesystem.createDirectory, "music")
  local ok, err = pcall(function()
    file:open("r")
    local data = file:read()
    file:close()
    love.filesystem.write("music/" .. base, data)
  end)
  if ok then
    if Say then Say("MUSIC ADDED: " .. base:upper()) end
    if Music and Music.scan then Music.scan() end
    if Music and Music.playPath then Music.playPath("music/" .. base) end
  else
    if Say then Say("COULD NOT SAVE MUSIC") end
  end
end
