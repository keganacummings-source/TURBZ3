-- Menu chrome. Every screen should go through these so the game reads as one interface:
-- dark sheets, a blood/gold rail, 16px titles, and rows tall enough to click.

UI = UI or {}

UI.PAD = 16
UI.ROW = 36
UI.TITLE = 16
UI.BODY = 8
UI.HELP = 8

function UI.wh()
  return Engine.W or 480, Engine.H or 480
end

-- Centred content column for menus that used to live in a 320px strip.
function UI.stage(maxW)
  local W, H = UI.wh()
  local w = math.min(maxW or 680, W - 40)
  local h = H - 28
  local x = math.floor((W - w) / 2)
  return x, 14, w, h, W, H
end

function UI.panel(x, y, w, h, title)
  x, y = math.floor(x), math.floor(y)
  w, h = math.floor(w), math.floor(h)
  if w < 8 or h < 8 then return end
  Box(x + 6, y + 7, w, h, "#00000099")
  Box(x, y, w, h, "panel")
  Box(x, y, w, math.min(36, h), "panel2")
  Box(x, y, 4, h, "blood")
  Box(x + 4, y, 2, h, "kyo")
  Frame(x, y, w, h, "kyo")
  if w > 16 and h > 16 then Frame(x + 6, y + 6, w - 12, h - 12, "edge") end
  local close = S and S.screen ~= "menu" and S.screen ~= "explore" and S.screen ~= "battle" and S.screen ~= "title" and S.screen ~= "intro"
  local titleW = w - (close and 56 or 32)
  if title and title ~= "" then
    TextFit(Upper(tostring(title)), x + 16, y + 24, math.max(40, titleW), "kyo", 8, 8)
  end
  if close then
    local cx, cy, cw, ch = x + w - 30, y + 8, 22, 22
    Box(cx, cy, cw, ch, "panel")
    Frame(cx, cy, cw, ch, "blood")
    Text("X", cx + 7, cy + 16, "kyo", 8)
    UI.closeRect = { x = cx, y = cy, w = cw, h = ch }
  end
end

function UI.dimBackdrop()
  local W, H = UI.wh()
  Box(0, 0, W, H, "#05040ad4")
  Box(0, 0, W, 3, "kyo")
  Box(0, H - 3, W, 3, "blood")
end

function UI.helpBar(text)
  local W, H = UI.wh()
  local h = 22
  local y = H - h
  Box(0, y, W, h, "panel")
  Box(0, y, W, 2, "kyo")
  TextFit(tostring(text or ""), 14, y + 16, W - 28, "ink", 8, 8)
end

function UI.tabs(tabs, active, x, y, w)
  local n = #tabs
  if n < 1 then return end
  local tw = math.floor(w / n)
  UI._tabs = { x = x, y = y, w = tw, h = 28, n = n }
  for i, label in ipairs(tabs) do
    local tx = x + (i - 1) * tw
    local on = (label == active) or (i == active)
    Box(tx, y, tw - 4, 28, on and "panel2" or "panel")
    Frame(tx, y, tw - 4, 28, on and "kyo" or "edge")
    if on then Box(tx, y, tw - 4, 3, "kyo") end
    TextFit(Upper(tostring(label)), tx + 6, y + 18, tw - 16, on and "kyo" or "dim", 8, 8, "center")
  end
end

function UI.listRow(x, y, w, h, selected, label, sub, color, action)
  h = h or UI.ROW
  Box(x + 2, y + 2, w, h, "#00000055")
  Box(x, y, w, h, selected and "panel2" or "panel")
  Frame(x, y, w, h, selected and "kyo" or "edge")
  if selected then Box(x, y, 4, h, "kyo") end
  local text = Upper(tostring(label or ""))
  local subText = (sub and sub ~= "" and h >= 36) and tostring(sub) or nil
  if subText then
    TextFit(text, x + 14, y + 16, w - 28, selected and "kyo" or (color or "ink"), 8, 8)
    TextFit(subText, x + 14, y + h - 8, w - 28, "dim", 8, 8)
  else
    TextFit(text, x + 14, y + math.floor(h / 2) + 4, w - 28, selected and "kyo" or (color or "ink"), 8, 8)
  end
  if type(action) == "function" then UI.track(x, y, w, h, action) end
end

function UI.button(x, y, w, h, label, selected, action)
  Box(x + 2, y + 3, w, h, "#00000066")
  Box(x, y, w, h, selected and "panel2" or "panel")
  Frame(x, y, w, h, selected and "kyo" or "edge")
  if selected then Box(x, y, 4, h, "kyo") end
  TextFit(Upper(tostring(label)), x + 8, y + math.floor(h / 2) + 4, w - 16, selected and "kyo" or "ink", 8, 8, "center")
  if type(action) == "function" then UI.track(x, y, w, h, action) end
end

function UI.beginFrame()
  UI._hits = {}
  UI._tabs = nil
  UI.closeRect = nil
end

function UI.track(x, y, w, h, action)
  UI._hits = UI._hits or {}
  UI._hits[#UI._hits + 1] = { x = x, y = y, w = w, h = h, action = action }
end

function UI.fire(mx, my)
  if UI.closeRect and UI.hit(mx, my, UI.closeRect.x, UI.closeRect.y, UI.closeRect.w, UI.closeRect.h) then
    if Engine and Engine.key then Engine.key("escape") end
    return true
  end
  if UI._tabs and UI.hit(mx, my, UI._tabs.x, UI._tabs.y, UI._tabs.w * UI._tabs.n, UI._tabs.h) then
    local i = math.floor((mx - UI._tabs.x) / UI._tabs.w) + 1
    if S then
      if S.screen == "camp" then S.campTab = Clamp(i, 1, 3); Play("step"); return true end
      if S.screen == "armor" then S.armorTab = Clamp(i, 1, 3); S.armorSel = 1; Play("step"); return true end
    end
  end
  local hits = UI._hits or {}
  for i = #hits, 1, -1 do
    local b = hits[i]
    if UI.hit(mx, my, b.x, b.y, b.w, b.h) then
      b.action()
      return true
    end
  end
  return false
end

function UI.navList(key, index, count)
  if count < 1 then return 1 end
  if IsKey(key, "up") then return (index - 2) % count + 1 end
  if IsKey(key, "down") then return index % count + 1 end
  return index
end

function UI.navTabs(key, index, count)
  if count < 1 then return 1 end
  if key == "tab" or IsKey(key, "right") then return index % count + 1 end
  if IsKey(key, "left") then return (index - 2) % count + 1 end
  return index
end

UI.tooltip = nil

function UI.setTooltip(lines, mx, my)
  if not lines or #lines == 0 then UI.tooltip = nil return end
  UI.tooltip = { lines = lines, x = mx or 0, y = my or 0 }
end

function UI.clearTooltip()
  UI.tooltip = nil
end

function UI.drawTooltip()
  local t = UI.tooltip
  if not t or not t.lines or #t.lines == 0 then return end
  local pad, lineH = 10, 14
  local maxW = 0
  for _, line in ipairs(t.lines) do
    maxW = math.max(maxW, Font(8):getWidth(tostring(line)))
  end
  local w = math.min(420, maxW + pad * 2)
  local h = #t.lines * lineH + pad * 2
  local x = math.floor(t.x + 14)
  local y = math.floor(t.y + 14)
  local W, H = UI.wh()
  if x + w > W - 6 then x = W - w - 6 end
  if y + h > H - 6 then y = math.max(4, t.y - h - 8) end
  if x < 4 then x = 4 end
  if y < 4 then y = 4 end
  Box(x + 3, y + 3, w, h, "#00000088")
  Box(x, y, w, h, "panel")
  Frame(x, y, w, h, "kyo")
  Box(x, y, 3, h, "blood")
  for i, line in ipairs(t.lines) do
    local col = (i == 1) and "kyo" or "ink"
    Text(tostring(line), x + pad, y + pad + i * lineH - 2, col, 8)
  end
end

function UI.moveTooltipLines(moveId)
  local a = Get("Attack", moveId)
  if not a then return { Upper(tostring(moveId)), "UNKNOWN MOVE" } end
  local lines = {
    Upper(a.name or moveId),
    Upper(tostring(a.type or "?")) .. "  PWR " .. tostring(a.power or 0),
    "ACC " .. tostring(a.accuracy or 100) .. "%  CRIT " .. tostring(a.crit or 0) .. "%",
  }
  local function addWrapped(text)
    if not text or text == "" then return end
    local wrapped = WrapText and WrapText(Upper(tostring(text)), 280, 8) or { Upper(tostring(text)) }
    for _, line in ipairs(wrapped) do lines[#lines + 1] = line end
  end
  if a.effect and a.effect ~= "" and a.effect ~= "none" then
    local eff = Get("Effect", a.effect)
    local about = (eff and (eff.about or eff.name)) or a.effect
    addWrapped("FX: " .. tostring(about))
  end
  if a.about and a.about ~= "" then addWrapped(a.about) end
  return lines
end

function UI.hit(mx, my, x, y, w, h)
  return mx >= x and my >= y and mx < x + w and my < y + h
end

function UI.fitRows(top, bottom, rowH)
  rowH = rowH or UI.ROW
  if rowH < 1 then rowH = 1 end
  return math.max(1, math.floor(((bottom or 0) - (top or 0)) / rowH))
end

function UI.clampOff(off, count, view)
  local maxOff = math.max(0, (count or 0) - math.max(1, view or 1))
  off = math.floor(off or 0)
  if off < 0 then return 0 end
  if off > maxOff then return maxOff end
  return off
end

-- Freeze click arguments. A closure created inside a for-loop otherwise
-- sees the loop's last value when the player actually clicks.
function UI.on(fn, a, b, c, d)
  return function()
    return fn(a, b, c, d)
  end
end
