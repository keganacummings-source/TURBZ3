-- Drawing words: Box, Frame, Text, Fill, Bar, DrawSprite, DrawGhost, DrawPlayer, HSL
local fonts = {}
Engine.colorCache = {}
Engine.imageCache = {}
local imageOrder = {}
local IMAGE_CAP = 64

local function rememberImage(path)
  for i = #imageOrder, 1, -1 do
    if imageOrder[i] == path then table.remove(imageOrder, i) end
  end
  imageOrder[#imageOrder + 1] = path
  while #imageOrder > IMAGE_CAP do
    local old = table.remove(imageOrder, 1)
    local img = Engine.imageCache[old]
    Engine.imageCache[old] = nil
    if img and img ~= false and img.release then pcall(function() img:release() end) end
  end
end

-- Load a PNG once. love.js sometimes says getInfo is missing, or refuses
-- newImage(path), while the same bytes still decode through ImageData.
function LoadImage(path)
  if not path or path == "" then return nil end
  local cached = Engine.imageCache[path]
  if cached ~= nil then
    if cached ~= false then rememberImage(path) end
    return cached ~= false and cached or nil
  end
  local img
  local ok, made = pcall(love.graphics.newImage, path)
  if ok and made then img = made end
  if not img and love.filesystem.read then
    local bytes = love.filesystem.read(path)
    if type(bytes) == "string" and #bytes > 8 then
      local fdOk, fd = pcall(love.filesystem.newFileData, bytes, "tex.png")
      if fdOk and fd and love.image and love.image.newImageData then
        local idOk, data = pcall(love.image.newImageData, fd)
        if idOk and data then
          local imOk, made2 = pcall(love.graphics.newImage, data)
          if imOk and made2 then img = made2 end
        end
      end
    end
  end
  if not img then
    Engine.imageCache[path] = false
    return nil
  end
  img:setFilter("nearest", "nearest")
  Engine.imageCache[path] = img
  rememberImage(path)
  return img
end

function DrawImage(path, x, y, w, h)
  local img = LoadImage(path)
  if not img then return false end
  love.graphics.setColor(1, 1, 1, 1)
  local iw, ih = img:getWidth(), img:getHeight()
  love.graphics.draw(img, x, y, 0, (w or iw) / iw, (h or ih) / ih)
  return true
end

-- The canvas tracks the WINDOW aspect ratio (fixed 320 tall) so the world reaches
-- the screen edges instead of being letter-boxed. Recreated on boot + window resize.
function Engine.sizeCanvas()
  local ww, wh = 1280, 720
  local ok, a, b = pcall(love.graphics.getDimensions)
  if ok and a and a > 0 and b and b > 0 then ww, wh = a, b end
  -- Higher logical resolution keeps UI readable when integer-scaled fullscreen.
  local base = Settings.height or 480
  if base < 400 then base = 480 end
  Engine.H = base
  Engine.W = Clamp(math.floor(base * (ww / math.max(1, wh)) + 0.5), 480, 2560)
  Engine.canvas = love.graphics.newCanvas(Engine.W, Engine.H)
  if Engine.canvas and Engine.canvas.setFilter then
    Engine.canvas:setFilter("nearest", "nearest")
  end
end

function Engine.initDraw()
  love.graphics.setDefaultFilter("nearest", "nearest")
  love.graphics.setLineStyle("rough")
  Engine.sizeCanvas()
  fonts = {}
  Engine.colorCache = {}
  Engine.boundsCache = {}
  Engine.imageCache = {}
end

function HSL(h, s, l)
  h, s, l = (h % 360) / 360, s / 100, l / 100
  local function f(p, q, t)
    if t < 0 then t = t + 1 end
    if t > 1 then t = t - 1 end
    if t < 1 / 6 then return p + (q - p) * 6 * t end
    if t < 1 / 2 then return q end
    if t < 2 / 3 then return p + (q - p) * (2 / 3 - t) * 6 end
    return p
  end
  local q = l < 0.5 and l * (1 + s) or l + s - l * s
  local p = 2 * l - q
  return { f(p, q, h + 1 / 3), f(p, q, h), f(p, q, h - 1 / 3), 1 }
end

function ToColor(c, depth)
  if type(c) == "table" then return c end
  if type(c) ~= "string" then return { 1, 0, 1, 1 } end
  local cached = Engine.colorCache[c]
  if cached then return cached end
  local named = rawget(Colors, c)
  if named and (depth or 0) < 5 then return ToColor(named, (depth or 0) + 1) end
  local hex = c:match("^#(%x+)$")
  local col = { 1, 0, 1, 1 }
  if hex and #hex == 3 then hex = hex:sub(1, 1):rep(2) .. hex:sub(2, 2):rep(2) .. hex:sub(3, 3):rep(2) end
  if hex and (#hex == 6 or #hex == 8) then
    col = { tonumber(hex:sub(1, 2), 16) / 255, tonumber(hex:sub(3, 4), 16) / 255, tonumber(hex:sub(5, 6), 16) / 255,
      #hex == 8 and tonumber(hex:sub(7, 8), 16) / 255 or 1 }
  end
  Engine.colorCache[c] = col
  return col
end

function SetColor(c) love.graphics.setColor(ToColor(c)) end

-- Pixel font: PressStart2P is only sharp at multiples of 8.
-- Snap every requested size to 8 / 16 / 24 so glyphs never soft-scale.
local PIXEL_SIZES = { 8, 16, 24 }
local function snapPixelSize(size)
  size = tonumber(size) or 8
  if size <= 8 then return 8 end
  if size <= 16 then return 16 end
  return 24
end

function Font(size)
  size = snapPixelSize(size)
  if not fonts[size] then
    local path = Settings.font
    local f
    if path and love.filesystem.getInfo(path) then
      f = love.graphics.newFont(path, size)
    else
      f = love.graphics.newFont(size)
    end
    f:setFilter("nearest", "nearest")
    -- Hinting off helps some platforms keep blocky edges
    if f.setHinting then pcall(function() f:setHinting("none") end) end
    fonts[size] = f
  end
  return fonts[size]
end

function PixelSize(size)
  return snapPixelSize(size)
end

function Box(x, y, w, h, color)
  SetColor(color)
  love.graphics.rectangle("fill", math.floor(x), math.floor(y), w, h)
end

function Frame(x, y, w, h, color)
  SetColor(color)
  love.graphics.setLineWidth(1)
  love.graphics.rectangle("line", math.floor(x) + 0.5, math.floor(y) + 0.5, w - 1, h - 1)
end

function Fill(color)
  -- A full-canvas background should never be shifted with a centred legacy panel.
  if Engine.centerFixedDraw then
    love.graphics.push()
    love.graphics.origin()
    Box(0, 0, Engine.W, Engine.H, color)
    love.graphics.pop()
  else
    Box(0, 0, Engine.W, Engine.H, color)
  end
end

-- y is the bottom line of the text (same as the original HTML game)
function Text(s, x, y, color, size)
  size = PixelSize(size or 8)
  local str = tostring(s or "")
  local logicalWidth = Engine.centerFixedDraw and 320 or (Engine.W or 320)
  local available = math.max(16, logicalWidth - (x or 0) - 4)
  -- Prefer size 8; never go below 8 (sub-8 softens PressStart2P)
  local f = Font(size)
  if f:getWidth(str) > available and size > 8 then
    size = 8
    f = Font(8)
  end
  love.graphics.setFont(f)
  SetColor(color or "ink")
  -- Integer positions only — subpixel print is a top cause of fuzzy glyphs
  love.graphics.print(str, math.floor(x + 0.5), math.floor((y or 0) - size + 0.5))
end

-- V2 layout helpers: keep labels inside panels and support centred UI text.
-- Text remains backwards compatible with all existing game/mod scripts.
function TextFit(s, x, y, maxWidth, color, size, minSize, align)
  size = PixelSize(size or 8)
  minSize = 8  -- never soft-scale the pixel font
  local str = tostring(s or "")
  local f = Font(size)
  if f:getWidth(str) > maxWidth and size > 8 then
    size = 8
    f = Font(8)
  end
  if f:getWidth(str) > maxWidth then
    while #str > 3 and Font(8):getWidth(str .. "...") > maxWidth do str = str:sub(1, -2) end
    str = str .. (#str < #tostring(s or "") and "..." or "")
  end
  local measured = Font(size):getWidth(str)
  if align == "center" then x = x + math.max(0, (maxWidth - measured) / 2)
  elseif align == "right" then x = x + math.max(0, maxWidth - measured) end
  Text(str, x, y, color, size)
end

-- Break a line into rows that fit. Used by tooltips so nothing collapses to "...".
function WrapText(s, maxWidth, size)
  size = PixelSize(size or 8)
  maxWidth = math.max(24, maxWidth or 200)
  local f = Font(size)
  local lines, cur = {}, ""
  local function pushWord(word)
    if cur == "" then cur = word
    elseif f:getWidth(cur .. " " .. word) <= maxWidth then cur = cur .. " " .. word
    else
      lines[#lines + 1] = cur
      cur = word
    end
    while f:getWidth(cur) > maxWidth and #cur > 1 do
      local cut = cur
      while #cut > 1 and f:getWidth(cut) > maxWidth do cut = cut:sub(1, -2) end
      lines[#lines + 1] = cut
      cur = cur:sub(#cut + 1)
    end
  end
  for word in tostring(s or ""):gmatch("%S+") do pushWord(word) end
  if cur ~= "" then lines[#lines + 1] = cur end
  if #lines == 0 then lines[1] = "" end
  return lines
end

function TextCenter(s, cx, y, color, size)
  size = size or 8
  local str = tostring(s or "")
  Text(str, math.floor(cx - Font(size):getWidth(str) / 2), y, color, size)
end

function Panel(x, y, w, h, fill, outline)
  Box(x, y, w, h, fill or "#171b2a")
  Frame(x, y, w, h, outline or "#69728b")
end

function Bar(x, y, w, value, max, color)
  Box(x, y, w, 8, "bar_back")
  Box(x, y, math.max(0, w * math.max(0, value) / math.max(1, max)), 8, color)
  Frame(x, y, w, 8, "ink")
end

local spriteBake = {}

local function gridsOf(sp)
  if sp.frames and #sp.frames > 0 then return sp.frames end
  if #sp > 0 then return { sp } end
  return nil
end

-- One image per sprite. Drawing every pixel as its own rectangle stalled towns.
local function bakedSprite(id)
  local hit = spriteBake[id]
  if hit ~= nil then return hit or nil end
  local sp = Get("Sprite", id)
  local grids = sp and gridsOf(sp)
  if not grids or not love.image or not love.image.newImageData then
    spriteBake[id] = false
    return nil
  end
  local n, h, w = #grids, 0, 0
  for _, rows in ipairs(grids) do
    h = math.max(h, #rows)
    for _, row in ipairs(rows) do if type(row) == "string" then w = math.max(w, #row) end end
  end
  if w < 1 or h < 1 then spriteBake[id] = false return nil end
  local ok, data = pcall(love.image.newImageData, w * n, h)
  if not ok or not data then spriteBake[id] = false return nil end
  local pal = sp.palette or {}
  for fi, rows in ipairs(grids) do
    local ox = (fi - 1) * w
    for yy, row in ipairs(rows) do
      if type(row) == "string" then
        for xx = 1, #row do
          local ch = row:sub(xx, xx)
          if ch ~= "." and ch ~= " " then
            local col = ToColor(pal[ch] or "#ffffff")
            data:setPixel(ox + xx - 1, yy - 1, col[1], col[2], col[3], col[4] or 1)
          end
        end
      end
    end
  end
  local imgOk, img = pcall(love.graphics.newImage, data)
  if not imgOk or not img then spriteBake[id] = false return nil end
  img:setFilter("nearest", "nearest")
  spriteBake[id] = { img = img, w = w, h = h, n = n, fps = sp.fps or 4, quads = {} }
  return spriteBake[id]
end

function DrawSprite(id, x, y, scale, palette)
  local sp = Get("Sprite", id)
  if not sp then Box(x, y, 8 * (scale or 1), 8 * (scale or 1), "#ff00ff") return end
  local s = scale or 1
  if palette == nil then
    local b = bakedSprite(id)
    if b then
      local frame = 0
      if b.n > 1 then frame = math.floor(Tick() * b.fps / 60) % b.n end
      local q = b.quads[frame]
      if not q then
        q = love.graphics.newQuad(frame * b.w, 0, b.w, b.h, b.img:getDimensions())
        b.quads[frame] = q
      end
      local dw = math.max(1, math.floor(b.w * s + 0.5))
      local dh = math.max(1, math.floor(b.h * s + 0.5))
      love.graphics.setColor(1, 1, 1, 1)
      love.graphics.draw(b.img, q, math.floor(x), math.floor(y), 0, dw / b.w, dh / b.h)
      return
    end
  end
  local rows = sp
  if #sp.frames > 0 then rows = sp.frames[math.floor(Tick() * sp.fps / 60) % #sp.frames + 1] end
  local pal = palette or sp.palette
  for yy = 1, #rows do
    local row = rows[yy]
    for xx = 1, #row do
      local ch = row:sub(xx, xx)
      if ch ~= "." and ch ~= " " then
        SetColor(pal[ch] or "#ffffff")
        love.graphics.rectangle("fill", x + (xx - 1) * s, y + (yy - 1) * s, s, s)
      end
    end
  end
end

Engine.boundsCache = {}
-- the box around the visible pixels of a sprite: { left, top, right, bottom }
function SpriteBounds(id)
  local c = Engine.boundsCache[id]
  if c then return c end
  local sp = Get("Sprite", id)
  local x0, y0, x1, y1 = 999, 999, -1, -1
  if sp then
    for _, rows in ipairs(#sp.frames > 0 and sp.frames or { sp }) do
      for yy = 1, #rows do
        for xx = 1, #rows[yy] do
          local ch = rows[yy]:sub(xx, xx)
          if ch ~= "." and ch ~= " " then x0, y0, x1, y1 = math.min(x0, xx - 1), math.min(y0, yy - 1), math.max(x1, xx - 1), math.max(y1, yy - 1) end
        end
      end
    end
  end
  c = x1 < 0 and { 0, 0, 7, 7 } or { x0, y0, x1, y1 }
  Engine.boundsCache[id] = c
  return c
end

local function topLeft(id, cx, cy, s)
  local b = SpriteBounds(id)
  return math.floor(cx - (b[1] + b[3] + 1) * s / 2 + 0.5), math.floor(cy - (b[2] + b[4] + 1) * s / 2 + 0.5)
end

-- draw a sprite so its visible pixels are centred on cx, cy (used for every tile)
function DrawSpriteAt(id, cx, cy, scale, palette)
  local x, y = topLeft(id, cx, cy, scale or 1)
  DrawSprite(id, x, y, scale or 1, palette)
end

-- Sprite scale is stable across levels: level changes stats, not the footprint of a 32x32 asset.
-- Image-backed sprites keep their aspect ratio and fit within a consistent 16-pixel tile footprint.
function GhostDrawScale(g, base)
  base = base or 1
  if not g then return base end
  return base
end

-- Holy State: a ghost at Settings.holyLevel (300) gets a halo
function IsHoly(g) return (g.level or 1) >= (Settings.holyLevel or 300) end

function GhostTypeTint(g)
  local types = {}
  if GhostTypes then types = GhostTypes(g) or {} end
  if #types == 0 then
    local sp = Get("Ghost", g and g.species)
    if sp and sp.type then types = { sp.type } end
    if sp and sp.type2 then types[#types + 1] = sp.type2 end
  end
  local r, gg, b = 0.85, 0.85, 0.9
  local n = 0
  for _, tid in ipairs(types) do
    local t = Get("Type", tid)
    if t and t.color then
      local col = ToColor(t.color)
      if col then
        r, gg, b = r + (col[1] or 1), gg + (col[2] or 1), b + (col[3] or 1)
        n = n + 1
      end
    end
  end
  if n > 0 then
    r, gg, b = r / (n + 1), gg / (n + 1), b / (n + 1)
    -- boost saturation slightly so greyscale art reads as type-colored
    local avg = (r + gg + b) / 3
    r = avg + (r - avg) * 1.35
    gg = avg + (gg - avg) * 1.35
    b = avg + (b - avg) * 1.35
  end
  return r, gg, b
end

function DrawGhostAt(g, cx, cy, scale, offset)
  local sp = Get("Ghost", g.species)
  if not sp and not (g.layers) then return end
  local s = GhostDrawScale(g, scale or 1)
  local bob = math.sin(((S and S.t) or 0) / 18 + (offset or 0) * 0.7) * (1.2 * math.max(0.6, s))
  cy = cy + bob
  local layers = g.layers
  if not layers and g.species and S and S.ghoulLooks and S.ghoulLooks[g.species] then
    local e = S.ghoulLooks[g.species]
    layers = {
      sheet = "ghoul", body = e.body, hair = e.hair, head = e.head, chest = e.chest,
      legs = e.legs, feet = e.feet, accessory = e.accessory, type = e.type or (sp and sp.type), rarity = g.rarity,
    }
  end
  if layers and Sheets and Sheets.draw then
    local frame = math.floor(((S and S.t) or 0) / 8) % 4
    layers.type = layers.type or (g.type or (sp and sp.type))
    layers.rarity = g.rarity or layers.rarity
    if Sheets.draw(layers, cx, cy, s, 0, frame) then
      if IsHoly(g) and not g.noHalo then
        SetColor(Settings.haloColor or "#fff1a8")
        love.graphics.rectangle("fill", math.floor(cx - 8 * s), math.floor(cy - 28 * s), math.max(4, 16 * s), math.max(1, s))
        love.graphics.setColor(1, 1, 1, 1)
      end
      return
    end
  end
  if not sp then return end
  local imgName = WorldGhosts and WorldGhosts.imageFor and WorldGhosts.imageFor(g) or g.imageSprite or sp.imageSprite
  if imgName and LoadImage then
    local img = LoadImage("assets/ghosts/" .. tostring(imgName) .. ".png")
    if img then
      local iw, ih = img:getWidth(), img:getHeight()
      local fit = (32 * s) / math.max(iw, ih)
      local dw, dh = iw * fit, ih * fit
      love.graphics.setColor(1, 1, 1, 1)
      love.graphics.draw(img, math.floor(cx - dw / 2), math.floor(cy - dh + 4 * s), 0, fit, fit)
      if IsHoly(g) and not g.noHalo then
        SetColor(Settings.haloColor or "#fff1a8")
        love.graphics.rectangle("fill", math.floor(cx - dw / 4), math.floor(cy - dh - 3 * s), math.max(2, dw / 2), math.max(1, s))
        love.graphics.setColor(1, 1, 1, 1)
      end
      return
    end
  end
  local spriteId = g.sprite or sp.sprite
  if not Get("Sprite", spriteId) then spriteId = Get("Sprite", sp.sprite) and sp.sprite or "ghoul_fallback"; g.sprite = spriteId end
  local x, y = topLeft(spriteId, cx, cy, s)
  DrawGhost(g, x, y, s, offset)
end

function DrawPlayerAt(cx, cy, scale)
  scale = scale or 1
  local bob = (math.floor(Tick() / 8) % 2)
  if Transform and Transform.current and Transform.current() and Transform.draw then
    if Transform.draw(cx, cy + bob * scale * 0.15, scale) then return end
  end
  local look = Character and Character.ensurePlayerLook and Character.effectiveLook(Character.ensurePlayerLook()) or nil
  if Character and Character.draw and look then
    local dir = 0
    if S and S.dir then dir = Character.dirFromFacing(S.dir[1] or 0, S.dir[2] or 1) end
    local moving = false
    if S then
      if S.moveTarget then moving = true end
      if KeyHeld and (KeyHeld("up") or KeyHeld("down") or KeyHeld("left") or KeyHeld("right")) then moving = true end
    end
    local frame = Character.walkFrame(S and S.steps or 0, moving)
    Character.draw(look, cx, cy + (moving and bob * scale * 0.15 or 0), scale, dir, frame)
    return
  end
  local p = Get("Player", Settings.player)
  if not p then return end
  local sprite = (S.playerSprite and Get("Sprite", S.playerSprite)) and S.playerSprite or p.sprite
  DrawDressedAt(sprite, cx + (p.offsetX or 0) * scale, cy + ((p.offsetY or 0) + bob) * scale, scale, nil, S.wearing)
end

-- draws a 14x14-grid character sprite with up to maxWearing cosmetic overlays aligned
-- to the same grid origin. `wearing` is a list of Wearable ids. pal overrides the base palette.
function DrawDressedAt(spriteId, cx, cy, scale, pal, wearing)
  scale = scale or 1
  local x, y = topLeft(spriteId, cx, cy, scale)
  DrawSprite(spriteId, x, y, scale, pal)
  for _, id in ipairs(wearing or {}) do
    local w = Get("Wearable", id)
    if w and w.sprite ~= "" and Get("Sprite", w.sprite) then
      DrawSprite(w.sprite, x + (w.offsetX or 0) * scale, y + (w.offsetY or 0) * scale, scale)
    end
  end
end

function DrawGhost(g, x, y, scale, offset)
  local sp = Get("Ghost", g.species)
  if not sp then return end
  local imgName = g.imageSprite or (sp and sp.imageSprite)
  if imgName and LoadImage then
    local img = LoadImage("assets/ghosts/" .. tostring(imgName) .. ".png")
    if img then
      local s = scale or 1
      local iw, ih = img:getWidth(), img:getHeight()
      local fit = 16 * s / math.max(iw, ih)
      love.graphics.setColor(1, 1, 1, 1)
      love.graphics.draw(img, x, y, 0, fit, fit)
      return
    end
  end
  local ty = Get("Type", sp.type)
  local pal = {}
  for k, v in pairs(ty and ty.palette or {}) do pal[k] = v end
  local time = Tick() + (offset or 0)
  local bonus = Rules.ghost_look and Rules.ghost_look(pal, g, sp, time) or 0
  local r = ApplyRarity(pal, g, sp, time)
  local s = (scale or 1) + (bonus or 0)
  if IsHoly(g) and not g.noHalo then
    local b = SpriteBounds(g.sprite or sp.sprite)
    local hx, hw, hy = x + b[1] * s, (b[3] - b[1] + 1) * s, y + b[2] * s - s * 2 - math.floor(math.sin(time / 15) * s * 0.5)
    SetColor(Settings.haloColor or "#fff1a8")
    love.graphics.rectangle("fill", hx + s, hy, hw - 2 * s, math.max(1, s / 2))
    love.graphics.rectangle("fill", hx, hy + math.max(1, s / 2), s, math.max(1, s / 2))
    love.graphics.rectangle("fill", hx + hw - s, hy + math.max(1, s / 2), s, math.max(1, s / 2))
  end
  local spriteId = g.sprite or sp.sprite
  if not Get("Sprite", spriteId) then spriteId = Get("Sprite", sp.sprite) and sp.sprite or "ghoul_fallback"; g.sprite = spriteId end
  DrawSprite(spriteId, x, y, s, pal)
  if r then DrawRarityExtras(r, spriteId, x, y, s, time) end
end

function DrawPlayer(x, y)
  if Character and Character.draw then
    local look = Character.effectiveLook(Character.ensurePlayerLook())
    Character.draw(look, x + 16, y + 24, 1, 0, 0)
    return
  end
  local p = Get("Player", Settings.player)
  if not p then return end
  local bob = p.bob and (math.floor(Tick() / 8) % 2) or 0
  local sprite = (S.playerSprite and Get("Sprite", S.playerSprite)) and S.playerSprite or p.sprite
  DrawSprite(sprite, x + p.offsetX, y + p.offsetY + bob, 1)
end

function Engine.drawErrors()
  local ww, wh = love.graphics.getDimensions()
  love.graphics.setColor(0, 0, 0, 0.88)
  love.graphics.rectangle("fill", 0, 0, ww, wh)
  love.graphics.setFont(love.graphics.newFont(13))
  love.graphics.setColor(1, 0.45, 0.4, 1)
  love.graphics.print("TURBO ENGINE - " .. #Engine.errors .. " FILE PROBLEM(S)", 16, 14)
  love.graphics.setColor(0.94, 0.9, 0.83, 1)
  local y = 40
  for i, e in ipairs(Engine.errors) do
    if y > wh - 60 then love.graphics.print("... and " .. (#Engine.errors - i + 1) .. " more (see kyo_errors.txt)", 16, y) break end
    local text = "[" .. i .. "] " .. e
    local _, lines = love.graphics.getFont():getWrap(text, ww - 32)
    love.graphics.printf(text, 16, y, ww - 32)
    y = y + #lines * 16 + 6
  end
  love.graphics.setColor(0.94, 0.84, 0.55, 1)
  love.graphics.print("ENTER = keep playing    F5 = reload files    F1 = show this again", 16, wh - 28)
end
