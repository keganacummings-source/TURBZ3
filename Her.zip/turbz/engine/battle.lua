-- Team battles: when a ghost faints the next one in the party is thrown out (both sides).
-- XP goes to the ghost that lands the knockout. Ghost HP lives only in battle, so everyone is full again afterwards.
function TypeBonus(attackType, defendType)
  return Rules.type_bonus(attackType, defendType)
end

-- Effectiveness vs a unit (supports dual-type ghosts: best multiplier applies)
function MoveEffectiveness(attack, targetUnit)
  if not attack or not targetUnit then return 1 end
  local g = targetUnit.ghost
  local types = GhostTypes and GhostTypes(g) or { targetUnit.type or "normal" }
  local prod = 1
  for _, t in ipairs(types) do
    local m = TypeBonus(attack.type, t)
    if m == 0 then return 0 end  -- a real immunity still blocks the attack
    prod = prod * m
  end
  -- Multi-typing should create tactical variety, not exponential damage swings.
  -- Normal is a universal baseline; the final multiplier is kept within a readable,
  -- testable band regardless of whether a ghost has one type or five.
  return Clamp(prod, 0.25, 3.0)
end

function IsSuperEffective(attack, targetUnit)
  return MoveEffectiveness(attack, targetUnit) > 1
end


function MakeUnit(g)
  local sp = Species(g)
  local st = Rules.unit_stats(g, sp)
  local r = RarityOf(g)
  local u = { ghost = g, name = GhostName(g), type = (GhostTypes(g)[1] or "normal"), level = g.level, rarity = r.id, boost = r.damageBoost,
    hp = st.hp, max = st.hp, shown = st.hp, atk = st.atk, def = st.def, spd = st.spd, status = {}, mods = { atk = 0, def = 0 },
    hitT = 0, faintT = 0, enterT = 0, lungeT = 0 }
  for _, k in ipairs(Settings.stats) do u[k] = g[k] or 0 end
  return u
end

function Give(u, name, turns) u.status[name] = turns or 1 end
function Has(u, name) return (u.status[name] or 0) > 0 end
function Take(u, name) u.status[name] = nil end
function Heal(u, n) u.hp = math.min(u.max, u.hp + n) end
function Hurt(u, n) u.hp = u.hp - n end
function Lower(u, stat, n, limit) u.mods[stat] = math.min(limit or 99, (u.mods[stat] or 0) + (n or 1)) end
function Raise(u, stat, n, limit) u.mods[stat] = math.max(-(limit or 99), (u.mods[stat] or 0) - (n or 1)) end

local function statusHooks(u, hook, e)
  local names = {}
  for name in pairs(u.status) do table.insert(names, name) end
  for _, name in ipairs(names) do
    local eff = Get("Effect", name)
    if eff and eff[hook] and Has(u, name) then eff[hook](e) end
  end
end

function BestMove(me, foe)
  local best, score = nil, -1
  for i, a in ipairs(MovesOf(me.ghost)) do
    local s = MoveCooldown(me, a) > 0 and -0.5 or Rules.move_score(a, foe, me)
    if s > score then best, score = i, s end
  end
  return best
end

local function forceSwapActive(target)
  local b = S.battle
  if not b or not target or target.hp <= 0 then return false end
  local team, side
  if target == b.me then team, side = b.myTeam, "me"
  elseif target == b.foe then team, side = b.foeTeam, "foe"
  else return false end
  for _, u in ipairs(team or {}) do
    if u ~= target and u.hp > 0 then
      if side == "me" then b.me = u else b.foe = u end
      u.enterT = 18
      u.lungeT = 0
      return true
    end
  end
  return false
end

function Strike(user, target, attack)
  local e = { user = user, target = target, attack = attack, skip = false, damage = 0 }
  statusHooks(user, "onBeforeAct", e)
  if e.skip then return Word("waits", Upper(user.name)) end
  if not Chance(attack.accuracy) then return Word("misses", Upper(attack.name)) end
  e.damage = Rules.damage(user, target, attack)
  if S.battle then
    if user == S.battle.me and Armor and Armor.get then
      local sk = string.lower((target and target.name) or "")
      if string.find(sk, "skeleton", 1, true) then
        e.damage = math.max(1, Round(e.damage * (1 + Armor.get("skeleton_bane") / 100)))
      end
    end
    if target == S.battle.me and Armor and Armor.get then
      local ward = Armor.get("ward")
      e.damage = math.max(1, Round(e.damage * (1 - math.min(0.6, ward / 100))))
      if Armor.get("echo_guard") > 0 and love.math.random(1, 100) <= math.min(20, Armor.get("echo_guard")) then
        e.damage = 0
      end
    end
    local function boonMul(unit, want)
      local b = unit and unit.ghost and unit.ghost.boon
      if not b or not Armor or not Armor.ENCHANT_BY_ID then return 0 end
      local def = Armor.ENCHANT_BY_ID[b.id]
      if def and def.key == want then return b.power or 0 end
      return 0
    end
    e.damage = math.max(0, Round(e.damage * (1 + boonMul(user, "might") / 100) * (1 - math.min(0.45, boonMul(target, "ward") / 100))))
  end
  -- Human companions contribute passive team perks; bonuses stack, capped by TownCompanionBonus.
  if TownCompanionBonus and S.battle then
    if user == S.battle.me then e.damage = math.max(1, Round(e.damage * (1 + TownCompanionBonus("strike") / 100))) end
    if target == S.battle.me then e.damage = math.max(1, Round(e.damage * (1 - TownCompanionBonus("ward") / 100))) end
  end
  statusHooks(target, "onDefend", e)
  target.hp = target.hp - e.damage
  if S.battle and user == S.battle.me and Armor and Armor.get and e.damage > 0 then
    local ls = Armor.get("lifesteal")
    if ls > 0 then Heal(user, math.max(1, Round(e.damage * math.min(0.2, ls / 100)))) end
  end
  if S.battle and target == S.battle.me and Armor and Armor.get and e.damage > 0 then
    local th = Armor.get("thorns")
    if th > 0 then
      user.hp = user.hp - math.max(1, Round(e.damage * math.min(0.2, th / 100)))
      user.hitT = 14
    end
  end
  target.hitT = 14
  local eff = Get("Effect", attack.effect)
  if eff and eff.onHit then eff.onHit(e) end
  if e.reflect and e.reflect > 0 then
    user.hp = user.hp - e.reflect
    user.hitT = 14
  end
  if e.forceSwap and target.hp > 0 then e.swapped = forceSwapActive(target) end
  Fire("hit", e)
  local note = Upper(attack.name) .. " " .. e.damage
  if e.reflect and e.reflect > 0 then note = note .. " / COUNTER " .. e.reflect end
  if e.swapped then note = note .. " / FORCED SWAP" end
  return note
end

local function doMove(user, target, attack)
  if not attack then return end
  user.cool = user.cool or {}
  if (user.cool[attack.id] or 0) > 0 then attack = MovesOf(user.ghost)[1] end
  if attack.cooldown > 0 then user.cool[attack.id] = attack.cooldown + 1 end
  user.lungeT = 10
  AttackFX(user, target, attack)
  local note = Strike(user, target, attack)
  table.insert(S.battle.log, 1, note)
  S.battle.line = note
  Play(attack.sound ~= "" and attack.sound or (attack.power > 40 and "hit_big" or "hit"))
end

-- turns left before a move can be used again (Attack cooldown)
function MoveCooldown(u, attack) return u.cool and u.cool[attack.id] or 0 end

-- seeded, tag-driven attack animation. battle.kyo reads S.battle.fx and draws it.
function AttackFX(user, target, attack)
  local b = S.battle
  if not b then return end
  b.fx = { tags = attack.anim or {}, atype = attack.type, t = attack.animLength or 18, max = attack.animLength or 18, foe = (user == b.foe) }
end

function NextAlive(team)
  for _, u in ipairs(team) do if u.hp > 0 then return u end end
  return nil
end

function AliveCount(team)
  local n = 0
  for _, u in ipairs(team) do if u.hp > 0 then n = n + 1 end end
  return n
end

-- add XP to a ghost (levels it up). Returns the "GREW TO LV" lines
function GiveXp(g, amount)
  local lines = {}
  local mult = 1
  if Armor and Armor.get then
    mult = mult + (Armor.get("ghost_xp") or 0) / 100 + (Armor.get("xp_boost") or 0) / 100 + (Armor.get("quest_xp") or 0) / 200
  end
  if g and g.boon and Armor and Armor.ENCHANT_BY_ID then
    local def = Armor.ENCHANT_BY_ID[g.boon.id]
    if def and (def.key == "ghost_xp" or def.key == "xp_boost") then mult = mult + (g.boon.power or 0) / 200 end
  end
  amount = math.max(1, math.floor((amount or 0) * mult))
  g.xp = (g.xp or 0) + amount
  while g.level < Settings.maxLevel and g.xp >= Rules.xp_needed(g.level) do
    g.xp = g.xp - Rules.xp_needed(g.level)
    g.level = g.level + 1
    local reward = Settings.kyoPerLevelUp or 100
    S.kyo = (S.kyo or 0) + reward
    if S.battle then S.battle.leveled = (S.battle.leveled or 0) + 1 end
    table.insert(lines, Word("grew", GhostName(g), g.level) .. " +" .. reward .. " KYO")
    Fire("ghost_level_up", { ghost = g, level = g.level })
    if g.level % 5 == 0 then
      local a = TryLearnMove(g)
      if a then table.insert(lines, Upper(GhostName(g) .. " LEARNED " .. a.name .. "!")) end
    end
    if g.level == (Settings.holyLevel or 300) then table.insert(lines, Word("holy", GhostName(g))) Fire("ghost_holy", { ghost = g }) end
    local before = GhostName(g)
    local evo = CheckEvolve(g)
    if evo then table.insert(lines, Word("evolved", before, Upper(evo))) end
  end
  return lines
end

local function giveXp(winner, loser)
  local b = S.battle
  local mult = b.enemy and b.enemy.xpMultiplier or Settings.wildXpMultiplier
  local companionXp = TownCompanionBonus and TownCompanionBonus("xp") or 0
  local amount = Round(Rules.xp_reward(loser) * mult * (1 + companionXp / 100))
  table.insert(b.xpLog, Word("xp_gain", GhostName(winner.ghost), amount))
  for _, line in ipairs(GiveXp(winner.ghost, amount)) do table.insert(b.xpLog, line) end
  winner.level = winner.ghost.level
  b.line = Word("xp_gain", GhostName(winner.ghost), amount)
end

-- checks for knocked out ghosts and queues the swap / end of battle
local function resolve()
  local b = S.battle
  if not b then return end
  if b.foe.hp <= 0 and not b.foe.down then
    b.foe.down, b.foe.faintT = true, 1
    giveXp(b.me, b.foe)
    b.wait = Settings.faintTicks
    b.pending = function()
      local nxt = NextAlive(b.foeTeam)
      if not nxt then return WinBattle() end
      b.foe, nxt.enterT = nxt, 20
      b.line = b.enemy and Word("sends_out", Upper(b.enemy.name), Upper(nxt.name)) or Word("jumps", Upper(nxt.name))
      Play("jump")
      resolve()
    end
    return
  end
  if b.me.hp <= 0 and not b.me.down then
    b.me.down, b.me.faintT = true, 1
    b.wait = Settings.faintTicks
    b.pending = function()
      local nxt = NextAlive(b.myTeam)
      if not nxt then return LoseBattle() end
      b.me, nxt.enterT = nxt, 20
      b.line = Word("go_ghost", Upper(nxt.name))
      Play("jump")
      resolve()
    end
  end
end

-- true while an animation is playing (moves are ignored)
function BattleBusy()
  local b = S.battle
  return not b or b.wait > 0 or b.pending ~= nil
end

function BattleTick()
  local b = S.battle
  for _, team in ipairs({ b.myTeam, b.foeTeam }) do
    for _, u in ipairs(team) do
      local hp = math.max(0, u.hp)
      u.shown = math.abs(u.shown - hp) < 0.3 and hp or u.shown + (hp - u.shown) * 0.15
      if u.hitT > 0 then u.hitT = u.hitT - 1 end
      if u.enterT > 0 then u.enterT = u.enterT - 1 end
      if u.lungeT > 0 then u.lungeT = u.lungeT - 1 end
      if u.faintT > 0 and u.faintT < 40 then u.faintT = u.faintT + 1 end
    end
  end
  if b.wait > 0 then
    b.wait = b.wait - 1
    if b.wait == 0 and b.pending then
      local p = b.pending
      b.pending = nil
      p()
    end
  end
  if b.fx then b.fx.t = b.fx.t - 1 if b.fx.t <= 0 then b.fx = nil end end
end

local function endTurn()
  local b = S.battle
  for _, u in ipairs({ b.me, b.foe }) do
    for id, n in pairs(u.cool or {}) do u.cool[id] = n > 1 and n - 1 or nil end
  end
  for _, u in ipairs({ b.me, b.foe }) do
    local names = {}
    for name in pairs(u.status) do table.insert(names, name) end
    for _, name in ipairs(names) do
      local eff = Get("Effect", name)
      if eff and Has(u, name) and u.hp > 0 then
        if eff.onTurnEnd then eff.onTurnEnd(u) end
        if eff.countdown and u.status[name] then u.status[name] = u.status[name] - 1 end
      end
    end
  end
  b.wait = Settings.turnTicks
  resolve()
end

local function enemyTeam(npc, def)
  local team = {}
  local region = World.regionAt(npc.x, npc.y)
  if region then region._spawnX, region._spawnY = npc.x, npc.y end
  local lo, hi
  if LevelRangeAt then lo, hi = LevelRangeAt(npc.x, npc.y) else lo, hi = 1, (Settings.worldLevelMax or 180) end
  for _, entry in ipairs(def.party or {}) do
    local id, level
    if entry == "random" then
      id, level = RollSpawn(region)
    else
      id = entry
      -- Fixed trainer signatures scale with the actual encounter location too;
      -- otherwise a fixed low-level ghost could appear in the endgame islands.
      level = Rules.wild_level(lo, hi)
    end
    if id and Get("Ghost", id) then
      local cap = (World.map and World.map.id == "giant_world") and (Settings.worldLevelMax or 180) or (Settings.maxLevel or 400)
      level = Clamp((level or Rules.wild_level(lo, hi)) + (def.levelBonus or 0), 1, cap)
      local ghost = MakeGhost(id, level, CommonRarity())
      if ghost then table.insert(team, MakeUnit(ghost)) end
    end
  end
  if #team == 0 then
    local level = Rules.wild_level(lo, hi)
    table.insert(team, MakeUnit(MakeGhost(Settings.starter, level, CommonRarity())))
  end
  return team
end

function BeginBattle()
  local intro = S.intro
  LeadGhost()
  local myTeam = {}
  local _ps = (EffectivePartySize and EffectivePartySize()) or Settings.partySize or 6
  for i = 1, _ps do if S.party[i] then table.insert(myTeam, MakeUnit(S.party[i])) end end
  local b = { myTeam = myTeam, me = myTeam[1], log = {}, xpLog = {}, wait = 0 }
  if intro.boss then
    local def = intro.boss
    b.boss, b.enemy = def, def
    b.foeTeam = BossTeam(def)
    b.line = Word("boss_appears", Upper(def.name))
    for _, u in ipairs(b.foeTeam) do S.seen[u.ghost.species] = true end
  elseif intro.npc then
    local def = Get("Enemy", intro.npc.enemy)
    b.npc, b.enemy = intro.npc, def
    b.foeTeam = enemyTeam(intro.npc, def)
    b.line = Word("wants_fight", Upper(def.name))
    for _, u in ipairs(b.foeTeam) do S.seen[u.ghost.species] = true end
  else
    local r = RarityOf(intro.wild.ghost)
    local name = GhostName(intro.wild.ghost)
    b.wild = intro.wild
    b.foeTeam = { MakeUnit(intro.wild.ghost) }
    b.line = r.oneIn > 0 and Word("rare_jumps", Upper(r.name), name) or Word("jumps", name)
    -- 40% chance of a DOUBLE wild: a second, lower-level ghost jumps in too
    if Chance(40) then
      local region = World.regionAt(S.px, S.py)
      local id2, lv2 = RollSpawn(region)
      if id2 and Get("Ghost", id2) then
        local lv = Clamp(lv2 or intro.wild.ghost.level, 1, Max(1, intro.wild.ghost.level - 1))
        local g2 = MakeGhost(id2, lv, CommonRarity())
        if g2 then table.insert(b.foeTeam, MakeUnit(g2)) b.line = Upper(name .. " - AMBUSH! 2 GHOSTS") end
      end
    end
    for _, u in ipairs(b.foeTeam) do S.seen[u.ghost.species] = true end
    local keep = {}
    for _, w in ipairs(S.wilds) do if w ~= intro.wild then table.insert(keep, w) end end
    S.wilds = keep
  end
  b.foe = b.foeTeam[1]
  b.foe.enterT, b.me.enterT = 20, 20
  b.wait = 20
  S.battle, S.intro = b, nil
  Go("battle")
  S.shake = 6
  Fire("battle_start", b)
end


-- Can the player open the party swap UI?
function CanSwap()
  local b = S.battle
  if not b or BattleBusy() then return false end
  if b.shrine then return false end
  local alive = 0
  for _, u in ipairs(b.myTeam or {}) do
    if u.hp > 0 and u ~= b.me then alive = alive + 1 end
  end
  return alive > 0
end

-- Wild-only runaway (trainers, bosses, shrine, PvP cannot flee)
function CanFlee()
  local b = S.battle
  if not b then return false end
  if b.enemy or b.boss or b.shrine then return false end
  return b.wild ~= nil
end

-- Swap active ghost for another living party member (index into b.myTeam).
-- Foe gets a free attack after a voluntary swap.
function SwapGhost(index)
  local b = S.battle
  if not b or BattleBusy() then return end
  local u = b.myTeam[index]
  if not u or u.hp <= 0 then
    b.line = "CAN'T SWITCH"
    return
  end
  if u == b.me then
    b.line = "ALREADY OUT"
    return
  end
  b.me = u
  u.enterT = 16
  b.line = Word("go_ghost", Upper(u.name))
  b.swapOpen = false
  Play("jump")
  if b.foe and b.foe.hp > 0 then
    local theirs = MovesOf(b.foe.ghost)[BestMove(b.foe, b.me) or 1]
    if theirs then doMove(b.foe, b.me, theirs) end
  end
  endTurn()
end

function OpenSwapMenu()
  local b = S.battle
  if not CanSwap() then
    if b then b.line = "NO ONE LEFT TO SWAP" end
    return
  end
  b.swapOpen = true
  b.bagOpen = false
  b.swapIndex = 1
end

function TryFlee()
  local b = S.battle
  if not b or BattleBusy() then return end
  if not CanFlee() then
    b.line = Word("cant_flee")
    Play("bump")
    return
  end
  local chance = 55 + ((b.me.spd or 0) - (b.foe.spd or 0)) * 6
  if chance < 25 then chance = 25 end
  if chance > 95 then chance = 95 end
  if Chance(chance) then
    S.battle = nil
    Go("explore")
    Say(Word("fled"))
    Play("step")
    Fire("battle_fled", b)
    if LocalSave then LocalSave() end
  else
    b.line = "COULDN'T ESCAPE!"
    Play("bump")
    if b.foe and b.foe.hp > 0 then
      local theirs = MovesOf(b.foe.ghost)[BestMove(b.foe, b.me) or 1]
      if theirs then doMove(b.foe, b.me, theirs) end
    end
    endTurn()
  end
end

function UseMove(n)
  local b = S.battle
  if BattleBusy() then return end
  local activeMe, activeFoe = b.me, b.foe
  local moves = MovesOf(activeMe.ghost)
  local mine = moves[n]
  if not mine then return end
  if MoveCooldown(activeMe, mine) > 0 then b.line = Word("cooling", Upper(mine.name), MoveCooldown(activeMe, mine)) return end
  local foeMoves = MovesOf(activeFoe.ghost)
  local foeMove = foeMoves[BestMove(activeFoe, activeMe) or 1]
  if activeMe.spd >= activeFoe.spd then
    doMove(activeMe, activeFoe, mine)
    -- The defending side may have been forced to switch. The replacement must choose
    -- its own move, never inherit the outgoing unit's move object.
    if b.foe and b.foe.hp > 0 and b.me and b.me.hp > 0 then
      local replacementMoves = MovesOf(b.foe.ghost)
      local reply = replacementMoves[BestMove(b.foe, b.me) or 1]
      if reply then doMove(b.foe, b.me, reply) end
    end
  else
    doMove(activeFoe, activeMe, foeMove)
    -- A forced swap replaces the actor and consumes the selected action; the new
    -- active ghost cannot accidentally use a move chosen for the ghost shoved out.
    if b.me == activeMe and b.me.hp > 0 and b.foe and b.foe.hp > 0 then
      doMove(activeMe, b.foe, mine)
    elseif b.me ~= activeMe then
      b.line = (b.line or "") .. " / FORCED OUT - NEW ALLY ENTERS"
    end
  end
  endTurn()
end

-- spend KYO for +1 level (cost + max come from rules/kyo_level.kyo)
function KyoLevelUp(g)
  if not g then Say(Word("no_ghost")) return false end
  local cost, max = Rules.kyo_level(g)
  if g.level >= max then Say(Word("max_level", GhostName(g))) return false end
  if S.kyo < cost then Say(Word("need_kyo", cost)) Play("bump") return false end
  S.kyo = S.kyo - cost
  local before = GhostName(g)
  g.level = g.level + 1
  if g.level % 5 == 0 then TryLearnMove(g) end
  Say(g.level == (Settings.holyLevel or 300) and Word("holy", GhostName(g)) or Word("kyo_level", GhostName(g), g.level, cost))
  if g.level == (Settings.holyLevel or 300) then Fire("ghost_holy", { ghost = g }) end
  Play("win")
  local evo = CheckEvolve(g)
  if evo then Say(Word("evolved", before, Upper(evo))) end
  Fire("ghost_level_up", { ghost = g, level = g.level, kyo = true })
  return true
end

-- after using an item the foe gets a free attack
function BattleItemTurn()
  local b = S.battle
  doMove(b.foe, b.me, MovesOf(b.foe.ghost)[BestMove(b.foe, b.me) or 1])
  endTurn()
end

function WinBattle()
  S.statsLifetime = S.statsLifetime or {}
  S.statsLifetime.kills = (S.statsLifetime.kills or 0) + 1
  if S.quest and not S.quest.done and S.quest.progress then
    local def = Get("Quest", S.quest.id)
    if def and def.goals then
      for i, g in ipairs(def.goals) do
        if g.kind == "kill" or g.kind == "catch" then
          S.quest.progress[i] = (S.quest.progress[i] or 0) + 1
        end
      end
      if QuestCheck then QuestCheck() end
    end
  end
  if S.battle and S.battle.wild and Mechanics and Mechanics.onWildWin then
    Mechanics.onWildWin(S.battle.foe)
  end
  if S._armoredFight and S.battle then S.battle.armoredSkeleton = true S._armoredFight = nil end
  if Loot and Loot.onBattleWin then Loot.onBattleWin(S.battle) end
  -- Armor drops
  if Armor and Armor.tryDropFromGhost and S.battle then
    local lvl = 1
    if S.battle.foe and S.battle.foe.level then lvl = S.battle.foe.level
    elseif S.battle.foe and S.battle.foe.ghost and S.battle.foe.ghost.level then lvl = S.battle.foe.ghost.level end
    local isBoss = S.battle.boss or S.worldBossFight
    if isBoss and WorldBoss and WorldBoss.onDefeated then
      WorldBoss.onDefeated()
    else
      Armor.tryDropFromGhost(lvl, false)
    end
  end
  local b = S.battle
  if b.shrine then return ShrineWin() end
  local res = {
    xpLog = b.xpLog or {},
    enemy = b.enemy,
    boss = b.boss,
    region = RegionAt(S.px, S.py).id,
    wild = b.wild,
    canCatch = false,
    caughtAlready = b.caught and true or false,
    leveled = (b.leveled or 0) > 0,
  }
  -- Wild: do NOT auto-box. Present XP + optional catch (100% if defeated, needs a jar).
  if b.wild and b.foeTeam and b.foeTeam[1] then
    local g = b.foeTeam[1].ghost
    res.ghost = g
    res.defeated = true
    if b.caught then
      -- Already jarred mid-battle; still show XP summary
      res.caughtAlready = true
      local sp = Species(g)
      local prev = S.best and S.best[sp.id]
      res.better = (not prev) or StatSum(g) > StatSum(prev)
      if res.better and S.best then S.best[sp.id] = g end
      if not (S.box and (function()
        for _, x in ipairs(S.box) do if x == g then return true end end
        for _, x in ipairs(S.party or {}) do if x == g then return true end end
        return false
      end)()) then
        table.insert(S.box, g)
      end
      S.caught = S.caught or {}
      S.caught[sp.id] = S.caught[sp.id] or {}
      S.caught[sp.id][g.rarity or "faded"] = true
      if CompanionCongratsRare then CompanionCongratsRare(g) end
    else
      res.canCatch = true
    end
  end
  if b.boss then res.bossLook = BossLook(b.boss) BossBeaten(b.boss) end
  if b.enemy then
    local fortune = TownCompanionBonus and TownCompanionBonus("fortune") or 0
    local earned = Round(b.enemy.kyoReward * (1 + fortune / 100))
    S.kyo = S.kyo + earned
    res.kyo = earned
    local keep = {}
    for _, n in ipairs(S.npcs) do if n ~= b.npc then table.insert(keep, n) end end
    S.npcs = keep
    if b.npc then Fire("enemy_defeated", { enemy = b.npc.enemy, region = res.region }) end
  end
  for _, it in ipairs(All("Item")) do
    if it.dropChance > 0 and Chance(it.dropChance * (b.enemy and 2 or 1)) then GiveItem(it.id, 1, "kill") res.drop = it.name break end
  end
  S.kills = S.kills + 1
  Rules.trainer_level()
  S.result, S.battle = res, nil
  -- Always show the result screen so XP is visible; wild fights offer catch.
  Go("result")
  Play("win")
  Fire("battle_won", res)
  if LocalSave then LocalSave() end
  Fire("team_healed")
end

-- Full wipeout: find a zone whose ghosts are a stage UNDER your strongest ghost and drop you on a
-- random walkable tile there. Returns true if it moved you.
local function strongestLevel()
  local m = 1
  for _, g in ipairs(Owned()) do if g and (g.level or 1) > m then m = g.level end end
  return m
end

function RespawnAfterWipe()
  -- A wipe always returns the player to Crownfall's castle spawn, never a random tile.
  local map = World.map or Get("Map", "giant_world")
  if not map or not map.start then return false end
  local x, y = map.start[1], map.start[2]
  if not World.walkable(x, y) then
    local spot = World.emptyNear and World.emptyNear(x, y, 10, 3)
    if spot and spot[1] and spot[2] then x, y = spot[1], spot[2] end
  end
  if Camp and Camp.applySpawn and Camp.applySpawn() then
    x, y = S.px, S.py
  else
    S.px, S.py = x, y
  end
  S.rx, S.ry, S.followers, S.fpos = S.px, S.py, {}, {}
  S.wilds, S.npcs = {}, {}
  S.discovered = S.discovered or {}
  local home = World.regionAt(x, y)
  if home and home.id then S.discovered[home.id] = true end
  return true, home or World.manor
end

-- After death: grant a fresh random starter that can roll rarity + multi-type.
-- Level is a % of previous trainer level so luck can still feel strong early.
function GrantRandomStarterGhost()
  local species = GhostList and GhostList() or All("Ghost")
  if not species or #species == 0 then
    S.party = S.party or {}
    S.party[1] = MakeGhost(Settings.starter, math.max(1, S.trainer or 1), false)
    return S.party[1]
  end
  local pick = species[love.math.random(1, #species)]
  local lvl = math.max(1, math.floor((S.trainer or 1) * (0.35 + love.math.random() * 0.45)))
  local g = MakeGhost(pick.id, lvl, nil)
  if not g then
    g = MakeGhost(Settings.starter, math.max(1, S.trainer or 1), false)
  end
  S.party = {}
  S.party[1] = g
  if g and g.species then S.seen = S.seen or {}; S.seen[g.species] = true end
  local rarityName = (g and g.rarity and Get("Rarity", g.rarity) and Get("Rarity", g.rarity).name) or "COMMON"
  local gname = (g and GhostName and GhostName(g)) or (pick and pick.name) or (pick and pick.id) or "?"
  Say("NEW STARTER: " .. Upper(tostring(gname)) .. " [" .. Upper(tostring(rarityName)) .. "] LV" .. tostring(g and g.level or lvl))
  return g
end

function LoseBattle()
  if Armor and Armor.get and Armor.get("second_chance") > 0 and not (S._usedSecondChance) then
    S._usedSecondChance = true
    if S.battle and S.battle.me then
      S.battle.me.hp = math.max(1, math.floor((S.battle.me.max or 10) * 0.35))
    end
    Say("ARMOR BREAKS — YOU LIVE")
    Play("jump")
    return
  end
  S._usedSecondChance = nil

  local lost = S.battle
  if lost.shrine then return ShrineLose() end
  S.battle = nil
  -- Wipe: keep skills, armor bag/equipped, enchant stash, bank, camps, look.
  -- Lose: pocket KYO, bag items, party/box ghosts (non-banked), transform state, stamina.
  local lostKyo = S.kyo or 0
  S.statsLifetime = S.statsLifetime or {}
  S.statsLifetime.deaths = (S.statsLifetime.deaths or 0) + 1
  S._diedZone = World.regionAt and World.regionAt(S.px, S.py)
  S._diedLostKyo = lostKyo
  S.kyo = 0
  S.bag = {}
  S.party = {}
  S.box = {}
  S.transform = nil
  S.stamina = 100
  if Bank and Bank.onWipeout then Bank.onWipeout() end
  GrantRandomStarterGhost()
  -- Respawn at nearest camp if any
  local moved, zone = false, nil
  if Camp and Camp.nearest then
    local c, idx = Camp.nearest(S.px, S.py, S.map)
    if c and c.x then
      if idx then Camp.setActive(idx) end
      S.px, S.py = c.x + 0.0, c.y + 0.0
      S.rx, S.ry = S.px, S.py
      moved = true
      zone = World.regionAt and World.regionAt(c.x, c.y)
    end
  end
  if not moved then
    moved, zone = RespawnAfterWipe()
  end
  S._diedZone = zone
  S._diedLostKyo = lostKyo
  Go("died")
  Play("bump")
  Fire("battle_lost", lost)
  Fire("team_healed")
  Fire("player_wiped", { kyoLost = lostKyo, zone = zone })
  if Armor and Armor.syncVisuals then Armor.syncVisuals() end
  if LocalSave then LocalSave() end
end
