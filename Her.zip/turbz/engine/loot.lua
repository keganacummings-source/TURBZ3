
-- Enemy/wild loot: food, kyo scraps, rare low armor; armored skeletons drop gear.

Loot = Loot or {}

local FOOD = { "bread", "meat", "berry", "ration", "fish_meal", "candy", "apple", "cheese", "honey", "raw_fish" }

function Loot.giveFood(id)
  if GiveItem then GiveItem(id, 1, "kill") end
  Say("LOOT " .. Upper(id or "FOOD"))
end

function Loot.onBattleWin(b)
  if not b then return end
  local lvl = 1
  if b.foe and b.foe.level then lvl = b.foe.level
  elseif b.foe and b.foe.ghost and b.foe.ghost.level then lvl = b.foe.ghost.level end

  -- Always small kyo scrap
  local kyo = math.max(1, math.floor(2 + lvl * 0.4 + love.math.random(0, 5)))
  S.kyo = (S.kyo or 0) + kyo

  local hunt = SkillLevel and SkillLevel("hunting") or 1
  local chance = 55 + math.min(30, (hunt - 1) * 0.08)
  if Armor and Armor.get then chance = math.min(90, chance + Armor.get("loot_find") * 0.3) end
  if love.math.random(1, 100) <= chance then
    local id = FOOD[love.math.random(1, #FOOD)]
    Loot.giveFood(id)
  end
  if Spirit and Spirit.gain then Spirit.gain(2 + math.floor(lvl / 25)) end

  -- Armored skeleton flag
  if b.armoredSkeleton or (b.boss and b.enemy == "armored_skeleton") then
    if Armor and Armor.tryDropFromGhost then
      Armor.tryDropFromGhost(math.max(lvl, 40), true)
    end
  end
end

-- Spawn chance for armored skeleton enemies in the wild
function Loot.trySpawnArmoredSkeleton()
  if not S.npcs then return end
  if love.math.random(1, 1000) > 3 then return end
  if not World or not World.walkable then return end
  local x = love.math.random(4, (World.w or 20) - 5)
  local y = love.math.random(4, (World.h or 20) - 5)
  if not World.walkable(x, y) then return end
  S.armoredSkeletons = S.armoredSkeletons or {}
  S.armoredSkeletons[#S.armoredSkeletons + 1] = {
    x = x, y = y, level = math.max(15, (S.trainer or 5) + love.math.random(5, 25)),
    name = "Armored Skeleton",
  }
end
