-- SessionNet: small host-authoritative UDP lobby for private, peer-hosted sessions.
--
-- Design goals:
--   * No account or Cloudflare dependency; the offline game never needs networking.
--   * Host keeps the lobby and relays small player snapshots/chat to up to 3 guests.
--   * A session has its own world ID. Each local player gets a separate character save
--     under multiplayer/<world-id>/players/<player-id>/ so SP data cannot cross over.
--
-- Requires LuaSocket (`socket`) in the LÖVE runtime. The game deliberately reports a
-- friendly status if the module is missing instead of making offline play fail.
local json = require("engine.json")
local socketOK, socketLib = pcall(require, "socket")

SessionNet = {
  available = socketOK and type(socketLib) == "table",
  mode = "offline", -- offline | host | client
  status = "OFFLINE PLAY READY",
  udp = nil, port = 27644,
  worldId = nil, pin = nil, playerId = nil,
  hostIp = nil, hostPort = nil,
  connected = false, started = false, pendingNewWorld = false,
  advertiseAddress = "", lanAddress = "127.0.0.1", code = "",
  players = {}, chat = {},
  lastHello = -9999, lastSnapshot = -9999, lastState = -9999,
  lastTick = 0, lastStateReceived = 0,
}

local ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
local function randomId(n)
  local out = {}
  for i = 1, n do local k = love.math.random(1, #ALPHABET); out[i] = ALPHABET:sub(k, k) end
  return table.concat(out)
end
local function digits(n)
  local out = {}
  for i = 1, n do out[i] = tostring(love.math.random(0, 9)) end
  return table.concat(out)
end
local function cleanPart(v, fallback)
  v = tostring(v or ""):gsub("[^%w_-]", "")
  if v == "" then return fallback or "unknown" end
  return v:sub(1, 48)
end
local function nowTick() return (S and S.t) or 0 end
local function localName()
  if S and type(S.playerName) == "string" and S.playerName ~= "" then return S.playerName end
  if SessionNet.playerId == "host" then return "Host" end
  return "Guest-" .. tostring(SessionNet.playerId or "guest"):sub(-4):upper()
end
local function saveProfilePath() return "multiplayer/host_world.json" end
local function saveLocalIdPath() return "multiplayer/local_player_id.txt" end

local function ensureDir()
  pcall(love.filesystem.createDirectory, "multiplayer")
end

local function localPlayerId()
  ensureDir()
  local id = love.filesystem.read(saveLocalIdPath())
  id = tostring(id or ""):gsub("[^%w_-]", "")
  if #id < 6 then
    id = "p-" .. randomId(10)
    love.filesystem.write(saveLocalIdPath(), id)
  end
  return id
end

local function detectLanAddress()
  if not SessionNet.available then return "127.0.0.1" end
  -- Asking the OS which local interface would route to a public IP does not send data.
  local ok, probe = pcall(socketLib.udp)
  if ok and probe then
    pcall(function() probe:settimeout(0); probe:setpeername("1.1.1.1", 53) end)
    local good, ip = pcall(function() return probe:getsockname() end)
    pcall(function() probe:close() end)
    if good and type(ip) == "string" and ip ~= "0.0.0.0" then return ip end
  end
  return "127.0.0.1"
end

local function closeSocket()
  if SessionNet.udp then pcall(function() SessionNet.udp:close() end) end
  SessionNet.udp = nil
end

local function openSocket(port)
  if not SessionNet.available then
    SessionNet.status = "NETWORK MODULE MISSING - OFFLINE PLAY STILL WORKS"
    return false
  end
  closeSocket()
  local ok, udp = pcall(socketLib.udp)
  if not ok or not udp then
    SessionNet.status = "COULD NOT CREATE NETWORK SOCKET"
    return false
  end
  pcall(function() udp:settimeout(0) end)
  local requestedPort = tonumber(port) or 27644
  local bound, err = udp:setsockname("*", requestedPort)
  if not bound then
    pcall(function() udp:close() end)
    SessionNet.status = "PORT " .. tostring(port) .. " UNAVAILABLE: " .. tostring(err or "BIND FAILED")
    return false
  end
  SessionNet.udp = udp
  if requestedPort > 0 then
    SessionNet.port = requestedPort
  else
    local _, assignedPort = udp:getsockname()
    SessionNet.localPort = tonumber(assignedPort) or 0
  end
  return true
end

local function sendTo(ip, port, packet)
  if not SessionNet.udp or not ip or not port then return false end
  packet.room = packet.room or SessionNet.worldId
  packet.pin = packet.pin or SessionNet.pin
  local ok, data = pcall(json.encode, packet)
  if not ok or not data then return false end
  local sent = SessionNet.udp:sendto(data, ip, tonumber(port))
  return sent ~= nil
end

local function resetRuntime()
  SessionNet.players, SessionNet.chat = {}, {}
  SessionNet.connected, SessionNet.started = false, false
  SessionNet.lastHello, SessionNet.lastSnapshot, SessionNet.lastState = -9999, -9999, -9999
  SessionNet.lastStateReceived = nowTick()
end

local function updateHostCode()
  local addr = tostring(SessionNet.advertiseAddress or ""):gsub("^%s+", ""):gsub("%s+$", "")
  if addr == "" then addr = SessionNet.lanAddress or detectLanAddress() end
  SessionNet.code = addr .. ":" .. tostring(SessionNet.port or 27644) .. ":" .. tostring(SessionNet.worldId or "ROOM") .. ":" .. tostring(SessionNet.pin or "000000")
  return SessionNet.code
end

function SessionNet.setAdvertiseAddress(address)
  SessionNet.advertiseAddress = tostring(address or ""):gsub("[^%w%.%-]", "")
  updateHostCode()
end

local function readHostProfile()
  ensureDir()
  local raw = love.filesystem.read(saveProfilePath())
  if not raw then return nil end
  local ok, profile = pcall(json.decode, raw)
  if ok and type(profile) == "table" and profile.worldId and profile.pin then return profile end
  return nil
end

local function saveHostProfile()
  ensureDir()
  local profile = {
    worldId = SessionNet.worldId, pin = SessionNet.pin,
    playerId = "host", port = SessionNet.port or 27644,
  }
  love.filesystem.write(saveProfilePath(), json.encode(profile))
end

function SessionNet.canHostSavedWorld()
  local profile = readHostProfile()
  return profile ~= nil
end

function SessionNet.startHost(existing)
  resetRuntime()
  SessionNet.mode = "offline"
  SessionNet.lanAddress = detectLanAddress()
  local profile = existing and readHostProfile() or nil
  if existing and not profile then
    SessionNet.status = "NO SAVED HOST WORLD YET - HOST A NEW WORLD FIRST"
    return false
  end
  local port = tonumber((profile and profile.port) or SessionNet.port or 27644) or 27644
  if not openSocket(port) then return false end
  if profile then
    SessionNet.worldId, SessionNet.pin = cleanPart(profile.worldId, randomId(6)), tostring(profile.pin)
  else
    SessionNet.worldId, SessionNet.pin = randomId(6), digits(6)
  end
  SessionNet.playerId = "host"
  SessionNet.hostIp, SessionNet.hostPort = nil, nil
  SessionNet.pendingNewWorld = not existing
  SessionNet.started = false
  SessionNet.mode = "host"
  SessionNet.connected = true
  SessionNet.status = "LOBBY OPEN - WAITING FOR FRIENDS"
  SessionNet.advertiseAddress = ""
  updateHostCode()
  if not existing then saveHostProfile() end
  return true
end

local function parseCode(code)
  code = tostring(code or ""):gsub("^%s+", ""):gsub("%s+$", ""):gsub("%s", "")
  local ip, port, room, pin = code:match("^([^:]+):(%d+):([%w_-]+):([%w_-]+)$")
  port = tonumber(port)
  if not ip or not port or port < 1 or port > 65535 or not room or not pin then return nil end
  if #ip > 253 or #room > 48 or #pin > 48 then return nil end
  return ip, port, room:upper(), pin:upper()
end

function SessionNet.join(code)
  SessionNet.leave()
  resetRuntime()
  local ip, port, room, pin = parseCode(code)
  if not ip then
    SessionNet.status = "INVALID HOST CODE - EXPECT ADDRESS:PORT:ROOM:PIN"
    return false
  end
  if not openSocket(0) then return false end
  SessionNet.mode = "client"
  SessionNet.worldId, SessionNet.pin = cleanPart(room, "room"), tostring(pin)
  SessionNet.playerId = localPlayerId()
  SessionNet.hostIp, SessionNet.hostPort = ip, port
  SessionNet.advertiseAddress = ""
  SessionNet.started = false
  SessionNet.status = "CONNECTING TO HOST..."
  SessionNet.lastHello = -9999
  SessionNet.code = code
  return true
end

local function currentPlayerSnapshot(id, name)
  local out = { id = id, name = tostring(name or "Traveler"):sub(1, 24), ready = true }
  if S and S.screen == "explore" and S.map then
    out.map = tostring(S.map):sub(1, 40)
    out.x, out.y = math.floor(S.px or 1), math.floor(S.py or 1)
    out.sprite = tostring((Get("Player", Settings.player) or {}).sprite or "kyo"):sub(1, 40)
  end
  return out
end

local function sendHello()
  sendTo(SessionNet.hostIp, SessionNet.hostPort, {
    type = "hello", id = SessionNet.playerId,
    name = localName(),
    room = SessionNet.worldId, pin = SessionNet.pin,
  })
end

local function peerCount()
  local n = 0
  for _ in pairs(SessionNet.players) do n = n + 1 end
  return n
end

local function findPeerByAddress(ip, port)
  for id, p in pairs(SessionNet.players) do
    if p.ip == ip and tonumber(p.port) == tonumber(port) then return id, p end
  end
end

local function buildPlayerList()
  local out = {}
  local hostName = localName()
  local host = currentPlayerSnapshot("host", hostName)
  out[#out + 1] = host
  for id, p in pairs(SessionNet.players) do
    out[#out + 1] = {
      id = id, name = p.name or "Guest", ready = p.ready ~= false,
      map = p.map, x = p.x, y = p.y, sprite = p.sprite,
    }
  end
  table.sort(out, function(a, b)
    if a.id == "host" then return true end
    if b.id == "host" then return false end
    return tostring(a.name) < tostring(b.name)
  end)
  return out
end

local function peerSend(p, packet)
  if p and p.ip and p.port then return sendTo(p.ip, p.port, packet) end
  return false
end

local function handleHostPacket(packet, ip, port)
  if type(packet) ~= "table" or packet.room ~= SessionNet.worldId or tostring(packet.pin or "") ~= tostring(SessionNet.pin) then return end
  local id = cleanPart(packet.id, "guest")
  if packet.type == "hello" then
    local existing = SessionNet.players[id]
    if not existing and peerCount() >= 3 then
      sendTo(ip, port, { type = "full", room = SessionNet.worldId, pin = SessionNet.pin })
      return
    end
    local p = existing or { id = id }
    p.name = tostring(packet.name or "Guest"):gsub("[%c]", ""):sub(1, 24)
    p.ip, p.port, p.lastSeen = ip, port, nowTick()
    p.ready = true
    SessionNet.players[id] = p
    peerSend(p, { type = "welcome", id = "host", name = localName(), started = SessionNet.started, players = buildPlayerList(), room = SessionNet.worldId, pin = SessionNet.pin })
  elseif packet.type == "snapshot" then
    local p = SessionNet.players[id]
    if not p then return end
    p.ip, p.port, p.lastSeen = ip, port, nowTick()
    p.name = tostring(packet.name or p.name or "Guest"):gsub("[%c]", ""):sub(1, 24)
    p.map = type(packet.map) == "string" and packet.map:sub(1, 40) or p.map
    p.x = type(packet.x) == "number" and math.floor(math.max(-100000, math.min(packet.x, 100000))) or p.x
    p.y = type(packet.y) == "number" and math.floor(math.max(-100000, math.min(packet.y, 100000))) or p.y
    p.sprite = type(packet.sprite) == "string" and packet.sprite:sub(1, 40) or p.sprite
  elseif packet.type == "chat" then
    local p = SessionNet.players[id]
    if not p then return end
    local line = { name = p.name or "Guest", text = tostring(packet.text or ""):gsub("[%c]", " "):sub(1, 120) }
    if line.text ~= "" then
      SessionNet.chat[#SessionNet.chat + 1] = line
      while #SessionNet.chat > 8 do table.remove(SessionNet.chat, 1) end
      for peerId, peer in pairs(SessionNet.players) do
        if peerId ~= id then peerSend(peer, { type = "chat", line = line, room = SessionNet.worldId, pin = SessionNet.pin }) end
      end
    end
  elseif packet.type == "leave" then
    SessionNet.players[id] = nil
  end
end

local function handleClientPacket(packet)
  if type(packet) ~= "table" or packet.room ~= SessionNet.worldId or tostring(packet.pin or "") ~= tostring(SessionNet.pin) then return end
  if packet.type == "full" then
    SessionNet.status = "LOBBY IS FULL (HOST + 3 GUESTS)"
    SessionNet.connected = false
  elseif packet.type == "welcome" then
    SessionNet.connected = true
    SessionNet.status = "CONNECTED - WAITING FOR HOST"
    SessionNet.lastStateReceived = nowTick()
    if type(packet.players) == "table" then
      SessionNet.players = {}
      for _, p in ipairs(packet.players) do if p.id and p.id ~= SessionNet.playerId then SessionNet.players[p.id] = p end end
    end
    if packet.started then SessionNet.started = true end
  elseif packet.type == "state" then
    SessionNet.connected = true
    SessionNet.status = packet.started and "IN MULTIPLAYER WORLD" or "IN LOBBY - WAITING FOR HOST"
    SessionNet.started = packet.started == true
    SessionNet.lastStateReceived = nowTick()
    SessionNet.players = {}
    for _, p in ipairs(packet.players or {}) do
      if p.id and p.id ~= SessionNet.playerId then SessionNet.players[p.id] = p end
    end
  elseif packet.type == "chat" and type(packet.line) == "table" then
    SessionNet.chat[#SessionNet.chat + 1] = packet.line
    while #SessionNet.chat > 8 do table.remove(SessionNet.chat, 1) end
  end
end

local function processPackets()
  if not SessionNet.udp then return end
  for _ = 1, 100 do -- drain a bounded number of non-blocking packets per frame
    local data, ip, port = SessionNet.udp:receivefrom()
    if not data then break end
    local ok, packet = pcall(json.decode, data)
    if ok and type(packet) == "table" then
      if SessionNet.mode == "host" then
        handleHostPacket(packet, ip, port)
        if SessionNet.handleExtraHost then SessionNet.handleExtraHost(packet, ip, port) end
      elseif SessionNet.mode == "client" then
        handleClientPacket(packet)
        if SessionNet.handleExtraClient then SessionNet.handleExtraClient(packet) end
      end
    end
  end
end

local function hostBroadcast()
  local players = buildPlayerList()
  -- Attach local host rich data
  for _, pl in ipairs(players) do
    if pl.id == "host" and S then
      pl.trainer = S.trainer
      pl.party = {}
      for i, g in ipairs(S.party or {}) do
        if i > 6 then break end
        pl.party[#pl.party + 1] = { sp = g.species, lv = g.level, hp = g.hp, max = g.max, rar = g.rarity }
      end
    end
  end
  local packet = {
    type = "state", started = SessionNet.started, players = players,
    room = SessionNet.worldId, pin = SessionNet.pin,
    weather = S and S.weather or "clear",
    seed = SessionNet.worldSeed,
  }
  for _, p in pairs(SessionNet.players) do peerSend(p, packet) end
  if SessionNet.pushWorldState and (SessionNet._wsEvery or 0) + 90 < nowTick() then
    SessionNet._wsEvery = nowTick()
    SessionNet.pushWorldState()
  end
end

function SessionNet.enterWorld(forceNew)
  if SessionNet.mode ~= "host" and SessionNet.mode ~= "client" then return false end
  local worldId = cleanPart(SessionNet.worldId, "room")
  local playerId = cleanPart(SessionNet.playerId, "player")
  -- Set session metadata AFTER Engine.newState, BEFORE HasSave/LoadGame.
  local sound = not (S and S.sound == false)
  Engine.newState()
  S.sound = sound
  S.sessionMode, S.sessionWorldId, S.sessionPlayerId = "multiplayer", worldId, playerId
  S.playerName = S.playerName or localName()
  S.sessionName = S.playerName
  Engine.safe(World.build, "giant_world")
  local loaded = false
  if not forceNew and HasSave() then loaded = Engine.safe(LoadGame) == true end
  if not loaded then
    Engine.placeAtStart()
    -- Stagger the first spawn slightly so players do not stack on the same tile.
    local candidates = {}
    local sx, sy = World.map.start[1], World.map.start[2]
    for r = 0, 8 do
      for dy = -r, r do
        for dx = -r, r do
          if math.abs(dx) == r or math.abs(dy) == r then
            local x, y = sx + dx, sy + dy
            if World.walkable(x, y) then candidates[#candidates + 1] = { x, y } end
          end
        end
      end
      if #candidates >= 32 then break end
    end
    if #candidates > 0 then
      local sum = 0
      for i = 1, #playerId do sum = sum + playerId:byte(i) end
      local at = (sum % #candidates) + 1
      S.px, S.py = candidates[at][1], candidates[at][2]
    end
    S.rx, S.ry = S.px, S.py
    S.worldVersion = 5
    S.party[1] = MakeGhost(Settings.starter, S.trainer)
    Engine.safe(NewQuest)
  end
  S.sessionMode, S.sessionWorldId, S.sessionPlayerId = "multiplayer", worldId, playerId
  S.rx, S.ry = S.px, S.py
  Go("explore")
  Say(loaded and "MULTIPLAYER CHARACTER LOADED" or "MULTIPLAYER WORLD - CHARACTER SAVED SEPARATELY")
  LocalSave()
  return true
end

function SessionNet.startGame()
  if SessionNet.mode ~= "host" then return false end
  SessionNet.started = true
  SessionNet.status = "WORLD STARTED"
  hostBroadcast()
  return SessionNet.enterWorld(SessionNet.pendingNewWorld)
end

function SessionNet.sayChat(text)
  text = tostring(text or ""):gsub("[%c]", " "):sub(1, 120)
  if text == "" then return false end
  local line = { name = localName(), text = text }
  SessionNet.chat[#SessionNet.chat + 1] = line
  while #SessionNet.chat > 8 do table.remove(SessionNet.chat, 1) end
  if SessionNet.mode == "client" and SessionNet.connected then
    sendTo(SessionNet.hostIp, SessionNet.hostPort, { type = "chat", id = SessionNet.playerId, text = text, room = SessionNet.worldId, pin = SessionNet.pin })
  elseif SessionNet.mode == "host" then
    for _, p in pairs(SessionNet.players) do peerSend(p, { type = "chat", line = line, room = SessionNet.worldId, pin = SessionNet.pin }) end
  end
  return true
end

function SessionNet.playerList()
  if SessionNet.mode == "host" then return buildPlayerList() end
  local out = {}
  for _, p in pairs(SessionNet.players) do out[#out + 1] = p end
  table.sort(out, function(a, b) if a.id == "host" then return true elseif b.id == "host" then return false end return tostring(a.name) < tostring(b.name) end)
  if SessionNet.mode == "client" and SessionNet.connected then
    local seen = false
    for _, p in ipairs(out) do if p.id == SessionNet.playerId then seen = true end end
    if not seen then out[#out + 1] = { id = SessionNet.playerId, name = localName(), localPlayer = true } end
  end
  return out
end

function SessionNet.tick()
  if SessionNet.mode == "offline" or not SessionNet.udp then return end
  processPackets()
  local t = nowTick()
  if SessionNet.mode == "host" then
    for id, p in pairs(SessionNet.players) do
      if t - (p.lastSeen or t) > 600 then SessionNet.players[id] = nil end -- 10 seconds without a packet
    end
    if t - SessionNet.lastState >= 12 then SessionNet.lastState = t; hostBroadcast() end
  elseif SessionNet.mode == "client" then
    if not SessionNet.connected and t - SessionNet.lastHello >= 30 then
      SessionNet.lastHello = t
      sendHello()
    elseif SessionNet.connected then
      if t - SessionNet.lastSnapshot >= 12 then
        SessionNet.lastSnapshot = t
        local snap = currentPlayerSnapshot(SessionNet.playerId, localName())
        snap.type = "snapshot"
        snap.trainer = S and S.trainer or 1
        snap.party = {}
        for i, g in ipairs((S and S.party) or {}) do
          if i > 6 then break end
          snap.party[#snap.party + 1] = { sp = g.species, lv = g.level, hp = g.hp, max = g.max, rar = g.rarity }
        end
        sendTo(SessionNet.hostIp, SessionNet.hostPort, snap)
      end
      if t - (SessionNet.lastStateReceived or t) > 600 then
        SessionNet.connected = false
        SessionNet.status = "HOST CONNECTION LOST - LOCAL CHARACTER IS STILL SAFE"
      end
    end
    if SessionNet.started and S and S.screen == "multiplayer" then
      SessionNet.enterWorld(false)
    end
  end
end

function SessionNet.drawWorld()
  if (SessionNet.mode ~= "host" and SessionNet.mode ~= "client") or not S or S.screen ~= "explore" then return end
  local localId = SessionNet.playerId
  for id, p in pairs(SessionNet.players or {}) do
    if id ~= localId and p.map == S.map and type(p.x) == "number" and type(p.y) == "number" then
      local cx, cy = WorldToScreen(p.x, p.y)
      local pl = Get("Player", Settings.player)
      if pl then DrawDressedAt(pl.sprite, cx, cy, CharScale(), { D = "#302641", B = "#7762c4", L = "#c9b9ff", H = "#ffffff" }, nil) end
      local name = tostring(p.name or "PLAYER"):upper():sub(1, 20)
      Box(cx - (#name * 4 + 6) / 2 + 8, cy - 15, #name * 4 + 6, 10, "shade")
      Text(name, cx - (#name * 4 + 6) / 2 + 11, cy - 7, "kyo")
    end
  end
end

function SessionNet.leave()
  -- Save while the current state still identifies its multiplayer world/player.
  -- This prevents a later menu/quit save from ever routing this character into SP.
  if S and S.sessionMode == "multiplayer" and S.map and LocalSave then pcall(LocalSave) end
  if SessionNet.mode == "client" and SessionNet.connected then
    sendTo(SessionNet.hostIp, SessionNet.hostPort, { type = "leave", id = SessionNet.playerId, room = SessionNet.worldId, pin = SessionNet.pin })
  end
  closeSocket()
  SessionNet.mode = "offline"
  SessionNet.connected, SessionNet.started = false, false
  SessionNet.players = {}
  SessionNet.status = "OFFLINE PLAY READY"
  SessionNet.hostIp, SessionNet.hostPort = nil, nil
  SessionNet.worldId, SessionNet.pin, SessionNet.playerId = nil, nil, nil
end

function SessionNet.shutdown()
  SessionNet.leave()
end

-- Display an explorable multiplayer status without drawing any online/account UI.
function SessionNet.overlay()
  if not S or S.screen ~= "explore" or S.sessionMode ~= "multiplayer" then return end
  local connected = SessionNet.mode == "host" or (SessionNet.mode == "client" and SessionNet.connected)
  TextFit(connected and "MULTIPLAYER" or "MP OFFLINE", Engine.W - 100, 44, 94, connected and "kyo" or "off", 6, 5)
end

-- =====================================================================
-- FULL WORLD SYNC + REAL-TIME PVP
-- Host is authoritative. Guests apply host events; PvP is host-mediated.
-- =====================================================================

SessionNet.worldSeed = SessionNet.worldSeed or nil
SessionNet.pvp = SessionNet.pvp or nil -- active challenge / battle meta
SessionNet.eventSeq = SessionNet.eventSeq or 0

local function nextSeq()
  SessionNet.eventSeq = (SessionNet.eventSeq or 0) + 1
  return SessionNet.eventSeq
end

local function broadcastAll(packet)
  packet.room = SessionNet.worldId
  packet.pin = SessionNet.pin
  if SessionNet.mode == "host" then
    for _, p in pairs(SessionNet.players) do peerSend(p, packet) end
  elseif SessionNet.mode == "client" and SessionNet.connected then
    sendTo(SessionNet.hostIp, SessionNet.hostPort, packet)
  end
end

-- Richer player snapshot (party preview for PvP + look)
local function richSnapshot(id, name)
  local base = currentPlayerSnapshot(id, name)
  base.trainer = S and S.trainer or 1
  base.kyo = S and math.floor(S.kyo or 0) or 0
  -- Compact party: species + level + hp ratio
  base.party = {}
  if S and S.party then
    for i, g in ipairs(S.party) do
      if i > 6 then break end
      base.party[#base.party + 1] = {
        sp = g.species or g.id,
        lv = g.level or 1,
        hp = g.hp or 1,
        max = g.max or g.hp or 1,
        rar = g.rarity,
      }
    end
  end
  if S and S.look then
    base.look = {
      bodyType = S.look.bodyType, skin = S.look.skin, hair = S.look.hair,
      hairColor = S.look.hairColor, chest = S.look.chest, legs = S.look.legs,
      feet = S.look.feet, head = S.look.head,
    }
  end
  return base
end

-- Host pushes shared world state (weather, market tick, seed)
function SessionNet.pushWorldState()
  if SessionNet.mode ~= "host" then return end
  local payload = {
    type = "world_state",
    seq = nextSeq(),
    weather = S and S.weather or "clear",
    t = S and S.t or 0,
    seed = SessionNet.worldSeed,
    market = nil,
  }
  if S and S.shroomMarket and S.shroomMarket.prices then
    -- send only a compact price table (numbers)
    payload.market = S.shroomMarket.prices
    payload.marketAt = S.shroomMarket.lastRefresh
  end
  broadcastAll(payload)
end

-- Any peer can request host to re-sync
function SessionNet.requestSync()
  if SessionNet.mode == "client" and SessionNet.connected then
    sendTo(SessionNet.hostIp, SessionNet.hostPort, {
      type = "sync_request", id = SessionNet.playerId,
      room = SessionNet.worldId, pin = SessionNet.pin,
    })
  elseif SessionNet.mode == "host" then
    SessionNet.pushWorldState()
  end
end

-- Broadcast a world event (node harvest, wild despawn, etc.)
function SessionNet.emitEvent(kind, data)
  if SessionNet.mode == "offline" then return end
  local packet = {
    type = "world_event",
    kind = kind,
    data = data or {},
    id = SessionNet.playerId,
    seq = nextSeq(),
  }
  if SessionNet.mode == "host" then
    broadcastAll(packet)
    SessionNet.applyEvent(kind, data, SessionNet.playerId)
  else
    broadcastAll(packet) -- host will validate + rebroadcast
  end
end

function SessionNet.applyEvent(kind, data, fromId)
  if not data then return end
  if kind == "node_gone" and ResourceNodes and S and S.resourceNodes then
    for i = #S.resourceNodes, 1, -1 do
      local n = S.resourceNodes[i]
      if n.x == data.x and n.y == data.y then table.remove(S.resourceNodes, i) break end
    end
  elseif kind == "weather" and S then
    S.weather = data.weather or S.weather
  elseif kind == "market_refresh" and S and data.prices then
    S.shroomMarket = S.shroomMarket or {}
    S.shroomMarket.prices = data.prices
    S.shroomMarket.lastRefresh = data.at or love.timer.getTime()
    if fromId ~= SessionNet.playerId then Say("*** SHROOM MARKET SYNCED ***") end
  elseif kind == "wild_clear" and S and data.x and data.y then
    -- optional: clear local wild marker at tile
  end
end

-- ---------------- PvP ----------------
-- Challenge a nearby player; host mediates accept → both enter shared battle.

function SessionNet.challengePlayer(targetId)
  if SessionNet.mode == "offline" then Say("HOST OR JOIN A SESSION FIRST") return false end
  if not targetId or targetId == SessionNet.playerId then return false end
  local packet = {
    type = "pvp_challenge",
    id = SessionNet.playerId,
    target = targetId,
    name = localName(),
    party = (richSnapshot(SessionNet.playerId, localName()).party),
    room = SessionNet.worldId, pin = SessionNet.pin,
  }
  if SessionNet.mode == "host" then
    if targetId == "host" then return false end
    local p = SessionNet.players[targetId]
    if p then peerSend(p, packet) end
    -- also notify self
    SessionNet.pvp = { phase = "outgoing", target = targetId, from = SessionNet.playerId }
    Say("CHALLENGE SENT TO " .. tostring((p and p.name) or targetId):upper())
  else
    sendTo(SessionNet.hostIp, SessionNet.hostPort, packet)
    SessionNet.pvp = { phase = "outgoing", target = targetId, from = SessionNet.playerId }
    Say("CHALLENGE SENT")
  end
  Play("quest")
  return true
end

function SessionNet.acceptPvp()
  local pvp = SessionNet.pvp
  if not pvp or pvp.phase ~= "incoming" then return false end
  local packet = {
    type = "pvp_accept",
    id = SessionNet.playerId,
    from = pvp.from,
    party = richSnapshot(SessionNet.playerId, localName()).party,
    room = SessionNet.worldId, pin = SessionNet.pin,
  }
  if SessionNet.mode == "host" then
    SessionNet.beginPvpBattle(pvp.from, SessionNet.playerId, pvp.party, packet.party)
  else
    sendTo(SessionNet.hostIp, SessionNet.hostPort, packet)
  end
  return true
end

function SessionNet.declinePvp()
  local pvp = SessionNet.pvp
  if not pvp then return end
  local packet = {
    type = "pvp_decline", id = SessionNet.playerId, from = pvp.from,
    room = SessionNet.worldId, pin = SessionNet.pin,
  }
  if SessionNet.mode == "host" then
    local p = SessionNet.players[pvp.from]
    if p then peerSend(p, packet) end
  else
    sendTo(SessionNet.hostIp, SessionNet.hostPort, packet)
  end
  SessionNet.pvp = nil
  Say("CHALLENGE DECLINED")
end

-- Build foe team from compact party snapshot and start local battle UI as trainer fight
function SessionNet.beginPvpBattle(idA, idB, partyA, partyB)
  local amI_A = (SessionNet.playerId == idA) or (SessionNet.mode == "host" and idA == "host" and SessionNet.playerId == "host")
  local amI_B = (SessionNet.playerId == idB) or (SessionNet.mode == "host" and idB == "host")
  local myId = SessionNet.playerId
  local foeParty = (myId == idA) and partyB or partyA
  local foeName = "RIVAL"
  if SessionNet.players[idA] and myId ~= idA then foeName = SessionNet.players[idA].name or foeName end
  if SessionNet.players[idB] and myId ~= idB then foeName = SessionNet.players[idB].name or foeName end
  if idA == "host" and myId ~= "host" then foeName = localName and "HOST" or "HOST" end

  -- Notify both sides
  local startPkt = {
    type = "pvp_start",
    a = idA, b = idB,
    partyA = partyA, partyB = partyB,
    room = SessionNet.worldId, pin = SessionNet.pin,
  }
  if SessionNet.mode == "host" then
    for _, p in pairs(SessionNet.players) do peerSend(p, startPkt) end
  end

  SessionNet.pvp = { phase = "battle", a = idA, b = idB }
  SessionNet.startLocalPvp(foeParty, foeName)
end

function SessionNet.startLocalPvp(foeParty, foeName)
  if not foeParty or #foeParty == 0 then
    Say("RIVAL HAS NO GHOSTS")
    return
  end
  -- Convert compact party into real ghosts for battle
  local team = {}
  for _, slot in ipairs(foeParty) do
    local g = MakeGhost(slot.sp or Settings.starter, slot.lv or 1, slot.rar)
    if g then
      g.hp = math.max(1, math.floor((slot.hp or 1)))
      if MakeUnit then
        local u = MakeUnit(g)
        u.hp = math.max(1, math.floor((slot.hp or u.max or 1) * ((slot.max and slot.max > 0) and (slot.hp / slot.max) or 1)))
        team[#team + 1] = u
      else
        team[#team + 1] = g
      end
    end
  end
  if #team == 0 then Say("COULD NOT BUILD RIVAL TEAM") return end
  -- Use existing trainer battle entry if available
  if StartTrainerBattle then
    StartTrainerBattle(foeName or "RIVAL", team)
  elseif StartBattle then
    StartBattle({ trainer = true, name = foeName or "RIVAL", team = team })
  else
    -- Fallback: set S.battle manually like a wild with trainer flag
    S.battle = {
      trainer = true, pvp = true, name = foeName or "RIVAL",
      foe = team[1], foeTeam = team, foeIndex = 1,
      unit = S.party and S.party[1] and MakeUnit and MakeUnit(S.party[1]) or nil,
      line = "PVP BATTLE!",
    }
    Go("battle")
  end
  Say("PVP BATTLE START!")
  Play("jump")
end

-- Nearby player challenge helper (call from talk/key)
function SessionNet.tryChallengeNearest()
  if SessionNet.mode == "offline" then return false end
  local best, bestD = nil, 9
  local list = SessionNet.players or {}
  if SessionNet.mode == "host" then
    -- include self as host in list already
  end
  for id, p in pairs(list) do
    if id ~= SessionNet.playerId and p.map == (S and S.map) and p.x and p.y then
      local dx, dy = (p.x - S.px), (p.y - S.py)
      local d = dx * dx + dy * dy
      if d < bestD then best, bestD = id, d end
    end
  end
  -- Also host presence for clients: host is in SessionNet.players as "host" after state
  if best then return SessionNet.challengePlayer(best) end
  Say("NO PLAYER IN RANGE")
  return false
end

-- Patch packet handlers via wrappers (called from process path if we hook types)
function SessionNet.handleExtraHost(packet, ip, port)
  local id = cleanPart(packet.id, "guest")
  if packet.type == "snapshot" then
    local p = SessionNet.players[id]
    if p and packet.party then p.party = packet.party end
    if p and packet.look then p.look = packet.look end
    if p and packet.trainer then p.trainer = packet.trainer end
  elseif packet.type == "sync_request" then
    SessionNet.pushWorldState()
  elseif packet.type == "world_event" then
    SessionNet.applyEvent(packet.kind, packet.data, id)
    -- rebroadcast to others
    for peerId, peer in pairs(SessionNet.players) do
      if peerId ~= id then peerSend(peer, packet) end
    end
  elseif packet.type == "pvp_challenge" then
    local target = cleanPart(packet.target, "")
    if target == "host" or target == SessionNet.playerId then
      SessionNet.pvp = { phase = "incoming", from = id, party = packet.party, name = packet.name }
      Say((packet.name or "PLAYER") .. " CHALLENGES YOU! (P ACCEPT / N DECLINE)")
      Play("jump")
    else
      local p = SessionNet.players[target]
      if p then peerSend(p, packet) end
    end
  elseif packet.type == "pvp_accept" then
    local from = cleanPart(packet.from, "")
    local partyA = (SessionNet.players[from] and SessionNet.players[from].party) or {}
    local partyB = packet.party or {}
    -- if host is one side
    if from == "host" or id == "host" then
      SessionNet.beginPvpBattle(from, id, partyA, partyB)
    else
      SessionNet.beginPvpBattle(from, id, partyA, partyB)
    end
  elseif packet.type == "pvp_decline" then
    local from = cleanPart(packet.from, "")
    if from == SessionNet.playerId or from == "host" then
      SessionNet.pvp = nil
      Say("CHALLENGE DECLINED")
    end
    local p = SessionNet.players[from]
    if p then peerSend(p, packet) end
  end
end

function SessionNet.handleExtraClient(packet)
  if packet.type == "world_state" then
    if packet.weather and S then S.weather = packet.weather end
    if packet.market and S then
      S.shroomMarket = S.shroomMarket or {}
      S.shroomMarket.prices = packet.market
      S.shroomMarket.lastRefresh = packet.marketAt
    end
    if packet.seed then SessionNet.worldSeed = packet.seed end
    SessionNet.lastStateReceived = nowTick()
  elseif packet.type == "world_event" then
    SessionNet.applyEvent(packet.kind, packet.data, packet.id)
  elseif packet.type == "pvp_challenge" then
    SessionNet.pvp = { phase = "incoming", from = packet.id, party = packet.party, name = packet.name }
    Say((packet.name or "PLAYER") .. " CHALLENGES YOU! (P ACCEPT / N DECLINE)")
    Play("jump")
  elseif packet.type == "pvp_start" then
    local my = SessionNet.playerId
    local foeParty = (my == packet.a) and packet.partyB or packet.partyA
    SessionNet.pvp = { phase = "battle", a = packet.a, b = packet.b }
    SessionNet.startLocalPvp(foeParty, "RIVAL")
  elseif packet.type == "pvp_decline" then
    SessionNet.pvp = nil
    Say("CHALLENGE DECLINED")
  elseif packet.type == "state" and packet.players then
    -- richer player list already applied upstream; stash party data
    for _, pl in ipairs(packet.players) do
      if pl.id and pl.id ~= SessionNet.playerId then
        SessionNet.players[pl.id] = SessionNet.players[pl.id] or {}
        local p = SessionNet.players[pl.id]
        for k, v in pairs(pl) do p[k] = v end
      end
    end
  end
end
