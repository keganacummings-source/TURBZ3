-- Click a wild ghost: ease camera toward it, slight zoom, show stats + moves.

GhostInspect = GhostInspect or {}

function GhostInspect.open(wild)
  if not wild or not wild.ghost then return end
  S.ghostInspect = {
    wild = wild,
    ghost = wild.ghost,
    t = 0,
    camX0 = S.rx or S.px,
    camY0 = S.ry or S.py,
    zoom0 = S.zoom or 1,
  }
  Play("step")
end

function GhostInspect.close()
  if S.ghostInspect and S.ghostInspect.zoom0 then
    S.zoom = S.ghostInspect.zoom0
  end
  S.ghostInspect = nil
end

function GhostInspect.update(dt)
  local gi = S.ghostInspect
  if not gi then return end
  gi.t = (gi.t or 0) + (dt or 0.016)
  local w = gi.wild
  local tx = (w.rx or w.x or S.px)
  local ty = (w.ry or w.y or S.py)
  local k = 1 - math.exp(-3.2 * (dt or 0.016))
  S.rx = (S.rx or S.px) + (tx - (S.rx or S.px)) * k
  S.ry = (S.ry or S.py) + (ty - (S.ry or S.py)) * k
  -- slight zoom in (respect discrete zoom table if present)
  local targetZ = (gi.zoom0 or 1) * 1.25
  S.zoom = (S.zoom or 1) + (targetZ - (S.zoom or 1)) * k
end

function GhostInspect.draw()
  local gi = S.ghostInspect
  if not gi or not gi.ghost then return end
  local g = gi.ghost
  local sp = Species and Species(g) or Get("Ghost", g.species)
  local W, H = Engine.W or 480, Engine.H or 480
  local panelW = math.floor(W * 0.38)
  Box(8, 48, panelW, H - 70, "panel")
  Frame(8, 48, panelW, H - 70, "kyo")
  local y = 64
  TextFit(Upper(GhostName and GhostName(g) or (sp and sp.name) or "?"), 16, y, panelW - 16, "kyo", 8, 8)
  y = y + 18
  local types = {}
  if GhostTypes then
    for _, t in ipairs(GhostTypes(g) or {}) do types[#types + 1] = Upper(t) end
  elseif sp then
    if sp.type then types[1] = Upper(sp.type) end
    if sp.type2 then types[2] = Upper(sp.type2) end
  end
  TextFit("TYPE " .. table.concat(types, " / "), 16, y, panelW - 16, "green", 8, 8)
  y = y + 16
  local r = RarityOf and RarityOf(g)
  TextFit("LV" .. tostring(g.level or 1) .. "  " .. Upper((r and r.name) or ""), 16, y, panelW - 16, "ink", 8, 8)
  y = y + 20
  Text("STATS", 16, y, "dim", 8)
  y = y + 14
  for _, st in ipairs(Settings.stats or { "spooky", "sleepy", "speed", "damage", "mass" }) do
    TextFit(Upper(st) .. "  " .. tostring(g[st] or (sp and sp[st]) or 0), 16, y, panelW - 16, "ink", 8, 8)
    y = y + 13
  end
  y = y + 8
  Text("MOVES", 16, y, "dim", 8)
  y = y + 14
  local moves = MovesOf and MovesOf(g) or {}
  for _, m in ipairs(moves) do
    local nm = type(m) == "table" and (m.name or m.id) or tostring(m)
    TextFit("- " .. Upper(nm), 16, y, panelW - 16, "ink", 8, 8)
    y = y + 13
    if y > H - 40 then break end
  end
  Text("ESC / CLICK AWAY TO CLOSE", 16, H - 28, "help", 8)
end
