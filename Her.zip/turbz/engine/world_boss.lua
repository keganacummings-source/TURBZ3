-- World bosses: every 30 minutes a skeleton warlord with a full competitive party spawns.
-- Killing always drops armor.

WorldBoss = WorldBoss or {}

local INTERVAL = 30 * 60 -- seconds
local PARTY_SIZE = 6

function WorldBoss.init()
  S.worldBoss = S.worldBoss or {
    nextAt = (love.timer and love.timer.getTime() or 0) + 60, -- first boss after 1 min
    active = nil,
    kills = 0,
  }
end

local function pickTile()
  if not World or not World.w then return S.px or 10, S.py or 10 end
  for _ = 1, 40 do
    local x = love.math.random(4, World.w - 5)
    local y = love.math.random(4, World.h - 5)
    if World.walkable(x, y) then return x, y end
  end
  return S.px or 10, S.py or 10
end

local function buildParty(level)
  local team = {}
  local all = All("Ghost") or {}
  if #all == 0 then return team end
  for i = 1, PARTY_SIZE do
    local sp = all[love.math.random(1, #all)]
    local lv = math.max(20, level + love.math.random(-5, 15))
    local g = MakeGhost and MakeGhost(sp.id, lv) or nil
    if g then team[#team + 1] = g end
  end
  return team
end

local NAMES = {
  "Marrow Saint", "Ash Regent", "Tide Tyrant", "Grave Oracle", "Hollow Crown",
  "Cinder Maw", "Rime Butcher", "Void Cantor", "Thorn King", "Blood Nun",
}

function WorldBoss.spawn()
  WorldBoss.init()
  local x, y = pickTile()
  local level = math.max(40, (S.trainer or 10) + 25)
  local party = buildParty(level)
  local layers = Sheets and Sheets.roll and Sheets.roll("boss", "ghoul", "eclipse") or nil
  S.bossSigs = S.bossSigs or {}
  if layers then
    local sig = string.format("%d%d%d%d%d", layers.body or 0, layers.head or 0, layers.chest or 0, layers.legs or 0, layers.accessory or 0)
    local guard = 0
    while S.bossSigs[sig] and guard < 12 and Sheets.roll do
      layers = Sheets.roll("boss", "ghoul", "eclipse")
      sig = string.format("%d%d%d%d%d", layers.body or 0, layers.head or 0, layers.chest or 0, layers.legs or 0, layers.accessory or 0)
      guard = guard + 1
    end
    S.bossSigs[sig] = true
  end
  local boss = {
    id = "world_boss_" .. tostring((S.t or 0) + love.math.random(1, 99999)),
    kind = "WorldBoss",
    name = NAMES[love.math.random(1, #NAMES)] .. " " .. love.math.random(2, 9),
    x = x, y = y,
    level = level,
    party = party,
    sprite = "enemy",
    layers = layers,
    once = true,
  }
  S.worldBoss.active = boss
  S.worldBoss.nextAt = (love.timer and love.timer.getTime() or 0) + INTERVAL
  Say(Upper(boss.name) .. " HAS RISEN")
  Play("jump")
  Fire("world_boss_spawn", boss)
  return boss
end

function WorldBoss.update(dt)
  WorldBoss.init()
  local now = love.timer and love.timer.getTime() or 0
  if S.worldBoss.active then return end
  if now >= (S.worldBoss.nextAt or 0) then
    WorldBoss.spawn()
  end
end

function WorldBoss.active()
  return S.worldBoss and S.worldBoss.active
end

function WorldBoss.onDefeated()
  local b = WorldBoss.active()
  if not b then return end
  -- Always drop armor
  if Armor and Armor.tryDropFromGhost then
    Armor.tryDropFromGhost(b.level or 120, true)
    -- chance for a second piece
    if love.math.random(1, 100) <= 35 then
      Armor.tryDropFromGhost(b.level or 120, true)
    end
  end
  S.worldBoss.kills = (S.worldBoss.kills or 0) + 1
  S.worldBoss.active = nil
  S.worldBoss.nextAt = (love.timer and love.timer.getTime() or 0) + INTERVAL
  Say("WARLORD FALLEN — ARMOR CLAIMED")
  Play("win")
end

function WorldBoss.tryEngage()
  local b = WorldBoss.active()
  if not b then return false end
  if math.abs((S.px or 0) - b.x) > 1 or math.abs((S.py or 0) - b.y) > 1 then return false end
  -- Start trainer-style battle with the warlord party
  if not S.battle and b.party and #b.party > 0 then
    -- Build a faux boss def for existing battle path
    S.worldBossFight = b
    if StartBossBattle then
      StartBossBattle(b)
    elseif StartTrainerBattle then
      StartTrainerBattle(b)
    else
      -- Manual: use first ghost as wild-like multi
      local wild = { x = b.x, y = b.y, ghost = b.party[1], species = b.party[1].species, boss = true }
      if StartIntro then StartIntro(wild) end
    end
    return true
  end
  return false
end
