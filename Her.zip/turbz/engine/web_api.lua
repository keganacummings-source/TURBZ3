-- Website play only. Desktop LÖVE never opens a socket and never posts chat.
-- love.js evaluates JavaScript through love.js.eval (os/openURL bridge).
local json = require("engine.json")

WebApi = {
  on = false,
  user = "",
  token = "",
  lines = {},
  seen = {},
  since = 0,
  wait = {},
  clock = 0,
  chatClock = 0,
  beatClock = 0,
  status = "",
}

local function js(code)
  if not (love.js and love.js.eval) then return "" end
  local ok, out = pcall(love.js.eval, code)
  if not ok or type(out) ~= "string" then return "" end
  return out
end

local function installBridge()
  return js([[(function(){
    if (window.TURBZ_BRIDGE) return "ok";
    window.TURBZ_BRIDGE = {
      inbox: {},
      seq: 1,
      send: function(method, path, body) {
        var id = String(this.seq++);
        var self = this;
        var opt = { method: method, headers: { "Content-Type": "application/json", "Authorization": "Bearer " + (window.TURBZ_TOKEN || "") } };
        if (body) opt.body = body;
        fetch((window.TURBZ_API || "") + path, opt)
          .then(function(r){ return r.text(); })
          .then(function(t){ self.inbox[id] = t || "{}"; })
          .catch(function(e){ self.inbox[id] = JSON.stringify({ ok:false, error:String(e) }); });
        return id;
      },
      begin: function(id) { this.bufs = this.bufs || {}; this.bufs[id] = ""; return "ok"; },
      push: function(id, chunk) { this.bufs[id] = (this.bufs[id] || "") + chunk; return "ok"; },
      finish: function(id, path) {
        var body = this.bufs[id] || "{}";
        delete this.bufs[id];
        var req = String(this.seq++);
        var self = this;
        var headers = { "Content-Type": "application/json", "Authorization": "Bearer " + (window.TURBZ_TOKEN || "") };
        var jobs = [];
        jobs.push(fetch((window.TURBZ_API || "") + path, { method: "POST", headers: headers, body: body }).then(function(r){ return r.text(); }).catch(function(e){ return JSON.stringify({ ok:false, error:String(e) }); }));
        Promise.all(jobs).then(function(parts){ self.inbox[req] = parts[0] || "{}"; });
        return req;
      },
      take: function(id) {
        if (!Object.prototype.hasOwnProperty.call(this.inbox, id)) return "WAIT";
        var v = this.inbox[id];
        delete this.inbox[id];
        return "DATA:" + v;
      }
    };
    return "ok";
  })()]])
end

function WebApi.boot()
  local osname = (love.system and love.system.getOS and love.system.getOS()) or ""
  WebApi.on = osname == "Web"
  if not WebApi.on then return end
  installBridge()
  local raw = js([[(function(){ return JSON.stringify({ user: window.TURBZ_USER || "", token: window.TURBZ_TOKEN || "", api: window.TURBZ_API || "" }); })()]])
  local info = json.decode(raw) or {}
  WebApi.user = tostring(info.user or "")
  WebApi.token = tostring(info.token or "")
  if WebApi.user == "" or WebApi.token == "" then
    WebApi.status = "LOG IN ON THE WEBSITE TO PLAY"
  else
    WebApi.status = "GLOBAL CHAT ON  ·  " .. WebApi.user
    WebApi.note("SYSTEM", "WEBSITE PLAY. PLAIN TEXT IN THIS CHAT GOES TO EVERYONE ON THE SITE.")
  end
end

function WebApi.note(name, text)
  if not WebApi.on then return end
  WebApi.lines[#WebApi.lines + 1] = { name = name or "SYSTEM", text = text or "" }
  while #WebApi.lines > 80 do table.remove(WebApi.lines, 1) end
end

local function track(id)
  id = tostring(id or ""):gsub("%s+", "")
  if id ~= "" and id ~= "ok" then WebApi.wait[id] = true end
end

local function pump()
  local done = {}
  for id in pairs(WebApi.wait) do
    local raw = js("window.TURBZ_BRIDGE.take(" .. json.encode(id) .. ")")
    raw = tostring(raw or ""):gsub("^%s+", ""):gsub("%s+$", "")
    if raw == "WAIT" or raw == "" then
      -- still in flight
    elseif raw:sub(1, 5) == "DATA:" then
      done[#done + 1] = id
      local payload = json.decode(raw:sub(6)) or {}
      if payload.ok == false and payload.error then WebApi.status = tostring(payload.error) end
      if payload.message then WebApi.ingest(payload.message) end
      if payload.messages then
        for _, m in ipairs(payload.messages) do WebApi.ingest(m) end
      end
    else
      done[#done + 1] = id
    end
  end
  for _, id in ipairs(done) do WebApi.wait[id] = nil end
end

function WebApi.ingest(m)
  if type(m) ~= "table" or not m.id then return end
  local id = tonumber(m.id) or 0
  if id <= 0 or WebApi.seen[id] then return end
  WebApi.seen[id] = true
  if id > WebApi.since then WebApi.since = id end
  for i = #WebApi.lines, math.max(1, #WebApi.lines - 6), -1 do
    local line = WebApi.lines[i]
    if line.pending and line.name == m.user and line.text == m.text then
      line.pending, line.id = nil, id
      return
    end
  end
  WebApi.lines[#WebApi.lines + 1] = { id = id, name = (m.via == "discord" and ((m.user or "?") .. " · DISCORD") or (m.user or "?")), text = m.text or "" }
  while #WebApi.lines > 80 do table.remove(WebApi.lines, 1) end
end

function WebApi.postLarge(path, tbl)
  if not WebApi.on or WebApi.token == "" then return false end
  local body = json.encode(tbl or {})
  local bid = "b" .. tostring(math.floor((love.math.random() * 1e9)))
  js("window.TURBZ_BRIDGE.begin(" .. json.encode(bid) .. ")")
  local i = 1
  while i <= #body do
    local chunk = body:sub(i, i + 1800)
    i = i + 1800
    js("window.TURBZ_BRIDGE.push(" .. json.encode(bid) .. "," .. json.encode(chunk) .. ")")
  end
  track(js("window.TURBZ_BRIDGE.finish(" .. json.encode(bid) .. "," .. json.encode(path) .. ")"))
  return true
end

function WebApi.say(text)
  if not WebApi.on then return false end
  text = tostring(text or ""):gsub("[%c]", " "):sub(1, 180)
  if text == "" or text:sub(1, 1) == "/" then return false end
  if WebApi.token == "" then
    WebApi.note("SYSTEM", "LOG IN ON THE WEBSITE BEFORE CHAT.")
    return false
  end
  WebApi.lines[#WebApi.lines + 1] = { pending = true, name = WebApi.user, text = text }
  local body = json.encode({ text = text })
  local id = js("window.TURBZ_BRIDGE.send('POST','/api/chat'," .. json.encode(body) .. ")")
  track(id)
  return true
end

local function gear()
  local eq = (Armor and Armor.equipped and Armor.equipped()) or {}
  local slots = (Armor and Armor.SLOTS) or { "head", "chest", "legs", "feet", "accessory" }
  local out = {}
  for _, slot in ipairs(slots) do
    local p = eq[slot]
    if type(p) == "table" then
      local enchants = {}
      for i, e in ipairs(p.enchants or {}) do
        if i > 12 then break end
        local def = Armor.ENCHANT_BY_ID and e.id and Armor.ENCHANT_BY_ID[e.id]
        local unit = (def and def.unit) or ""
        local power = math.floor(tonumber(e.power) or 0)
        local shown = tostring((def and def.name) or e.id or "Enchant")
        if power > 0 then
          if unit == "%" then shown = shown .. " +" .. power .. "%"
          else shown = shown .. " +" .. power end
        end
        enchants[#enchants + 1] = {
          name = shown:sub(1, 48),
          about = tostring((def and def.about) or ""):sub(1, 80),
        }
      end
      local effects = {}
      for i, fx in ipairs(p.fx or {}) do
        if i > 3 then break end
        effects[#effects + 1] = "Sigil " .. tostring(math.floor(tonumber(fx) or 0))
      end
      out[#out + 1] = {
        slot = slot,
        name = tostring(p.name or slot):sub(1, 48),
        rarity = tostring(p.qualityName or p.quality or "Common"):sub(1, 16),
        quality = tostring(p.quality or "common"):sub(1, 16),
        level = math.max(1, math.min(400, math.floor(tonumber(p.level) or 1))),
        enchants = enchants,
        effects = effects,
      }
    end
  end
  return out
end

function WebApi.postFeed(tbl)
  if not WebApi.on or WebApi.token == "" then return false end
  local body = json.encode(tbl or {})
  if #body > 6000 then return false end
  local id = js("window.TURBZ_BRIDGE.send('POST','/api/feed'," .. json.encode(body) .. ")")
  track(id)
  return true
end

local function snapshot()
  local owned = {}
  local function add(g)
    if type(g) == "table" then owned[#owned + 1] = g end
  end
  for _, g in ipairs(S.party or {}) do add(g) end
  for _, g in ipairs(S.box or {}) do add(g) end
  local total = 0
  for _, g in ipairs(owned) do total = total + math.floor(tonumber(g.level) or 1) end
  table.sort(owned, function(a, b) return (tonumber(a.level) or 1) > (tonumber(b.level) or 1) end)
  local top = {}
  for i = 1, math.min(6, #owned) do
    local g = owned[i]
    local name = (GhostName and GhostName(g)) or g.nick or g.name or g.species or "Ghost"
    top[#top + 1] = { name = tostring(name):sub(1, 16), species = tostring(g.species or ""), level = math.floor(tonumber(g.level) or 1) }
  end
  local loot = {}
  for i, drop in ipairs(S.recentDrops or {}) do
    if i > 6 then break end
    loot[#loot + 1] = { id = tostring(drop.id or "item"):sub(1, 32), name = tostring(drop.name or "Item"):sub(1, 32) }
  end
  return {
    character = tostring(S.playerName or WebApi.user or "KYO"):sub(1, 16),
    trainer = math.floor(tonumber(S.trainer) or 1),
    totalLevels = total,
    ghostCount = #owned,
    top = top,
    equipment = gear(),
    loot = loot,
  }
end

function WebApi.snapshot()
  return snapshot()
end

local function playing()
  if not S or not S.screen then return false end
  return S.screen ~= "title" and S.screen ~= "menu" and S.screen ~= "login" and S.screen ~= "multiplayer"
end

function WebApi.tick(dt)
  if not WebApi.on or WebApi.token == "" then return end
  WebApi.clock = WebApi.clock + (dt or 0)
  if WebApi.clock < 0.4 then return end
  WebApi.clock = 0
  pump()
  WebApi.chatClock = WebApi.chatClock + 0.4
  WebApi.beatClock = WebApi.beatClock + 0.4
  if WebApi.chatClock >= 3 then
    WebApi.chatClock = 0
    local id = js("window.TURBZ_BRIDGE.send('GET','/api/chat?after=" .. tostring(WebApi.since) .. "')")
    track(id)
  end
  if WebApi.beatClock >= 20 and playing() then
    WebApi.beatClock = 0
    local body = json.encode(snapshot())
    local id = js("window.TURBZ_BRIDGE.send('POST','/api/presence'," .. json.encode(body) .. ")")
    track(id)
  end
end
