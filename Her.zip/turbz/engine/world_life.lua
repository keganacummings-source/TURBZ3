-- Living overworld: settlements/camps are terms; travelers, ambushes, and nodes move at runtime.
-- Most townfolk leave their tiles. A minority (keepers, guards, merchants, and a stable handful) stay put.

WorldLife = WorldLife or {}

NewTerm "Settlement" {
  name = "Hamlet",
  map = "giant_world",
  x = 0,
  y = 0,
  level = 1,
  city = false,
  rest = false,
  sprite = "quest_flag",
  about = "",
}

NewTerm "EnemyCamp" {
  name = "Bone Camp",
  map = "giant_world",
  x = 0,
  y = 0,
  level = 10,
  pack = 4,
  sprite = "skeleton",
  about = "",
}

local function hashId(id)
  local h = 0
  id = tostring(id or "")
  for i = 1, #id do h = (h + id:byte(i) * i) % 100000 end
  return h
end

function WorldLife.isAnchored(def)
  if not def then return true end
  if def.anchored == true then return true end
  local blob = string.lower((def.role or "") .. " " .. (def.name or "") .. " " .. (def.id or ""))
  if blob:find("merchant", 1, true) or blob:find("vendor", 1, true) or blob:find("shop", 1, true) then
    return true
  end
  -- Most people stay on their tile. Only about one in eight wanders, and not far.
  if hashId(def.id) % 8 ~= 0 then return true end
  return false
end

local function isCompanion(id)
  for _, v in ipairs(S.npcCompanions or {}) do if v == id then return true end end
  return false
end

local function ghostPool()
  local all = (GhostList and GhostList()) or All("Ghost") or {}
  return all
end

function WorldLife.bindFolk()
  S.folk = S.folk or {}
  local function consider(def)
    if not def or def.map ~= (S.map or "giant_world") then return end
    local st = S.folk[def.id]
    if not st then
      local anchored = WorldLife.isAnchored(def)
      st = {
        homeX = def.x, homeY = def.y,
        anchored = anchored,
        activity = anchored and "stay" or "wander",
        tx = def.x, ty = def.y,
        timer = love.math.random(2, 8),
        stuck = 0,
        talk = 0,
        party = nil,
        leader = false,
        pet = nil,
        petName = nil,
      }
      if not anchored then
        local h = hashId(def.id)
        local pool = ghostPool()
        if h % 3 == 1 and #pool > 0 then
          local g = pool[(h % #pool) + 1]
          st.pet = g.id
          st.petName = g.name or g.id
        end
        if not World.walkable(def.x, def.y) and World.emptyNear then
          local spots = World.emptyNear(def.x, def.y, 8, 1)
          if spots[1] then def.x, def.y = spots[1][1], spots[1][2] end
        end
      end
      S.folk[def.id] = st
    else
      st.homeX, st.homeY = st.homeX or def.x, st.homeY or def.y
      local anchored = WorldLife.isAnchored(def)
      if anchored then def.x, def.y = st.homeX, st.homeY end
      st.anchored = anchored
    end
    if st.anchored then def.x, def.y = st.homeX, st.homeY end
  end
  for _, def in ipairs(All("TownNPC")) do consider(def) end
  for _, def in ipairs(All("Blurb")) do consider(def) end
  WorldLife.formParties()
end

function WorldLife.formParties()
  local roam = {}
  for _, def in ipairs(All("TownNPC")) do
    local st = S.folk and S.folk[def.id]
    if st and not st.anchored and not st.party then roam[#roam + 1] = def end
  end
  table.sort(roam, function(a, b)
    local sa, sb = S.folk[a.id], S.folk[b.id]
    if sa.homeY ~= sb.homeY then return sa.homeY < sb.homeY end
    return sa.homeX < sb.homeX
  end)
  local i = 1
  while i + 2 <= #roam do
    local a, b, c = roam[i], roam[i + 1], roam[i + 2]
    local ax, ay = S.folk[a.id].homeX, S.folk[a.id].homeY
    local function close(d)
      local st = S.folk[d.id]
      return math.abs(st.homeX - ax) + math.abs(st.homeY - ay) < 700
    end
    if close(b) and close(c) then
      S.folk[a.id].leader = true
      S.folk[a.id].party = a.id
      S.folk[b.id].party = a.id
      S.folk[c.id].party = a.id
      i = i + 3
    else
      i = i + 1
    end
  end
end

local function walkableStep(x, y, nx, ny, selfId)
  if not World.walkable(nx, ny) then return false end
  if nx == math.floor((S.px or 0) + 0.5) and ny == math.floor((S.py or 0) + 0.5) then return false end
  local hit = PlaceAt and PlaceAt(nx, ny)
  if hit and hit.id ~= selfId and hit.kind ~= "TownNPC" and hit.kind ~= "Blurb" and hit.kind ~= "QuestGiver" then
    return false
  end
  return true
end

local function stepToward(def, st, tx, ty)
  local x, y = def.x, def.y
  if x == tx and y == ty then return true end
  local dx, dy = tx - x, ty - y
  local sx = dx == 0 and 0 or (dx > 0 and 1 or -1)
  local sy = dy == 0 and 0 or (dy > 0 and 1 or -1)
  local opts
  if math.abs(dx) >= math.abs(dy) then
    opts = { { sx, 0 }, { 0, sy }, { sx, sy }, { -sy, 0 }, { 0, -sx } }
  else
    opts = { { 0, sy }, { sx, 0 }, { sx, sy }, { 0, -sx }, { -sy, 0 } }
  end
  for _, d in ipairs(opts) do
    if not (d[1] == 0 and d[2] == 0) then
      local nx, ny = x + d[1], y + d[2]
      if walkableStep(x, y, nx, ny, def.id) then
        def.x, def.y = nx, ny
        st.faceDx, st.faceDy = d[1], d[2]
        st.steps = (st.steps or 0) + 1
        st.stuck = 0
        return nx == tx and ny == ty
      end
    end
  end
  st.stuck = (st.stuck or 0) + 1
  return false
end

local function findNode(x, y, limit)
  local best, bd = nil, limit or 180
  for _, n in ipairs(S.resourceNodes or {}) do
    local d = math.abs(n.x - x) + math.abs(n.y - y)
    if d > 2 and d < bd then best, bd = n, d end
  end
  return best
end

local function findShore(x, y)
  for _ = 1, 8 do
    local nx = x + love.math.random(-10, 10)
    local ny = y + love.math.random(-10, 10)
    if World.walkable(nx, ny) then
      for _, d in ipairs(DIRS or { {1,0},{-1,0},{0,1},{0,-1} }) do
        local t = World.tileAt and World.tileAt(nx + d[1], ny + d[2])
        if t == "ocean" then return nx, ny end
      end
    end
  end
  return nil
end

local function findWild(x, y)
  local best, bd = nil, 14
  for _, w in ipairs(S.wilds or {}) do
    local d = math.abs((w.x or 0) - x) + math.abs((w.y or 0) - y)
    if d > 1 and d < bd then best, bd = w, d end
  end
  return best
end

local function findTalker(def, st)
  local best, bd, who = nil, 70, nil
  local function scan(list)
    for _, other in ipairs(list) do
      if other.id ~= def.id then
        local os = S.folk[other.id]
        if os and not os.anchored then
          local d = math.abs(other.x - def.x) + math.abs(other.y - def.y)
          if d > 1 and d < bd then best, bd, who = other, d, other end
        end
      end
    end
  end
  scan(All("TownNPC"))
  return who
end

local function randomWalkable(x, y, lo, hi)
  for _ = 1, 16 do
    local nx = x + love.math.random(lo, hi) * (love.math.random(0, 1) == 0 and -1 or 1)
    local ny = y + love.math.random(lo, hi) * (love.math.random(0, 1) == 0 and -1 or 1)
    if World.walkable(nx, ny) then return nx, ny end
  end
  return x, y
end

function WorldLife.retarget(def, st)
  if st.party and not st.leader then
    local lead = Get("TownNPC", st.party)
    if lead then
      st.activity = "party"
      st.tx, st.ty = lead.x, lead.y
      st.timer = 6
      return
    end
  end
  local roll = love.math.random(1, 100)
  if st.leader then roll = love.math.random(1, 100) end
  local biasHunt = st.leader and roll <= 55
  if biasHunt or (not st.leader and roll <= 24) then
    st.activity = "hunt"
    local w = findWild(def.x, def.y)
    if w then st.tx, st.ty = w.x, w.y
    else st.tx, st.ty = randomWalkable(def.x, def.y, 2, 6) end
  elseif roll <= 46 then
    st.activity = "resource"
    local n = findNode(def.x, def.y, 10)
    if n then st.tx, st.ty = n.x, n.y
    else st.tx, st.ty = randomWalkable(def.x, def.y, 2, 6) end
  elseif roll <= 64 then
    st.activity = "fish"
    local fx, fy = findShore(def.x, def.y)
    if fx then st.tx, st.ty = fx, fy
    else st.activity = "wander"; st.tx, st.ty = randomWalkable(def.x, def.y, 2, 5) end
  elseif roll <= 80 then
    st.activity = "talk"
    local other = findTalker(def, st)
    if other then st.tx, st.ty = other.x, other.y; st.talkTarget = other.id
    else st.activity = "wander"; st.tx, st.ty = randomWalkable(def.x, def.y, 2, 5) end
  else
    st.activity = "wander"
    st.tx, st.ty = randomWalkable(def.x, def.y, 2, 6)
  end
  local hx, hy = st.homeX or def.x, st.homeY or def.y
  local dx, dy = (st.tx or hx) - hx, (st.ty or hy) - hy
  if math.abs(dx) + math.abs(dy) > 8 then
    local pull = 8 / math.max(1, math.abs(dx) + math.abs(dy))
    st.tx = math.floor(hx + dx * pull + 0.5)
    st.ty = math.floor(hy + dy * pull + 0.5)
  end
  st.timer = love.math.random(8, 22)
  st.stuck = 0
end

local function stepOne(def)
  local st = S.folk and S.folk[def.id]
  if not st or st.anchored or isCompanion(def.id) then return end
  if (st.talk or 0) > 0 then st.talk = st.talk - 1; return end
  st.timer = (st.timer or 0) - 1
  if not st.tx or st.stuck > 4 or st.timer <= 0 then WorldLife.retarget(def, st) end
  local arrived = stepToward(def, st, st.tx or def.x, st.ty or def.y)
  if arrived then
    if st.activity == "talk" then st.talk = 5 end
    if st.activity == "fish" or st.activity == "resource" or st.activity == "hunt" then
      st.timer = love.math.random(4, 9)
      st.tx, st.ty = def.x, def.y
      if st.timer <= 1 then WorldLife.retarget(def, st) end
    else
      WorldLife.retarget(def, st)
    end
  end
end

local function stepAmbushers()
  local px = math.floor((S.px or 0) + 0.5)
  local py = math.floor((S.py or 0) + 0.5)
  for _, n in ipairs(S.npcs or {}) do
    if n.ambush then
      n.away = 0
      local dx, dy = px - n.x, py - n.y
      if math.abs(dx) + math.abs(dy) <= 1 and S.screen == "explore" and not S.battle and StartEnemyIntro then
        StartEnemyIntro(n)
        return
      end
      local sx = dx == 0 and 0 or (dx > 0 and 1 or -1)
      local sy = dy == 0 and 0 or (dy > 0 and 1 or -1)
      local opts = { { sx, 0 }, { 0, sy }, { sx, sy } }
      for _, d in ipairs(opts) do
        local nx, ny = n.x + d[1], n.y + d[2]
        if not (d[1] == 0 and d[2] == 0) and World.walkable(nx, ny) then
          n.x, n.y = nx, ny
          break
        end
      end
    end
  end
end

function WorldLife.tryAmbush()
  if S.screen ~= "explore" or S.battle or S.book then return end
  local reg = World.regionAt and World.regionAt(S.px, S.py)
  local biome = reg and string.lower(reg.biome or "") or ""
  if World.inHaven and World.inHaven(S.px, S.py) then return end
  if Armor and Armor.get and love.math.random(1, 100) <= math.min(70, Armor.get("ambush_ward") or 0) then return end
  if biome == "city" or biome == "capital" then return end
  if World.manorX and math.abs((S.px or 0) - World.manorX) + math.abs((S.py or 0) - World.manorY) < 28 then return end
  for _, def in ipairs(All("Settlement")) do
    if math.abs(def.x - (S.px or 0)) + math.abs(def.y - (S.py or 0)) < 14 then return end
  end
  local spots = World.emptyNear and World.emptyNear(S.px, S.py, 12, 6) or {}
  if #spots < 2 then return end
  local lv = (LevelAtTile and LevelAtTile(S.px, S.py)) or (S.trainer or 8)
  local kind = lv >= 55 and "skeleton_knight" or "skeleton"
  if not Get("Enemy", kind) then kind = "skeleton" end
  if not Get("Enemy", kind) then return end
  local pack = math.min(#spots, 3 + love.math.random(0, 2))
  S.npcs = S.npcs or {}
  for i = 1, pack do
    local s = spots[i]
    S.npcs[#S.npcs + 1] = {
      enemy = kind,
      uid = NextUid and NextUid() or (1000 + i),
      x = s[1], y = s[2], rx = s[1], ry = s[2],
      away = 0, ambush = true,
    }
  end
  Say("SKELETONS AMBUSH YOU")
  Play("jump")
  S.shake = 8
end

function WorldLife.sweepCamps()
  S.roamCamps = S.roamCamps or {}
  local alive = {}
  for _, n in ipairs(S.npcs or {}) do
    if n.campId then alive[n.campId] = true end
  end
  local keep = {}
  for _, c in ipairs(S.roamCamps) do
    if c.triggered and not alive[c.id] then
      Say("THE CAMP BREAKS APART")
    else
      keep[#keep + 1] = c
    end
  end
  S.roamCamps = keep
end

function WorldLife.spawnRoamCamp()
  if World.inHaven and World.inHaven(S.px, S.py) then return end
  S.roamCamps = S.roamCamps or {}
  if #S.roamCamps >= 8 then return end
  local spots = World.emptyNear and World.emptyNear(S.px, S.py, 18, 10) or {}
  local far = {}
  for _, s in ipairs(spots) do
    if not OnScreen or not OnScreen(s[1], s[2]) then far[#far + 1] = s end
  end
  local spot = far[1] or spots[1]
  if not spot then return end
  local lv = (LevelAtTile and LevelAtTile(spot[1], spot[2])) or 8
  local id = "roam_" .. tostring((S.turn or 0) + love.math.random(1, 9999))
  S.roamCamps[#S.roamCamps + 1] = {
    id = id, x = spot[1], y = spot[2], level = lv, pack = 3 + love.math.random(0, 2),
    layers = Sheets and Sheets.roll and Sheets.roll("skeleton", "ghoul", "faded") or nil,
  }
end

function WorldLife.triggerCamps()
  local px = math.floor((S.px or 0) + 0.5)
  local py = math.floor((S.py or 0) + 0.5)
  for _, c in ipairs(S.roamCamps or {}) do
    if not c.triggered and math.abs(c.x - px) + math.abs(c.y - py) <= 2 then
      c.triggered = true
      local kind = (c.level or 1) >= 70 and "skeleton_knight" or "skeleton"
      if not Get("Enemy", kind) then kind = "skeleton" end
      S.npcs = S.npcs or {}
      for i = 1, c.pack or 4 do
        local ox = ((i - 1) % 3) - 1
        local oy = math.floor((i - 1) / 3)
        local nx, ny = c.x + ox, c.y + oy
        if i == 1 or (World.walkable and World.walkable(nx, ny)) then
          local layers = Sheets and Sheets.roll and Sheets.roll("skeleton", "ghoul", kind == "skeleton_knight" and "eclipse" or "faded")
          S.npcs[#S.npcs + 1] = {
            enemy = kind, uid = NextUid and NextUid() or i,
            x = nx, y = ny, rx = nx, ry = ny, away = 0, campId = c.id, layers = layers,
          }
        end
      end
      Say("A CAMP RISES TO MEET YOU")
      Play("jump")
    end
  end
end

function WorldLife.update(dt)
  if not S or S.map ~= "giant_world" then return end
  if not S._walkerRule then
    S._walkerRule = 2
    S.folk = nil
  end
  if not S.folk then WorldLife.bindFolk() end
  S._ambushIn = (S._ambushIn or (18 + love.math.random(0, 12))) - (dt or 0)
  if S._ambushIn <= 0 then
    S._ambushIn = 32 + love.math.random(0, 28)
    WorldLife.tryAmbush()
  end
  S._campIn = (S._campIn or 20) - (dt or 0)
  if S._campIn <= 0 then
    S._campIn = 24 + love.math.random(0, 16)
    WorldLife.spawnRoamCamp()
  end
  WorldLife.triggerCamps()
  WorldLife.sweepCamps()
  S._folkTick = (S._folkTick or 0) + (dt or 0)
  if S._folkTick < 0.75 then return end
  S._folkTick = 0
  if S.screen ~= "explore" then return end
  local px, py = S.px or 0, S.py or 0
  local function near(def)
    return math.abs((def.x or 0) - px) + math.abs((def.y or 0) - py) < 28
  end
  local function stepSome(kind, budget)
    local list = All(kind)
    local n = #list
    if n == 0 or budget <= 0 then return budget end
    local cursorKey = kind == "TownNPC" and "_folkCursor" or "_blurbCursor"
    local guard = 0
    while budget > 0 and guard < n do
      guard = guard + 1
      S[cursorKey] = ((S[cursorKey] or 0) % n) + 1
      local def = list[S[cursorKey]]
      if def and near(def) then
        stepOne(def)
        budget = budget - 1
      end
    end
    return budget
  end
  local budget = stepSome("TownNPC", 2)
  stepSome("Blurb", budget)
  stepAmbushers()
end

function WorldLife.bubble(def)
  local st = S.folk and S.folk[def.id]
  if not st or st.anchored then return nil end
  if (st.talk or 0) > 0 then return "..." end
  if st.activity == "fish" and def.x == st.tx and def.y == st.ty then return "FISH" end
  if st.activity == "hunt" then return "HUNT" end
  if st.activity == "resource" and def.x == st.tx then return "FORAGE" end
  if st.leader and st.activity == "party" then return "LEAD" end
  return nil
end

function WorldLife.facing(def)
  local st = S.folk and def and S.folk[def.id]
  if not st then return 0 end
  if Character and Character.dirFromFacing then
    return Character.dirFromFacing(st.faceDx or 0, st.faceDy or 1)
  end
  return 0
end

function WorldLife.moving(def)
  local st = S.folk and def and S.folk[def.id]
  if not st or st.anchored then return false end
  return def.x ~= st.tx or def.y ~= st.ty
end

function WorldLife.petOf(def)
  local st = S.folk and S.folk[def.id]
  if not st or not st.pet or isCompanion(def.id) then return nil end
  return st
end

function WorldLife.onWorld()
  if not S or (S.map or "giant_world") ~= "giant_world" then return end
  if ResourceNodes and ResourceNodes.seedMap then ResourceNodes.seedMap() end
  WorldLife.bindFolk()
end

PlaceKinds.Settlement = function(def)
  local line = def.about ~= "" and def.about or (def.name .. " welcomes you.")
  Say(Upper(line))
  if def.rest then
    for _, g in ipairs(S.party or {}) do
      if g and g.max then g.hp = g.max end
    end
    Say("YOU REST IN " .. Upper(def.name) .. ". THE PARTY IS HEALED.")
    Play("quest")
  else
    Play("step")
  end
end

PlaceKinds.EnemyCamp = function(def)
  if S.screen ~= "explore" or S.book then return end
  S.campCleared = S.campCleared or {}
  local since = S.campCleared[def.id]
  if since then
    Say("THE CAMP IS GONE")
    return
  end
  Say(Upper(def.name) .. " — SKELETONS RUSH YOU")
  Play("jump")
  S.shake = 10
  local kind = (def.level or 10) >= 60 and "skeleton_knight" or "skeleton"
  if not Get("Enemy", kind) then kind = "skeleton" end
  local pack = def.pack or 4
  S.npcs = S.npcs or {}
  local first
  local campId = "place_" .. def.id
  for i = 1, pack do
    local ox = ((i - 1) % 3) - 1
    local oy = math.floor((i - 1) / 3)
    local nx, ny = def.x + ox, def.y + oy
    if i == 1 or (World.walkable and World.walkable(nx, ny)) then
      local npc = {
        enemy = kind,
        uid = NextUid and NextUid() or i,
        x = nx, y = ny, rx = nx, ry = ny,
        away = 0, ambush = true, campId = campId,
        layers = Sheets and Sheets.roll and Sheets.roll("skeleton", "ghoul", kind == "skeleton_knight" and "eclipse" or "faded") or nil,
      }
      S.npcs[#S.npcs + 1] = npc
      first = first or npc
    end
  end
  S.campCleared = S.campCleared or {}
  S.campCleared[def.id] = S.turn or 0
  if first and StartEnemyIntro then StartEnemyIntro(first) end
end
