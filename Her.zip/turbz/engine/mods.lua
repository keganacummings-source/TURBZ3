-- In-game mod manager: scan the mods/ folder, turn each mod ON/OFF (saved), rescan + reload.
-- OPT-IN: every mod starts OFF. Nothing loads until the player enables it on the Mods screen.
-- The enabled list lives next to the save, in kyo_mods.lua in the LOVE save folder.
Engine.modsOn = Engine.modsOn or {}
Engine.modsFile = "kyo_mods.lua"

-- mods/<name>/mod.kyo may call  ModInfo { title = "...", info = "...", version = "..." }
-- It is a harmless recorder - the Mods screen reads the file text directly so OFF mods still show info.
function ModInfo(t) return t end

function Engine.loadModsEnabled()
  Engine.modsOn = {}
  if love.filesystem.getInfo(Engine.modsFile) then
    local ok, chunk = pcall(love.filesystem.load, Engine.modsFile)
    if ok and chunk then
      local ran, d = pcall(chunk)
      if ran and type(d) == "table" and type(d.enabled) == "table" then
        for name, v in pairs(d.enabled) do if v then Engine.modsOn[name] = true end end
      end
    end
  end
  return Engine.modsOn
end

function Engine.saveModsEnabled()
  local parts = {}
  for name, v in pairs(Engine.modsOn) do
    if v then table.insert(parts, "[" .. string.format("%q", name) .. "]=true") end
  end
  love.filesystem.write(Engine.modsFile, "return {enabled={" .. table.concat(parts, ",") .. "}}")
end

local function countFiles(dir)
  local n = 0
  for _, name in ipairs(love.filesystem.getDirectoryItems(dir)) do
    local p = dir .. "/" .. name
    local info = love.filesystem.getInfo(p)
    if info and info.type == "directory" then n = n + countFiles(p)
    elseif info then n = n + 1 end
  end
  return n
end

local function readInfo(name)
  local out = { title = name, info = "", version = nil }
  local path = "mods/" .. name .. "/mod.kyo"
  if love.filesystem.getInfo(path) then
    local text = love.filesystem.read(path) or ""
    out.title = text:match('title%s*=%s*"(.-)"') or out.title
    out.info = text:match('info%s*=%s*"(.-)"') or out.info
    out.version = text:match('version%s*=%s*"(.-)"')
  end
  return out
end

-- a simple list the Mods screen draws: { name, title, info, version, files, on, locked }
function ModScan()
  local list = {}
  if love.filesystem.getInfo("mods") then
    local items = love.filesystem.getDirectoryItems("mods")
    table.sort(items)
    for _, name in ipairs(items) do
      local info = love.filesystem.getInfo("mods/" .. name)
      if info and info.type == "directory" and name:sub(1, 1) ~= "." then
        local locked = name:sub(1, 1) == "_"           -- legacy OFF-by-underscore mods can't be toggled on
        local meta = readInfo(name)
        table.insert(list, { name = name, title = meta.title, info = meta.info, version = meta.version,
          files = countFiles("mods/" .. name), on = (not locked) and (Engine.modsOn[name] == true), locked = locked })
      end
    end
  end
  return list
end

-- flip a mod and reload so the change shows right away (stays on the Mods screen)
function ModToggle(name)
  Engine.modsOn[name] = (not Engine.modsOn[name]) or nil
  Engine.saveModsEnabled()
  Engine.reload()
  S.screen = "mods"
  S.modList = ModScan()
  Say(Word("mods_saved"))
end

-- rescan folders + reload (so a freshly dropped-in mod appears)
function ModsRefresh()
  Engine.reload()
  S.screen = "mods"
  S.modList = ModScan()
  Say(Word("reloaded"))
end
