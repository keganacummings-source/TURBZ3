-- Individual resource nodes that appear while exploring.
-- Not shown on the world map atlas. Walk onto / face and interact to harvest; then they vanish.

ResourceNodes = ResourceNodes or {}

local MAX_NODES = 720
local SPAWN_CHANCE_PER_STEP = 14 -- percent when stepping in a valid biome

-- Node kinds tied to skills / biomes
local NODE_KINDS = {
  { id = "ore_node", name = "Ore Vein", skill = "mining", sprite = "bone",
    loot = { "ironroot_fungus", "rust_gill" }, food = "ration", biomes = { "ashen", "frost", "mountain", "rock" } },
  { id = "timber_node", name = "Timber Stand", skill = "woodcutting", sprite = "grass_tuft",
    loot = { "honey_bracket", "pitch_bolete" }, food = "bread", biomes = { "verdant", "forest", "moss", "hollow" } },
  { id = "shroom_node", name = "Wild Patch", skill = "shroom", sprite = "grass_tuft",
    loot = { "blue_lantern", "dreamspore", "embercap", "gravebell", "moonveil", "dew_cap" }, food = "mushroom_broth", biomes = { "all" } },
  { id = "fish_node", name = "Fishing Spot", skill = "fishing", sprite = "shore",
    loot = { "brine_gill", "pearl_button" }, food = "fish_meal", biomes = { "tide", "water", "marsh", "coast", "silver" } },
  { id = "hunt_node", name = "Game Trail", skill = "hunting", sprite = "bone",
    loot = { "ashen_puff", "thistle_puff" }, food = "meat", biomes = { "plains", "expanse", "corridor", "marches" } },
  { id = "berry_node", name = "Berry Bush", skill = "shroom", sprite = "grass_tuft",
    loot = { "dew_cap" }, food = "berry", biomes = { "all" } },
  { id = "spirit_well", name = "Spirit Well", skill = "adventuring", sprite = "shore",
    loot = { "moonveil", "dreamspore" }, food = "spirit_broth", biomes = { "all" } },
}

function ResourceNodes.ensure()
  S.resourceNodes = S.resourceNodes or {}
  return S.resourceNodes
end

local function biomeMatch(kind, region)
  if not region then return kind.biomes[1] == "all" end
  local name = string.lower((region.name or "") .. " " .. (region.id or "") .. " " .. (region.biome or ""))
  for _, b in ipairs(kind.biomes) do
    if b == "all" or string.find(name, b, 1, true) then return true end
  end
  return false
end

function ResourceNodes.seedMap()
  -- The old carpet dropped hundreds of nodes on the map, including under the camera.
  -- Nodes now only arrive from just outside the view, the same way wild ghosts do.
  S._nodeSeed = true
  if not S._nodeOffscreen then
    S.resourceNodes = {}
    S._nodeOffscreen = true
  end
end

local function inView(x, y)
  local cam = World and World._cam
  -- No camera yet means we do not know the real view. Treat the whole area as
  -- visible so a node cannot be dropped on the player before the first frame.
  if not cam then return true end
  if OnScreen and OnScreen(x, y) then return true end
  local pad = 3
  return x >= cam[1] - pad and x < cam[1] + cam[4] + pad and y >= cam[2] - pad and y < cam[2] + cam[5] + pad
end


local MARK = {
  ore_node = { tag = "ORE", name = "Ore Vein", color = "#e0b56a" },
  timber_node = { tag = "WOOD", name = "Timber Stand", color = "#8fbf62" },
  shroom_node = { tag = "SHROOM", name = "Wild Patch", color = "#c59bff" },
  fish_node = { tag = "FISH", name = "Fishing Spot", color = "#7ec8e3" },
  hunt_node = { tag = "TRAIL", name = "Game Trail", color = "#e07a62" },
  berry_node = { tag = "BERRY", name = "Berry Bush", color = "#d45d8c" },
  spirit_well = { tag = "SPIRIT", name = "Spirit Well", color = "#9ad7ff" },
}

local function markOf(n)
  return MARK[n and n.kind] or { tag = "NODE", name = n and n.name or "Resource", color = "#d8d2c4" }
end

local function kindById(id)
  for _, k in ipairs(NODE_KINDS) do if k.id == id then return k end end
  return NODE_KINDS[1]
end

function ResourceNodes.spawnOutside()
  local nodes = ResourceNodes.ensure()
  local dynamic = 0
  for _, n in ipairs(nodes) do if n.dynamic then dynamic = dynamic + 1 end end
  if dynamic >= 28 or #nodes >= 28 then return end
  -- Same rule as wild ghosts: never create a node until the camera exists,
  -- and never inside the rectangle the player can already see.
  if not World or not World._cam or not World.emptyNear or not S or not S.px then return end
  local tileSize = math.max(1, Settings.tileSize or 16)
  local minRange = math.max(Settings.spawnRange or 10,
    math.ceil(math.max(Engine.W or 320, Engine.H or 320) / tileSize * 0.62))
  local range = minRange + 14
  local candidates = World.emptyNear(S.px, S.py, range, minRange)
  local safe = {}
  for _, pos in ipairs(candidates) do
    local distance = math.abs(pos[1] - (S.px or 0)) + math.abs(pos[2] - (S.py or 0))
    if distance >= minRange and not inView(pos[1], pos[2]) then
      local crowded = false
      for _, n in ipairs(nodes) do
        if math.abs(n.x - pos[1]) + math.abs(n.y - pos[2]) < 8 then crowded = true break end
      end
      if not crowded then safe[#safe + 1] = pos end
    end
  end
  if #safe == 0 then return end
  local s = safe[love.math.random(1, #safe)]
  if inView(s[1], s[2]) or (OnScreen and OnScreen(s[1], s[2])) then return end
  local reg = World.regionAt and World.regionAt(s[1], s[2])
  local pool = {}
  for _, k in ipairs(NODE_KINDS) do
    if biomeMatch(k, reg) then pool[#pool + 1] = k end
  end
  if #pool == 0 then pool = { NODE_KINDS[3] } end
  local kind = pool[love.math.random(1, #pool)]
  local mark = MARK[kind.id]
  nodes[#nodes + 1] = {
    x = s[1], y = s[2],
    kind = kind.id,
    name = (mark and mark.name) or kind.name,
    skill = kind.skill,
    loot = kind.loot,
    food = kind.food,
    sprite = kind.sprite,
    rich = love.math.random(1, 100) <= 22,
    dynamic = true,
  }
end

-- Old callers used to drop a node on a nearby visible tile. That reads as a pop-in.
-- Any leftover call now uses the same off-screen rule as enemy spawns.
function ResourceNodes.trySpawnNearPlayer()
  ResourceNodes.spawnOutside()
end

function ResourceNodes.tick(dt)
  ResourceNodes.seedMap()
  S._nodeTimer = (S._nodeTimer or 0) + (dt or 0)
  if S._nodeTimer >= 2.2 then
    S._nodeTimer = 0
    ResourceNodes.spawnOutside()
  end
  ResourceNodes.glance()
end

function ResourceNodes.glance()
  local nodes = ResourceNodes.ensure()
  local best, bd
  local px, py = math.floor((S.px or 0) + 0.5), math.floor((S.py or 0) + 0.5)
  for _, n in ipairs(nodes) do
    local d = math.abs(n.x - px) + math.abs(n.y - py)
    if d <= (6 + (Armor and Armor.get and math.floor(Armor.get("node_sense") / 8) or 0)) and (not bd or d < bd) then best, bd = n, d end
  end
  if not best then return end
  local key = tostring(best.kind) .. ":" .. best.x .. ":" .. best.y
  if S._nodeLook == key then return end
  S._nodeLook = key
  local m = markOf(best)
  Say(m.tag .. "  " .. Upper(best.name or m.name))
end

function ResourceNodes.at(x, y)
  local tx = math.floor((x or 0) + 0.5)
  local ty = math.floor((y or 0) + 0.5)
  local best, bi, bd
  for i, n in ipairs(ResourceNodes.ensure()) do
    local d = math.abs(math.floor((n.x or 0) + 0.5) - tx) + math.abs(math.floor((n.y or 0) + 0.5) - ty)
    if not bd or d < bd then best, bi, bd = n, i, d end
  end
  if best and bd <= 1 then return best, bi end
  return nil
end

function ResourceNodes.harvest(n, index)
  if not n then return false end
  local lootId = (n.loot and #n.loot > 0) and n.loot[love.math.random(1, #n.loot)] or nil
  local skill = n.skill or "shroom"
  local yieldMult = SkillResourceYieldBonus and SkillResourceYieldBonus(skill) or 1
  if Armor and Armor.get then yieldMult = yieldMult * (1 + (Armor.get("harvest") or 0) / 100) end
  if n.rich then yieldMult = yieldMult + 0.5 end
  local count = math.max(1, math.floor((1 + love.math.random(0, 1)) * yieldMult))
  local lootName = lootId or "SCRAP"
  local got = false
  local mush = lootId and Get("Mushroom", lootId)
  local item = lootId and Get("Item", lootId)
  if mush and mush.name then lootName = mush.name end
  if item and item.name then lootName = item.name end
  if mush and HarvestShroomStrain then
    for i = 1, count do
      if HarvestShroomStrain(lootId, 2 + love.math.random(0, 3), i > 1) then got = true end
    end
  elseif lootId and GiveItem and Get("Item", lootId) then
    GiveItem(lootId, count)
    got = true
  end
  local foodId = n.food
  if not foodId then
    local foodBy = { ore_node = "ration", timber_node = "bread", shroom_node = "mushroom_broth", fish_node = "fish_meal", hunt_node = "meat", berry_node = "berry", spirit_well = "spirit_broth" }
    foodId = foodBy[n.kind]
  end
  if foodId and GiveItem and Get("Item", foodId) then
    local foodCount = math.max(1, count)
    GiveItem(foodId, foodCount)
    got = true
    lootName = (Get("Item", foodId) and Get("Item", foodId).name) or foodId
  end
  if n.kind == "spirit_well" and Spirit and Spirit.gain then Spirit.gain(6 + love.math.random(0, 4)) end
  if not got then
    if GiveItem then GiveItem("berry", 1) end
    lootName = "Wild Berry"
  end
  local m = markOf(n)
  Say(m.tag .. "  " .. Upper(n.name or m.name) .. "  —  " .. Upper(lootName) .. " x" .. count)
  if AddSkillXp then
    local xp = 10
    if SkillResourceXpBonus then xp = math.floor(xp * SkillResourceXpBonus(skill)) end
    AddSkillXp(skill, xp)
  end
  -- Remove node
  table.remove(S.resourceNodes, index)
  if SessionNet and SessionNet.emitEvent then SessionNet.emitEvent("node_gone", { x = n.x, y = n.y }) end
  Play("quest")
  Fire("resource_node_harvested", { kind = n.kind, loot = lootId })
  return true
end

function ResourceNodes.draw()
  local nodes = ResourceNodes.ensure()
  local z = WorldSpriteScale and WorldSpriteScale() or 1
  local px, py = S.px or 0, S.py or 0
  for _, n in ipairs(nodes) do
    if OnScreen and OnScreen(n.x, n.y) then
      local cx, cy = WorldToScreen(n.x, n.y)
      local m = markOf(n)
      local s = math.max(5, math.floor(6 * z))
      Box(cx - s, cy - s - 4, s * 2, s * 2 + 4, "#120e16ee")
      Box(cx - s + 2, cy - s - 2, s * 2 - 4, s * 2, m.color)
      Frame(cx - s, cy - s - 4, s * 2, s * 2 + 4, "#f4efe4")
      Text(m.tag, cx - math.floor(#m.tag * 4), cy - s - 16, m.color, 8)
      TextFit(Upper(n.name or m.name), cx - 52, cy + s + 10, 104, "ink", 8, 8, "center")
    end
  end
end

function ResourceNodes.interactFacing()
  local dir = S.dir or { 0, 1 }
  local tries = {
    { S.px, S.py },
    { S.px + dir[1], S.py + dir[2] },
    { S.px, S.py - 1 }, { S.px, S.py + 1 },
    { S.px - 1, S.py }, { S.px + 1, S.py },
  }
  for _, t in ipairs(tries) do
    local n, i = ResourceNodes.at(t[1], t[2])
    if n then return ResourceNodes.harvest(n, i) end
  end
  return false
end
