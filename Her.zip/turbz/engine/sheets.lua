-- Layered enemy sheets: ghouls (32), skeletons (32), bosses (64).
-- Pieces share a canvas. Draw the same direction and frame for every layer.

Sheets = Sheets or {}

local SPEC = {
  ghoul = {
    path = "assets/characters/ghoul_spritesheet.png",
    frame = 32, block = 128,
    rows = { body = 0, hair = 1, head = 2, chest = 3, legs = 4, feet = 5, accessory = 6 },
    order = { "body", "feet", "legs", "chest", "hair", "head", "accessory" },
    counts = { body = 10, hair = 10, head = 20, chest = 20, legs = 20, feet = 20, accessory = 20 },
    anchor = { 16, 31 },
  },
  skeleton = {
    path = "assets/characters/skeleton_spritesheet.png",
    frame = 32, block = 128,
    rows = { body = 0, head = 1, feet = 2 },
    order = { "body", "feet", "head" },
    counts = { body = 10, head = 20, feet = 20 },
    anchor = { 16, 31 },
  },
  boss = {
    path = "assets/characters/boss_spritesheet.png",
    frame = 64, block = 256,
    rows = { body = 0, hair = 1, head = 2, chest = 3, legs = 4, feet = 5, accessory = 6 },
    order = { "body", "feet", "legs", "chest", "hair", "head", "accessory" },
    counts = { body = 10, hair = 10, head = 20, chest = 20, legs = 20, feet = 20, accessory = 20 },
    anchor = { 32, 63 },
  },
}

Sheets.TYPE_TINT = {
  fire = { 1.00, 0.48, 0.28 }, water = { 0.40, 0.68, 1.00 }, earth = { 0.55, 0.78, 0.38 },
  electric = { 1.00, 0.92, 0.35 }, ice = { 0.62, 0.88, 1.00 }, void = { 0.62, 0.40, 0.95 },
  light = { 1.00, 0.94, 0.70 }, air = { 0.70, 0.92, 0.88 }, spirit = { 0.78, 0.62, 1.00 },
  normal = { 0.92, 0.90, 0.86 }, ghoul = { 0.62, 0.88, 0.52 }, blood = { 0.85, 0.22, 0.28 },
}

local RARITY_TINT = {
  common = { 1, 1, 1 }, faded = { 0.75, 0.78, 0.85 }, weeping = { 0.65, 0.75, 1 },
  sleeping = { 0.70, 0.95, 0.85 }, eclipse = { 0.85, 0.55, 1 }, kyo_touched = { 1, 0.82, 0.35 },
  epic = { 0.78, 0.55, 1 }, legendary = { 1, 0.84, 0.40 },
}

local images, quads = {}, {}

local function image(kind)
  local spec = SPEC[kind]
  if not spec then return nil end
  if images[kind] then return images[kind] end
  if not love.filesystem.getInfo(spec.path) then return nil end
  local ok, img = pcall(love.graphics.newImage, spec.path)
  if not ok or not img then return nil end
  img:setFilter("nearest", "nearest")
  images[kind] = img
  return img
end

local function quad(kind, part, index, direction, frame)
  local spec = SPEC[kind]
  local img = image(kind)
  if not spec or not img then return nil end
  local row = spec.rows[part]
  local count = spec.counts[part] or 1
  if row == nil or index == nil or index < 0 then return nil end
  index = index % count
  direction = math.max(0, math.min(3, direction or 0))
  frame = math.max(0, math.min(3, frame or 0))
  local key = table.concat({ kind, part, index, direction, frame }, ":")
  if quads[key] then return quads[key] end
  local x = index * spec.block + frame * spec.frame
  local y = row * spec.block + direction * spec.frame
  local q = love.graphics.newQuad(x, y, spec.frame, spec.frame, img:getDimensions())
  quads[key] = q
  return q
end

function Sheets.tint(typeId, rarityId)
  local t = Sheets.TYPE_TINT[typeId or ""] or { 1, 1, 1 }
  local r = RARITY_TINT[rarityId or ""] or { 1, 1, 1 }
  if rarityId and Get and Get("Rarity", rarityId) then
    local col = ToColor and ToColor(Get("Rarity", rarityId).color or "")
    if col then r = { col[1], col[2], col[3] } end
  end
  local function clamp(n) if n < 0.25 then return 0.25 end if n > 1.35 then return 1.35 end return n end
  return clamp(t[1] * 0.72 + r[1] * 0.55), clamp(t[2] * 0.72 + r[2] * 0.55), clamp(t[3] * 0.72 + r[3] * 0.55)
end

function Sheets.roll(kind, typeId, rarityId)
  local spec = SPEC[kind or "ghoul"] or SPEC.ghoul
  local look = { sheet = kind or "ghoul", type = typeId or "ghoul", rarity = rarityId or "" }
  for part, n in pairs(spec.counts) do
    look[part] = love.math.random(0, n - 1)
  end
  return look
end

-- Stable unique look so each placed boss / camp reads differently.
function Sheets.fromId(kind, id, typeId, rarityId)
  local spec = SPEC[kind or "boss"] or SPEC.boss
  local h = 2166136261
  local s = tostring(id or kind)
  for i = 1, #s do h = (h * 16777619 + s:byte(i)) % 2147483647 end
  local function take(n)
    h = (h * 1103515245 + 12345) % 2147483648
    return h % n
  end
  local look = { sheet = kind or "boss", type = typeId or "ghoul", rarity = rarityId or "eclipse" }
  for part, n in pairs(spec.counts) do look[part] = take(n) end
  return look
end

function Sheets.draw(look, cx, cy, scale, direction, frame)
  if not look then return false end
  local kind = look.sheet or "ghoul"
  local spec = SPEC[kind]
  local img = image(kind)
  if not spec or not img then return false end
  scale = scale or 1
  -- Never draw below 1:1. A half-scale nearest sample drops rows and squishes the body.
  if scale < 1 then scale = 1 end
  if kind == "boss" then scale = scale * 1.15 end
  local dest = math.max(spec.frame, math.floor(spec.frame * scale + 0.5))
  scale = dest / spec.frame
  local px = math.floor(cx - spec.anchor[1] * scale)
  local py = math.floor(cy - spec.anchor[2] * scale)
  local tr, tg, tb = Sheets.tint(look.type, look.rarity)
  for i, part in ipairs(spec.order) do
    local q = quad(kind, part, look[part], direction, frame)
    if q then
      if i == 1 then love.graphics.setColor(1, 1, 1, 1)
      else love.graphics.setColor(tr, tg, tb, 1) end
      love.graphics.draw(img, q, px, py, 0, scale, scale)
    end
  end
  love.graphics.setColor(1, 1, 1, 1)
  return true
end
