-- Tiny pure-Lua JSON encode/decode (enough for the DreamShare + relay payloads).
local json = {}

local function esc(s)
  return (s:gsub('[%z\1-\31\\"]', function(c)
    local map = { ['"'] = '\\"', ['\\'] = '\\\\', ['\n'] = '\\n', ['\r'] = '\\r', ['\t'] = '\\t', ['\b'] = '\\b', ['\f'] = '\\f' }
    return map[c] or string.format('\\u%04x', string.byte(c))
  end))
end

local function isArray(t)
  local n = 0
  for k in pairs(t) do
    if type(k) ~= "number" then return false end
    n = n + 1
  end
  return n == #t
end

local function enc(v)
  local t = type(v)
  if t == "nil" then return "null" end
  if t == "boolean" then return tostring(v) end
  if t == "number" then return (v ~= v or v == math.huge or v == -math.huge) and "null" or tostring(v) end
  if t == "string" then return '"' .. esc(v) .. '"' end
  if t == "table" then
    if isArray(v) then
      local out = {}
      for _, x in ipairs(v) do out[#out + 1] = enc(x) end
      return "[" .. table.concat(out, ",") .. "]"
    end
    local out = {}
    for k, x in pairs(v) do
      if type(k) == "string" or type(k) == "number" then out[#out + 1] = '"' .. esc(tostring(k)) .. '":' .. enc(x) end
    end
    return "{" .. table.concat(out, ",") .. "}"
  end
  return "null"
end
json.encode = enc

local decode
local function skip(s, i) return s:find("[^ \t\r\n]", i) or (#s + 1) end

local function parseStr(s, i)
  local out, i = {}, i + 1
  while i <= #s do
    local c = s:sub(i, i)
    if c == '"' then return table.concat(out), i + 1 end
    if c == '\\' then
      local n = s:sub(i + 1, i + 1)
      local map = { ['"'] = '"', ['\\'] = '\\', ['/'] = '/', n = '\n', r = '\r', t = '\t', b = '\b', f = '\f' }
      if n == 'u' then
        local hex = s:sub(i + 2, i + 5)
        local code = tonumber(hex, 16) or 63
        out[#out + 1] = (code < 128) and string.char(code) or "?"
        i = i + 6
      else
        out[#out + 1] = map[n] or n
        i = i + 2
      end
    else
      out[#out + 1] = c
      i = i + 1
    end
  end
  return table.concat(out), i
end

decode = function(s, i)
  i = skip(s, i)
  local c = s:sub(i, i)
  if c == '{' then
    local obj = {}
    i = skip(s, i + 1)
    if s:sub(i, i) == '}' then return obj, i + 1 end
    while true do
      local key; key, i = parseStr(s, skip(s, i))
      i = skip(s, i)
      if s:sub(i, i) == ':' then i = i + 1 end
      local val; val, i = decode(s, i)
      obj[key] = val
      i = skip(s, i)
      local ch = s:sub(i, i)
      if ch == ',' then i = skip(s, i + 1)
      else return obj, i + 1 end
    end
  elseif c == '[' then
    local arr = {}
    i = skip(s, i + 1)
    if s:sub(i, i) == ']' then return arr, i + 1 end
    while true do
      local val; val, i = decode(s, i)
      arr[#arr + 1] = val
      i = skip(s, i)
      local ch = s:sub(i, i)
      if ch == ',' then i = skip(s, i + 1)
      else return arr, i + 1 end
    end
  elseif c == '"' then
    return parseStr(s, i)
  elseif c == 't' then return true, i + 4
  elseif c == 'f' then return false, i + 5
  elseif c == 'n' then return nil, i + 4
  else
    local num = s:match("^%-?%d+%.?%d*[eE]?[%+%-]?%d*", i)
    if num then return tonumber(num), i + #num end
    return nil, i + 1
  end
end

function json.decode(s)
  if type(s) ~= "string" or s == "" then return nil end
  local ok, res = pcall(function() local v = decode(s, 1) return v end)
  if ok then return res end
  return nil
end

return json
