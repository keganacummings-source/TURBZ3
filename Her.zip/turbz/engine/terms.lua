-- The Turbo Script term system. NewTerm "Ghost" { field = default } creates the word Ghost "id" { ... }
local function kindOf(v)
  local t = type(v)
  if t == "string" then return "text" end
  if t == "number" then return "number" end
  if t == "boolean" then return "true/false" end
  if t == "table" then return "list { }" end
  if t == "function" then return "function" end
  return t
end

local function distance(a, b)
  a, b = a:lower(), b:lower()
  local prev = {}
  for j = 0, #b do prev[j] = j end
  for i = 1, #a do
    local cur = { [0] = i }
    for j = 1, #b do
      local cost = (a:sub(i, i) == b:sub(j, j)) and 0 or 1
      cur[j] = math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
    end
    prev = cur
  end
  return prev[#b]
end

function Engine.closest(word, options)
  local best, bestD = nil, 3
  for _, o in ipairs(options) do
    local d = distance(word, o)
    if d < bestD then best, bestD = o, d end
  end
  return best
end

local function fieldNames(schema)
  local out = {}
  for k in pairs(schema) do table.insert(out, k) end
  return out
end

function Define(kind, id, body)
  local schema = Game.terms[kind]
  if not schema then Engine.warn("'" .. tostring(kind) .. "' is not a term. Make it first with NewTerm") return nil end
  if type(body) ~= "table" then Engine.warn(kind .. ' "' .. id .. '" needs { ... } after the name') return nil end
  local def = {}
  for k, v in pairs(schema) do def[k] = Copy(v) end
  for k, v in pairs(body) do
    if type(k) == "string" then
      local isHook = k:match("^on%u") and type(v) == "function"
      if schema[k] == nil and not isHook then
        local guess = Engine.closest(k, fieldNames(schema))
        Engine.warn(kind .. ' "' .. id .. '": unknown field "' .. k .. '"' .. (guess and (' - did you mean "' .. guess .. '"?') or ""))
      elseif schema[k] ~= nil and type(schema[k]) ~= type(v) then
        Engine.warn(kind .. ' "' .. id .. '": "' .. k .. '" should be ' .. kindOf(schema[k]) .. " but got " .. kindOf(v))
      end
    end
    def[k] = v
  end
  def.id, def.kind, def.source = id, kind, Engine.file
  if not Game.data[kind][id] then table.insert(Game.order[kind], id) end
  Game.data[kind][id] = def
  return def
end

function NewTerm(kind)
  if type(kind) ~= "string" or not kind:match("^%u[%w_]*$") then
    Engine.warn('NewTerm needs a Capitalised name in quotes, like NewTerm "Item" { }') return function() end
  end
  return function(defaults)
    Game.terms[kind] = defaults or {}
    Game.data[kind] = Game.data[kind] or {}
    Game.order[kind] = Game.order[kind] or {}
    _G[kind] = function(id)
      if type(id) ~= "string" then
        Engine.warn(kind .. ' needs a name in quotes, like ' .. kind .. ' "my_name" { ... }')
        id = tostring(id)
      end
      return function(body) return Define(kind, id, body) end
    end
  end
end

-- Edit "Attack" "ember" { power = 60 }   (change something that already exists)
function Edit(kind)
  return function(id)
    return function(body)
      local d = Get(kind, id)
      if not d then Engine.warn('Edit: there is no ' .. tostring(kind) .. ' "' .. tostring(id) .. '" to edit') return end
      for k, v in pairs(body or {}) do d[k] = v end
    end
  end
end

-- Remove "Ghost" "nobi"
function Remove(kind)
  return function(id)
    if not Get(kind, id) then Engine.warn('Remove: there is no ' .. tostring(kind) .. ' "' .. tostring(id) .. '"') return end
    Game.data[kind][id] = nil
    for i, v in ipairs(Game.order[kind]) do if v == id then table.remove(Game.order[kind], i) break end end
  end
end

function Get(kind, id) return Game.data[kind] and Game.data[kind][id] or nil end

function All(kind)
  local out = {}
  for _, id in ipairs(Game.order[kind] or {}) do
    local d = Game.data[kind][id]
    if d then table.insert(out, d) end
  end
  return out
end

function Each(kind, fn) for _, d in ipairs(All(kind)) do fn(d, d.id) end end
function Count(kind) return #All(kind) end
