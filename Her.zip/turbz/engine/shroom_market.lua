-- Mushroom Market + Purity System
-- 10-stage purity (strain variants) with animated filter stages.
-- Market refreshes every 30 minutes; each unique mushroom has independent price drift.
-- Chat announcement on refresh. Integrated into Black Market.

ShroomMarket = ShroomMarket or {}

local REFRESH_SECONDS = 30 * 60 -- half hour
local PURITY_STAGES = {
  { id = "raw",        name = "Raw",        filter = "none",     mult = 0.70 },
  { id = "washed",     name = "Washed",     filter = "mist",     mult = 0.85 },
  { id = "dried",      name = "Dried",      filter = "dust",     mult = 1.00 },
  { id = "cured",      name = "Cured",      filter = "amber",    mult = 1.15 },
  { id = "aged",       name = "Aged",       filter = "smoke",    mult = 1.30 },
  { id = "refined",    name = "Refined",    filter = "glow",     mult = 1.50 },
  { id = "crystal",    name = "Crystal",    filter = "prism",    mult = 1.75 },
  { id = "ethereal",   name = "Ethereal",   filter = "ripple",   mult = 2.10 },
  { id = "ascended",   name = "Ascended",   filter = "halo",     mult = 2.60 },
  { id = "mythic",     name = "Mythic",     filter = "voidfire", mult = 3.40 },
}

function ShroomMarket.purityStages()
  return PURITY_STAGES
end

function ShroomMarket.purityByIndex(i)
  i = math.max(1, math.min(#PURITY_STAGES, i or 1))
  return PURITY_STAGES[i]
end

function ShroomMarket.purityById(id)
  for i, p in ipairs(PURITY_STAGES) do
    if p.id == id then return p, i end
  end
  return PURITY_STAGES[1], 1
end

-- Animated filter descriptors (consumed by draw layer)
local FILTER_ANIM = {
  none     = { pulse = 0, hue = 0, alpha = 0 },
  mist     = { pulse = 0.4, hue = 200, alpha = 0.25 },
  dust     = { pulse = 0.2, hue = 40,  alpha = 0.20 },
  amber    = { pulse = 0.5, hue = 35,  alpha = 0.35 },
  smoke    = { pulse = 0.6, hue = 0,   alpha = 0.30 },
  glow     = { pulse = 0.8, hue = 120, alpha = 0.40 },
  prism    = { pulse = 1.2, hue = 280, alpha = 0.45 },
  ripple   = { pulse = 1.0, hue = 180, alpha = 0.50 },
  halo     = { pulse = 1.4, hue = 50,  alpha = 0.55 },
  voidfire = { pulse = 1.8, hue = 300, alpha = 0.65 },
}

function ShroomMarket.filterAnim(filterId)
  return FILTER_ANIM[filterId or "none"] or FILTER_ANIM.none
end

function ShroomMarket.ensure()
  S.shroomMarket = S.shroomMarket or {
    prices = {},
    lastRefresh = 0,
    history = {},
  }
  local now = love.timer.getTime()
  if (S.shroomMarket.lastRefresh or 0) == 0 then
    ShroomMarket.fullReroll(true)
  elseif now - (S.shroomMarket.lastRefresh or 0) >= REFRESH_SECONDS then
    ShroomMarket.refresh()
  end
  return S.shroomMarket
end

function ShroomMarket.basePrice(mushroomId)
  local m = Get("Mushroom", mushroomId)
  if not m then return 10 end
  -- Base 1-50 depending on rarity / authored basePrice clamped
  local rarity = string.lower(tostring(m.rarity or "common"))
  local band = ({ common = 8, uncommon = 16, rare = 28, legendary = 42, mythic = 50 })[rarity] or 12
  local authored = tonumber(m.basePrice)
  if authored then
    return math.max(1, math.min(50, math.floor(authored)))
  end
  -- stable hash from id for variety inside band
  local h = 0
  for i = 1, #tostring(mushroomId) do h = h + string.byte(mushroomId, i) * i end
  local spread = math.floor(band * 0.4)
  return math.max(1, math.min(50, band - spread + (h % (spread * 2 + 1))))
end

function ShroomMarket.fullReroll(silent)
  local mkt = S.shroomMarket or { prices = {}, history = {} }
  S.shroomMarket = mkt
  mkt.prices = {}
  for _, m in ipairs(All("Mushroom") or {}) do
    local base = ShroomMarket.basePrice(m.id)
    -- small initial jitter ±8%
    local jitter = 1 + (love.math.random() * 0.16 - 0.08)
    mkt.prices[m.id] = math.max(1, math.floor(base * jitter))
  end
  mkt.lastRefresh = love.timer.getTime()
  if not silent then
    Say("*** SHROOM MARKET: NEW PRICES POSTED ***")
    if Play then Play("quest") end
  end
  Fire("shroom_market_refresh", { prices = mkt.prices })
end

function ShroomMarket.refresh()
  local mkt = ShroomMarket.ensure()
  for id, price in pairs(mkt.prices or {}) do
    -- independent drift ±1% to ±6% per half hour
    local delta = (love.math.random() * 0.10 - 0.05) -- -5% .. +5%
    -- occasional larger swings
    if love.math.random(1, 100) <= 8 then
      delta = delta + (love.math.random() * 0.12 - 0.06)
    end
    local nextP = math.max(1, math.floor(price * (1 + delta)))
    mkt.history = mkt.history or {}
    mkt.history[id] = mkt.history[id] or {}
    table.insert(mkt.history[id], { t = love.timer.getTime(), p = nextP })
    while #mkt.history[id] > 48 do table.remove(mkt.history[id], 1) end
    mkt.prices[id] = nextP
  end
  -- ensure any newly added mushrooms appear
  for _, m in ipairs(All("Mushroom") or {}) do
    if not mkt.prices[m.id] then
      mkt.prices[m.id] = ShroomMarket.basePrice(m.id)
    end
  end
  mkt.lastRefresh = love.timer.getTime()
  Say("*** SHROOM MARKET: NEW PRICES POSTED ***")
  if Play then Play("quest") end
  Fire("shroom_market_refresh", { prices = mkt.prices })
end

function ShroomMarket.price(mushroomId, purityIndex)
  ShroomMarket.ensure()
  local base = (S.shroomMarket.prices and S.shroomMarket.prices[mushroomId]) or ShroomMarket.basePrice(mushroomId)
  local pure = ShroomMarket.purityByIndex(purityIndex or 3)
  return math.max(1, math.floor(base * (pure.mult or 1)))
end

function ShroomMarket.secondsUntilRefresh()
  ShroomMarket.ensure()
  local elapsed = love.timer.getTime() - (S.shroomMarket.lastRefresh or 0)
  return math.max(0, REFRESH_SECONDS - elapsed)
end

function ShroomMarket.update(dt)
  if not S then return end
  ShroomMarket.ensure()
end

-- Inventory helper: bag key for pure strains
function ShroomStackKey(mushroomId, purityIndex)
  purityIndex = purityIndex or 3
  return "shroom_" .. mushroomId .. "_p" .. tostring(purityIndex)
end

function HarvestShroomStrain(mushroomId, purityIndex, silent)
  purityIndex = purityIndex or 3
  local m = Get("Mushroom", mushroomId)
  if not m then return false end
  local key = ShroomStackKey(mushroomId, purityIndex)
  S.bag = S.bag or {}
  S.bag[key] = (S.bag[key] or 0) + 1
  if not silent then
    local pure = ShroomMarket.purityByIndex(purityIndex)
    Say("HARVESTED " .. Upper(pure.name) .. " " .. Upper(m.name or mushroomId))
  end
  AddSkillXp("shroom", 8 + (purityIndex or 1) * 2)
  Fire("mushroom_harvested", { id = mushroomId, purity = purityIndex })
  return true
end
