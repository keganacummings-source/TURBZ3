-- Player listings on the black market: risk/reward timed sales.

BlackMarket = BlackMarket or {}

function BlackMarket.ensure()
  S.bmListings = S.bmListings or {}
  S.bmLastTick = S.bmLastTick or (love.timer and love.timer.getTime() or 0)
end

-- Sell chance per minute: cheaper = faster sales. Expensive = rare ticks.
function BlackMarket.sellChance(price)
  price = math.max(1, price or 1)
  -- ~55% / min at 50 kyo, ~25% at 500, ~8% at 5000, ~2% at 50k
  local c = 60 / (1 + math.log(price + 10) / math.log(8))
  return math.max(1.5, math.min(70, c))
end

-- Risk: each minute listed adds expire pressure; high prices rot faster in attention
function BlackMarket.riskChance(listing, minutesHeld)
  local price = listing.price or 1
  local base = 0.4 + minutesHeld * 0.15 + math.log(price + 50) / 30
  return math.min(12, base)
end

function BlackMarket.listItem(itemId, count)
  BlackMarket.ensure()
  count = count or 1
  if not itemId or (ItemCount and ItemCount(itemId) or 0) < count then
    Say("NOTHING TO LIST")
    Play("bump")
    return false
  end
  local it = Get("Item", itemId)
  local base = (it and it.price) or 20
  if ItemSellPrice and All then
    -- use generic sell valuation if available
  end
  local trade = SkillSellPriceMult and SkillSellPriceMult() or 1
  local price = math.max(1, math.floor(base * 0.85 * trade))
  if Armor and Armor.get then
    price = math.floor(price * (1 + (Armor.get("sell_boost") or 0) / 100))
  end
  -- remove from inventory
  if TakeItem then
    TakeItem(itemId, count)
  elseif S.bag and S.bag[itemId] then
    S.bag[itemId] = S.bag[itemId] - count
    if S.bag[itemId] <= 0 then S.bag[itemId] = nil end
  end
  S.bmListings[#S.bmListings + 1] = {
    kind = "item",
    id = itemId,
    name = (it and it.name) or itemId,
    count = count,
    price = price,
    listedAt = love.timer and love.timer.getTime() or 0,
    minutes = 0,
  }
  Say("LISTED " .. Upper((it and it.name) or itemId) .. " @ " .. price .. "K")
  Play("quest")
  if AddSkillXp then AddSkillXp("trading", 3) end
  return true
end

function BlackMarket.listGhost(ghost)
  BlackMarket.ensure()
  if not ghost then return false end
  local price = 100
  if Rules and Rules.ghost_price then price = Rules.ghost_price(ghost, { sellRate = 100 }) end
  if SkillSellPriceMult then price = math.floor(price * SkillSellPriceMult()) end
  -- remove from box
  if S.box then
    for i, g in ipairs(S.box) do
      if g == ghost or (g.gid and ghost.gid and g.gid == ghost.gid) then
        table.remove(S.box, i)
        break
      end
    end
  end
  S.bmListings[#S.bmListings + 1] = {
    kind = "ghost",
    ghost = ghost,
    name = GhostName and GhostName(ghost) or "Ghost",
    price = price,
    listedAt = love.timer and love.timer.getTime() or 0,
    minutes = 0,
  }
  Say("LISTED " .. Upper(GhostName and GhostName(ghost) or "GHOST") .. " @ " .. price .. "K")
  Play("quest")
  return true
end

function BlackMarket.cancel(index)
  BlackMarket.ensure()
  local L = S.bmListings[index]
  if not L then return end
  table.remove(S.bmListings, index)
  if L.kind == "item" then
    if GiveItem then GiveItem(L.id, L.count or 1) end
  elseif L.kind == "ghost" and L.ghost then
    table.insert(S.box, L.ghost)
  end
  Say("DELISTED")
  Play("step")
end

function BlackMarket.update(dt)
  BlackMarket.ensure()
  local now = love.timer and love.timer.getTime() or 0
  if now - (S.bmLastTick or 0) < 60 then return end
  S.bmLastTick = now
  local i = 1
  while i <= #S.bmListings do
    local L = S.bmListings[i]
    L.minutes = (L.minutes or 0) + 1
    local sellP = BlackMarket.sellChance(L.price)
    if love.math.random() * 100 < sellP then
      S.kyo = (S.kyo or 0) + (L.price or 0)
      table.remove(S.bmListings, i)
      Say("SOLD " .. Upper(L.name or "ITEM") .. " +" .. (L.price or 0) .. "K")
      Play("win")
      if AddSkillXp then AddSkillXp("trading", 8) end
    else
      i = i + 1
    end
  end
end
