-- Small helpers every .kyo file can use
function Engine.friendly(msg)
  msg = tostring(msg):gsub('%[string "(.-)"%]', "%1")
  local word = msg:match("attempt to call global '([%w_]+)'")
  if word then
    local guess = Engine.closest(word, Engine.knownWords())
    msg = msg .. "  >> '" .. word .. "' is not a Kyo word" .. (guess and (". Did you mean " .. guess .. "?") or "")
  end
  if msg:match("'}' expected") then msg = msg .. "  >> did you forget a comma , at the end of the line above?" end
  if msg:match("unfinished string") then msg = msg .. '  >> a " quote is missing' end
  local vtype = msg:match("arithmetic on %w+ '([%w_]+)' %(a (%a+) value%)")
  local vname = msg:match("arithmetic on %w+ '([%w_]+)'")
  if vname then
    local kind = msg:match("%(a (%a+) value%)")
    msg = msg .. "  >> '" .. vname .. "' is a " .. (kind or "?") .. " but maths needs a NUMBER here. Make sure that field/value is a number (not " .. (kind or "text") .. ")."
  end
  local idx = msg:match("index %w+ '([%w_]+)' %(a nil value%)")
  if idx then msg = msg .. "  >> '" .. idx .. "' does not exist (nil). Likely a misspelled id or a field that was never set." end
  local cal = msg:match("call %w+ '([%w_]+)' %(a nil value%)")
  if cal then msg = msg .. "  >> '" .. cal .. "' is not a function/word here - check the spelling." end
  return msg
end

function Engine.warn(msg, raw)
  local line = raw and Engine.friendly(msg) or ((Engine.file or "?") .. ": " .. tostring(msg))
  if Engine.seen[line] then return end
  Engine.seen[line] = true
  table.insert(Engine.errors, line)
  print("[KYO] " .. line)
  Engine.showErrors = true
end

function Engine.safe(fn, ...)
  if type(fn) ~= "function" then return nil end
  local ok, res = pcall(fn, ...)
  if not ok then Engine.warn(res, true) return nil end
  return res
end

function Engine.knownWords()
  local out = {}
  for k, v in pairs(_G) do
    if type(k) == "string" and k:match("^%u") and (type(v) == "function" or type(v) == "table") then table.insert(out, k) end
  end
  return out
end

-- events: When "battle_won" (function(e) ... end)
function When(name)
  return function(fn)
    if type(fn) ~= "function" then Engine.warn('When "' .. tostring(name) .. '" needs (function(e) ... end)') return end
    Game.events[name] = Game.events[name] or {}
    table.insert(Game.events[name], fn)
  end
end

function Fire(name, e)
  for _, fn in ipairs(Game.events[name] or {}) do Engine.safe(fn, e) end
  if name ~= "draw_world" and S and S.quest and QuestCheck then Engine.safe(QuestCheck, name, e) end
end

-- rules: Rule "damage" (function(...) ... end)
function Rule(name)
  return function(fn)
    if type(fn) ~= "function" then Engine.warn('Rule "' .. tostring(name) .. '" needs (function(...) ... end)') return end
    Rules[name] = fn
  end
end

-- maths
Min, Max, Floor, Abs, Sin, Cos, Sqrt = math.min, math.max, math.floor, math.abs, math.sin, math.cos, math.sqrt
PI = math.pi
function Round(v) return math.floor(v + 0.5) end
function Clamp(v, lo, hi) return math.max(lo, math.min(hi, v)) end
function Random(a, b)
  if a and b then return love.math.random(a, b) end
  if a then return love.math.random(a) end
  return love.math.random()
end
function Chance(percent) return love.math.random() * 100 < percent end
function Pick(list) if #list == 0 then return nil end return list[love.math.random(#list)] end
function PickWeighted(weights)
  local total = 0
  for _, w in pairs(weights) do total = total + w end
  if total <= 0 then return nil end
  local r = love.math.random() * total
  for k, w in pairs(weights) do r = r - w; if r <= 0 then return k end end
  return next(weights)
end
function InList(list, v) for _, x in ipairs(list or {}) do if x == v then return true end end return false end
function PercentOf(value, percent) return math.max(1, math.floor(value * percent / 100)) end
function Half(v) return math.max(1, math.floor(v / 2)) end

-- text
function Upper(s) return string.upper(tostring(s or "")) end
function Cut(s, n) return string.sub(tostring(s or ""), 1, n) end
function Word(key, ...)
  local w = rawget(Words, key) or key
  if select("#", ...) > 0 then
    local ok, out = pcall(string.format, w, ...)
    if ok then return out end
  end
  return w
end
function Say(msg) S.msg = msg end

-- time
function Tick() return S.t or 0 end
function Blink(every) return math.floor((S.t or 0) / every) % 2 == 1 end

-- input
function IsKey(key, action)
  local list = rawget(Keys, action)
  if type(list) == "string" then return key == list end
  if type(list) ~= "table" then return false end
  for _, k in ipairs(list) do if k == key then return true end end
  return false
end
function Inside(x, y, bx, by, bw, bh) return x >= bx and x <= bx + bw and y >= by and y <= by + bh end

function Copy(v)
  if type(v) ~= "table" then return v end
  local out = {}
  for k, x in pairs(v) do out[k] = Copy(x) end
  return out
end

function KeyHeld(action)
  local list = rawget(Keys, action)
  if type(list) == "string" then list = { list } end
  for _, k in ipairs(list or {}) do
    local ok, down = pcall(love.keyboard.isDown, k)
    if ok and down then return true end
  end
  return false
end
