-- One complete ghost picture per species, rolled when a world is created.
-- Looks are whole sprites (turbz_000 .. turbz_299). They are never layered.

WorldGhosts = WorldGhosts or {}

local COUNT = 300

local function rng(seed)
  seed = tonumber(seed) or 1
  return function(n)
    seed = (seed * 1103515245 + 12345) % 2147483648
    return (seed % n) + 1, seed
  end, seed
end

function WorldGhosts.imageId(n)
  n = (tonumber(n) or 0) % COUNT
  return string.format("turbz_%03d", n)
end

function WorldGhosts.roll(seed)
  seed = tonumber(seed) or os.time()
  local nextn = rng(seed)
  local images = {}
  for i = 0, COUNT - 1 do images[i + 1] = WorldGhosts.imageId(i) end
  for i = #images, 2, -1 do
    local j = nextn(#images)
    images[i], images[j] = images[j], images[i]
  end
  local forms = {}
  local species = {}
  if GhostList then
    for _, sp in ipairs(GhostList()) do
      if sp and sp.id and tostring(sp.id):match("^turbz_") then
        species[#species + 1] = sp.id
      end
    end
  end
  if #species == 0 then
    for i = 0, COUNT - 1 do species[#species + 1] = WorldGhosts.imageId(i) end
  end
  for i, sid in ipairs(species) do
    forms[sid] = images[((i - 1) % #images) + 1]
  end
  S.ghostForms = forms
  S.worldGhostSeed = seed
  return forms
end

function WorldGhosts.ensure()
  if S and S.ghostForms and next(S.ghostForms) then return S.ghostForms end
  return WorldGhosts.roll((S and S.worldGhostSeed) or os.time())
end

function WorldGhosts.imageFor(g)
  if not g then return nil end
  if type(g.imageSprite) == "string" and g.imageSprite ~= "" then return g.imageSprite end
  WorldGhosts.ensure()
  local mapped = S.ghostForms and S.ghostForms[g.species]
  if mapped then return mapped end
  local sp = Get and Get("Ghost", g.species)
  if sp and sp.imageSprite and sp.imageSprite ~= "" then return sp.imageSprite end
  return nil
end

-- Swap the whole picture. Does not stack parts.
function WorldGhosts.restyle(g)
  if not g then return nil end
  local cur = WorldGhosts.imageFor(g)
  local n = love.math.random(0, COUNT - 1)
  local id = WorldGhosts.imageId(n)
  if id == cur then id = WorldGhosts.imageId((n + 1) % COUNT) end
  g.imageSprite = id
  g.look, g.lookCode = nil, nil
  return id
end
