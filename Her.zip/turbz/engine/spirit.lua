-- Spirit meter. A slow inner reserve, separate from the ghosts you catch.
-- It regenerates, feeds a few tricks, and grows with adventuring and enchants.

Spirit = Spirit or {}

function Spirit.ensure()
  S.spirit = S.spirit or 8
  S.spiritMax = S.spiritMax or Spirit.max()
end

function Spirit.max()
  local adv = SkillLevel and SkillLevel("adventuring") or 1
  local soc = SkillLevel and SkillLevel("social") or 1
  local well = Armor and Armor.get and Armor.get("spirit_well") or 0
  return math.floor(36 + (adv - 1) * 0.28 + (soc - 1) * 0.08 + well * 0.6)
end

function Spirit.regen()
  local adv = SkillLevel and SkillLevel("adventuring") or 1
  local flow = Armor and Armor.get and Armor.get("spirit_flow") or 0
  return 0.12 + (adv - 1) * 0.004 + flow * 0.012
end

function Spirit.update(dt)
  if not S or S.battle then return end
  Spirit.ensure()
  S.spiritMax = Spirit.max()
  dt = dt or 0.016
  if (S.spirit or 0) < S.spiritMax then
    S.spirit = math.min(S.spiritMax, S.spirit + Spirit.regen() * dt)
  end
end

function Spirit.gain(n)
  Spirit.ensure()
  S.spiritMax = Spirit.max()
  S.spirit = math.min(S.spiritMax, (S.spirit or 0) + (n or 1))
end

function Spirit.spend(n)
  Spirit.ensure()
  n = n or 1
  if (S.spirit or 0) < n then return false end
  S.spirit = S.spirit - n
  return true
end

-- Spend spirit to point at the nearest resource and nudge stamina.
function Spirit.flare()
  if not Spirit.spend(8) then
    Say("NEED 8 SPIRIT")
    Play("bump")
    return false
  end
  local best, bd
  for _, node in ipairs((S.resourceNodes) or {}) do
    local d = math.abs(node.x - (S.px or 0)) + math.abs(node.y - (S.py or 0))
    if not bd or d < bd then best, bd = node, d end
  end
  if best then
    local dx, dy = best.x - (S.px or 0), best.y - (S.py or 0)
    local dir = math.abs(dx) > math.abs(dy) and (dx > 0 and "EAST" or "WEST") or (dy > 0 and "SOUTH" or "NORTH")
    Say("FLARE  " .. Upper(best.name or "NODE") .. " " .. dir)
  else
    Say("FLARE  THE WILD IS QUIET")
  end
  S.stamina = math.min(S.staminaMax or 100, (S.stamina or 0) + 6)
  Play("quest")
  return true
end
