-- Mycology Engine: Mushroom hunting, identification, species journal, and harvesting.
-- S.mushrooms = { journal = { [id] = { discovered = true, harvests = 1 } }, totalHarvested = 0 }

function EnsureMycology()
  S.mushrooms = S.mushrooms or {}
  S.mushrooms.journal = S.mushrooms.journal or {}
  S.mushrooms.totalHarvested = S.mushrooms.totalHarvested or 0
  return S.mushrooms
end

function MushroomList()
  local list = All("Mushroom")
  table.sort(list, function(a, b)
    if (a.order or 0) == (b.order or 0) then return a.id < b.id end
    return (a.order or 0) < (b.order or 0)
  end)
  return list
end

function IsMushroomDiscovered(id)
  local my = EnsureMycology()
  return my.journal[id] ~= nil and my.journal[id].discovered == true
end

function DiscoverMushroom(id)
  local m = Get("Mushroom", id)
  if not m then return false end
  local my = EnsureMycology()
  if not my.journal[id] then
    my.journal[id] = { discovered = true, harvests = 0 }
    AddMasteryXp("mycology", 35) -- Big discovery bonus
    Say("NEW SPECIES DISCOVERED: " .. Upper(m.name) .. "!")
    Play("quest")
    Fire("mushroom_discovered", { id = id, mushroom = m })
    return true
  end
  return false
end

function HarvestMushroom(id, silent)
  local m = Get("Mushroom", id)
  if not m then return 0 end
  local my = EnsureMycology()
  
  -- Record discovery if not yet logged
  local wasNew = DiscoverMushroom(id)
  
  -- Calculate yield with Mycology Mastery perk bonus
  local baseMin = m.yieldMin or 1
  local baseMax = m.yieldMax or 2
  local lvl = MasteryLevel("mycology")
  local bonus = (lvl >= 3) and 1 or 0 -- Keen Eye perk
  if lvl >= 7 then bonus = bonus + 1 end -- Fungal Bounty perk
  
  local count = math.random(baseMin, baseMax) + bonus
  GiveItem(m.item ~= "" and m.item or id, count)
  
  my.journal[id] = my.journal[id] or { discovered = true, harvests = 0 }
  my.journal[id].harvests = (my.journal[id].harvests or 0) + count
  my.totalHarvested = (my.totalHarvested or 0) + count
  
  -- Mastery XP
  local xp = (m.rarity == "legendary" and 35) or (m.rarity == "rare" and 25) or (m.rarity == "uncommon" and 18) or 12
  AddMasteryXp("mycology", xp)
  
  if not silent and not wasNew then
    Say("HARVESTED " .. Upper(m.name) .. " x" .. count .. "!")
    Play("hit")
  end
  
  Fire("mushroom_harvested", { id = id, count = count, mushroom = m })
  return count
end

-- Checks wild foraging roll on step
function CheckWildForage(x, y)
  if S.screen ~= "explore" then return end
  local reg = RegionAt(x, y)
  if not reg or not reg.id then return end

  -- Forage cooldown or roll
  S._forageCooldown = (S._forageCooldown or 0) - 1
  if S._forageCooldown > 0 then return end

  local mycoLvl = MasteryLevel("mycology")
  local baseChance = 3 + math.min(10, mycoLvl) -- increases with mycology mastery
  if math.random(1, 100) > baseChance then return end

  -- Find eligible mushrooms for this region
  local candidates = {}
  for _, m in ipairs(All("Mushroom")) do
    local valid = false
    if #m.biomes == 0 then
      valid = true
    else
      for _, b in ipairs(m.biomes) do
        if b == reg.id or b == "all" then valid = true break end
      end
    end
    if valid then table.insert(candidates, m) end
  end

  if #candidates == 0 then return end
  local pick = candidates[math.random(1, #candidates)]
  
  -- Harvest the wild find
  HarvestMushroom(pick.id, false)
  S._forageCooldown = math.random(25, 45) -- Reset step cooldown
end
