-- Modular ghost composition from assets/ghosts/ghost_spritesheet.png
-- Appearance is rolled once per ghost and stored as g.lookCode (string) so it persists.

GhostSprite = GhostSprite or {}

local SHEET = "assets/ghosts/ghost_spritesheet.png"
local BLOCK, FRAME = 128, 32

GhostSprite.ROW = { BODY = 0, MARKING = 1, EYES = 2, MOUTH = 3, HEAD = 4, ACCESSORY = 5, AURA = 6 }
GhostSprite.MAX = { BODY = 15, MARKING = 15, EYES = 15, MOUTH = 11, HEAD = 19, ACCESSORY = 19, AURA = 15 }
GhostSprite.ORDER = { "AURA", "BODY", "MARKING", "EYES", "MOUTH", "ACCESSORY", "HEAD" }
-- Tint slots: body tint on BODY + some heads; marking tint; aura tint
GhostSprite.BODY_TINT_HEADS = { [2] = true, [3] = true, [4] = true, [16] = true, [19] = true }
GhostSprite.GREY_ACC = { [8] = true, [9] = true }

local sheetImg
local quadCache = {}

function GhostSprite.ensureSheet()
  if sheetImg then return sheetImg end
  if not love.filesystem.getInfo(SHEET) then return nil end
  local ok, img = pcall(love.graphics.newImage, SHEET)
  if not ok or not img then return nil end
  img:setFilter("nearest", "nearest")
  sheetImg = img
  return sheetImg
end

function GhostSprite.quad(cat, index, direction, frame)
  direction = math.max(0, math.min(3, direction or 0))
  frame = math.max(0, math.min(3, frame or 0))
  index = math.max(0, math.min(GhostSprite.MAX[cat] or 15, index or 0))
  local key = table.concat({ cat, index, direction, frame }, ":")
  if quadCache[key] then return quadCache[key] end
  if not GhostSprite.ensureSheet() then return nil end
  local BX = index * BLOCK
  local BY = (GhostSprite.ROW[cat] or 0) * BLOCK
  local x = BX + frame * FRAME
  local y = BY + direction * FRAME
  local q = love.graphics.newQuad(x, y, FRAME, FRAME, sheetImg:getDimensions())
  quadCache[key] = q
  return q
end

-- Encode look as compact string: b,m,e,o,h,a,u,cB,cM,cA  (indices + 3 RGB packs)
function GhostSprite.encode(look)
  local function cpack(c)
    c = c or { 1, 1, 1 }
    return string.format("%02x%02x%02x",
      math.floor((c[1] or 1) * 255),
      math.floor((c[2] or 1) * 255),
      math.floor((c[3] or 1) * 255))
  end
  return table.concat({
    look.body or 0, look.marking or 0, look.eyes or 0, look.mouth or 0,
    look.head or 0, look.accessory or 0, look.aura or 0,
    cpack(look.bodyColor), cpack(look.markColor), cpack(look.auraColor),
  }, ",")
end

function GhostSprite.decode(code)
  if type(code) ~= "string" or code == "" then return nil end
  local p = {}
  for part in string.gmatch(code, "[^,]+") do p[#p + 1] = part end
  if #p < 10 then return nil end
  local function cunpack(s)
    local r = tonumber(s:sub(1, 2), 16) or 255
    local g = tonumber(s:sub(3, 4), 16) or 255
    local b = tonumber(s:sub(5, 6), 16) or 255
    return { r / 255, g / 255, b / 255 }
  end
  return {
    body = tonumber(p[1]) or 0,
    marking = tonumber(p[2]) or 0,
    eyes = tonumber(p[3]) or 0,
    mouth = tonumber(p[4]) or 0,
    head = tonumber(p[5]) or 0,
    accessory = tonumber(p[6]) or 0,
    aura = tonumber(p[7]) or 0,
    bodyColor = cunpack(p[8]),
    markColor = cunpack(p[9]),
    auraColor = cunpack(p[10]),
  }
end

local function typeColor(g)
  local types = GhostTypes and GhostTypes(g) or {}
  if #types == 0 then
    local sp = Get("Ghost", g and g.species)
    if sp and sp.type then types = { sp.type } end
  end
  local r, gg, b, n = 0.75, 0.8, 0.95, 0
  for _, tid in ipairs(types) do
    local t = Get("Type", tid)
    if t and t.color and ToColor then
      local col = ToColor(t.color)
      if col then r, gg, b, n = r + col[1], gg + col[2], b + col[3], n + 1 end
    end
  end
  if n > 0 then r, gg, b = r / (n + 1), gg / (n + 1), b / (n + 1) end
  return { r, gg, b }
end

function GhostSprite.roll(g)
  local seed = (g and g.gid) or love.math.random(1, 1e9)
  -- deterministic from gid string
  if type(seed) == "string" then
    local h = 0
    for i = 1, #seed do h = (h * 33 + seed:byte(i)) % 2147483647 end
    seed = h
  end
  local function rnd(max)
    seed = (seed * 1103515245 + 12345) % 2147483648
    return seed % (max + 1)
  end
  local function col()
    return { 0.35 + rnd(150) / 255, 0.35 + rnd(150) / 255, 0.35 + rnd(150) / 255 }
  end
  local base = typeColor(g)
  local look = {
    body = rnd(GhostSprite.MAX.BODY),
    marking = rnd(GhostSprite.MAX.MARKING),
    eyes = rnd(GhostSprite.MAX.EYES),
    mouth = rnd(GhostSprite.MAX.MOUTH),
    head = rnd(GhostSprite.MAX.HEAD),
    accessory = rnd(GhostSprite.MAX.ACCESSORY),
    aura = rnd(GhostSprite.MAX.AURA),
    bodyColor = { base[1] * (0.7 + rnd(50) / 100), base[2] * (0.7 + rnd(50) / 100), base[3] * (0.7 + rnd(50) / 100) },
    markColor = col(),
    auraColor = col(),
  }
  return look, GhostSprite.encode(look)
end

function GhostSprite.ensure(g)
  if not g then return nil end
  if g.lookCode then
    g.look = GhostSprite.decode(g.lookCode) or g.look
  end
  if not g.look then
    local look, code = GhostSprite.roll(g)
    g.look = look
    g.lookCode = code
  end
  return g.look
end

function GhostSprite.draw(g, cx, cy, scale, direction, frame)
  local look = GhostSprite.ensure(g)
  if not look or not GhostSprite.ensureSheet() then return false end
  scale = scale or 1
  direction = direction or 0
  frame = frame or 0
  -- bob already in sheet frames; slight float
  local bob = math.sin(((S and S.t) or 0) / 16) * 1.2 * scale
  local px = math.floor(cx - 16 * scale)
  local py = math.floor(cy - 28 * scale + bob)
  love.graphics.setColor(1, 1, 1, 0.88)
  for _, cat in ipairs(GhostSprite.ORDER) do
    local idx = look[string.lower(cat)] or look[cat:lower()] or 0
    -- map keys
    local key = cat == "BODY" and "body" or cat == "MARKING" and "marking"
      or cat == "EYES" and "eyes" or cat == "MOUTH" and "mouth"
      or cat == "HEAD" and "head" or cat == "ACCESSORY" and "accessory"
      or cat == "AURA" and "aura" or string.lower(cat)
    idx = look[key] or 0
    local q = GhostSprite.quad(cat, idx, direction, frame)
    if q then
      if cat == "BODY" or (cat == "HEAD" and GhostSprite.BODY_TINT_HEADS[idx]) then
        local c = look.bodyColor or { 1, 1, 1 }
        love.graphics.setColor(c[1], c[2], c[3], 0.9)
      elseif cat == "MARKING" or (cat == "ACCESSORY" and GhostSprite.GREY_ACC[idx]) or (cat == "EYES" and idx == 12) then
        local c = look.markColor or { 1, 1, 1 }
        love.graphics.setColor(c[1], c[2], c[3], 0.9)
      elseif cat == "AURA" then
        local c = look.auraColor or { 1, 1, 1 }
        love.graphics.setColor(c[1], c[2], c[3], 0.75)
      else
        love.graphics.setColor(1, 1, 1, 0.92)
      end
      love.graphics.draw(sheetImg, q, px, py, 0, scale, scale)
    end
  end
  love.graphics.setColor(1, 1, 1, 1)
  return true
end
