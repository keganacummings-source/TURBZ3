## Latest update: UI, context menus, NPCs, companions and world filler
See `UI_CONTEXT_WORLD_UPDATE.md` for changes, controls, and verification limits.

# TURBO ENGINE 1.0 — Turbz

A moddable LÖVE2D game engine. **Every piece of the game is its own small file.** The engine reads them all when the game starts.
Files are written in **Turbo Script** (`.kyo`). It's plain Lua underneath, with simple ready-made words on top, so Notepad++ can colour it and you can learn it quickly.

---

## 1. Run the game

1. Install **LÖVE 11.4 or newer**: https://love2d.org
2. **Windows:** drag the `TurboEngine` folder onto `love.exe`
   **or** in a terminal: `"C:\Program Files\LOVE\love.exe" path\to\TurboEngine`
   **Mac/Linux:** `love path/to/TurboEngine`
3. To share it as one file, zip everything **inside** the folder (so `main.lua` is at the top of the zip), then rename `.zip` to `.love`.

## 2. Set up Notepad++ (one time)

1. Notepad++ → **Language → User Defined Language → Define your language… → Import…**
   Pick `notepad++/KyoScript_UDL.xml` and restart Notepad++. Every `.kyo` file is now colour coded.
2. For auto-complete (it shows hints as you type), copy `notepad++/KyoScript.xml` into
   `C:\Program Files\Notepad++\autoCompletion\`, then turn it on in **Settings → Preferences → Auto-Completion**.

## 3. The folder

```
TurboEngine/
  main.lua  conf.lua        boots the engine (you rarely touch these)
  engine/                   the engine itself (Lua). This is where engine updates go.
  game/                     ALL the game content. One thing per file.
    terms/                  the words of Turbo Script (Attack, Ghost, Map...) - loaded first
    settings.kyo            big switches (which map, party size, spawn rates...)
    colors.kyo words.kyo keys.kyo
    types/                  normal fire water earth air electric ice void light spirit (strong/weak/immune)
    attacks/<type>/         38 attacks
    ghosts/<type>/          23 ghosts
    effects/                burn, soak, root, sleep, leech, spark, gloom, shell, none
    rarities/               Awake, Faded, Weeping, Sleeping, Eclipse, Kyo-Touched (auto recolours)
    rules/                  the maths: damage, hp, fleeing, stat rolls, levels, ghost colours
    maps/<map>/             one folder per map: the map, regions/, portals/, addons/ (expansions)
    items/  enemies/        bag items (heal, catch, flee, kyo...) and Skeleton enemies
    quests/  goals/         quests (goals + pick-one rewards) and the goal kinds they use
    bosses/ stores/ traders/  4x bosses, shops that restock, ghost traders
    tiles/                  wall, floor, road, grass_tuft, bone, pool
    sprites/                every pixel picture (ghosts, Kyo, the quarry flag)
    player/  sounds/  screens/
  mods/                     your mods. Each folder inside is one mod.
    _example_mod/           OFF (starts with _). Rename to example_mod to switch on.
  assets/                   fonts (and any sounds/images you add)
  notepad++/                syntax colours + auto complete for Notepad++
  KYOSCRIPT_GUIDE.md        every word of the language
```

## 4. How loading works

* On boot the engine loads **every `.kyo` / `.lua` file** in `game/`, then every folder in `mods/` (A → Z).
* Inside any folder: the `terms/` folder loads first, then the files (A → Z), then the other folders (A → Z).
* Anything whose name starts with `_` or `.` is **skipped**. Use this to switch a file or a mod off.
* If two files use the same name (`Ghost "nobi"`), **the last one loaded wins**. That's how mods replace things.
* Mods can also go in the LÖVE save folder: `%APPDATA%\LOVE\kyoengine\mods\` (Windows), `~/.local/share/love/kyoengine/mods/` (Linux).

## 5. While you mod

| Key | What it does |
|-----|--------------|
| **F5** | Reload every file **without closing the game**. Edit in Notepad++, save, press F5. |
| **F1** | Show the file problems list again |
| Enter | Close the problems list |

Mistakes don't crash the game. They show up in a list, for example
`game/attacks/fire/ember.kyo: Attack "ember": unknown field "powr" - did you mean "power"?`
The list is also saved to `kyo_errors.txt` in the save folder.

## 6. Game controls

Enter on the title → main menu · Esc pause menu · Arrows/WASD move (hold to walk) · **B** bag in battle · **R** rename · **G** Ghostbook (party · pedia · box · rarity) · **F** AFK · **N** new quarry · **M** sound · **O** save · **1-4** attack · Enter confirm · Tab switches book tab · Q/E change page · Esc quit
(Change any of these in `game/keys.kyo`.)

## 7. Updating the engine

* New content or features: put them in a mod or in `game/`. Use `NewTerm` to add new kinds of things and `System` to add new features (see the guide).
* Engine code updates: replace files in `engine/`. Your `game/` and `mods/` folders stay the same.
* The engine version is shown in the window title (`Engine.version` in `engine/core.lua`).

Font: Press Start 2P (SIL Open Font License, see `assets/fonts/OFL.txt`).

## What's new in this update (Turbz / Turbo Engine)

- **Game renamed to Turbz**, engine shown as **Turbo Engine** (the `.kyo` format and in-game `KYO` currency are unchanged).
- **Richer term fields** (all optional, old files keep working):
  - Ghost: `about`, `lore`, `catchRate`, `evolvesTo` + `evolveLevel` (species evolution), `onCaught(ghost, result)`.
  - Attack: `cooldown` (turns before reuse, no PP), `sound` (played on hit).
  - Item: `sellable` (on/off), `icon` (a Sprite id).
- **Holy State**: every ghost at level 300 gains a halo and doubles in size (same species) — engine-wide.
- **MODS screen** (main menu): list `mods/` folders with ON/OFF + info from an optional `mod.kyo`; ENTER toggles, `R` / REFRESH rescans + reloads, choices are saved to `kyo_mods.lua`.
- **World Atlas** (press `M` from exploration): pan with WASD/arrows or mouse-drag, zoom with the wheel or `+`/`-`, inspect land and landmarks with the mouse, press Enter to focus a selected area. Selecting map locations never teleports the character.
- **Fullscreen** (`F11`) and free window resizing (the 320x320 view scales to fit any aspect ratio).
- **First Content Pack** (`mods/content_pack_1/`): its regions now appear as parts of the global `giant_world` atlas instead of separate portal-linked maps.
- **Legacy DreamShare/MMO integration retired**: the account gate, cloud-save calls, shared MMO heartbeat, and PvP screen are no longer loaded. Current play is offline-first with optional peer-hosted sessions; see `MULTIPLAYER_REWORK.md`.


## Turbo Engine V2 update
- Resizable, larger default window with VSync enabled.
- Smoother capped fixed-step simulation and reduced catch-up spikes.
- Zoom controls: mouse wheel, `+` / `-`, and `0` to reset.
- Cosmetic weather particles (`S.weather = "rain"`, `"snow"`, `"embers"`, `"fog"`, or `"clear"`).
- `F3` toggles the FPS overlay.
- New `TextFit`, `TextCenter`, and `Panel` layout helpers for game screens and mods.


## Giant seamless world update

The default map is now `giant_world`, a single shared coordinate space containing the former Overworld, Zomnia, Verdant Hollow, Tide Reach, Ashen Wastes, Frost Marches, Void Expanse, and a crypt landmass. Former map portals are no longer drawn or triggered during exploration. Organic biome edges replace most rectangular borders, local paths form land connections, and seven marked bridges join long-distance landmasses. The map is an atlas, not a fast-travel menu: Enter focuses an area, but the character only moves through the world by walking. Legacy saves that point to a separate map are migrated to the global world's spawn.


## Atlas navigation, Crownfall, and companions

- Press **M** while exploring to open the World Atlas. **WASD / arrow keys** pan at zoomed-in scales; at the full-world overview they move the selected region so navigation never appears stuck. Use the **mouse wheel** to zoom around the pointer, **left-drag** to pan, and **click** a region or landmark for details. Press **Enter** to focus the selected region or landmark, **P** to center the map on the player, **F** to fit the full world, and **Esc** to return. None of these atlas actions teleports the character.
- Atlas symbols: **C** capital, **T** resident/town, **R** resource zone, **!** boss, **Q** quest contact, **S** shrine, and **$** shop/trader. Select a resource zone to see the mushroom/materials listed for that biome; harvesting is a later feature.
- The lower-left six-region district is **Crownfall Citadel**, a reclaimed, damaged castle city. Its residents have ambient nervous markers when the player approaches. Five common residents provide local remarks; Captain Vey, Scribe Orien, and Caretaker Miret discuss the spirit surge. Agree or disagree with a custom character to affect their opinion. Talk to them again; someone who likes you can be asked to **Follow Me**. Up to three human companions follow the party trail and occasionally display passive travel remarks.

## Latest world/combat update

See `CHANGELOG_WORLD_COMBAT.md`, `WORLD_COMBAT_QA.md`, and `ASSET_CREDITS_AND_WORLD_UPDATE.md` for the large-world coastline, Crownfall respawn, atlas fast travel, multitype enemy logic, tactical move rewrites, and art-source notes.


## Current multiplayer design: Offline First + Peer-Hosted Sessions

The old DreamShare account/MMO/cloud-save path and its bundled worker deployment files are removed from this release. Single-player **Continue** and **New Game** remain local and continue using the legacy single-player save file. Use **Main Menu → Host / Join Game** for multiplayer.

- **Host New World** creates a new private world session; **Host Saved World** reopens the saved host world.
- **Join With Host Code** accepts `ADDRESS:PORT:WORLD:PIN`. Share the exact code shown by the host. Up to three guests can join the host (four players total).
- Player positions and session chat are sent directly with non-blocking UDP using LÖVE's bundled LuaSocket. There is no Cloudflare polling in this path.
- Character saves and ghost files are isolated under `multiplayer/<world-id>/players/<player-id>/`. The original single-player save and ghost files remain separate. Rejoining the same world ID loads that player's multiplayer character.
- For two computers on the **same Wi-Fi**, use the host's LAN code. For a friend over the internet, the host must enter their public IPv4 address and forward **UDP port 27644** to their computer in the router/firewall. If the ISP uses CGNAT or blocks inbound traffic, use a private VPN network such as Tailscale/ZeroTier and share that VPN address instead; a host code alone cannot bypass a router/NAT without either direct inbound access or a relay. Multiplayer progress is saved locally before disconnecting, and quitting from the title/main menu will not route an old multiplayer character into the single-player save.

**Current multiplayer scope:** the lobby, player presence/position, and session chat are synchronized. Combat, wild encounters, quest completion, inventory, and NPC state are still simulated and saved independently per player; they are not yet host-authoritative co-op systems. The network protocol is a direct prototype and does not encrypt packets, so only share host codes with people you trust.
