# TURBZ — UI, Context Menus, NPCs, Companions & World Update

## UI and interaction reliability
- Rebuilt the character interaction panel as a centred, responsive context menu with a visible selection highlight, larger click targets, wrapped dialogue, and safe dialogue scrolling. Keyboard, mouse, and wheel inputs are handled by the same selection state so the highlighted action matches the action activated.
- Ordinary residents now provide an action menu rather than a one-line conversation dead end. Available options include talk, ask for work, check task, follow me, part ways, and leave, depending on relationship/quest state.
- Rebuilt the pause/options, quest list, bank, and resource-zone screens with constrained panels, visible viewports, and keyboard/mouse-wheel scrolling. Chat history also scrolls when the command input is empty.
- Added viewport/scroll handling to long lists including party, chat, trade, bag, online, alembic, mycology, and other inventory/catalog screens. Wheel routing calls screen-specific handlers first, retaining each screen's own selection behavior.
- Fixed legacy 320px UI text measuring against the whole widescreen canvas: text fitting in those screens now uses the intended logical panel width, preventing labels from spilling off-screen. Older panels are centered and pointer coordinates are mapped back to the same logical region.
- Rendering uses nearest-neighbour filtering for pixel fonts/art and prefers integer canvas scaling where the display dimensions allow it. Exact one-pixel crispness at every arbitrary display resolution cannot be guaranteed when integer scaling is impossible, but the game avoids unnecessary smoothing.

## Talkable NPCs and companion system
- Added 112 unique residents with distinct names, dialogue lines, roles, coordinates, palette sprites, and companion perk types. All 112 sprite IDs have a matching project sprite definition and all 112 residents have unique coordinates/IDs.
- Roughly 60% are configured to offer a personal task when first encountered; the individual offer is stored in the player's NPC quest state. Quest types can require travelling, catching a ghost, defeating an enemy/boss, or harvesting mushrooms.
- Finishing a personal task awards Kyo, raises the resident's trust, and unlocks recruitment. Positive reactions can also build trust. Merely opening a conversation does not automatically recruit the NPC.
- Companion recruitment and dismissal now expose the FOLLOW ME / PART WAYS options. Up to three companions may follow. Recruit IDs, quest progress, reactions, and positions are included in save state.
- Companion perks are wired into gameplay: bonus XP, increased attack damage, reduced incoming damage, or bonus Kyo. Combined active bonuses are capped to avoid runaway stacking.

## World filling and exploration
- Retained the large overworld and added 20 named lore landmarks spanning ruins, forests, lakes, mountain paths, watch posts, and resting sites.
- Added deterministic, seed-based placement for up to 12 additional small named points of interest. These are kept clear of existing placed characters/landmarks and the starting area, and remain stable for a given world seed.
- World terrain adds four lake coves with walkable shores, winding forest stands with trails, ruined homesteads/courtyards, and three bands of mountain cliffs with shifting narrow switchback gaps. Placed NPCs and start tiles are protected from terrain painting.
- Wild ghost/enemy spawning rejects spawn candidates that are visible in the current camera view. Off-screen wild ghosts retain their world position and are allowed to persist for up to 120 seconds after leaving view before despawn logic removes them.

## Sprite fallback and CC0 sourcing
- Added a project-local ghoul fallback sprite and missing-sprite validation fallbacks so missing art no longer prevents the species from spawning. New townfolk use project-authored pixel sprites and distinct palettes.
- QA found 284 PNGs under `assets/ghosts/`; all 189 unique `imageSprite` names used by 249 source references resolve to bundled PNGs. The fallback covers definitions that do not provide a valid sprite reference.
- Relevant OpenGameArt CC0 references were identified, including [NPC and Enemies](https://opengameart.org/content/npc-and-enemies-0) (Refo), [Ghost Sprite](https://opengameart.org/content/ghost-sprite) (ChiliGames), and the [CC0 Resources collection](https://opengameart.org/content/cc0-resources). Their external image binaries were not added to this archive because the build environment could not fetch them. This build does not claim to contain newly imported PNGs from those pages; review the original licenses and keep attribution when importing them in a future pass.

## Verification and limitations
- Static parser check: 459 Lua/Kyo files checked, 0 syntax failures.
- Sprite reference check: 249 `imageSprite` references / 189 unique names, 0 missing PNGs; 284 ghost PNGs bundled.
- Static NPC roster check: 112 unique resident IDs, 112 unique positions, and 112 matching sprite definitions.
- Archive integrity is checked before handoff.
- No LÖVE runtime was installed in the build environment. Full graphical testing of dialogue/click placement, fullscreen rendering, terrain walkability, companion AI, and encounter balance still needs to be performed in the game.
