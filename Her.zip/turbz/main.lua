-- TURBO ENGINE - boots the engine. All game content lives in game/ and mods/
require("engine.core")

function love.load() Engine.boot() end
function love.update(dt) Engine.update(dt) end
function love.draw() Engine.draw() end
function love.keypressed(key) Engine.key(key) end
function love.textinput(t) Engine.text(t) end
function love.mousepressed(x, y, button) Engine.click(x, y, button) end
function love.mousereleased(x, y, button) if Engine.releaseMouse then Engine.releaseMouse(x, y, button) end end
function love.mousemoved(x, y, dx, dy) if Engine.moveMouse then Engine.moveMouse(x, y, dx, dy) end end
function love.wheelmoved(x, y) Engine.wheel(y) end
function love.resize(w, h) Engine.resize() end
function love.quit()
  -- Never autosave from the title/main menu: menu entry intentionally clears the
  -- multiplayer session marker, and saving there could route stale MP state to SP.
  local screen = S and S.screen or "title"
  local safeToSave = screen ~= "title" and screen ~= "menu" and screen ~= "multiplayer" and screen ~= "login"
  if Settings.saveOnQuit and safeToSave then Engine.safe(SaveGame) end
  if SessionNet then SessionNet.shutdown() end
end
