# Multiplayer QA / Release Checklist

## Static checks completed in this package

- Compiled every Lua and Kyo file with the available Lua parser: 458 files, zero syntax failures.
- Ran a mocked `SessionNet` smoke check covering new-host setup, saved host-profile creation, host-code formatting, joining a parsed code, and rejection of malformed codes.
- Reviewed save path selection: no `sessionMode` uses the original `Settings.saveFile`; multiplayer mode selects `multiplayer/<world-id>/players/<player-id>/save.lua`; ghost seed files follow the same active save root.
- Removed the old Cloudflare worker and legacy online/HTTP client files from this release. `engine/core.lua` loads `engine.session_net`; `game/online.kyo` runs only the optional peer-session tick and drawing hooks.

## Must still be tested with LÖVE 11.4 on real machines

1. Open Host New World; verify a LAN code appears and host lobby stays responsive.
2. Open a second game on the same Wi-Fi; join using the code; verify the host roster becomes 2/4 and both players are visible in the same map.
3. Add two more guests; confirm the fifth player (host + four guests) is rejected and the host shows a full-lobby response.
4. Start the world; move each player and verify snapshots are visible at the other clients. Send chat each direction.
5. Save host and guest characters, quit, use Host Saved World with the same code/world ID, reconnect, and verify each player gets their prior separate character/ghost files.
6. Start single-player and verify it loads only `kyozzz2_save.lua` and `ghosts/`, with no multiplayer character appearing in the single-player party.
7. Test across separate internet connections only after forwarding UDP port 27644 or connecting both PCs through a private VPN overlay.

## Scope / limitations

This build synchronizes the lobby, presence/positions, and session chat. Battles, NPC state, quest progress, inventory and rewards remain client-local. UDP is not encrypted and the host code should only be shared with trusted players. The environment used for this build had no LÖVE runtime and cannot verify Windows firewall/router behavior or real cross-country connectivity.


Historical docs elsewhere in the project may mention cloud save/load from earlier builds; those endpoints are not part of this release and are not used by the running game.
