# TURBZ Final Update — Skills, Shrooms, World Overhaul

## Skills (persist across deaths, max 400)
- New long-term skills: Mining, Woodcutting, Hunting, Catching, Trading, Fishing, Social, Shroom
- XP curves scale similarly to ghost levels; skills are **kept between deaths**
- Bonuses:
  - **Fishing**: catch speed; chance to hook higher-rarity / lower-level ghosts at resource shores
  - **Mining / Woodcutting / Hunting / resource skills**: more yield + XP this life
  - **Catching**: flat catch-chance bonus
  - **Trading**: shops cheaper, sell value higher (feeds black market pricing)
  - **Social**: +1 party slot every 40 levels (up to +10 at 400)
  - **Shroom**: discovery chance + yield; purity quality finds

## Resource zones
- Zones are interactive: **Harvest** button / H / Enter
- Harvest grants skill XP tied to biome and shroom strains
- Fishing biomes can hook exotic low-level high-rarity ghosts

## Mushrooms (50 unique types)
- Full catalog in `game/mushrooms/_catalog_50.kyo`
- **10-stage purity / strain system** (Raw → Mythic) with distinct animated filter ids:
  none, mist, dust, amber, smoke, glow, prism, ripple, halo, voidfire
- Each stage is a unique strain variant (not a rarity tier)

## Shroom Market (stock-market style)
- Independent price per mushroom species
- Refreshes every **30 minutes** with small % drifts (occasional larger swings)
- Chat announcement: `*** SHROOM MARKET: NEW PRICES POSTED ***`
- Integrated as **SHROOMS** tab on the Black Market

## Black Market / Ghosts
- Ghost listings are high-level **exotics** with **unique move sets**
- Full rarity + multi-type rolls allowed on stock
- Shroom tab listed above

## Death rules
- On wipe: lose pocket KYO, bag, and **all ghosts not in the bank**
- Skills + bank vault remain
- Receive a **new random starter** at a % of trainer level that can roll rarity and multi-type (lucky fresh spawns)

## Companions
- Following companions are **clickable on-screen** and reachable via Talk without standing on their tile

## NPC placement
- Traveller roster reclustered into **Crownfall castle** and major **city hubs** so most residents live in settlements rather than the open wilds

## Files of note
- `engine/skills.lua`, `engine/shroom_market.lua`
- `game/mastery/skills_expanded.kyo`
- `game/mushrooms/_catalog_50.kyo`
- `game/screens/market.kyo`, `game/screens/resource_zone.kyo`
- patches to `engine/core.lua`, `engine/bank.lua`, `engine/battle.lua`, `engine/ghosts.lua`, `engine/loop.lua`, `engine/save.lua`, `game/screens/explore.kyo`, `game/world_expansion/setup.kyo`, `game/world_expansion/townfolk_roster.kyo`
