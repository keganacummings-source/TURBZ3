function love.conf(t)
  t.identity = "kyoengine"
  t.version = "11.4"
  t.window.title = "TURBZ - Turbo Engine"
  t.window.width = 1600
  t.window.height = 900
  t.window.resizable = true
  t.window.vsync = 1
  t.window.msaa = 0
  t.window.minwidth = 640
  t.window.minheight = 360
  t.window.fullscreen = false
  t.window.fullscreentype = "desktop"
  t.window.highdpi = false
  t.window.usedpiscale = false
end
