#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
OUT="${1:-$ROOT/dist/TURBZ.love}"
mkdir -p "$(dirname "$OUT")"
python3 - "$ROOT" "$OUT" <<'PY'
import os, sys, zipfile
root, out = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as archive:
    for current, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in ("dist", ".git", "__pycache__")]
        for filename in files:
            if filename.endswith((".love", ".pyc")):
                continue
            if filename in {
                "character_spritesheet.png",
                "character_spritesheet_v5_witch.png",
                "character_spritesheet_v5b_witch.png",
                "armor_v2_spritesheet.png",
            }:
                continue
            path = os.path.join(current, filename)
            rel = os.path.relpath(path, root)
            if rel == "main.lua" or rel == "conf.lua" or rel == "ATTRIBUTION.txt" or rel.startswith(("engine/", "game/", "assets/")):
                archive.write(path, rel)
print("Built", out)
PY
