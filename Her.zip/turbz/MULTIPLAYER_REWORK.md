# Multiplayer Rework — Offline First

## What changed

- Removed the old DreamShare-account boot requirement and bundled Cloudflare worker/client files from this release. No login, global MMO heartbeat, or cloud save/load is needed.
- Added Main Menu → **Host / Join Game** with New World, Saved Host World, Join by Host Code, a lobby roster, clipboard copy, and start/cancel controls.
- A host accepts up to three guests. The game sends non-blocking UDP snapshots; clients can see remote players and exchange lobby/session chat.
- Each session has a world ID and private pin. Character and ghost saves live in `multiplayer/<world-id>/players/<player-id>/`; single-player continues using `kyozzz2_save.lua` and the existing `ghosts/` directory.
- Host World ID/pin/port are kept in `multiplayer/host_world.json`; a local player ID is kept in `multiplayer/local_player_id.txt`. Host Saved World uses that ID so rejoining the same room loads existing saves.
- The legacy Players screen now shows the active peer session, and the old chat console no longer calls cloud APIs.

## Connection steps

1. Both players run the game with LÖVE 11.4 or newer.
2. Host selects **Host New World** (or **Host Saved World**), then sends the code displayed in the lobby.
3. Same Wi-Fi: share the LAN address in the code. Across the internet: the host enters their public IPv4 in the lobby field and forwards UDP port **27644** from their router to the host PC. Allow the game through the OS firewall.
4. The friend selects **Join With Host Code**, pastes the full code, and joins the lobby. The host presses **Start Game**.
5. Use the in-game **TAB → CHAT** console to send session messages.

If direct inbound hosting is blocked by carrier-grade NAT, share a VPN-overlay IP (such as Tailscale or ZeroTier) instead. Without direct inbound routing or a relay, a short code cannot magically establish a connection between two private home networks.

## Known limitations

This is a functional direct-host lobby/presence foundation, not complete co-op simulation yet. Positions and chat are synced; combat, random encounters, quest flags, NPC state, inventory and rewards still run locally for each player. The protocol is not encrypted or designed to resist malicious packet injection, so use it only with trusted friends. Internet play has not been live-tested from separate networks in this build environment.
